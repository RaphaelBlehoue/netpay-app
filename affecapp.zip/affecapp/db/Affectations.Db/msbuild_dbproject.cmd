@REM Section DATABASE
@REM Note - Ensure that the path to MSBuild.exe has been added to Path variable under Environment Variables. Follow link below for more details:
@REM https://stackoverflow.com/questions/6319274/how-do-i-run-msbuild-from-the-command-line-using-windows-sdk-7-1/
MSBuild.exe ./Affectations.Db.sln /p:Configuration=Release /p:Platform="Any CPU"