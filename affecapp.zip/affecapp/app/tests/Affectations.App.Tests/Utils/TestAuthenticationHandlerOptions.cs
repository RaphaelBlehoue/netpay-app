using Microsoft.AspNetCore.Authentication;

namespace Affectations.App.Tests.Utils;

public class TestAuthenticationHandlerOptions : AuthenticationSchemeOptions
{
    public string UserRole { get; set; } = null!;
}
