using Affectations.App.Tests.Utils;
using Affectations.Infrastructure.Data.Models;
using Affectations.Infrastructure.Stores;
using BoDi;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Options;
using Moq;

namespace Affectations.App.Tests.Hooks;

[Binding]
public static class InitWebApplicationFactory
{
    internal const string HttpResponseKey = nameof(HttpResponseKey);
    internal const string ApiResponseKey = nameof(ApiResponseKey);
    internal const string HttpClientKey = nameof(HttpClientKey);
    internal const string AuthenticationConfigKey = nameof(AuthenticationConfigKey);

    [BeforeScenario(Order = 1000)]
    public static void BeforeScenario(ScenarioContext scenarioContext, IObjectContainer objectContainer)
    {
        scenarioContext.TryGetValue("WebHostBuilderActions", out List<Action<IWebHostBuilder>> webHostBuilderActions);

        scenarioContext[HttpResponseKey] = null;
        scenarioContext[ApiResponseKey] = null;

        var application = new WebApplicationFactory<Program>().WithWebHostBuilder(builder =>
        {
            if (webHostBuilderActions != null)
            {
                foreach (var webHostBuilderAction in webHostBuilderActions)
                {
                    webHostBuilderAction(builder);
                }
            }

            builder.ConfigureTestServices(services =>
            {
                services
                    .AddAuthentication(TestAuthenticationHandler.AuthenticationScheme)
                    .AddScheme<TestAuthenticationHandlerOptions, TestAuthenticationHandler>(
                        TestAuthenticationHandler.AuthenticationScheme,
                        options => { }
                    );
                var ruleStore = new Mock<IRulesStore>();
                scenarioContext["RuleStore"] = ruleStore;

                var handlerMock = new Mock<HttpMessageHandler>();
                scenarioContext["HttpHandlerMock"] = handlerMock;
                services.MockDbContext(objectContainer);
                MockService(services, handlerMock);
                MockService(services, ruleStore);
            });
            builder.UseEnvironment("Testing");
        });

        var client = application.CreateClient();

        scenarioContext.TryAdd(
            AuthenticationConfigKey,
            application.Services.GetService<IOptionsMonitor<TestAuthenticationHandlerOptions>>()!.CurrentValue
        );
        scenarioContext.TryAdd(HttpClientKey, client);
    }

    private static void MockDbContext(this IServiceCollection services, IObjectContainer objectContainer)
    {
        var dbContextRegistration = services.FirstOrDefault(d =>
            d.ServiceType == typeof(DbContextOptions<AffectationsContext>)
        );
        if (dbContextRegistration != null)
        {
            services.Remove(dbContextRegistration);
        }

        var connection = new SqliteConnection("Filename=:memory:");
        connection.Open();
        var options = new DbContextOptionsBuilder<AffectationsContext>().UseSqlite(connection).Options;
        var context = new AffectationsContext(options);
        services.AddDbContext<AffectationsContext>(o => o.UseSqlite(connection));
        context.Database.EnsureCreated();
        objectContainer.RegisterInstanceAs(context);
    }

    /// <summary>
    /// Replace a given service with a mocked one in the Ioc container.
    /// </summary>
    /// <typeparam name="TService"></typeparam>
    /// <param name="services"></param>
    /// <param name="mockedService"></param>
    public static void MockService<TService>(IServiceCollection services, Mock<TService> mockedService)
        where TService : class
    {
        var service = services.Where(s => s.ServiceType == typeof(TService)).FirstOrDefault();

        if (service is not null)
        {
            services.RemoveAll<TService>();
        }

        switch (service?.Lifetime)
        {
            case ServiceLifetime.Transient:
                services.AddTransient<TService>(provider => mockedService.Object);
                break;
            case ServiceLifetime.Singleton:
                services.AddSingleton<TService>(service => mockedService.Object);
                break;
            case ServiceLifetime.Scoped:
                services.AddScoped<TService>(service => mockedService.Object);
                break;
            default:
                services.AddScoped<TService>(service => mockedService.Object);
                break;
        }
    }
}
