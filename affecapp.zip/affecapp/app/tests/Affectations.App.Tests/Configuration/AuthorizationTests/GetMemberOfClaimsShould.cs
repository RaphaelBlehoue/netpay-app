﻿using System.Security.Claims;
using System.Security.Principal;
using Affectations.App.Configuration.Authorization;

namespace Affectations.App.Tests.Configuration.AuthorizationTests;

public class GetMemberOfClaimsShould
{
    [Fact]
    public void ReturnEmptyArrayWhenIdentityIsNull()
    {
        IIdentity? identity = null;

        var result = identity.GetMemberOfClaims();

        Assert.Empty(result);
    }

    [Fact]
    public void ReturnEmptyArrayWhenIdentityIsNotClaimsIdentity()
    {
        IIdentity identity = new GenericIdentity("name");

        var result = identity.GetMemberOfClaims();

        Assert.Empty(result);
    }

    public static IEnumerable<object[]> MemberOfClaims = new[]
    {
        [0, Array.Empty<Claim>()],
        [1, new[] { new Claim(IdentityExtensions.MemberOfClaimType, "group1") }],

        [
            2,
            new[]
            {
                new Claim(IdentityExtensions.MemberOfClaimType, "group1"),
                new Claim(IdentityExtensions.MemberOfClaimType, "group2")
            }
        ],

        [
            3,
            new[]
            {
                new Claim(IdentityExtensions.MemberOfClaimType, "group1"),
                new Claim(IdentityExtensions.MemberOfClaimType, "group2"),
                new Claim(IdentityExtensions.MemberOfClaimType, "group3")
            }
        ],

        [
            4,
            new[]
            {
                new Claim(IdentityExtensions.MemberOfClaimType, "group1"),
                new Claim(IdentityExtensions.MemberOfClaimType, "group2"),
                new Claim(IdentityExtensions.MemberOfClaimType, "group3"),
                new Claim(IdentityExtensions.MemberOfClaimType, "group4")
            }
        ],
        new object[]
        {
            5,
            new[]
            {
                new Claim(IdentityExtensions.MemberOfClaimType, "group1"),
                new Claim(IdentityExtensions.MemberOfClaimType, "group2"),
                new Claim(IdentityExtensions.MemberOfClaimType, "group3"),
                new Claim(IdentityExtensions.MemberOfClaimType, "group4"),
                new Claim(IdentityExtensions.MemberOfClaimType, "group5")
            }
        },
    };

    [Theory]
    [MemberData(nameof(MemberOfClaims))]
    public void ReturnMemberOfClaims(int count, Claim[] claims)
    {
        var identity = new ClaimsIdentity(claims);

        var result = identity.GetMemberOfClaims();

        Assert.Equal(count, result.Length);
        for (var i = 0; i < count; i++)
        {
            Assert.Equal($"group{i + 1}", result[i].Value);
        }
    }
}
