﻿using Affectations.App.Configuration.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Moq;

namespace Affectations.App.Tests.Configuration.AuthorizationTests;

public class GetRequiredAuthorizationConfigurationShould
{
    private const string DefaultKeyId = "DEFAULT-TEST-KEY";
    private const string DefaultClientId = nameof(DefaultClientId);
    private const string OneAccountKeyId = "OA-TEST-KEY";
    private const string OneAccountClientId = nameof(OneAccountClientId);

    private readonly IHostApplicationBuilder _builder;

    public GetRequiredAuthorizationConfigurationShould()
    {
        var configurationManager = new ConfigurationManager();
        IConfigurationBuilder configBuilder = new ConfigurationBuilder();
        configBuilder.AddInMemoryCollection(
            new Dictionary<string, string>
            {
                ["AuthorizationConfiguration:Authority"] = "https://maam-dev.axa.com/maam/v2",
                ["AuthorizationConfiguration:ClientId"] = DefaultClientId,
                ["AuthorizationConfiguration:CallbackPath"] = "/signin-oidc",
                ["AuthorizationConfiguration:RequestedScopes:0"] = "openid",
                ["AuthorizationConfiguration:RequestedScopes:1"] = "profile",
                ["AuthorizationConfiguration:RequestedScopes:2"] = "email",
                ["AuthorizationConfiguration:RequestedScopes:3"] = "urn:axa:france:affectations-app",
                ["AuthorizationConfiguration:RequestedScopes:4"] = "urn:axa:france:racf",
                ["AuthorizationConfiguration:RequestedScopes:5"] = "urn:axa:france:distribution",
                ["AuthorizationConfiguration:RequestedScopes:6"] = "urn:axa:france:wac",
                ["AuthorizationConfiguration:Jwk:alg"] = "RS256",
                ["AuthorizationConfiguration:Jwk:d"] =
                    "twfG0BWboPsH9KAscOSZ3VIGOr7ynME3QJVdn3SF8CMOOZvnWXXaNDAiH-UYWi6NXVYdJGC7ybCTlSbxYWs49Q",
                ["AuthorizationConfiguration:Jwk:dp"] = "4FbPI_1nv5bgCRlybaHwDC7rgsykS2cV2IpHz867p9k",
                ["AuthorizationConfiguration:Jwk:dq"] = "nR062SenOPAskG4kLCFsZVfXujLl45xa9Ks2ocmkv8c",
                ["AuthorizationConfiguration:Jwk:e"] = "AQAB",
                ["AuthorizationConfiguration:Jwk:kid"] = DefaultKeyId,
                ["AuthorizationConfiguration:Jwk:kty"] = "RSA",
                ["AuthorizationConfiguration:Jwk:n"] =
                    "xTjtUuHzQeVTq7OEaMbQhGIeuJbxbDf_XifEp9D7a0vMuTrBXfmCyXuh7O87kbl_HaD3O3ZzJl7zBD6tLHpeMQ",
                ["AuthorizationConfiguration:Jwk:p"] = "6CZZpqMwtE73ep0cJWZa5KeKGrYfC1DM45eNHPwVwec",
                ["AuthorizationConfiguration:Jwk:q"] = "2Xv4Aqb2iQupFBSX88nd5WMwRQJPL0EOXIcLXaL1DCc",
                ["AuthorizationConfiguration:Jwk:qi"] = "L2mX0VtyX6X7DHP-AJTaDGRLiyz-noCZzRdvFI9U2mk",
                ["AuthorizationConfiguration:Jwk:use"] = "sig",
                ["AuthorizationConfiguration:OneAccount:Authority"] = "https://onelogin.dev.axa.com",
                ["AuthorizationConfiguration:OneAccount:ClientId"] = OneAccountClientId,
                ["AuthorizationConfiguration:OneAccount:CallbackPath"] = "/signin-oidc",
                ["AuthorizationConfiguration:OneAccount:RequestedScopes:0"] = "openid",
                ["AuthorizationConfiguration:OneAccount:RequestedScopes:1"] = "profile",
                ["AuthorizationConfiguration:OneAccount:RequestedScopes:2"] = "email",
                ["AuthorizationConfiguration:OneAccount:RequestedScopes:3"] = "urn:axa:france:affectations-app",
                ["AuthorizationConfiguration:OneAccount:RequestedScopes:4"] = "urn:axa:france:racf",
                ["AuthorizationConfiguration:OneAccount:RequestedScopes:5"] = "urn:axa:france:distribution",
                ["AuthorizationConfiguration:OneAccount:RequestedScopes:6"] = "urn:axa:france:wac",
                ["AuthorizationConfiguration:OneAccount:Jwk:alg"] = "RS256",
                ["AuthorizationConfiguration:OneAccount:Jwk:d"] =
                    "twfG0BWboPsH9KAscOSZ3VIGOr7ynME3QJVdn3SF8CMOOZvnWXXaNDAiH-UYWi6NXVYdJGC7ybCTlSbxYWs49Q",
                ["AuthorizationConfiguration:OneAccount:Jwk:dp"] = "4FbPI_1nv5bgCRlybaHwDC7rgsykS2cV2IpHz867p9k",
                ["AuthorizationConfiguration:OneAccount:Jwk:dq"] = "nR062SenOPAskG4kLCFsZVfXujLl45xa9Ks2ocmkv8c",
                ["AuthorizationConfiguration:OneAccount:Jwk:e"] = "AQAB",
                ["AuthorizationConfiguration:OneAccount:Jwk:kid"] = OneAccountKeyId,
                ["AuthorizationConfiguration:OneAccount:Jwk:kty"] = "RSA",
                ["AuthorizationConfiguration:OneAccount:Jwk:n"] =
                    "xTjtUuHzQeVTq7OEaMbQhGIeuJbxbDf_XifEp9D7a0vMuTrBXfmCyXuh7O87kbl_HaD3O3ZzJl7zBD6tLHpeMQ",
                ["AuthorizationConfiguration:OneAccount:Jwk:p"] = "6CZZpqMwtE73ep0cJWZa5KeKGrYfC1DM45eNHPwVwec",
                ["AuthorizationConfiguration:OneAccount:Jwk:q"] = "2Xv4Aqb2iQupFBSX88nd5WMwRQJPL0EOXIcLXaL1DCc",
                ["AuthorizationConfiguration:OneAccount:Jwk:qi"] = "L2mX0VtyX6X7DHP-AJTaDGRLiyz-noCZzRdvFI9U2mk",
                ["AuthorizationConfiguration:OneAccount:Jwk:use"] = "sig"
            }!
        );

        configurationManager.AddConfiguration(configBuilder.Build());

        var builder = new Mock<IHostApplicationBuilder>();
        builder.SetupGet(b => b.Configuration).Returns(configurationManager);
        _builder = builder.Object;
    }

    [Fact]
    public void RetrieveTheCorrectConfiguration_WhenASpecificIdpIsRequested()
    {
        _builder.Configuration.AddInMemoryCollection(
            new Dictionary<string, string> { ["AuthorizationConfiguration:IdentityProviderToUse"] = "OneAccount" }!
        );

        var configuration = _builder.GetRequiredAuthorizationConfiguration();

        AssertCommonConfigIsValid(configuration);
        Assert.Equal(OneAccountClientId, configuration.ClientId);
        Assert.Equal(OneAccountKeyId, configuration.Jwk.Kid);
    }

    [Fact]
    public void RetrieveTheCorrectConfiguration_WhenNoSpecificIdpIsRequested()
    {
        var configuration = _builder.GetRequiredAuthorizationConfiguration();

        AssertCommonConfigIsValid(configuration);
        Assert.Equal(DefaultClientId, configuration.ClientId);
        Assert.Equal(DefaultKeyId, configuration.Jwk.Kid);
    }

    private static void AssertCommonConfigIsValid(AuthorizationConfiguration configuration)
    {
        Assert.Equal("/signin-oidc", configuration.CallbackPath);
        Assert.Contains("openid", configuration.RequestedScopes);
        Assert.Contains("profile", configuration.RequestedScopes);
        Assert.Contains("email", configuration.RequestedScopes);
        Assert.Contains("urn:axa:france:affectations-app", configuration.RequestedScopes);
        Assert.Contains("urn:axa:france:racf", configuration.RequestedScopes);
        Assert.Contains("urn:axa:france:distribution", configuration.RequestedScopes);
        Assert.Contains("urn:axa:france:wac", configuration.RequestedScopes);
    }
}
