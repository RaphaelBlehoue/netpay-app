using Affectations.App.Tests.Common;
using Affectations.Infrastructure.Repositories;

namespace Affectations.App.Tests.Repositories;

public class TeamRepository_GetTeamsAsyncShould
{
    private readonly TeamRepository _target;

    public TeamRepository_GetTeamsAsyncShould()
    {
        var context = InMemoryDatabase.CreateContextWithTeams();

        _target = new TeamRepository(context);
    }

    [Fact]
    public async Task ReturnsTeams_WhenFound()
    {
        var expected = TestDataHelper.GetTeams();

        var result = await _target.GetTeamsAsync();

        result.Should().BeEquivalentTo(expected);
    }

    [Fact]
    public async Task ReturnsEmptyList_WhenNoDataInDataBase()
    {
        var _teamRepo = new TeamRepository(InMemoryDatabase.CreateContextWithEmptyTeams());
        var result = await _teamRepo.GetTeamsAsync();
        Assert.Empty(result);
    }
}
