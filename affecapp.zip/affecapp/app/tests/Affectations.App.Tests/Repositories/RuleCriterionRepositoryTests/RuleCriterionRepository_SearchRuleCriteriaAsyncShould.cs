using Affectations.App.Tests.Common;
using Affectations.Infrastructure.Repositories;
using Affectations.Infrastructure.Specifications;

namespace Affectations.App.Tests.Repositories.RuleCriterionRepositoryTests;

public class RuleCriterionRepository_SearchRuleCriteriaAsyncShould
{
    private readonly string CategoryCode = "INTERMEDIARY_NAME";
    private readonly string LabelStartsWithFilter = "fra";

    private readonly RuleCriterionRepository _target;

    public RuleCriterionRepository_SearchRuleCriteriaAsyncShould()
    {
        var context = InMemoryDatabase.CreateContextWithIntermediaryNameTRuleCriterionCategory();

        _target = new RuleCriterionRepository(context);
    }

    [Fact]
    public async Task ReturnMatchedIntermediaries_WhenFound()
    {
        var expected = TestDataHelper
            .GetIntermediaryNameRuleCriteria()
            .Where(x => !string.IsNullOrEmpty(x.Label) && x.Label.StartsWith(LabelStartsWithFilter))
            .OrderBy(x => x.Label)
            .ToArray();

        var ruleCriterionLabelSearchSpecification = new RuleCriterionLabelSearchSpecification(
            CategoryCode,
            LabelStartsWithFilter
        )
        {
            PageNumber = 1,
            PageSize = 10,
        };

        var result = await _target.SearchRuleCriteriaAsync(ruleCriterionLabelSearchSpecification);

        result.Data.Should().BeEquivalentTo(expected);
    }
}
