using Affectations.App.Tests.Common;
using Affectations.Infrastructure.Repositories;

namespace Affectations.App.Tests.Repositories.RuleCriterionRepositoryTests;

public class RuleCriterionRepository_GetRuleCriteriaAsyncShould
{
    private readonly RuleCriterionRepository _target;

    public RuleCriterionRepository_GetRuleCriteriaAsyncShould()
    {
        var context = InMemoryDatabase.CreateContextWithRuleCriteria();

        _target = new RuleCriterionRepository(context);
    }

    [Fact]
    public async Task ReturnRuleCriteria_WhenFound()
    {
        var expected = TestDataHelper.GetRuleCriteriaCategories();

        var result = await _target.GetRuleCriteriaAsync(200);

        result.Should().BeEquivalentTo(expected);
    }
}
