using System.Net;
using Affectations.App.Tests.Common;
using Affectations.Domain.AggregatesRoots.RuleAggregate;
using Affectations.Domain.Exceptions;
using Affectations.Infrastructure.Mappers;
using Affectations.Infrastructure.Repositories;
using Affectations.Infrastructure.Stores;
using AutoMapper;
using Moq;

namespace Affectations.App.Tests.Repositories.RuleRepositoryTests;

public class RuleRepository_AddRuleAsyncShould
{
    private readonly Mock<IRulesStore> _rulesStore;
    private readonly RuleRepository _target;
    private readonly Rule _input;

    public RuleRepository_AddRuleAsyncShould()
    {
        _input = TestHelper.GetRuleInstance();
        _rulesStore = new Mock<IRulesStore>();
        _target = new RuleRepository(
            _rulesStore.Object,
            new MapperConfiguration(cfg => cfg.AddProfile<MapperProfiles>()).CreateMapper()
        );
    }

    [Fact]
    public async Task ReturnsBadRequest()
    {
        var expectedException = new RuleException(
            "Bad request",
            new ClientMRMApiException("Bad Request", (int)HttpStatusCode.BadRequest, null, null, null)
        );
        _rulesStore
            .Setup(m => m.AddRuleAsync(It.Is<RuleDto>(d => TestHelper.AreEquivalent(_input, d))))
            .ThrowsAsync(expectedException)
            .Verifiable();

        var exception = await Assert.ThrowsAsync<RuleException>(() => _target.AddRuleAsync(_input));
        Assert.Equal(expectedException.Message, exception.Message);
    }

    [Fact]
    public async Task ReturnsNotFound()
    {
        var expectedException = new RuleException(
            "Not found",
            new ClientMRMApiException("Not Found", (int)HttpStatusCode.NotFound, null, null, null)
        );
        _rulesStore
            .Setup(m => m.AddRuleAsync(It.Is<RuleDto>(d => TestHelper.AreEquivalent(_input, d))))
            .ThrowsAsync(expectedException)
            .Verifiable();

        var exception = await Assert.ThrowsAsync<RuleException>(() => _target.AddRuleAsync(_input));
        Assert.Equal(expectedException.Message, exception.Message);
    }

    [Fact]
    public async Task ReturnsRuleAdded()
    {
        var ruleAdded = TestHelper.GetMrmRuleDtoInstance();
        _rulesStore
            .Setup(m => m.AddRuleAsync(It.Is<RuleDto>(d => TestHelper.AreEquivalent(_input, d))))
            .ReturnsAsync(ruleAdded)
            .Verifiable();

        var result = await _target.AddRuleAsync(_input);
        Assert.NotNull(result);
        Assert.True(TestHelper.AreEquivalent(result, ruleAdded));
    }
}
