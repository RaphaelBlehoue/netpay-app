using System.Net;
using Affectations.App.Tests.Common;
using Affectations.Domain.AggregatesRoots.RuleAggregate;
using Affectations.Domain.Exceptions;
using Affectations.Domain.Models;
using Affectations.Infrastructure.Mappers;
using Affectations.Infrastructure.Repositories;
using Affectations.Infrastructure.Stores;
using AutoMapper;
using Moq;

namespace Affectations.App.Tests.Repositories.RuleRepositoryTests;

public class RuleRepository_ExportRulesShould
{
    private readonly Mock<IRulesStore> _rulesStore;
    private readonly RuleRepository _target;
    private ClientMRMApiException? _clientMRMApiException;
    private readonly FilterRuleModel _input;

    public RuleRepository_ExportRulesShould()
    {
        _input = GetRuleInstance();
        _rulesStore = new Mock<IRulesStore>();
        _target = new RuleRepository(
            _rulesStore.Object,
            new MapperConfiguration(cfg => cfg.AddProfile<MapperProfiles>()).CreateMapper()
        );
    }

    [Fact]
    public async Task ReturnsBadRequest()
    {
        _clientMRMApiException = new ClientMRMApiException(
            "Bad Request",
            (int)HttpStatusCode.BadRequest,
            null,
            null,
            null
        );
        var expectedException = new RuleException("Bad request", _clientMRMApiException);

        _rulesStore
            .Setup(m => m.ExportReglesAsync(It.Is<FiltreRulesDto>(d => TestHelper.AreEquivalent(_input, d))))
            .ThrowsAsync(_clientMRMApiException)
            .Verifiable();
        var exception = await Assert.ThrowsAsync<RuleException>(() => _target.ExportRules(GetRuleInstance()));
        Assert.Equal(expectedException.Message, exception.Message);
    }

    [Fact]
    public async Task ReturnsNotFound()
    {
        _clientMRMApiException = new ClientMRMApiException("Not Found", (int)HttpStatusCode.NotFound, null, null, null);
        var expectedException = new RuleException("Not found", _clientMRMApiException);

        _rulesStore
            .Setup(m => m.ExportReglesAsync(It.Is<FiltreRulesDto>(d => TestHelper.AreEquivalent(_input, d))))
            .ThrowsAsync(_clientMRMApiException)
            .Verifiable();
        var exception = await Assert.ThrowsAsync<RuleException>(() => _target.ExportRules(GetRuleInstance()));
        Assert.Equal(expectedException.Message, exception.Message);
    }

    public static FilterRuleModel GetRuleInstance()
    {
        var ids = new List<long>();
        var ruleDetailsDto = new RuleDetails();
        var criteresDto = new CriteriaModel();
        var affectationDto = new Affectation();
        var conditionsDto = new Conditions();

        return new FilterRuleModel(ids, ruleDetailsDto, criteresDto, affectationDto, conditionsDto);
    }
}
