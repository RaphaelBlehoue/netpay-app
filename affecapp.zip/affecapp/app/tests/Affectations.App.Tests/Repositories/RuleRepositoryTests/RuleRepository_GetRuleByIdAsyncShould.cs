using Affectations.App.Tests.Common;
using Affectations.Domain.Exceptions;
using Affectations.Infrastructure.Mappers;
using Affectations.Infrastructure.Repositories;
using Affectations.Infrastructure.Stores;
using AutoMapper;
using Moq;

namespace Affectations.App.Tests.Repositories.RuleRepositoryTests;

public class RuleRepository_GetRuleByIdAsyncShould
{
    private readonly long _invalidRegleId = -1;
    private readonly long _validRegleId = 1;
    private readonly Mock<IRulesStore> _rulesStore;
    private readonly RuleNotFoundException _ruleNotFoundException;
    private readonly RuleRepository _target;

    public RuleRepository_GetRuleByIdAsyncShould()
    {
        _ruleNotFoundException = new RuleNotFoundException(_invalidRegleId);
        _rulesStore = new Mock<IRulesStore>();
        _target = new RuleRepository(
            _rulesStore.Object,
            new MapperConfiguration(cfg => cfg.AddProfile<MapperProfiles>()).CreateMapper()
        );
    }

    [Fact]
    public async Task ReturnRuleNotFound_WhenIdWasNotFound()
    {
        var expected = _ruleNotFoundException.Message;
        _rulesStore.Setup(m => m.GetRuleByIdAsync(It.IsAny<long>())).ThrowsAsync(_ruleNotFoundException).Verifiable();

        var exception = await Assert.ThrowsAsync<RuleNotFoundException>(
            () => _target.GetRuleByIdAsync(_invalidRegleId)
        );
        Assert.Equal(expected, exception.Message);
    }

    [Fact]
    public async Task ReturnRuleFounded()
    {
        var expectedRule = TestHelper.GetMrmRuleDtoInstance();
        _rulesStore.Setup(m => m.GetRuleByIdAsync(It.IsAny<long>())).ReturnsAsync(expectedRule).Verifiable();
        var result = await _target.GetRuleByIdAsync(_validRegleId);
        Assert.NotNull(result);
        Assert.True(TestHelper.AreEquivalent(result, expectedRule));
    }
}
