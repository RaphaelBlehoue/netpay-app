using System.Net;
using Affectations.App.Tests.Common;
using Affectations.Domain.Exceptions;
using Affectations.Domain.Models;
using Affectations.Infrastructure.Mappers;
using Affectations.Infrastructure.Repositories;
using Affectations.Infrastructure.Stores;
using AutoMapper;
using Moq;

namespace Affectations.App.Tests.Repositories.RuleRepositoryTests;

public class RuleRepository_UpdateRulesAsyncShould
{
    private readonly Mock<IRulesStore> _rulesStore;
    private readonly RuleRepository _target;
    private readonly RuleMassUpdate _input;

    public RuleRepository_UpdateRulesAsyncShould()
    {
        _input = TestHelper.GetRuleMassUpdateInstance();
        _rulesStore = new Mock<IRulesStore>();
        _target = new RuleRepository(
            _rulesStore.Object,
            new MapperConfiguration(cfg => cfg.AddProfile<MapperProfiles>()).CreateMapper()
        );
    }

    [Fact]
    public async Task ReturnsBadRequest()
    {
        var expectedException = new RuleException(
            "Bad request",
            new ClientMRMApiException("Bad Request", (int)HttpStatusCode.BadRequest, null, null, null)
        );

        _rulesStore
            .Setup(m => m.UpdateRulesAsync(It.Is<BulkUpdateDto>(d => TestHelper.AreEquivalent(_input, d))))
            .ThrowsAsync(expectedException)
            .Verifiable();

        var exception = await Assert.ThrowsAsync<RuleException>(() => _target.UpdateRulesAsync(_input));
        Assert.Equal(expectedException.Message, exception.Message);
    }

    [Fact]
    public async Task ReturnsNotFound()
    {
        var expectedException = new RuleException(
            "Not found",
            new ClientMRMApiException("Not Found", (int)HttpStatusCode.NotFound, null, null, null)
        );
        _rulesStore
            .Setup(m => m.UpdateRulesAsync(It.Is<BulkUpdateDto>(d => TestHelper.AreEquivalent(_input, d))))
            .ThrowsAsync(expectedException)
            .Verifiable();

        var exception = await Assert.ThrowsAsync<RuleException>(() => _target.UpdateRulesAsync(_input));
        Assert.Equal(expectedException.Message, exception.Message);
    }

    [Fact]
    public async Task ReturnsCountRuleModified()
    {
        var expectedCount = 2;
        _rulesStore
            .Setup(m => m.UpdateRulesAsync(It.Is<BulkUpdateDto>(d => TestHelper.AreEquivalent(_input, d))))
            .ReturnsAsync(expectedCount)
            .Verifiable();

        var actualCount = await _target.UpdateRulesAsync(_input);
        Assert.Equal(expectedCount, actualCount);
    }
}
