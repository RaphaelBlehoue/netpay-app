using System.Net;
using Affectations.App.Tests.Common;
using Affectations.Domain.AggregatesRoots.RuleAggregate;
using Affectations.Domain.Exceptions;
using Affectations.Infrastructure.Mappers;
using Affectations.Infrastructure.Repositories;
using Affectations.Infrastructure.Stores;
using AutoMapper;
using Moq;

namespace Affectations.App.Tests.Repositories.RuleRepositoryTests;

public class RuleRepository_UpdateRuleAsyncShould
{
    private readonly Mock<IRulesStore> _rulesStore;
    private readonly RuleRepository _target;
    private readonly Rule _input;

    public RuleRepository_UpdateRuleAsyncShould()
    {
        _input = GetRuleInstance();
        _rulesStore = new Mock<IRulesStore>();
        _target = new RuleRepository(
            _rulesStore.Object,
            new MapperConfiguration(cfg => cfg.AddProfile<MapperProfiles>()).CreateMapper()
        );
    }

    [Fact]
    public async Task ReturnsBadRequest()
    {
        var expectedException = new RuleException(
            "Bad request",
            new ClientMRMApiException("Bad Request", (int)HttpStatusCode.BadRequest, null, null, null)
        );

        _rulesStore
            .Setup(m => m.UpdateRuleAsync(It.Is<RuleDto>(d => TestHelper.AreEquivalent(_input, d))))
            .ThrowsAsync(expectedException)
            .Verifiable();

        var exception = await Assert.ThrowsAsync<RuleException>(() => _target.UpdateRuleAsync(_input));
        Assert.Equal(expectedException.Message, exception.Message);
    }

    [Fact]
    public async Task ReturnsNotFound()
    {
        var expectedException = new RuleException(
            "Not found",
            new ClientMRMApiException("Not Found", (int)HttpStatusCode.NotFound, null, null, null)
        );
        _rulesStore
            .Setup(m => m.UpdateRuleAsync(It.Is<RuleDto>(d => TestHelper.AreEquivalent(_input, d))))
            .ThrowsAsync(expectedException)
            .Verifiable();

        var exception = await Assert.ThrowsAsync<RuleException>(() => _target.UpdateRuleAsync(_input));
        Assert.Equal(expectedException.Message, exception.Message);
    }

    [Fact]
    public async Task ReturnsRuleUpdated()
    {
        var ruleUpdated = TestHelper.GetMrmRuleDtoInstance();
        _rulesStore
            .Setup(m => m.UpdateRuleAsync(It.Is<RuleDto>(d => TestHelper.AreEquivalent(_input, d))))
            .ReturnsAsync(ruleUpdated)
            .Verifiable();

        var result = await _target.UpdateRuleAsync(_input);
        Assert.NotNull(result);
    }

    public static Rule GetRuleInstance()
    {
        var ruleDetails = new RuleDetails
        {
            RuleName = "SampleRule",
            Statut = "Active",
            StartDate = new DateTime(2023, 12, 31),
            EndDate = new DateTime(2024, 12, 31),
            Comment = "This is a sample rule.",
            CreationDate = new DateTime(2023, 12, 15),
            CreatedBy = "JohnDoe",
            CreatorId = "123",
            UpdateDate = new DateTime(2023, 12, 20),
            UpdatorId = "456"
        };

        var criteres = new Domain.AggregatesRoots.RuleAggregate.Criteria
        {
            Segmentation = new List<string> { "S1" },
            DistributorRegion = new List<string> { "59" },
            Branch = new List<string> { "Branch" }
        };

        var affectation = new Affectation
        {
            AffectedTeam = "TeamA",
            AffectedRegion = "RegionX",
            AffectedEmployee = "John Doe",
            AffectedEmployeeId = "E12345",
            AffectationDate = new DateTime(2024, 01, 15).AddDays(1),
            AffectationDemandDate = new DateTime(2024, 01, 15)
        };
        var conditions = new Conditions();

        return new Rule(id: 1, ruleDetails, criteres, affectation, conditions);
    }
}
