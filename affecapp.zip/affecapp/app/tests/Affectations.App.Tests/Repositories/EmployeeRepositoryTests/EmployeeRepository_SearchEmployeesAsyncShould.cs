using Affectations.App.Tests.Common;
using Affectations.Infrastructure.Repositories;
using Affectations.Infrastructure.Specifications;

namespace Affectations.App.Tests.Repositories.EmployeeRepositoryTests;

public class EmployeeRepository_SearchEmployeesAsyncShould
{
    private readonly string LastNameStartsWithFilter = "bou";

    private readonly EmployeeRepository _target;

    public EmployeeRepository_SearchEmployeesAsyncShould()
    {
        var context = InMemoryDatabase.CreateContextWithEmployees();

        _target = new EmployeeRepository(context);
    }

    [Fact]
    public async Task ReturnMatchedEmployees_WhenFound()
    {
        var expected = TestDataHelper
            .GetEmployees()
            .Where(x => !string.IsNullOrEmpty(x.LastName) && x.LastName.StartsWith(LastNameStartsWithFilter))
            .OrderBy(x => x.LastName)
            .ToArray();

        var employeeLastNameSearchSpecification = new EmployeeLastNameSearchSpecification(LastNameStartsWithFilter)
        {
            PageNumber = 1,
            PageSize = 10,
        };

        var result = await _target.SearchEmployeesAsync(employeeLastNameSearchSpecification);

        result.Data.Should().BeEquivalentTo(expected);
    }
}
