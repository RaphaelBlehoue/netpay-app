using Affectations.Domain.Entities;
using Affectations.Infrastructure.Data.Models;

namespace Affectations.App.Tests.Common;

public static class TestDataHelper
{
    public static TEmployee[] GetTEmployees()
    {
        return
        [
            new()
            {
                Id = "s1000001",
                LastName = "John",
                FirstName = "Doe"
            },
            new()
            {
                Id = "s1000002",
                LastName = "David",
                FirstName = "Davidson"
            },
            new()
            {
                Id = "S009671",
                LastName = "Boureau",
                FirstName = "Paul"
            },
            new()
            {
                Id = "S009672",
                LastName = "Bouchet",
                FirstName = "Michele"
            },
            new()
            {
                Id = "S009673",
                LastName = "Bousseau",
                FirstName = "Bruno"
            }
        ];
    }

    public static Employee[] GetEmployees()
    {
        return
        [
            new()
            {
                Id = "s1000001",
                LastName = "John",
                FirstName = "Doe"
            },
            new()
            {
                Id = "s1000002",
                LastName = "David",
                FirstName = "Davidson"
            },
            new()
            {
                Id = "S009671",
                LastName = "Boureau",
                FirstName = "Paul"
            },
            new()
            {
                Id = "S009672",
                LastName = "Bouchet",
                FirstName = "Michele"
            },
            new()
            {
                Id = "S009673",
                LastName = "Bousseau",
                FirstName = "Bruno"
            }
        ];
    }

    public static TRuleCriterionCategory[] GetTRuleCriteriaCategories()
    {
        return
        [
            new()
            {
                Code = "C1",
                Label = "Criterion 1",
                TRuleCriteria = [new() { Code = "Item1", Label = "Item1" }]
            },
            new()
            {
                Code = "C2",
                Label = "Criterion 2",
                TRuleCriteria = [new() { Code = "Item2", Label = "Item2" }, new() { Code = "Item3", Label = "Item3" }]
            }
        ];
    }

    public static RuleCriterionCategory[] GetRuleCriteriaCategories()
    {
        return
        [
            new()
            {
                Code = "C1",
                Label = "Criterion 1",
                RuleCriteria = [new() { Code = "Item1", Label = "Item1" }]
            },
            new()
            {
                Code = "C2",
                Label = "Criterion 2",
                RuleCriteria = [new() { Code = "Item2", Label = "Item2" }, new() { Code = "Item3", Label = "Item3" }]
            }
        ];
    }

    public static IDictionary<string, RuleCriterionCategory> GetFakeRuleCriteriaDictionary()
    {
        var dictionary = new Dictionary<string, RuleCriterionCategory>
        {
            {
                "C1",
                new()
                {
                    Code = "C1",
                    Label = "Criterion 1",
                    RuleCriteria = [new() { Code = "Item1", Label = "Item1" }]
                }
            },
            {
                "C2",
                new()
                {
                    Code = "C2",
                    Label = "Criterion 2",
                    RuleCriteria =
                    [
                        new() { Code = "Item2", Label = "Item2" },
                        new() { Code = "Item3", Label = "Item3" }
                    ]
                }
            }
        };

        return dictionary;
    }

    public static TTeam[] GetTTeams()
    {
        return
        [
            new()
            {
                Code = "ES_CONSTRUCTION_IDF",
                Name = "ES_CONSTRUCTION_IDF",
                RegionCode = "64"
            },
            new()
            {
                Code = "ES_DAB1_IDF",
                Name = "ES_DAB1_IDF",
                RegionCode = "64"
            }
        ];
    }

    public static Team[] GetTeams()
    {
        return
        [
            new()
            {
                Code = "ES_CONSTRUCTION_IDF",
                Name = "ES_CONSTRUCTION_IDF",
                RegionCode = "64"
            },
            new()
            {
                Code = "ES_DAB1_IDF",
                Name = "ES_DAB1_IDF",
                RegionCode = "64"
            }
        ];
    }

    public static TRuleCriterionCategory[] GetIntermediaryNameTRuleCriterionCategory()
    {
        return [new() { Code = "INTERMEDIARY_NAME", Label = "Nom intermédiare" }];
    }

    public static TRuleCriterion[] GetIntermediaryNameTRuleCriterion()
    {
        return
        [
            new()
            {
                Code = "Code1",
                Label = "FRANCOIS A1",
                RuleCriterionCategoryCode = "INTERMEDIARY_NAME"
            },
            new()
            {
                Code = "Code2",
                Label = "FRANCOIS A2",
                RuleCriterionCategoryCode = "INTERMEDIARY_NAME"
            },
            new()
            {
                Code = "Code3",
                Label = "FRANCOIS A3",
                RuleCriterionCategoryCode = "INTERMEDIARY_NAME"
            },
            new()
            {
                Code = "Code4",
                Label = "FRANCOIS A4",
                RuleCriterionCategoryCode = "INTERMEDIARY_NAME"
            },
            new()
            {
                Code = "Code5",
                Label = "FRANCOIS A5",
                RuleCriterionCategoryCode = "INTERMEDIARY_NAME"
            },
            new()
            {
                Code = "Code6",
                Label = "PAUL A1",
                RuleCriterionCategoryCode = "INTERMEDIARY_NAME"
            },
            new()
            {
                Code = "Code7",
                Label = "PAUL A2",
                RuleCriterionCategoryCode = "INTERMEDIARY_NAME"
            }
        ];
    }

    public static RuleCriterion[] GetIntermediaryNameRuleCriteria()
    {
        return
        [
            new() { Code = "Code1", Label = "FRANCOIS A1" },
            new() { Code = "Code2", Label = "FRANCOIS A2" },
            new() { Code = "Code3", Label = "FRANCOIS A3" },
            new() { Code = "Code4", Label = "FRANCOIS A4" },
            new() { Code = "Code5", Label = "FRANCOIS A5" },
            new() { Code = "Code6", Label = "PAUL A1" },
            new() { Code = "Code7", Label = "PAUL A2" }
        ];
    }
}
