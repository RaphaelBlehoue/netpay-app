using System.Globalization;
using Affectations.App.Dtos;
using Affectations.App.Enums;
using Affectations.Domain.AggregatesRoots.RuleAggregate;
using Affectations.Domain.Models;
using Affectations.Infrastructure.Stores;
using Microsoft.IdentityModel.Tokens;

namespace Affectations.App.Tests.Common;

internal class TestHelper
{
    public static bool AreEquivalent(Rule? r, Infrastructure.Stores.RuleDto? d)
    {
        if (r is null || d is null)
        {
            return r is null && d is null;
        }

        const string dateFormat = "yyyy-MM-ddTHH:mm:ss.fffzzz";
        return r.RuleDetails?.RuleName == d.RuleDetails?.Nom
            && r.RuleDetails?.Statut == d.RuleDetails?.Statut
            && r.RuleDetails?.StartDate == d.RuleDetails?.DateDebut?.DateTime
            && r.RuleDetails?.EndDate == d.RuleDetails?.DateFin?.DateTime
            && r.RuleDetails?.Comment == d.RuleDetails?.Commentaire
            && r.RuleDetails?.CreationDate == d.RuleDetails?.DateCreation?.DateTime
            && r.RuleDetails?.CreatedBy == d.RuleDetails?.CreePar
            && r.RuleDetails?.CreatorId == d.RuleDetails?.MatriculeCreateur
            && r.RuleDetails?.UpdateDate == d.RuleDetails?.DateMiseAJour?.DateTime
            && r.RuleDetails?.UpdatedBy == d.RuleDetails?.MiseAJourPar
            && r.RuleDetails?.UpdatorId == d.RuleDetails?.MatriculeModificateur
            && (
                (r.Criteres.Segmentation.IsNullOrEmpty() && d.Criteres.Segmentation.IsNullOrEmpty())
                || (r.Criteres?.Segmentation.SequenceEqual(d.Criteres?.Segmentation)).GetValueOrDefault()
            )
            && (
                (r.Criteres.DistributorRegion.IsNullOrEmpty() && d.Criteres.Region.IsNullOrEmpty())
                || (r.Criteres?.DistributorRegion.SequenceEqual(d.Criteres.Region)).GetValueOrDefault()
            )
            && (
                (r.Criteres.Network.IsNullOrEmpty() && d.Criteres.Reseau.IsNullOrEmpty())
                || (r.Criteres?.Network.SequenceEqual(d.Criteres?.Reseau)).GetValueOrDefault()
            )
            && (
                (r.Criteres.Network.IsNullOrEmpty() && d.Criteres.Reseau.IsNullOrEmpty())
                || (r.Criteres?.Branch.SequenceEqual(d.Criteres?.Branche)).GetValueOrDefault()
            )
            && (
                (r.Criteres.Copht.IsNullOrEmpty() && d.Criteres.Copht.IsNullOrEmpty())
                || (r.Criteres?.Copht.SequenceEqual(d.Criteres?.Copht)).GetValueOrDefault()
            )
            && (
                (r.Criteres.DistributorDepartment.IsNullOrEmpty() && d.Criteres.Departement.IsNullOrEmpty())
                || (r.Criteres?.DistributorDepartment.SequenceEqual(d.Criteres?.Departement)).GetValueOrDefault()
            )
            && (
                (r.Criteres.ContractCategory.IsNullOrEmpty() && d.Criteres.CategorieContrat.IsNullOrEmpty())
                || (r.Criteres?.ContractCategory.SequenceEqual(d.Criteres?.CategorieContrat)).GetValueOrDefault()
            )
            && (
                (r.Criteres.UVCode.IsNullOrEmpty() && d.Criteres.Produit.IsNullOrEmpty())
                || (r.Criteres?.UVCode.SequenceEqual(d.Criteres?.Produit)).GetValueOrDefault()
            )
            && (
                (r.Criteres.IntermediateName.IsNullOrEmpty() && d.Criteres.NomIntermediaire.IsNullOrEmpty())
                || (r.Criteres?.IntermediateName.SequenceEqual(d.Criteres?.NomIntermediaire)).GetValueOrDefault()
            )
            && (
                (r.Criteres.PortfolioCode.IsNullOrEmpty() && d.Criteres.Portefeuille.IsNullOrEmpty())
                || (r.Criteres?.PortfolioCode.SequenceEqual(d.Criteres?.Portefeuille)).GetValueOrDefault()
            )
            && (
                (r.Criteres.Clause.IsNullOrEmpty() && d.Criteres.Clause.IsNullOrEmpty())
                || (r.Criteres?.Clause.SequenceEqual(d.Criteres?.Clause)).GetValueOrDefault()
            )
            && (
                (r.Criteres.SyndicCode.IsNullOrEmpty() && d.Criteres.CodeSyndic.IsNullOrEmpty())
                || (r.Criteres?.SyndicCode.SequenceEqual(d.Criteres?.CodeSyndic)).GetValueOrDefault()
            )
            && (
                (r.Criteres.NafCode.IsNullOrEmpty() && d.Criteres.CodeNaf.IsNullOrEmpty())
                || (r.Criteres?.NafCode.SequenceEqual(d.Criteres?.CodeNaf)).GetValueOrDefault()
            )
            && (
                (r.Criteres.ClientNumber.IsNullOrEmpty() && d.Criteres.NumeroClient.IsNullOrEmpty())
                || (r.Criteres?.ClientNumber.SequenceEqual(d.Criteres?.NumeroClient)).GetValueOrDefault()
            )
            && (
                (r.Criteres.AccountManager.IsNullOrEmpty() && d.Criteres.ChargeDeClientele.IsNullOrEmpty())
                || (r.Criteres?.AccountManager.SequenceEqual(d.Criteres?.ChargeDeClientele)).GetValueOrDefault()
            )
            && (
                (r.Criteres.ContractNumber.IsNullOrEmpty() && d.Criteres.NumeroContrat.IsNullOrEmpty())
                || (r.Criteres?.ContractNumber.SequenceEqual(d.Criteres?.NumeroContrat)).GetValueOrDefault()
            )
            && r.Affectation?.AffectedTeam == d.Affectations?.AffecteEquipe
            && r.Affectation?.AffectedRegion == d.Affectations?.AffecteRegion
            && r.Affectation?.AffectedEmployee == d.Affectations?.AffecteCollaborateur
            && r.Affectation?.AffectedEmployeeId == d.Affectations?.MatriculeCollaborateur
            && r.Affectation?.AffectationDate?.ToString(dateFormat, CultureInfo.InvariantCulture)
                == d.Affectations?.DateAffectation
            && r.Affectation?.AffectationDemandDate?.ToString(dateFormat, CultureInfo.InvariantCulture)
                == d.Affectations?.DateDemandeAffectation;
    }

    public static bool AreEquivalent(FilterRuleModel? r, FiltreRulesDto? d)
    {
        if (r is null || d is null)
        {
            return r is null && d is null;
        }

        const string dateFormat = "yyyy-MM-ddTHH:mm:ss.fffzzz";
        return r.RuleDetails?.RuleName == d.RuleDetails?.Nom
            && r.RuleDetails?.Statut == d.RuleDetails?.Statut
            && r.RuleDetails?.StartDate == d.RuleDetails?.DateDebut?.DateTime
            && r.RuleDetails?.EndDate == d.RuleDetails?.DateFin?.DateTime
            && r.RuleDetails?.Comment == d.RuleDetails?.Commentaire
            && r.RuleDetails?.CreationDate == d.RuleDetails?.DateCreation?.DateTime
            && r.RuleDetails?.CreatedBy == d.RuleDetails?.CreePar
            && r.RuleDetails?.CreatorId == d.RuleDetails?.MatriculeCreateur
            && r.RuleDetails?.UpdateDate == d.RuleDetails?.DateMiseAJour?.DateTime
            && r.RuleDetails?.UpdatedBy == d.RuleDetails?.MiseAJourPar
            && r.RuleDetails?.UpdatorId == d.RuleDetails?.MatriculeModificateur
            && r.Criteres?.Segmentation == d.Criterion?.Segmentation
            && r.Criteres?.DistributorRegion == d.Criterion?.Departement
            && r.Criteres?.Network == d.Criterion?.Reseau
            && r.Criteres?.Branch == d.Criterion?.Branche
            && r.Criteres?.Copht
                == (
                    d.Criterion?.Copht is not null ? decimal.Parse(d.Criterion.Copht, CultureInfo.CurrentCulture) : null
                )
            && r.Criteres?.DistributorDepartment == d.Criterion?.Departement
            && r.Criteres?.ContractCategory == d.Criterion?.CategorieContrat
            && r.Criteres?.UVCode == d.Criterion?.Produit
            && r.Criteres?.IntermediateName == d.Criterion?.NomIntermediaire
            && r.Criteres?.PortfolioCode == d.Criterion?.Portefeuille
            && r.Criteres?.Clause == d.Criterion?.Clause
            && r.Criteres?.SyndicCode == d.Criterion?.CodeSyndic
            && r.Criteres?.NafCode == d.Criterion?.CodeNaf
            && r.Criteres?.ClientNumber == d.Criterion?.NumeroClient
            && r.Criteres?.AccountManager == d.Criterion?.ChargeDeClientele
            && r.Criteres?.ContractNumber == d.Criterion?.NumeroContrat
            && r.Affectation?.AffectedTeam == d.Affectations?.AffecteEquipe
            && r.Affectation?.AffectedRegion == d.Affectations?.AffecteRegion
            && r.Affectation?.AffectedEmployee == d.Affectations?.AffecteCollaborateur
            && r.Affectation?.AffectedEmployeeId == d.Affectations?.MatriculeCollaborateur
            && r.Affectation?.AffectationDate?.ToString(dateFormat, CultureInfo.InvariantCulture)
                == d.Affectations?.DateAffectation
            && r.Affectation?.AffectationDemandDate?.ToString(dateFormat, CultureInfo.InvariantCulture)
                == d.Affectations?.DateDemandeAffectation;
    }

    public static Rule GetRuleInstance()
    {
        var ruleDetails = new RuleDetails
        {
            RuleName = "SampleRule",
            Statut = "Active",
            StartDate = new DateTime(2023, 12, 31),
            EndDate = new DateTime(2024, 12, 31),
            Comment = "This is a sample rule.",
            CreationDate = new DateTime(2023, 12, 15),
            CreatedBy = "JohnDoe",
            CreatorId = "123",
            UpdateDate = new DateTime(2023, 12, 20),
            UpdatorId = "456"
        };

        var criteres = new Domain.AggregatesRoots.RuleAggregate.Criteria
        {
            Segmentation = new List<string> { "S1" },
            DistributorRegion = new List<string> { "59" },
            Branch = new List<string> { "Branch" }
        };

        var affectation = new Affectation
        {
            AffectedTeam = "TeamA",
            AffectedRegion = "RegionX",
            AffectedEmployee = "John Doe",
            AffectedEmployeeId = "E12345",
            AffectationDate = new DateTime(2024, 01, 15).AddDays(1),
            AffectationDemandDate = new DateTime(2024, 01, 15)
        };
        var conditions = new Conditions();

        return new Rule(id: 0, ruleDetails, criteres, affectation, conditions);
    }

    public static Dtos.RuleDto GetRuleDtoInstance()
    {
        var ruleDetailsDto = new RuleDetailsDto()
        {
            RuleName = "SampleRule",
            Statut = "Active",
            StartDate = new DateTime(2023, 12, 31),
            EndDate = new DateTime(2024, 12, 31),
            Comment = "This is a sample rule.",
            CreationDate = DateTime.Now,
            CreatedBy = "JohnDoe",
            CreatorId = "123",
            UpdateDate = DateTime.Now.AddDays(5),
            UpdatorId = "456"
        };

        var criteresDto = new Dtos.CriteresDto() { Branch = "A;B;C" };

        var affectationDto = new Dtos.AffectationDto()
        {
            AffectedTeam = "TeamA",
            AffectedRegion = "RegionX",
            AffectedEmployee = "John Doe",
            AffectedEmployeeId = "E12345",
            AffectationDate = DateTime.Now,
            AffectationDemandDate = DateTime.Now.AddDays(1)
        };
        var conditionsDto = new Dtos.ConditionsDto() { BranchCondition = "est parmi" };

        return new Dtos.RuleDto(id: 0, ruleDetailsDto, criteresDto, affectationDto, conditionsDto);
    }

    public static Dtos.FilterRuleDto GetRuleFilterDtoInstance()
    {
        var ids = new List<long>();
        var ruleDetailsDto = new RuleDetailsDto()
        {
            RuleName = "SampleRule",
            Statut = "Active",
            StartDate = new DateTime(2023, 12, 31),
            EndDate = new DateTime(2024, 12, 31),
            Comment = "This is a sample rule.",
            CreationDate = DateTime.Now,
            CreatedBy = "JohnDoe",
            CreatorId = "123",
            UpdateDate = DateTime.Now.AddDays(5),
            UpdatorId = "456"
        };

        var criteresDto = new CriteresDto() { Branch = "A;B;C" };

        var affectationDto = new Dtos.AffectationDto()
        {
            AffectedTeam = "TeamA",
            AffectedRegion = "RegionX",
            AffectedEmployee = "John Doe",
            AffectedEmployeeId = "E12345",
            AffectationDate = DateTime.Now,
            AffectationDemandDate = DateTime.Now.AddDays(1)
        };
        var conditionsDto = new Dtos.ConditionsDto() { BranchCondition = "est parmi" };

        return new FilterRuleDto(ids, ruleDetailsDto, criteresDto, affectationDto, conditionsDto);
    }

    public static RulePersistance GetRulePersistanceInstance()
    {
        var ruleDetailsDto = new RuleDetailsDto()
        {
            RuleName = "SampleRule",
            Statut = "Active",
            StartDate = new DateTime(2023, 12, 31),
            EndDate = new DateTime(2024, 12, 31),
            Comment = "This is a sample rule.",
            CreationDate = DateTime.Now,
            CreatedBy = "JohnDoe",
            CreatorId = "123",
            UpdateDate = DateTime.Now.AddDays(5),
            UpdatorId = "456"
        };

        var affectationDto = new Dtos.AffectationDto()
        {
            AffectedTeam = "TeamA",
            AffectedRegion = "RegionX",
            AffectedEmployee = "John Doe",
            AffectedEmployeeId = "E12345",
            AffectationDate = DateTime.Now,
            AffectationDemandDate = DateTime.Now.AddDays(1)
        };

        var rules = new Dictionary<string, Dtos.CriterionDto>
        {
            {
                CriteriaEnum.Branch.ToString(),
                new Dtos.CriterionDto() { Condition = "est parmi", Values = ["A", "B", "C"] }
            }
        };

        return new RulePersistance(id: 0, ruleDetailsDto, affectationDto, rules);
    }

    public static RuleCreationDto GetRuleCreationDtoInstance()
    {
        var ruleDetailsDto = new RuleDetailsCreationDto()
        {
            RuleName = "SampleRule",
            Statut = "Active",
            StartDate = new DateTime(2023, 12, 31),
            EndDate = new DateTime(2024, 12, 31),
            Comment = "This is a sample rule."
        };

        var affectationDto = new Dtos.AffectationDto()
        {
            AffectedTeam = "TeamA",
            AffectedRegion = "RegionX",
            AffectedEmployee = "John Doe",
            AffectedEmployeeId = "E12345",
            AffectationDate = DateTime.Now,
            AffectationDemandDate = DateTime.Now.AddDays(1)
        };

        var rules = new Dictionary<string, Dtos.CriterionDto>
        {
            {
                CriteriaEnum.Branch.ToString(),
                new Dtos.CriterionDto() { Condition = "est parmi", Values = ["A", "B", "C"] }
            }
        };

        return new Dtos.RuleCreationDto(id: 0, ruleDetailsDto, affectationDto, rules);
    }

    public static Infrastructure.Stores.RuleDto GetMrmRuleDtoInstance()
    {
        const string dateFormat = "yyyy-MM-ddTHH:mm:ss.fffzzz";
        var ruleDetails = new RuleDetailDto
        {
            Nom = "SampleRule",
            Statut = "Active",
            DateDebut = new DateTime(2023, 12, 31),
            DateFin = new DateTime(2024, 12, 31),
            Commentaire = "This is a sample rule.",
            DateCreation = new DateTime(2023, 12, 15),
            CreePar = "JohnDoe",
            MatriculeCreateur = "123",
            DateMiseAJour = new DateTime(2023, 12, 20),
            MatriculeModificateur = "456"
        };

        var criteres = new Infrastructure.Stores.Criteria
        {
            Segmentation = new List<string> { "S1" },
            Region = new List<string> { "59" },
            Branche = new List<string> { "Branch" }
        };

        var affectation = new Infrastructure.Stores.AffectationDto
        {
            AffecteEquipe = "TeamA",
            AffecteRegion = "RegionX",
            AffecteCollaborateur = "John Doe",
            MatriculeCollaborateur = "E12345",
            DateAffectation = new DateTime(2024, 01, 16).ToString(dateFormat, CultureInfo.InvariantCulture),
            DateDemandeAffectation = new DateTime(2024, 01, 15).ToString(dateFormat, CultureInfo.InvariantCulture)
        };
        var conditions = new Infrastructure.Stores.ConditionsDto()
        {
            ConditionBranche = "est parmi",
            ConditionSegmentation = "est parmi"
        };

        return new Infrastructure.Stores.RuleDto()
        {
            Id = 1,
            RuleDetails = ruleDetails,
            Affectations = affectation,
            Conditions = conditions,
            Criteres = criteres
        };
    }

    public static PaginationResponseRuleDto GetPaginationResponseRuleDto()
    {
        var _content = new List<Infrastructure.Stores.RuleDto>() { GetMrmRuleDtoInstance() };
        var data = new PaginationResponseRuleDto()
        {
            NumPage = 0,
            Size = 10,
            TotalPages = 1,
            Content = _content
        };
        return data;
    }

    public static ICollection<Infrastructure.Stores.RuleDto> GetRuleDtoCollection()
    {
        var rules = new List<Infrastructure.Stores.RuleDto>() { GetMrmRuleDtoInstance() };
        return rules;
    }

    public static ICollection<Infrastructure.Stores.RuleDto> GetRulesDtoCollection()
    {
        const string dateFormat = "yyyy-MM-ddTHH:mm:ss.fffzzz";
        var rules = new List<Infrastructure.Stores.RuleDto>()
        {
            new Infrastructure.Stores.RuleDto()
            {
                Id = 10,
                RuleDetails = new RuleDetailDto
                {
                    Nom = "Rule 10",
                    Statut = "Active",
                    DateDebut = new DateTime(2023, 12, 31),
                    DateFin = new DateTime(2024, 12, 31),
                    Commentaire = "This is a sample rule.",
                    DateCreation = new DateTime(2023, 12, 15),
                    CreePar = "JohnDoe",
                    MatriculeCreateur = "123",
                    DateMiseAJour = new DateTime(2023, 12, 20),
                    MatriculeModificateur = "456"
                },
                Affectations = new Infrastructure.Stores.AffectationDto
                {
                    AffecteEquipe = "TeamA",
                    AffecteRegion = "RegionX",
                    AffecteCollaborateur = "John Doe",
                    MatriculeCollaborateur = "E12345",
                    DateAffectation = new DateTime(2024, 01, 16).ToString(dateFormat, CultureInfo.InvariantCulture),
                    DateDemandeAffectation = new DateTime(2024, 01, 15).ToString(
                        dateFormat,
                        CultureInfo.InvariantCulture
                    )
                },
                Conditions = new Infrastructure.Stores.ConditionsDto()
                {
                    ConditionBranche = "est parmi",
                    ConditionSegmentation = "est parmi",
                    ConditionRegion = "est parmi"
                },
                Criteres = new Infrastructure.Stores.Criteria
                {
                    Segmentation = new List<string> { "S1" },
                    Region = new List<string> { "59" },
                    Branche = new List<string> { "Branch" }
                }
            },
            new Infrastructure.Stores.RuleDto()
            {
                Id = 30,
                RuleDetails = new RuleDetailDto
                {
                    Nom = "Rule 30",
                    Statut = "Active",
                    DateDebut = new DateTime(2023, 12, 31),
                    DateFin = new DateTime(2024, 12, 31),
                    Commentaire = "This is a sample rule.",
                    DateCreation = new DateTime(2023, 12, 15),
                    CreePar = "JohnDoe",
                    MatriculeCreateur = "123",
                    DateMiseAJour = new DateTime(2023, 12, 20),
                    MatriculeModificateur = "456"
                },
                Affectations = new Infrastructure.Stores.AffectationDto
                {
                    AffecteEquipe = "TeamA",
                    AffecteRegion = "RegionX",
                    AffecteCollaborateur = "John Doe",
                    MatriculeCollaborateur = "E12345",
                    DateAffectation = new DateTime(2024, 01, 16).ToString(dateFormat, CultureInfo.InvariantCulture),
                    DateDemandeAffectation = new DateTime(2024, 01, 15).ToString(
                        dateFormat,
                        CultureInfo.InvariantCulture
                    )
                },
                Conditions = new Infrastructure.Stores.ConditionsDto()
                {
                    ConditionBranche = "est parmi",
                    ConditionSegmentation = "est parmi",
                    ConditionCodeNaf = "est égale à"
                },
                Criteres = new Infrastructure.Stores.Criteria
                {
                    Segmentation = new List<string> { "S1" },
                    Branche = new List<string> { "Branch" },
                    CodeNaf = new List<string> { "123A456" }
                }
            }
        };
        return rules;
    }

    public static RuleMassUpdate GetRuleMassUpdateInstance()
    {
        return new RuleMassUpdate
        {
            Ids = [1, 2],
            AffectedEmployee = "John Doe",
            AffectedEmployeeId = "E12345",
            AffectedTeam = "TeamA",
            Comment = "Test commentaire",
            EndDate = new DateTime(2024, 12, 31)
        };
    }

    public static bool AreEquivalent(RuleMassUpdate? r, BulkUpdateDto? d)
    {
        if (r is null || d is null)
        {
            return r is null && d is null;
        }

        return r.Ids.ToList().SequenceEqual(d.Ids)
            && r?.AffectedEmployee == d?.AffecteCollaborateur
            && r?.AffectedTeam == d?.AffecteEquipe
            && r?.Comment == d?.Commentaire
            && r?.EndDate == d?.DateFin?.DateTime;
    }
}
