using Affectations.App.Tests.Common;
using Affectations.Infrastructure.Data.Models;
using Microsoft.EntityFrameworkCore;

namespace Affectations.App.Tests;

public static class InMemoryDatabase
{
    public static AffectationsContext CreateContext()
    {
        var options = new DbContextOptionsBuilder<AffectationsContext>()
            .UseInMemoryDatabase($"Affectations.App.Tests-{Guid.NewGuid()}")
            .Options;

        return new AffectationsContext(options);
    }

    public static AffectationsContext CreateContextWithEmployees()
    {
        var context = CreateContext();
        context.TEmployees.AddRange(TestDataHelper.GetTEmployees());
        context.SaveChanges();
        return context;
    }

    public static AffectationsContext CreateContextWithRuleCriteria()
    {
        var context = CreateContext();
        context.TRuleCriterionCategories.AddRange(TestDataHelper.GetTRuleCriteriaCategories());
        context.SaveChanges();
        return context;
    }

    public static AffectationsContext CreateContextWithTeams()
    {
        var context = CreateContext();
        context.TTeams.AddRange(TestDataHelper.GetTTeams());
        context.SaveChanges();
        return context;
    }

    public static AffectationsContext CreateContextWithEmptyTeams()
    {
        var context = CreateContext();
        context.SaveChanges();
        return context;
    }

    public static AffectationsContext CreateContextWithIntermediaryNameTRuleCriterionCategory()
    {
        var context = CreateContext();
        context.TRuleCriterionCategories.AddRange(TestDataHelper.GetIntermediaryNameTRuleCriterionCategory());
        context.SaveChanges();
        return context;
    }
}
