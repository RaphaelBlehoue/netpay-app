﻿using Affectations.App.Controllers.v0;
using Microsoft.AspNetCore.Http.HttpResults;

namespace Affectations.App.Tests.Controllers.v0.MultilingualHelloWorldControllerTests;

public class MultilingualHelloWorldController_GetDeprecatedShould
{
    private readonly MultilingualHelloWorldController _controller = new();

    [Fact]
    public void ReturnTheDefaultValue()
    {
        var result = _controller.GetDeprecated();

        var okObjectResult = Assert.IsType<Ok<string>>(result);
        var responseString = Assert.IsAssignableFrom<string>(okObjectResult.Value);
        Assert.Equal(MultilingualHelloWorldController.DefaultResult, responseString);
    }
}
