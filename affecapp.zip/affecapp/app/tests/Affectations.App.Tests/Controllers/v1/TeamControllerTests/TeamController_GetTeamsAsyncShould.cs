using Affectations.App.Controllers.v1;
using Affectations.App.Services;
using Affectations.App.Tests.Common;
using Affectations.Domain.Entities;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.Extensions.Logging;
using Moq;

namespace Affectations.App.Tests.Controllers.v1.TeamsControllerTests;

public class TeamController_GetTeamsAsyncShould
{
    private readonly Mock<ILogger<TeamsController>> _logger;
    private readonly Mock<ITeamService> _teamService;

    public TeamController_GetTeamsAsyncShould()
    {
        _logger = new Mock<ILogger<TeamsController>>();
        _teamService = new Mock<ITeamService>();
    }

    [Fact]
    public async Task ReturnTeams_WhenFound()
    {
        _teamService.Setup(m => m.GetTeamsAsync()).ReturnsAsync(TestDataHelper.GetTeams()).Verifiable();
        var teamsController = new TeamsController(_teamService.Object, _logger.Object);
        var result = await teamsController.GetTeamsAsync();
        var objectResult = Assert.IsType<Ok<IEnumerable<Team>>>(result);
        var response = Assert.IsAssignableFrom<IEnumerable<Team>>(objectResult.Value);
        var expected = TestDataHelper.GetTeams();
        response.Should().BeEquivalentTo(expected);
    }

    [Fact]
    public async Task ReturnsEmptyList()
    {
        _teamService.Setup(m => m.GetTeamsAsync()).ReturnsAsync(Enumerable.Empty<Team>()).Verifiable();
        var teamsController = new TeamsController(_teamService.Object, _logger.Object);
        var result = await teamsController.GetTeamsAsync();
        var objectResult = Assert.IsType<Ok<IEnumerable<Team>>>(result);
        var response = Assert.IsAssignableFrom<IEnumerable<Team>>(objectResult.Value);
        Assert.Empty(response);
    }
}
