using Affectations.App.Controllers.v1;
using Affectations.App.Dtos;
using Affectations.App.Services;
using Affectations.Domain.Exceptions;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;

namespace Affectations.App.Tests.Controllers.v1.RulesControllerTests;

public class RulesController_GetRuleByIdAsyncShould
{
    private readonly long _invalidRegleId = -1;
    private readonly long _validRegleId = 1;

    private readonly Mock<ILogger<RulesController>> _logger;
    private readonly Mock<IRuleService> _ruleService;
    private readonly RuleNotFoundException _ruleNotFoundException;
    private readonly RulesController _rulesController;

    public RulesController_GetRuleByIdAsyncShould()
    {
        _ruleNotFoundException = new RuleNotFoundException(_invalidRegleId);
        _logger = new Mock<ILogger<RulesController>>();
        _ruleService = new Mock<IRuleService>();
        _rulesController = new RulesController(_ruleService.Object, _logger.Object);
    }

    [Fact]
    public async Task ReturnRuleNotFound_WhenIdWasNotFound()
    {
        var expected = _ruleNotFoundException.Message;
        _ruleService.Setup(m => m.GetRuleByIdAsync(_invalidRegleId)).ThrowsAsync(_ruleNotFoundException).Verifiable();

        var result = await _rulesController.GetRuleByIdAsync(_invalidRegleId);

        var objectResult = Assert.IsType<BadRequest<ProblemDetails>>(result);
        var response = Assert.IsAssignableFrom<ProblemDetails>(objectResult.Value);
        Assert.Equal(expected, response.Detail);
    }

    [Fact]
    public async Task ReturnRuleWhenFound()
    {
        var expected = GetRuleDtoInstance();
        _ruleService.Setup(m => m.GetRuleByIdAsync(_validRegleId)).ReturnsAsync(expected).Verifiable();

        var result = await _rulesController.GetRuleByIdAsync(_validRegleId);

        var objectResult = Assert.IsType<Ok<RuleDto>>(result);
        var response = Assert.IsAssignableFrom<RuleDto>(objectResult.Value);
        Assert.Equal(_validRegleId, response.Id);
    }

    private static RuleDto GetRuleDtoInstance()
    {
        var ruleDetailsDto = new RuleDetailsDto()
        {
            RuleName = "SampleRule",
            Statut = "Active",
            StartDate = new DateTime(2023, 12, 31),
            EndDate = new DateTime(2024, 12, 31),
            Comment = "This is a sample rule.",
            CreationDate = DateTime.Now,
            CreatedBy = "JohnDoe",
            CreatorId = "123",
            UpdateDate = DateTime.Now.AddDays(5),
            UpdatorId = "456"
        };

        var criteresDto = new CriteresDto()
        {
            Segmentation = "S1",
            DistributorRegion = "59",
            Network = "N1",
            Branch = "Branch",
            Copht = 123456789.10M,
            DistributorDepartment = "59",
            ContractCategory = "C1",
            UVCode = "U123",
            IntermediateName = "IntermediateName",
            PortfolioCode = "12345",
            Clause = "123456789",
            SyndicCode = "12345",
            NafCode = "NafCode",
            ClientNumber = "Client123",
            AccountManager = "Manager123",
            ContractNumber = "Contract123"
        };

        var affectationDto = new AffectationDto()
        {
            AffectedTeam = "TeamA",
            AffectedRegion = "RegionX",
            AffectedEmployee = "John Doe",
            AffectedEmployeeId = "E12345",
            AffectationDate = DateTime.Now,
            AffectationDemandDate = DateTime.Now.AddDays(1)
        };
        var conditionsDto = new ConditionsDto();

        return new RuleDto(id: 1, ruleDetailsDto, criteresDto, affectationDto, conditionsDto);
    }
}
