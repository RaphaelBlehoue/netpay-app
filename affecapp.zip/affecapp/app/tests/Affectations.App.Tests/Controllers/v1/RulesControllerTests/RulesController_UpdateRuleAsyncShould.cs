using System.Security.Claims;
using Affectations.App.Controllers.v1;
using Affectations.App.Dtos;
using Affectations.App.Enums;
using Affectations.App.Services;
using Affectations.Domain.Exceptions;
using AxaFrance.E2ELogging;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;

namespace Affectations.App.Tests.Controllers.v1.RulesControllerTests;

public class RulesController_UpdateRuleAsyncShould
{
    private readonly Mock<ILogger<RulesController>> _logger;
    private readonly Mock<IRuleService> _ruleService;
    private RuleException? _ruleException;
    private readonly RulesController _rulesController;

    public RulesController_UpdateRuleAsyncShould()
    {
        _logger = new Mock<ILogger<RulesController>>();
        _ruleService = new Mock<IRuleService>();
        _rulesController = new RulesController(_ruleService.Object, _logger.Object);
        var httpContext = new DefaultHttpContext();
        httpContext.User = new ClaimsPrincipal(
            new ClaimsIdentity(new Claim[] { new Claim(ClaimTypes.Email, "your_user_id_here") })
        );

        var correlationContextAccessorMock = new Mock<ICorrelationContextAccessor>();
        var correlationContext = new CorrelationContext("fake_correlation_id");
        correlationContextAccessorMock.Setup(m => m.CorrelationContext).Returns(correlationContext);

        httpContext.RequestServices = new ServiceCollection()
            .AddSingleton(correlationContextAccessorMock.Object)
            .BuildServiceProvider();

        _rulesController.ControllerContext = new ControllerContext { HttpContext = httpContext };
    }

    [Theory]
    [InlineData("Date de début est obligatoire")]
    [InlineData("Date de début n'est pas valide")]
    [InlineData("le Code NAF, Le format a respecter est : xxxxxxx.")]
    [InlineData("Code Syndic : 5 caractères obligatoires.")]
    [InlineData("N° client : seuls les caractères numériques sont acceptés.")]
    [InlineData("Chargé de clientèle : Veuillez respecter le format : S000000.")]
    [InlineData("N° contrat : ne dois pas dépasser 16 caractères.")]
    public async Task ReturnBadRequest_WhenStartDateHasNoValue(string exceptionMessage)
    {
        _ruleException = new RuleException(exceptionMessage);
        var expected = _ruleException.Message;
        _ruleService
            .Setup(m => m.UpdateRuleAsync(It.Is<RulePersistance>(r => r is RulePersistance)))
            .ThrowsAsync(_ruleException)
            .Verifiable();

        var ruleCreationDto = GetRuleCreationDtoInstance();
        var result = await _rulesController.UpdateRuleAsync(ruleCreationDto.Id, ruleCreationDto);
        var actualMessage = _rulesController.HttpContext.Features.Get<RuleException>();

        Assert.IsType<BadRequestResult>(result);
        Assert.Equal(expected, actualMessage.Message);
    }

    [Fact]
    public async Task ReturnCreated_WhenRuleAdded()
    {
        var ruleDto = GetRuleDtoInstance();
        var ruleCreationDto = GetRuleCreationDtoInstance();
        _ruleService
            .Setup(m => m.UpdateRuleAsync(It.Is<RulePersistance>(r => r is RulePersistance)))
            .ReturnsAsync(ruleDto)
            .Verifiable();
        var result = await _rulesController.UpdateRuleAsync(ruleCreationDto.Id, ruleCreationDto);
        var objectResult = Assert.IsType<OkObjectResult>(result);
        var response = Assert.IsAssignableFrom<RuleDto>(objectResult.Value);
        Assert.NotNull(response);
        Assert.IsType<RuleDto>(response);
    }

    private RuleCreationDto GetRuleCreationDtoInstance()
    {
        var ruleDetailsDto = new RuleDetailsCreationDto()
        {
            RuleName = "SampleRule",
            Statut = "Active",
            StartDate = new DateTime(2023, 12, 31),
            EndDate = new DateTime(2024, 12, 31),
            Comment = "This is a sample rule."
        };

        var affectationDto = new Dtos.AffectationDto()
        {
            AffectedTeam = "TeamA",
            AffectedRegion = "RegionX",
            AffectedEmployee = "John Doe",
            AffectedEmployeeId = "E12345",
            AffectationDate = DateTime.Now,
            AffectationDemandDate = DateTime.Now.AddDays(1)
        };

        var rules = new Dictionary<string, CriterionDto>
        {
            {
                CriteriaEnum.Branch.ToString(),
                new CriterionDto() { Condition = "est parmi", Values = ["A", "B", "C"] }
            }
        };

        return new RuleCreationDto(id: 3, ruleDetailsDto, affectationDto, rules);
    }

    public static RuleDto GetRuleDtoInstance()
    {
        var ruleDetailsDto = new RuleDetailsDto()
        {
            RuleName = "SampleRule",
            Statut = "Active",
            StartDate = new DateTime(2023, 12, 31),
            EndDate = new DateTime(2024, 12, 31),
            Comment = "This is a sample rule.",
            CreationDate = DateTime.Now,
            CreatedBy = "JohnDoe",
            CreatorId = "123",
            UpdateDate = DateTime.Now.AddDays(5),
            UpdatorId = "456"
        };

        var criteresDto = new CriteresDto() { Branch = "A;B;C" };

        var affectationDto = new AffectationDto()
        {
            AffectedTeam = "TeamA",
            AffectedRegion = "RegionX",
            AffectedEmployee = "John Doe",
            AffectedEmployeeId = "E12345",
            AffectationDate = DateTime.Now,
            AffectationDemandDate = DateTime.Now.AddDays(1)
        };
        var conditionsDto = new ConditionsDto() { BranchCondition = "est parmi" };

        return new RuleDto(id: 3, ruleDetailsDto, criteresDto, affectationDto, conditionsDto);
    }
}
