using System.Security.Claims;
using Affectations.App.Controllers.v1;
using Affectations.App.Dtos;
using Affectations.App.Services;
using Affectations.App.Tests.Common;
using Affectations.Domain.Exceptions;
using AxaFrance.E2ELogging;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;

namespace Affectations.App.Tests.Controllers.v1.RulesControllerTests;

public class RulesController_AddRuleAsyncShould
{
    private readonly Mock<ILogger<RulesController>> _logger;
    private readonly Mock<IRuleService> _ruleService;
    private RuleException? _ruleException;
    private readonly RulesController _rulesController;

    public RulesController_AddRuleAsyncShould()
    {
        _logger = new Mock<ILogger<RulesController>>();
        _ruleService = new Mock<IRuleService>();
        _rulesController = new RulesController(_ruleService.Object, _logger.Object);
        var httpContext = new DefaultHttpContext();
        httpContext.User = new ClaimsPrincipal(
            new ClaimsIdentity(new Claim[] { new Claim(ClaimTypes.Email, "your_user_id_here") })
        );

        var correlationContextAccessorMock = new Mock<ICorrelationContextAccessor>();
        var correlationContext = new CorrelationContext("fake_correlation_id");
        correlationContextAccessorMock.Setup(m => m.CorrelationContext).Returns(correlationContext);

        httpContext.RequestServices = new ServiceCollection()
            .AddSingleton(correlationContextAccessorMock.Object)
            .BuildServiceProvider();

        _rulesController.ControllerContext = new ControllerContext { HttpContext = httpContext };
    }

    [Theory]
    [InlineData("Date de début est obligatoire")]
    [InlineData("Date de début n'est pas valide")]
    [InlineData("le Code NAF, Le format a respecter est : xxxxxxx.")]
    [InlineData("Code Syndic : 5 caractères obligatoires.")]
    [InlineData("N° client : seuls les caractères numériques sont acceptés.")]
    [InlineData("Chargé de clientèle : Veuillez respecter le format : S000000.")]
    [InlineData("N° contrat : ne dois pas dépasser 16 caractères.")]
    public async Task ReturnBadRequest_When(string exceptionMessage)
    {
        _ruleException = new RuleException(exceptionMessage);
        var expected = _ruleException.Message;
        _ruleService
            .Setup(m => m.AddRuleAsync(It.Is<RulePersistance>(r => r is RulePersistance)))
            .ThrowsAsync(_ruleException)
            .Verifiable();
        var ruleDto = TestHelper.GetRuleCreationDtoInstance();

        var result = await _rulesController.AddRuleAsync(ruleDto);
        var actualMessage = _rulesController.HttpContext.Features.Get<RuleException>();

        Assert.IsType<BadRequestResult>(result);
        Assert.Equal(expected, actualMessage?.Message);
    }

    [Fact]
    public async Task ReturnCreated_WhenRuleAdded()
    {
        var ruleCreationDto = TestHelper.GetRuleCreationDtoInstance();
        var rulePersistanceDto = TestHelper.GetRulePersistanceInstance();
        var ruleDto = TestHelper.GetRuleDtoInstance();
        _ruleService.Setup(m => m.AddRuleAsync(rulePersistanceDto)).ReturnsAsync(ruleDto).Verifiable();

        var result = await _rulesController.AddRuleAsync(ruleCreationDto);

        Assert.IsType<CreatedAtRouteResult>(result);
    }
}
