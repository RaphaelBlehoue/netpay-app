using System.Security.Claims;
using System.Text;
using Affectations.App.Controllers.v1;
using Affectations.App.Dtos;
using Affectations.App.Models;
using Affectations.App.Services;
using Affectations.App.Tests.Common;
using Affectations.Domain.Exceptions;
using AxaFrance.E2ELogging;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;

namespace Affectations.App.Tests.Controllers.v1.RulesControllerTests;

public class RulesController_ExportRulesShould
{
    private readonly Mock<ILogger<RulesController>> _logger;
    private readonly Mock<IRuleService> _ruleService;
    private RuleException? _ruleException;
    private readonly RulesController _rulesController;
    private readonly FilterRuleDto ruleDto;

    public RulesController_ExportRulesShould()
    {
        _logger = new Mock<ILogger<RulesController>>();
        _ruleService = new Mock<IRuleService>();
        _rulesController = new RulesController(_ruleService.Object, _logger.Object);
        var httpContext = new DefaultHttpContext();
        httpContext.User = new ClaimsPrincipal(
            new ClaimsIdentity(new Claim[] { new Claim(ClaimTypes.Email, "your_user_id_here") })
        );

        var correlationContextAccessorMock = new Mock<ICorrelationContextAccessor>();
        var correlationContext = new CorrelationContext("fake_correlation_id");
        correlationContextAccessorMock.Setup(m => m.CorrelationContext).Returns(correlationContext);

        httpContext.RequestServices = new ServiceCollection()
            .AddSingleton(correlationContextAccessorMock.Object)
            .BuildServiceProvider();

        _rulesController.ControllerContext = new ControllerContext { HttpContext = httpContext };
        ruleDto = TestHelper.GetRuleFilterDtoInstance();
    }

    [Fact]
    public async Task ReturnsNotFound_WhenNoDataFound()
    {
        _ruleException = new RuleException("Not found");
        var expected = _ruleException.Message;

        _ruleService
            .Setup(m => m.ExportRuleCsv(It.Is<FilterRuleDto>(r => r is FilterRuleDto)))
            .ThrowsAsync(_ruleException)
            .Verifiable();

        var result = await _rulesController.ExportRules(ruleDto);
        var objectResult = Assert.IsType<NotFoundResult>(result);
    }

    [Fact]
    public async Task ReturnsBadRequest_WhenRuleDtoIsInvalid()
    {
        _ruleException = new RuleException("Bad request");
        var expected = _ruleException.Message;

        _ruleService
            .Setup(m => m.ExportRuleCsv(It.Is<FilterRuleDto>(r => r is FilterRuleDto)))
            .ThrowsAsync(_ruleException)
            .Verifiable();

        var result = await _rulesController.ExportRules(ruleDto);
        var objectResult = Assert.IsType<BadRequestResult>(result);
    }

    [Fact]
    public async Task ReturnsOk()
    {
        var csvContent = File.ReadAllText("Common/regleIDs.csv");
        var csvFile = new CustomFile
        {
            ContentType = "text/csv",
            FileContents = Encoding.UTF8.GetBytes(csvContent),
            FileName = $"list-{DateTime.Now.ToString("yyyyMMdd-HHmmss")}.csv"
        };
        _ruleService.Setup(m => m.ExportRuleCsv(It.Is<FilterRuleDto>(r => r is FilterRuleDto))).ReturnsAsync(csvFile);

        var result = await _rulesController.ExportRules(ruleDto);

        Assert.IsType<FileContentResult>(result);
        var fileContentResult = (FileContentResult)result;
        var actualContent = Encoding.UTF8.GetString(fileContentResult.FileContents);
        var expected = csvContent.Replace(" ", "").Replace("\r", "").Replace("\n", "");
        var actual = actualContent.Replace(" ", "").Replace("\r", "").Replace("\n", "");
        Assert.Equal(expected, actual);
    }
}
