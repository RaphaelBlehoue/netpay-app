using System.Security.Claims;
using Affectations.App.Controllers.v1;
using Affectations.App.Dtos;
using Affectations.App.Services;
using Affectations.App.Tests.Common;
using Affectations.Domain.Exceptions;
using Affectations.Domain.Models;
using AxaFrance.E2ELogging;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Moq;

namespace Affectations.App.Tests.Controllers.v1.RulesControllerTests;

public class RulesController_SearchRulesAsyncShould
{
    private readonly Mock<ILogger<RulesController>> _logger;
    private readonly Mock<IRuleService> _ruleService;
    private RuleException? _ruleException;
    private readonly RulesController _rulesController;
    private readonly RuleDto ruleDto;
    private const int Page = 1;
    private const int PageMRM = 0;
    private const int Size = 10;

    public RulesController_SearchRulesAsyncShould()
    {
        _logger = new Mock<ILogger<RulesController>>();
        _ruleService = new Mock<IRuleService>();
        _rulesController = new RulesController(_ruleService.Object, _logger.Object);
        var httpContext = new DefaultHttpContext();
        httpContext.User = new ClaimsPrincipal(
            new ClaimsIdentity(new Claim[] { new Claim(ClaimTypes.Email, "your_user_id_here") })
        );

        var correlationContextAccessorMock = new Mock<ICorrelationContextAccessor>();
        var correlationContext = new CorrelationContext("fake_correlation_id");
        correlationContextAccessorMock.Setup(m => m.CorrelationContext).Returns(correlationContext);

        httpContext.RequestServices = new ServiceCollection()
            .AddSingleton(correlationContextAccessorMock.Object)
            .BuildServiceProvider();

        _rulesController.ControllerContext = new ControllerContext { HttpContext = httpContext };
        ruleDto = TestHelper.GetRuleDtoInstance();
    }

    [Fact]
    public async Task ReturnsNotFound_WhenNoDataFound()
    {
        _ruleException = new RuleException("Not found");
        var expected = _ruleException.Message;

        _ruleService
            .Setup(m => m.SearchRulesAsync(PageMRM, Size, It.Is<RuleDto>(r => r is RuleDto)))
            .ThrowsAsync(_ruleException)
            .Verifiable();

        var result = await _rulesController.SearchRulesAsync(Page, Size, ruleDto);
        var objectResult = Assert.IsType<NotFoundResult>(result);
    }

    [Fact]
    public async Task ReturnsBadRequest_WhenRuleDtoIsInvalid()
    {
        _ruleException = new RuleException("Bad request");
        var expected = _ruleException.Message;

        _ruleService
            .Setup(m => m.SearchRulesAsync(PageMRM, Size, It.Is<RuleDto>(r => r is RuleDto)))
            .ThrowsAsync(_ruleException)
            .Verifiable();

        var result = await _rulesController.SearchRulesAsync(Page, Size, ruleDto);
        var objectResult = Assert.IsType<BadRequestResult>(result);
    }

    [Fact]
    public async Task ReturnsOk()
    {
        _ruleService
            .Setup(m => m.SearchRulesAsync(It.IsAny<int>(), It.IsAny<int>(), It.Is<RuleDto>(r => r is RuleDto)))
            .ReturnsAsync(GetPaginationResponseRuleDto());

        var result = await _rulesController.SearchRulesAsync(PageMRM, Size, ruleDto);
        var objectResult = Assert.IsType<OkObjectResult>(result);
    }

    private static PagedData<RuleDto> GetPaginationResponseRuleDto()
    {
        return new PagedData<RuleDto>()
        {
            Page = 1,
            Size = 10,
            TotalPages = 2,
            Data = new List<RuleDto>() { TestHelper.GetRuleDtoInstance() }
        };
    }
}
