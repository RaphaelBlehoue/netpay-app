using Affectations.App.Configuration.RuleCriterionOptions;
using Affectations.App.Controllers.v1;
using Affectations.App.Services;
using Affectations.App.Tests.Common;
using Affectations.Domain.Entities;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;

namespace Affectations.App.Tests.Controllers.v1.RuleCriteriaControllerTests;

public class RuleCriteriaController_GetRuleCriteriaAsyncShould
{
    private readonly Mock<ILogger<RuleCriteriaController>> _logger;
    private readonly Mock<IRuleCriterionService> _ruleCriterionService;
    private readonly Mock<IOptions<RuleCriterionOptions>> _ruleCriterionOptions;

    public RuleCriteriaController_GetRuleCriteriaAsyncShould()
    {
        _logger = new Mock<ILogger<RuleCriteriaController>>();
        _ruleCriterionService = new Mock<IRuleCriterionService>();
        _ruleCriterionOptions = new Mock<IOptions<RuleCriterionOptions>>();
    }

    [Fact]
    public async Task ReturnRuleCriteria_WhenFound()
    {
        _ruleCriterionService
            .Setup(m => m.GetRuleCriteriaAsync(200))
            .ReturnsAsync(TestDataHelper.GetFakeRuleCriteriaDictionary())
            .Verifiable();

        _ruleCriterionOptions.Setup(x => x.Value).Returns(new RuleCriterionOptions() { RowCountPerCriterion = 200 });

        var ruleCriteriaController = new RuleCriteriaController(
            _ruleCriterionService.Object,
            _logger.Object,
            _ruleCriterionOptions.Object
        );

        var result = await ruleCriteriaController.GetRuleCriteriaAsync();

        var objectResult = Assert.IsType<Ok<IDictionary<string, RuleCriterionCategory>>>(result);
        var response = Assert.IsAssignableFrom<IDictionary<string, RuleCriterionCategory>>(objectResult.Value);
        var expected = TestDataHelper.GetFakeRuleCriteriaDictionary();
        response.Should().BeEquivalentTo(expected);
    }
}
