using System.Net.Http.Headers;
using System.Text;
using Affectations.App.Tests.Hooks;
using Affectations.App.Tests.Utils;
using Newtonsoft.Json;

namespace Affectations.App.Tests;

internal class BaseApiActions
{
    protected readonly ScenarioContext _scenarioContext;

    public BaseApiActions(ScenarioContext scenarioContext)
    {
        _scenarioContext = scenarioContext;
    }

    protected HttpClient HttpClient
    {
        get => (HttpClient)_scenarioContext[InitWebApplicationFactory.HttpClientKey];
    }

    protected HttpResponseMessage HttpResponse
    {
        get => (HttpResponseMessage)_scenarioContext[InitWebApplicationFactory.HttpResponseKey];
        set => _scenarioContext[InitWebApplicationFactory.HttpResponseKey] = value;
    }

    protected async Task GetApiAsync(string route)
    {
        HttpClient.DefaultRequestHeaders.Remove("Authorization");
        HttpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(
            TestAuthenticationHandler.AuthenticationScheme
        );
        HttpResponse = await HttpClient.GetAsync(route);
    }

    protected async Task PostApiAsync(string route, HttpContent content)
    {
        HttpClient.DefaultRequestHeaders.Remove("Authorization");
        HttpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(
            TestAuthenticationHandler.AuthenticationScheme
        );

        HttpResponse = await HttpClient.PostAsync(route, content);
    }

    protected async Task PutApiAsync(string route, HttpContent content)
    {
        HttpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(
            TestAuthenticationHandler.AuthenticationScheme
        );

        HttpResponse = await HttpClient.PutAsync(route, content);
    }

    protected async Task<T> GetApiResponseAsync<T>()
    {
        if (_scenarioContext[InitWebApplicationFactory.ApiResponseKey] is T result)
        {
            return result;
        }

        var contentStr = await HttpResponse.Content.ReadAsStringAsync();
        _scenarioContext[InitWebApplicationFactory.ApiResponseKey] = JsonConvert.DeserializeObject<T>(contentStr);
        return (T)_scenarioContext[InitWebApplicationFactory.ApiResponseKey];
    }

    protected static async Task<StringContent> GenerateHttpBodyRequestFromFile(string fileName)
    {
        var fileContent = await File.ReadAllTextAsync(fileName).ConfigureAwait(false);
        return new StringContent(fileContent, Encoding.UTF8, "application/json");
    }
}
