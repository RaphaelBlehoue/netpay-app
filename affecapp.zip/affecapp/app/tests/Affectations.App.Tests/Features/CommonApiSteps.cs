using System.Net;
using Affectations.App.Tests.Hooks;
using Affectations.App.Tests.Utils;
using Microsoft.IdentityModel.Tokens;
using Xunit.Sdk;

namespace Affectations.App.Tests.Features;

[Binding]
[Scope(Tag = "integration")]
internal sealed class CommonApiSteps : BaseApiActions
{
    public CommonApiSteps(ScenarioContext scenarioContext)
        : base(scenarioContext) { }

    [Given("L'utilisateur est connecté en tant que \"(.*)\"")]
    public void GivenLutilisateurEstConnecteEnTantQue(string userRole)
    {
        var config = (TestAuthenticationHandlerOptions)
            _scenarioContext[InitWebApplicationFactory.AuthenticationConfigKey];
        if (userRole.IsNullOrEmpty())
        {
            throw new XunitException($"Le role utilisateur connecté '{userRole}' n'est pas connu.");
        }
        config.UserRole = userRole;
    }

    [Then("Le retour d'API est \"(.*)\"")]
    public void ThenLeRetourDApiEst(string statusCodeStr)
    {
        var statusCode = statusCodeStr switch
        {
            "Success" => HttpStatusCode.OK,
            "Created" => HttpStatusCode.Created,
            "Accepted" => HttpStatusCode.Accepted,
            "Unauthorized" => HttpStatusCode.Unauthorized,
            "Forbidden" => HttpStatusCode.Forbidden,
            "NotFound" => HttpStatusCode.NotFound,
            "InternalServerError" => HttpStatusCode.InternalServerError,
            "BadRequest" => HttpStatusCode.BadRequest,
            _
                => throw new XunitException(
                    $"L'état '{statusCodeStr}' n'est pas prévu dans la step '{nameof(ThenLeRetourDApiEst)}'."
                ),
        };
        HttpResponse.StatusCode.Should().Be(statusCode);
    }
}
