using System.Text;
using System.Text.Json;
using Affectations.App.Dtos;
using Affectations.Domain.Entities;
using Affectations.Domain.Models;
using Affectations.Infrastructure.Data.Models;
using TechTalk.SpecFlow.Assist;

namespace Affectations.App.Tests.Features.Employees;

[Binding]
[Scope(Feature = "Recherche collaborateurs")]
internal sealed class SearchEmployeesSteps : BaseApiActions
{
    private readonly AffectationsContext _context;

    private EmployeeSearchDto _employeeSearchDto;
    private IEnumerable<TEmployee> _employeeEntities;

    private int _expectedTotalData;
    private int _expectedTotalPages;

    public SearchEmployeesSteps(ScenarioContext scenarioContext, AffectationsContext context)
        : base(scenarioContext)
    {
        _context = context;
    }

    [Given(@"La base contient les collaborateurs suivants:")]
    public async Task GivenLaBaseContientLesCollaborateursSuivantsAsync(Table table)
    {
        _employeeEntities = table.CreateSet<TEmployee>();
        await _context.TEmployees.AddRangeAsync(_employeeEntities);
        await _context.SaveChangesAsync();
    }

    [Given(
        @"L'utilisateur souhaite faire une recherche de collaborateurs avec nom de famille commençant par ""(.*)"", numéro de page (.*) et taille de page (.*)"
    )]
    public void GivenLutilisateurSouhaiteFaireUneRechercheDeCollaborateursAvecNomDeFamilleCommencantParNumeroDePageEtTailleDePage(
        string lastNameStartWith,
        int pageNumber,
        int pageSize
    )
    {
        _employeeSearchDto = new EmployeeSearchDto()
        {
            LastNameStartsWithFilter = lastNameStartWith,
            PageNumber = pageNumber,
            PageSize = pageSize
        };
        var filteredEmployeeEntities = _employeeEntities
            .Where(x =>
                !string.IsNullOrEmpty(x.LastName)
                && x.LastName.StartsWith(lastNameStartWith, StringComparison.CurrentCultureIgnoreCase)
            )
            .OrderBy(x => x.LastName);

        var count = filteredEmployeeEntities.Count();
        _expectedTotalData = count;
        _expectedTotalPages = (count / pageSize) + (count % pageSize > 0 ? 1 : 0);
    }

    [Given(@"L'utilisateur souhaite faire une recherche de collaborateurs sans le critère nom de famille")]
    public void GivenLutilisateurSouhaiteFaireUneRechercheDeCollaborateursSansLeCritereNomDeFamille()
    {
        _employeeSearchDto = new EmployeeSearchDto()
        {
            LastNameStartsWithFilter = string.Empty,
            PageNumber = 1,
            PageSize = 10
        };
    }

    [When(@"L'utilisateur récupère la liste de collaborateurs")]
    public async Task WhenLutilisateurRecupereLaListeDeCollaborateursAsync()
    {
        var request = new StringContent(
            JsonSerializer.Serialize(_employeeSearchDto),
            Encoding.UTF8,
            "application/json"
        );
        await PostApiAsync($"api/v1/employees/search", request);
    }

    [Then(@"Les collaborateurs satisfaisants cette condition sont récupérés:")]
    public async Task ThenLesCollaborateursSatisfaisantsCetteConditionSontRecuperesAsync(Table table)
    {
        var actualPagedData = await GetApiResponseAsync<PagedData<Employee>>();
        var expectedEmployees = table.CreateSet<Employee>().ToArray();
        var actualEmployees = actualPagedData.Data.ToArray();

        actualPagedData.Data.Should().BeEquivalentTo(expectedEmployees);
        Assert.Equal(expectedEmployees.Length, actualEmployees.Length);
        for (var i = 0; i < expectedEmployees.Length; i++)
        {
            Assert.True(AreEquivalent(expectedEmployees[i], actualEmployees[i]));
        }
        Assert.Equal(_expectedTotalData, actualPagedData.TotalData);
        Assert.Equal(_expectedTotalPages, actualPagedData.TotalPages);
    }

    [Then(@"La page retournée est vide")]
    public async Task ThenLaPageRetourneeEstVideAsync()
    {
        var actualPagedData = await GetApiResponseAsync<PagedData<Employee>>();
        var actualEmployees = actualPagedData.Data.ToArray();
        Assert.True(actualEmployees.Length == 0);
        Assert.Equal(_expectedTotalData, actualPagedData.TotalData);
        Assert.Equal(_expectedTotalPages, actualPagedData.TotalPages);
    }

    private static bool AreEquivalent(Employee? expectedEmployee, Employee? actualEmployee)
    {
        if (expectedEmployee is null || actualEmployee is null)
        {
            return expectedEmployee is null && actualEmployee is null;
        }

        return expectedEmployee.Id == actualEmployee.Id
            && expectedEmployee.FirstName == actualEmployee.FirstName
            && expectedEmployee.LastName == actualEmployee.LastName;
    }
}
