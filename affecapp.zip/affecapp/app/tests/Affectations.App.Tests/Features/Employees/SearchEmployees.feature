@integration
Feature: Recherche collaborateurs

En tant qu'utilisateur, je veux effectuer une recherche sur les collarateurs presénts dans la base de données d'Easy Affectation afin de récupérer
ceux dont le nom de famille commence par une chaine de mots spécifiée

Background:
        Given La base contient les collaborateurs suivants:
        | Id      | FirstName | LastName  |
        | S004021 | Dubois    | Yvette    |
        | S009670 | Lambert   | Dominique |
        | S009671 | Paul      | Boureau   |
        | S009672 | Michele   | Bouchet   |
        | S009673 | Bruno     | Bousseau  |
        | S009674 | Carla     | Bouchez   |
        | S009675 | Emma      | Bouteiler |

Rule: Si les données des collaborateurs existent en base de données, l'api retourne une liste de collarateurs satisfaisant la chaine de mots voulue

    Scenario: Recherche avec critère nom de famille
        Given L'utilisateur est connecté en tant que "IAM_BAFFO_USER"
        And L'utilisateur souhaite faire une recherche de collaborateurs avec nom de famille commençant par "bou", numéro de page 1 et taille de page 2
        When L'utilisateur récupère la liste de collaborateurs
        Then Les collaborateurs satisfaisants cette condition sont récupérés:
        | Id      | FirstName | LastName  |
        | S009672 | Michele   | Bouchet   |
        | S009674 | Carla     | Bouchez   |

    Scenario: Recherche avec critère nom de famille qui n'existe pas
        Given L'utilisateur est connecté en tant que "IAM_BAFFO_USER"
        And L'utilisateur souhaite faire une recherche de collaborateurs avec nom de famille commençant par "aaa", numéro de page 1 et taille de page 2
        When L'utilisateur récupère la liste de collaborateurs
        Then La page retournée est vide
