using Affectations.Domain.Entities;
using Affectations.Infrastructure.Data.Models;
using TechTalk.SpecFlow.Assist;

namespace Affectations.App.Tests.Features.Teams;

[Binding]
[Scope(Feature = "Information Teams")]
internal sealed class GetTeamsSteps : BaseApiActions
{
    private readonly AffectationsContext _context;

    public GetTeamsSteps(ScenarioContext scenarioContext, AffectationsContext context)
        : base(scenarioContext)
    {
        _context = context;
    }

    [Given(@"La base contient les équipes suivantes:")]
    public async Task GivenLaBaseContientLesEquipesSuivantes(Table table)
    {
        var teams = table.CreateSet<TTeam>();
        await _context.TTeams.AddRangeAsync(teams);
        await _context.SaveChangesAsync();
    }

    [When(@"L'utilisateur récupère la liste des équipes")]
    public async Task WhenLutilisateurRecupereLaListeDesEquipes() => await GetApiAsync($"api/v1/teams");

    [Then("L'utilisateur récupère la liste des équipes suivante:")]
    public async Task ThenLUtilisateurRecupereLaListeDesEquipesSuivante(Table table)
    {
        var expectedResult = table.CreateSet<Team>();
        var teams = await GetApiResponseAsync<IEnumerable<Team>>();
        teams.Count().Should().Be(expectedResult.Count());
        teams.Should().BeEquivalentTo(expectedResult);
    }

    [Then("L'utilisateur récupère la liste des équipes vide")]
    public async Task ThenLUtilisateurRecupereLaListeDesEquipesVide()
    {
        var teams = await GetApiResponseAsync<IEnumerable<Team>>();
        teams.Count().Should().Be(0);
    }
}
