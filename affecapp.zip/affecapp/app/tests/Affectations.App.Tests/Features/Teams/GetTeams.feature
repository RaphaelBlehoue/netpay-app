@integration
Feature: Information Teams

Scenario: L'utilisateur récupère les équipes en base de données
    Given L'utilisateur est connecté en tant que "IAM_BAFFO_USER"
    And La base contient les équipes suivantes:
        | Code                | Name                |
        | ES_CONSTRUCTION_IDF | ES_CONSTRUCTION_IDF |
        | ES_DAB1_IDF         | ES_DAB1_IDF         |
    When L'utilisateur récupère la liste des équipes
    Then Le retour d'API est "Success"
    And L'utilisateur récupère la liste des équipes suivante:
            | Code                | Name                |
            | ES_CONSTRUCTION_IDF | ES_CONSTRUCTION_IDF |
            | ES_DAB1_IDF         | ES_DAB1_IDF         |

Scenario: L'utilisateur récupère une liste des équipes vide
    Given L'utilisateur est connecté en tant que "IAM_BAFFO_USER"
    When L'utilisateur récupère la liste des équipes
    Then Le retour d'API est "Success"
    And L'utilisateur récupère la liste des équipes vide
