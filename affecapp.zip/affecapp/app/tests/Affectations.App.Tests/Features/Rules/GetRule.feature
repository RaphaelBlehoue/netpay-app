@integration
Feature: Get rule

En tant qu'utilisateur, je veux récupérer une règle afin d'avoir ces informations

Rule: Si l'identifiant de la règle n'existe pas, l'api retourne une erreur

    Scenario: La règle n'existe pas
    Given L'utilisateur est connecté en tant que "IAM_BAFFO_USER"
    When L'utilisateur récupère la règle inexistante avec l'id 2
    Then Le retour d'API est "NotFound"

Rule: Si l'identifiant de la règle existe, l'api retourne la règle

    Scenario: La règle existe
    Given L'utilisateur est connecté en tant que "IAM_BAFFO_USER"
    When L'utilisateur récupère la règle existante avec l'id 1
    Then La règle est récupéréé
