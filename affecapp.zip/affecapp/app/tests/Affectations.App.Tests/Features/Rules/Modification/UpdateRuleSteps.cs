using Affectations.App.Tests.Common;
using Affectations.Infrastructure.Stores;
using Microsoft.IdentityModel.Tokens;
using Moq;

namespace Affectations.App.Tests.Features.Rules.Modification;

[Binding]
[Scope(Feature = "Update rule")]
internal sealed class UpdateRuleSteps : BaseApiActions
{
    public UpdateRuleSteps(ScenarioContext scenarioContext)
        : base(scenarioContext) { }

    [When(@"L'utilisateur envoie une règle valide ""([^""]*)""")]
    public async Task WhenLutilisateurEnvoieUneRegleValide(string jsonFile)
    {
        if (!jsonFile.IsNullOrEmpty())
        {
            var ruleStore = (Mock<IRulesStore>)_scenarioContext["RuleStore"];
            ruleStore
                .Setup(x => x.UpdateRuleAsync(It.IsAny<RuleDto>()))
                .ReturnsAsync(TestHelper.GetMrmRuleDtoInstance());
            var request = await GenerateHttpBodyRequestFromFile(jsonFile);
            await PutApiAsync($"api/v1/rules/1", request);
        }
    }

    [When(@"L'utilisateur envoie une règle non valide ""([^""]*)""")]
    public async Task WhenLutilisateurEnvoieUneRegleNonValide(string jsonFile)
    {
        if (!jsonFile.IsNullOrEmpty())
        {
            var ruleStore = (Mock<IRulesStore>)_scenarioContext["RuleStore"];
            ruleStore
                .Setup(x => x.UpdateRuleAsync(It.IsAny<RuleDto>()))
                .ReturnsAsync(TestHelper.GetMrmRuleDtoInstance());
            var request = await GenerateHttpBodyRequestFromFile(jsonFile);
            await PutApiAsync($"api/v1/rules/1", request);
        }
    }

    [Then(@"Le retour contient l'objet modifié")]
    public async Task ThenLeRetourContientLobjetModifie()
    {
        var rule = await GetApiResponseAsync<Dtos.RuleDto>();
        var expectedId = 1;
        Assert.NotNull(rule);
        Assert.IsType<Dtos.RuleDto>(rule);
        Assert.Equal(expectedId, rule.Id);
    }
}
