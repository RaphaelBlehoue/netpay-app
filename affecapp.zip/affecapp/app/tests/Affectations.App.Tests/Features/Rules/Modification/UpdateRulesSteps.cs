using System.Text;
using Affectations.App.Tests.Common;
using Affectations.Infrastructure.Stores;
using Microsoft.IdentityModel.Tokens;
using Moq;

namespace Affectations.App.Tests.Features.Rules.Modification;

[Binding]
[Scope(Feature = "Update rules")]
internal sealed class UpdateRulesSteps : BaseApiActions
{
    public UpdateRulesSteps(ScenarioContext scenarioContext)
        : base(scenarioContext) { }

    [When(@"L'utilisateur envoie une liste de règles valides ""(.*)""")]
    public async Task WhenLutilisateurEnvoieUneListeDeReglesValidesAsync(string jsonFile)
    {
        if (!jsonFile.IsNullOrEmpty())
        {
            var ruleStore = (Mock<IRulesStore>)_scenarioContext["RuleStore"];
            var ruleMassUpdateInstance = TestHelper.GetRuleMassUpdateInstance();
            ruleStore
                .Setup(x =>
                    x.UpdateRulesAsync(It.Is<BulkUpdateDto>(d => TestHelper.AreEquivalent(ruleMassUpdateInstance, d)))
                )
                .ReturnsAsync(2)
                .Verifiable();
            var request = await GenerateHttpBodyRequestFromFile(jsonFile);
            await PutApiAsync($"api/v1/rules", request);
        }
    }

    [When(@"L'utilisateur envoie une liste de règles non valides")]
    public async Task WhenLutilisateurEnvoieUneListeDeReglesNonValidesAsync()
    {
        var ruleStore = (Mock<IRulesStore>)_scenarioContext["RuleStore"];
        var ruleMassUpdateInstance = TestHelper.GetRuleMassUpdateInstance();
        ruleStore
            .Setup(x =>
                x.UpdateRulesAsync(It.Is<BulkUpdateDto>(d => TestHelper.AreEquivalent(ruleMassUpdateInstance, d)))
            )
            .ReturnsAsync(0)
            .Verifiable();
        var request = new StringContent(string.Empty, Encoding.UTF8, "application/json");
        await PutApiAsync($"api/v1/rules", request);
    }

    [Then(@"Le retour contient le nombre de règles modifiés")]
    public async Task ThenLeRetourContientLeNombreDeReglesModifiesAsync()
    {
        var expectedResult = 2;
        var actualResult = await GetApiResponseAsync<int>();
        Assert.Equal(expectedResult, actualResult);
    }
}
