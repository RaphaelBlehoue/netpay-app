@integration
Feature: Update rule

Scenario: L'utilisateur veut modifier une règle valide.
Given L'utilisateur est connecté en tant que "IAM_BAFFO_UPDATE"
When L'utilisateur envoie une règle valide "Features/Rules/Modification/data/RegleValide.json"
Then Le retour d'API est "Success"
And Le retour contient l'objet modifié

Scenario: L'utilisateur veut modifier une règle non valide.
Given L'utilisateur est connecté en tant que "IAM_BAFFO_UPDATE"
When L'utilisateur envoie une règle non valide "Features/Rules/Modification/data/RegleNonValide.json"
Then Le retour d'API est "BadRequest"
