@integration
Feature: Update rules

En tant qu'utilisateur, je veux modifier plusieurs règles existantes afin de mettre à jour les éléments souhaités de ces règles.

Scenario: L'utilisateur veut modifier une liste de règles valides.
Given L'utilisateur est connecté en tant que "IAM_BAFFO_UPDATE"
When L'utilisateur envoie une liste de règles valides "Features/Rules/Modification/data/MassUpdateValidRules.json"
Then Le retour d'API est "Success"
And Le retour contient le nombre de règles modifiés

Scenario: L'utilisateur veut modifier une liste de règles non valides.
Given L'utilisateur est connecté en tant que "IAM_BAFFO_UPDATE"
When L'utilisateur envoie une liste de règles non valides
Then Le retour d'API est "BadRequest"
