using System.Net;
using Affectations.App.Tests.Common;
using Affectations.Infrastructure.Stores;
using Moq;

namespace Affectations.App.Tests.Features.Rules;

[Binding]
[Scope(Feature = "Get rule")]
internal sealed class GetRuleSteps : BaseApiActions
{
    public GetRuleSteps(ScenarioContext scenarioContext)
        : base(scenarioContext) { }

    [When(@"L'utilisateur récupère la règle inexistante avec l'id (.*)")]
    public async Task WhenLutilisateurRecupereLaRegleInexistante(int id)
    {
        var ruleStore = (Mock<IRulesStore>)_scenarioContext["RuleStore"];
        ruleStore
            .Setup(x => x.GetRuleByIdAsync(It.IsAny<long>()))
            .ThrowsAsync(new ClientMRMApiException("Not Found", (int)HttpStatusCode.NotFound, null, null, null));
        await GetApiAsync($"api/v1/rules/{id}");
    }

    [When(@"L'utilisateur récupère la règle existante avec l'id (.*)")]
    public async Task WhenLutilisateurRecupereLaRegleExistante(int id)
    {
        var ruleStore = (Mock<IRulesStore>)_scenarioContext["RuleStore"];
        ruleStore.Setup(x => x.GetRuleByIdAsync(It.IsAny<long>())).ReturnsAsync(TestHelper.GetMrmRuleDtoInstance());
        await GetApiAsync($"api/v1/rules/{id}");
    }

    [Then(@"La règle est récupéréé")]
    public async Task ThenLaRegleEstRecuperee()
    {
        var rule = await GetApiResponseAsync<Dtos.RuleDto>();
        var expectedId = 1;
        Assert.NotNull(rule);
        Assert.Equal(expectedId, rule.Id);
    }
}
