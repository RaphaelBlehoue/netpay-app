@integration
Feature: Add rule

Scenario: L'utilisateur veut ajouter une règle valide.
Given L'utilisateur est connecté en tant que "IAM_BAFFO_UPDATE"
When L'utilisateur ajoute une règle valide "Features/Rules/Addition/data/RegleValide.json"
Then Le retour d'API est "Created"
And Le retour contient l'objet ajouté

Scenario: L'utilisateur veut ajouter une règle non valide.
Given L'utilisateur est connecté en tant que "IAM_BAFFO_UPDATE"
When L'utilisateur ajoute une règle non valide "Features/Rules/Addition/data/RegleNonValide.json"
Then Le retour d'API est "BadRequest"
