using Affectations.App.Tests.Common;
using Affectations.Infrastructure.Stores;
using Microsoft.IdentityModel.Tokens;
using Moq;

namespace Affectations.App.Tests.Features.Rules.Addition;

[Binding]
[Scope(Feature = "Add rule")]
internal sealed class AddRuleSteps : BaseApiActions
{
    public AddRuleSteps(ScenarioContext scenarioContext)
        : base(scenarioContext) { }

    [When(@"L'utilisateur ajoute une règle valide ""([^""]*)""")]
    public async Task WhenLutilisateurAjouteUneRegleValide(string jsonFile)
    {
        if (!jsonFile.IsNullOrEmpty())
        {
            var ruleStore = (Mock<IRulesStore>)_scenarioContext["RuleStore"];
            ruleStore.Setup(x => x.AddRuleAsync(It.IsAny<RuleDto>())).ReturnsAsync(TestHelper.GetMrmRuleDtoInstance());
            var request = await GenerateHttpBodyRequestFromFile(jsonFile);
            await PostApiAsync($"api/v1/rules", request);
        }
    }

    [When(@"L'utilisateur ajoute une règle non valide ""([^""]*)""")]
    public async Task WhenLutilisateurAjouteUneRegleNonValide(string jsonFile)
    {
        if (!jsonFile.IsNullOrEmpty())
        {
            var ruleStore = (Mock<IRulesStore>)_scenarioContext["RuleStore"];
            ruleStore.Setup(x => x.AddRuleAsync(It.IsAny<RuleDto>())).ReturnsAsync(TestHelper.GetMrmRuleDtoInstance());
            var request = await GenerateHttpBodyRequestFromFile(jsonFile);
            await PostApiAsync($"api/v1/rules", request);
        }
    }

    [Then(@"Le retour contient l'objet ajouté")]
    public async Task ThenLeRetourContientLobjetAjoute()
    {
        var rule = await GetApiResponseAsync<Dtos.RuleDto>();
        Assert.NotNull(rule);
    }
}
