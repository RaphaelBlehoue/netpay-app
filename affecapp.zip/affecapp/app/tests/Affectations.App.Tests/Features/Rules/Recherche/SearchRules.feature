@integration
Feature: Search rules
En tant qu'utilisateur, je veux avoir les règles affichés dans un tableau afin de les visualiser facilement


Scenario: Je récupère la liste des règles existantes sans criteres de recherche
Given L'utilisateur est connecté en tant que "IAM_BAFFO_USER"
When Je récupère la liste des règles existante avec les paramètres page 0 et le size 10 et les criteres de recherche Features/Rules/Recherche/data/DefaultDtoRecherche.json
Then Le retour d'API est "Success"
And Je récupère la liste des règles dans le fichier JSON Features/Rules/Recherche/data/Regles.json

Scenario: Je récupère la liste des règles inexistantes
Given L'utilisateur est connecté en tant que "IAM_BAFFO_USER"
When Je récupère la liste des règles inexistante avec les paramètres page 1 et le size 10 avec les criteres de recherche du fichier JSON Features/Rules/Recherche/data/DtoRecherche.json
Then Le retour d'API est "BadRequest"



