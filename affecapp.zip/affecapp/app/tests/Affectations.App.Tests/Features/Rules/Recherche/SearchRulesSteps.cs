using System.Net;
using System.Text.Json;
using Affectations.App.Tests.Common;
using Affectations.Domain.Models;
using Affectations.Infrastructure.Stores;
using Microsoft.IdentityModel.Tokens;
using Moq;

namespace Affectations.App.Tests.Features.Rules.recherche;

[Binding]
[Scope(Feature = "Search rules")]
internal sealed class SearchRulesSteps : BaseApiActions
{
    private PagedData<Dtos.RuleDto>? PagedRule;
    List<Dtos.RuleDto> ruleDtos = new List<Dtos.RuleDto>();

    public SearchRulesSteps(ScenarioContext scenarioContext)
        : base(scenarioContext) { }

    [When(
        @"Je récupère la liste des règles existante avec les paramètres page (.*) et le size (.*) et les criteres de recherche (.*)"
    )]
    public async Task WhenJeRecupereLaListeDesReglesExistante(int page, int size, string jsonFile)
    {
        var ruleStore = (Mock<IRulesStore>)_scenarioContext["RuleStore"];
        ruleStore
            .Setup(x => x.GetAllRulesAsync(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<FiltreRulesDto>()))
            .ReturnsAsync(TestHelper.GetPaginationResponseRuleDto());
        var request = await GenerateHttpBodyRequestFromFile(jsonFile);
        await PostApiAsync($"/api/v1/rules/search?page={page}&size={size}", request);
    }

    [Then(@"Je récupère la liste des règles dans le fichier JSON (.*)")]
    public async Task ThenJeRecupereLaListeDesReglesDansLeFichierJSON(string jsonFile)
    {
        if (!jsonFile.IsNullOrEmpty())
        {
            var jsonContent = File.ReadAllText(jsonFile);
            ruleDtos = JsonSerializer.Deserialize<List<Dtos.RuleDto>>(jsonContent);
            PagedRule = GetPaginationResponseRuleDto(ruleDtos);
        }
        var data = await GetApiResponseAsync<PagedData<Dtos.RuleDto>>();
        Assert.NotNull(data);
        var expected = PagedRule;
        data.Data.Count().Should().Be(expected.Data.Count());
    }

    [When(
        @"Je récupère la liste des règles inexistante avec les paramètres page (.*) et le size (.*) avec les criteres de recherche du fichier JSON (.*)"
    )]
    public async Task WhenJeRecupereLaListeDesReglesInexistanteAvecLesParametresPageEtLeSizeAvecLesCriteresDeRechercheDuFichierJSONFeaturesRulesRechercheDataDtoRecherche_Json(
        int page,
        int size,
        string jsonFile
    )
    {
        var ruleStore = (Mock<IRulesStore>)_scenarioContext["RuleStore"];
        ruleStore
            .Setup(x => x.GetAllRulesAsync(It.IsAny<int>(), It.IsAny<int>(), It.IsAny<FiltreRulesDto>()))
            .ThrowsAsync(new ClientMRMApiException("Not Found", (int)HttpStatusCode.NotFound, null, null, null));
        var request = await GenerateHttpBodyRequestFromFile(jsonFile);
        await PostApiAsync($"/api/v1/rules/search?page={page}&size={size}", request);
    }

    private static PagedData<Dtos.RuleDto> GetPaginationResponseRuleDto(List<Dtos.RuleDto> ruleDtos)
    {
        return new PagedData<Dtos.RuleDto>()
        {
            Page = 0,
            Size = 10,
            TotalPages = 1,
            Data = ruleDtos
        };
    }
}
