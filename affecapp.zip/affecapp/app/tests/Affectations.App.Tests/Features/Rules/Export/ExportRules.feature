@integration
Feature: Export rules
En tant qu'utilisateur, je veux exporter une règles ou liste des règles


Scenario: J'exporte une règle via son id
Given L'utilisateur est connecté en tant que "IAM_BAFFO_USER"
When J'exporte une règle via son id dans l'objet suivant Features/Rules/Export/data/ExportFilterId.json
Then Le retour d'API est "Success"
And Je récupère le fichier csv suivant Common/regleID.csv

Scenario: J'exporte une liste des règles via leurs ids
Given L'utilisateur est connecté en tant que "IAM_BAFFO_USER"
When J'exporte une liste des règles via leurs ids dans l'objet suivant Features/Rules/Export/data/ExportFilterIds.json
Then Le retour d'API est "Success"
And Je récupère le fichier csv suivant Common/regleIDs.csv

Scenario: J'exporte une liste des règles via un filtre
Given L'utilisateur est connecté en tant que "IAM_BAFFO_USER"
When J'exporte une liste des règles via un filtre dans l'objet suivant Features/Rules/Export/data/ExportFilterIds.json
Then Le retour d'API est "Success"
And Je récupère le fichier csv suivant Common/regleFilter.csv

