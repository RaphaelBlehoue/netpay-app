using Affectations.App.Tests.Common;
using Affectations.Infrastructure.Stores;
using Microsoft.IdentityModel.Tokens;
using Moq;

namespace Affectations.App.Tests.Features.Rules.Export;

[Binding]
[Scope(Feature = "Export rules")]
internal sealed class ExportRulesSteps : BaseApiActions
{
    public ExportRulesSteps(ScenarioContext scenarioContext)
        : base(scenarioContext) { }

    [When(@"J'exporte une règle via son id dans l'objet suivant (.*)")]
    public async Task WhenJExportUneRegleViaSonId(string jsonFile)
    {
        var request = await GenerateHttpBodyRequestFromFile(jsonFile);
        //var filterDto = await GetMrmFilterDto(request);
        var ruleStore = (Mock<IRulesStore>)_scenarioContext["RuleStore"];
        ruleStore
            .Setup(x => x.ExportReglesAsync(It.Is<FiltreRulesDto>(r => r is FiltreRulesDto)))
            .ReturnsAsync(TestHelper.GetRuleDtoCollection());
        await PostApiAsync($"/api/v1/rules/export", request);
    }

    [When(@"J'exporte une liste des règles via leurs ids dans l'objet suivant (.*)")]
    public async Task WhenJExportUneListeDesReglesViaLeursIds(string jsonFile)
    {
        var request = await GenerateHttpBodyRequestFromFile(jsonFile);
        var ruleStore = (Mock<IRulesStore>)_scenarioContext["RuleStore"];
        ruleStore
            .Setup(x => x.ExportReglesAsync(It.Is<FiltreRulesDto>(r => r is FiltreRulesDto)))
            .ReturnsAsync(TestHelper.GetRulesDtoCollection());
        await PostApiAsync($"/api/v1/rules/export", request);
    }

    [When(@"J'exporte une liste des règles via un filtre dans l'objet suivant (.*)")]
    public async Task WhenJExportUneListeDesReglesViaUnFiltre(string jsonFile)
    {
        var request = await GenerateHttpBodyRequestFromFile(jsonFile);
        var ruleStore = (Mock<IRulesStore>)_scenarioContext["RuleStore"];
        ruleStore
            .Setup(x => x.ExportReglesAsync(It.Is<FiltreRulesDto>(r => r is FiltreRulesDto)))
            .ReturnsAsync(TestHelper.GetRuleDtoCollection());
        await PostApiAsync($"/api/v1/rules/export", request);
    }

    [Then(@"Je récupère le fichier csv suivant (.*)")]
    public async Task ThenJeRecupereLeFichierCsvSuivant(string jsonFile)
    {
        if (!jsonFile.IsNullOrEmpty())
        {
            var csv = File.ReadAllText(jsonFile);
            var data = await HttpResponse.Content.ReadAsStringAsync();
            Assert.NotNull(data);
            var expected = csv.Replace(" ", "").Replace("\r", "").Replace("\n", "");
            var actual = data.Replace(" ", "").Replace("\r", "").Replace("\n", "");
            Assert.Equal(expected, actual);
        }
    }
}
