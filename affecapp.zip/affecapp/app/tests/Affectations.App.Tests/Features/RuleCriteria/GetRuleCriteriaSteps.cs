using Affectations.Domain.Entities;
using Affectations.Infrastructure.Data.Models;
using TechTalk.SpecFlow.Assist;

namespace Affectations.App.Tests.Features.RuleCriteria;

[Binding]
[Scope(Feature = "Récupération des référentiels")]
internal sealed class GetRuleCriteriaSteps : BaseApiActions
{
    private readonly AffectationsContext _context;
    private const int _categoryCount = 2;

    public GetRuleCriteriaSteps(ScenarioContext scenarioContext, AffectationsContext context)
        : base(scenarioContext)
    {
        _context = context;
    }

    [Given(@"La base de données contient les catégories des critères suivants:")]
    public async Task GivenLaBaseContientLesCategoriesDesCriteresSuivants(Table table)
    {
        var criterionCategories = table.CreateSet<TRuleCriterionCategory>();
        await _context.TRuleCriterionCategories.AddRangeAsync(criterionCategories);
        await _context.SaveChangesAsync();
    }

    [Given(@"La base de données contient les critères suivants:")]
    public async Task GivenLaBaseContientLesCriteresSuivant(Table table)
    {
        var criterions = table.CreateSet<TRuleCriterion>();
        await _context.TRuleCriteria.AddRangeAsync(criterions);
        await _context.SaveChangesAsync();
    }

    [When(@"L'utilisateur récupère la liste des critères")]
    public async Task WhenLutilisateurRecupereLaListeDesEquipes() => await GetApiAsync($"api/v1/rule-criteria");

    [Then("L'utilisateur récupère la liste des critères par catégories")]
    public async Task ThenLUtilisateurRecupereLaListeDesCriteresParCategories()
    {
        var criterions = await GetApiResponseAsync<IDictionary<string, RuleCriterionCategory>>();
        criterions.Count().Should().BeGreaterThanOrEqualTo(_categoryCount);
    }
}
