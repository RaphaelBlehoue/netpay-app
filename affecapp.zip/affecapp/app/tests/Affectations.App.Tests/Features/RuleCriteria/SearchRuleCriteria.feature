@integration
Feature: Recherche critères

En tant qu'utilisateur, je veux effectuer une recherche sur un critère choisi presént dans la base de données d'Easy Affectation afin de récupérer
les données liées dont le libellé commence par une chaine de mots spécifiée

Background:
   Given La base contient les catégories de critère suivants:
    | Code              | Label            |
    | INTERMEDIARY_NAME | Nom intermédiare |
   Given La base contient les critères suivants:
    | Code  | Label       | RuleCriterionCategoryCode |
    | Code1 | FRANCOIS A1 | INTERMEDIARY_NAME         |
    | Code2 | FRANCOIS A2 | INTERMEDIARY_NAME         |
    | Code3 | FRANCOIS A3 | INTERMEDIARY_NAME         |
    | Code4 | FRANCOIS A4 | INTERMEDIARY_NAME         |
    | Code5 | FRANCOIS A5 | INTERMEDIARY_NAME         |
    | Code6 | PAUL A1     | INTERMEDIARY_NAME         |
    | Code7 | PAUL A1     | INTERMEDIARY_NAME         |

Rule: Si les données liées au critère choisi existent dans la base de données, l'api retourne une liste de données liées satisfaisant la chaine de mots voulue pour le critère choisi

Scenario: Recherche nom intermédiare avec les bons paramètres
    Given L'utilisateur est connecté en tant que "IAM_BAFFO_USER"
    And L'utilisateur souhaite faire une recherche sur le critère "INTERMEDIARY_NAME" dont le libellé commence par "fra", numéro de page 1 et taille de page 2
    When L'utilisateur récupère la liste des données liées au critère choisi
    Then Les données liées au critère choisi satisfaisants cette condition sont récupérées:
    | Code  | Label       |
    | Code1 | FRANCOIS A1 |
    | Code2 | FRANCOIS A2 |

Scenario: Recherche nom intermédiare avec un libellé qui n'existe pas
    Given L'utilisateur est connecté en tant que "IAM_BAFFO_USER"
    And L'utilisateur souhaite faire une recherche sur le critère "INTERMEDIARY_NAME" dont le libellé commence par "aaa", numéro de page 1 et taille de page 2
    When L'utilisateur récupère la liste des données liées au critère choisi
    Then La page retournée est vide
