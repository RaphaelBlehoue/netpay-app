@integration
Feature: Récupération des référentiels

En tant qu'utilisateur, je veux avoir des référentiels stockés dans EASY Affectation afin de les utiliser dans des listes déroulantes ou à la saisie


Scenario: L'utilisateur récupère la liste des référentiels
    Given L'utilisateur est connecté en tant que "IAM_BAFFO_USER"
    And La base de données contient les catégories des critères suivants:
        | Code                 | Label                |
        | BRANCH               | BRANCH               |
        | QP_CONTRACT_CATEGORY | QP_CONTRACT_CATEGORY |
    And La base de données contient les critères suivants:
        | Code            | Label           | RuleCriterionCategoryCode |
        | Auto            | Auto            | BRANCH                    |
        | Construction    | Construction    | BRANCH                    |
        | QP classique SC | QP classique SC | QP_CONTRACT_CATEGORY      |
        | Black List      | Black List      | QP_CONTRACT_CATEGORY      |
    When L'utilisateur récupère la liste des critères
    Then Le retour d'API est "Success"
    And L'utilisateur récupère la liste des critères par catégories


