using System.Text;
using System.Text.Json;
using Affectations.App.Dtos;
using Affectations.App.Tests.Common;
using Affectations.Domain.Entities;
using Affectations.Domain.Models;
using Affectations.Infrastructure.Data.Models;
using TechTalk.SpecFlow.Assist;

namespace Affectations.App.Tests.Features.RuleCriteria;

[Binding]
[Scope(Feature = "Recherche critères")]
internal sealed class SearchRuleCriteriaSteps : BaseApiActions
{
    private readonly AffectationsContext _context;

    private RuleCriterionSearchDto _ruleCriterionSearchDto;

    private int _expectedTotalData;
    private int _expectedTotalPages;

    public SearchRuleCriteriaSteps(ScenarioContext scenarioContext, AffectationsContext context)
        : base(scenarioContext)
    {
        _context = context;
    }

    [Given(@"La base contient les catégories de critère suivants:")]
    public async Task GivenLaBaseContientLesCategoriesDeCritereSuivantsAsync(Table table)
    {
        var ruleCriterionCategories = table.CreateSet<TRuleCriterionCategory>();
        await _context.TRuleCriterionCategories.AddRangeAsync(ruleCriterionCategories);
        await _context.SaveChangesAsync();
    }

    [Given(@"La base contient les critères suivants:")]
    public async Task GivenLaBaseContientLesCriteresSuivantsAsync(Table table)
    {
        var ruleCriteria = table.CreateSet<TRuleCriterion>();
        await _context.TRuleCriteria.AddRangeAsync(ruleCriteria);
        await _context.SaveChangesAsync();
    }

    [Given(
        @"L'utilisateur souhaite faire une recherche sur le critère ""(.*)"" dont le libellé commence par ""(.*)"", numéro de page (.*) et taille de page (.*)"
    )]
    public void GivenLutilisateurSouhaiteFaireUneRechercheSurLeCritereDontLeLibelleCommenceParNumeroDePageEtTailleDePage(
        string categoryCode,
        string labelStartsWithFilter,
        int pageNumber,
        int pageSize
    )
    {
        _ruleCriterionSearchDto = new RuleCriterionSearchDto()
        {
            CategoryCode = categoryCode,
            LabelStartsWithFilter = labelStartsWithFilter,
            PageNumber = pageNumber,
            PageSize = pageSize
        };

        var entitiesToSkip = (pageNumber - 1) * pageSize;

        var filteredRuleCriteria = TestDataHelper
            .GetIntermediaryNameTRuleCriterion()
            .Where(x =>
                x.RuleCriterionCategoryCode == categoryCode
                && !string.IsNullOrEmpty(x.Label)
                && x.Label.StartsWith(labelStartsWithFilter, StringComparison.CurrentCultureIgnoreCase)
            );

        var count = filteredRuleCriteria.Count();
        _expectedTotalData = count;
        _expectedTotalPages = (count / pageSize) + (count % pageSize > 0 ? 1 : 0);
    }

    [When(@"L'utilisateur récupère la liste des données liées au critère choisi")]
    public async Task WhenLutilisateurRecupereLaListeDesDonneesLieesAuCritereChoisiAsync()
    {
        var request = new StringContent(
            JsonSerializer.Serialize(_ruleCriterionSearchDto),
            Encoding.UTF8,
            "application/json"
        );
        await PostApiAsync($"api/v1/rule-criteria/search", request);
    }

    [Then(@"Les données liées au critère choisi satisfaisants cette condition sont récupérées:")]
    public async Task ThenLesDonneesLieesAuCritereChoisiSatisfaisantsCetteConditionSontRecupereesAsync(Table table)
    {
        var actualPagedData = await GetApiResponseAsync<PagedData<RuleCriterion>>();
        var expectedRuleCriteria = table.CreateSet<RuleCriterion>().ToArray();
        var actualRuleCriteria = actualPagedData.Data.ToArray();

        actualPagedData.Data.Should().BeEquivalentTo(expectedRuleCriteria);
        Assert.Equal(expectedRuleCriteria.Length, actualRuleCriteria.Length);
        for (var i = 0; i < expectedRuleCriteria.Length; i++)
        {
            Assert.True(AreEquivalent(expectedRuleCriteria[i], actualRuleCriteria[i]));
        }
        Assert.Equal(_expectedTotalData, actualPagedData.TotalData);
        Assert.Equal(_expectedTotalPages, actualPagedData.TotalPages);
    }

    [Then(@"La page retournée est vide")]
    public async Task ThenLaPageRetourneeEstVideAsync()
    {
        var actualPagedData = await GetApiResponseAsync<PagedData<RuleCriterion>>();
        var actualRuleCriteria = actualPagedData.Data.ToArray();
        Assert.True(actualRuleCriteria.Length == 0);
        Assert.Equal(_expectedTotalData, actualPagedData.TotalData);
        Assert.Equal(_expectedTotalPages, actualPagedData.TotalPages);
    }

    private static bool AreEquivalent(RuleCriterion? expectedRuleCriterion, RuleCriterion? actualRuleCriterion)
    {
        if (expectedRuleCriterion is null || actualRuleCriterion is null)
        {
            return expectedRuleCriterion is null && actualRuleCriterion is null;
        }

        return expectedRuleCriterion.Code == actualRuleCriterion.Code
            && expectedRuleCriterion.Label == actualRuleCriterion.Label;
    }
}
