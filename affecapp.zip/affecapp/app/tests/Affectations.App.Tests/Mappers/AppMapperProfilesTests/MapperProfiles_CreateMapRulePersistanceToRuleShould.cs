using Affectations.App.Constants;
using Affectations.App.Dtos;
using Affectations.App.Mappers;
using Affectations.Domain.AggregatesRoots.RuleAggregate;
using AutoMapper;

namespace Affectations.App.Tests.Mappers.AppMapperProfilesTests;

public class MapperProfiles_CreateMapRulePersistanceToRuleShould
{
    private static readonly DateTime currentDateTime = DateTime.Now;

    private readonly IMapper _mapper;

    public MapperProfiles_CreateMapRulePersistanceToRuleShould()
    {
        _mapper = new MapperConfiguration(cfg => cfg.AddProfile<MapperProfiles>()).CreateMapper();
    }

    [Fact]
    public void ReturnsRule()
    {
        var rulePersistance = GetRulePersistanceInstance();
        var actualRule = _mapper.Map<Rule>(rulePersistance);
        var expectedRule = GetRuleInstance();
        Assert.True(AreEquivalent(expectedRule, actualRule));
    }

    private static RulePersistance GetRulePersistanceInstance()
    {
        var ruleDetailsDto = new RuleDetailsDto()
        {
            RuleName = "Rule1",
            Statut = "active",
            StartDate = new DateTime(2023, 12, 31),
            EndDate = new DateTime(2024, 12, 31),
            Comment = "This is a sample rule.",
            CreationDate = currentDateTime,
            CreatedBy = "JohnDoe",
            CreatorId = "123",
            UpdateDate = currentDateTime.AddDays(5),
            UpdatorId = "456"
        };

        var affectationDto = new AffectationDto()
        {
            AffectedTeam = "TeamA",
            AffectedRegion = "RegionX",
            AffectedEmployee = "John Doe",
            AffectedEmployeeId = "E12345",
            AffectationDate = currentDateTime,
            AffectationDemandDate = currentDateTime.AddDays(1)
        };

        var rules = new Dictionary<string, CriterionDto>
        {
            {
                CriteriaNames.AccountManager,
                new CriterionDto() { Condition = "est parmi", Values = ["S123456"] }
            },
            {
                CriteriaNames.Branch,
                new CriterionDto() { Condition = "est parmi", Values = ["A", "B", "C"] }
            },
            {
                CriteriaNames.Clause,
                new CriterionDto() { Condition = "est parmi", Values = ["670000"] }
            },
            {
                CriteriaNames.ClientNumber,
                new CriterionDto() { Condition = "est parmi", Values = ["123456789"] }
            },
            {
                CriteriaNames.ContractCategory,
                new CriterionDto() { Condition = "est parmi", Values = ["Finance"] }
            },
            {
                CriteriaNames.ContractNumber,
                new CriterionDto() { Condition = "est parmi", Values = ["987654321"] }
            },
            {
                CriteriaNames.Copht,
                new CriterionDto() { Condition = "plus grand ou égal à", Values = ["2"] }
            },
            {
                CriteriaNames.Department,
                new CriterionDto() { Condition = "est parmi", Values = ["D1"] }
            },
            {
                CriteriaNames.IntermediateName,
                new CriterionDto() { Condition = "est parmi", Values = ["Nom1"] }
            },
            {
                CriteriaNames.NafCode,
                new CriterionDto() { Condition = "est parmi", Values = ["CodeNaf1"] }
            },
            {
                CriteriaNames.Network,
                new CriterionDto() { Condition = "est parmi", Values = ["Nwk1"] }
            },
            {
                CriteriaNames.Portfolio,
                new CriterionDto() { Condition = "est parmi", Values = ["Portfolio1"] }
            },
            {
                CriteriaNames.Region,
                new CriterionDto() { Condition = "est parmi", Values = ["R1"] }
            },
            {
                CriteriaNames.Segmentation,
                new CriterionDto() { Condition = "est parmi", Values = ["S1"] }
            },
            {
                CriteriaNames.SyndicCode,
                new CriterionDto() { Condition = "est parmi", Values = ["SC1"] }
            },
            {
                CriteriaNames.UVCode,
                new CriterionDto() { Condition = "est parmi", Values = ["Code1"] }
            }
        };

        return new RulePersistance(id: 0, ruleDetailsDto, affectationDto, rules);
    }

    private static Rule GetRuleInstance()
    {
        var ruleDetails = new RuleDetails
        {
            RuleName = "Rule1",
            Statut = "active",
            StartDate = new DateTime(2023, 12, 31),
            EndDate = new DateTime(2024, 12, 31),
            Comment = "This is a sample rule.",
            CreationDate = currentDateTime,
            CreatedBy = "JohnDoe",
            CreatorId = "123",
            UpdateDate = currentDateTime.AddDays(5),
            UpdatorId = "456"
        };

        var affectation = new Affectation
        {
            AffectedTeam = "TeamA",
            AffectedRegion = "RegionX",
            AffectedEmployee = "John Doe",
            AffectedEmployeeId = "E12345",
            AffectationDate = currentDateTime,
            AffectationDemandDate = currentDateTime.AddDays(1)
        };

        var criteria = new Criteria
        {
            AccountManager = new List<string> { "S123456" },
            Branch = new List<string> { "A", "B", "C" },
            Clause = new List<string> { "670000" },
            ClientNumber = new List<string> { "123456789" },
            ContractCategory = new List<string> { "Finance" },
            ContractNumber = new List<string> { "987654321" },
            Copht = new List<string> { "2" },
            DistributorDepartment = new List<string> { "D1" },
            DistributorRegion = new List<string> { "R1" },
            IntermediateName = new List<string> { "Nom1" },
            NafCode = new List<string> { "CodeNaf1" },
            Network = new List<string> { "Nwk1" },
            PortfolioCode = new List<string> { "Portfolio1" },
            Segmentation = new List<string> { "S1" },
            SyndicCode = new List<string> { "SC1" },
            UVCode = new List<string> { "Code1" }
        };

        var conditions = new Conditions
        {
            AccountManagerCondition = "est parmi",
            BranchCondition = "est parmi",
            ClauseCondition = "est parmi",
            ClientNumberCondition = "est parmi",
            ContractCategoryCondition = "est parmi",
            ContractNumberCondition = "est parmi",
            CophtCondition = ">=",
            DepartmentCondition = "est parmi",
            IntermediateNameCondition = "est parmi",
            NafCodeCondition = "est parmi",
            NetworkCondition = "est parmi",
            PortfolioCondition = "est parmi",
            RegionCondition = "est parmi",
            SegmentationCondition = "est parmi",
            SyndicCodeCondition = "est parmi",
            UVCodeCondition = "est parmi"
        };

        return new Rule(id: 0, ruleDetails, criteria, affectation, conditions);
    }

    private static bool AreEquivalent(Rule? r, Rule? d)
    {
        if (r is null || d is null)
        {
            return r is null && d is null;
        }

        return r.RuleDetails?.RuleName == d.RuleDetails?.RuleName
            && r.RuleDetails?.Statut == d.RuleDetails?.Statut
            && r.RuleDetails?.StartDate == d.RuleDetails?.StartDate
            && r.RuleDetails?.EndDate == d.RuleDetails?.EndDate
            && r.RuleDetails?.Comment == d.RuleDetails?.Comment
            && r.RuleDetails?.CreationDate == d.RuleDetails?.CreationDate
            && r.RuleDetails?.CreatedBy == d.RuleDetails?.CreatedBy
            && r.RuleDetails?.CreatorId == d.RuleDetails?.CreatorId
            && r.RuleDetails?.UpdateDate == d.RuleDetails?.UpdateDate
            && r.RuleDetails?.UpdatedBy == d.RuleDetails?.UpdatedBy
            && r.RuleDetails?.UpdatorId == d.RuleDetails?.UpdatorId
            && r.Affectation?.AffectedTeam == d.Affectation?.AffectedTeam
            && r.Affectation?.AffectedRegion == d.Affectation?.AffectedRegion
            && r.Affectation?.AffectedEmployee == d.Affectation?.AffectedEmployee
            && r.Affectation?.AffectedEmployeeId == d.Affectation?.AffectedEmployeeId
            && r.Affectation?.AffectationDate == d.Affectation?.AffectationDate
            && r.Affectation?.AffectationDemandDate == d.Affectation?.AffectationDemandDate
            && r.Conditions?.AccountManagerCondition == d.Conditions?.AccountManagerCondition
            && r.Conditions?.BranchCondition == d.Conditions?.BranchCondition
            && r.Conditions?.ClauseCondition == d.Conditions?.ClauseCondition
            && r.Conditions?.ClientNumberCondition == d.Conditions?.ClientNumberCondition
            && r.Conditions?.ContractCategoryCondition == d.Conditions?.ContractCategoryCondition
            && r.Conditions?.ContractNumberCondition == d.Conditions?.ContractNumberCondition
            && r.Conditions?.CophtCondition == d.Conditions?.CophtCondition
            && r.Conditions?.DepartmentCondition == d.Conditions?.DepartmentCondition
            && r.Conditions?.IntermediateNameCondition == d.Conditions?.IntermediateNameCondition
            && r.Conditions?.NafCodeCondition == d.Conditions?.NafCodeCondition
            && r.Conditions?.NetworkCondition == d.Conditions?.NetworkCondition
            && r.Conditions?.PortfolioCondition == d.Conditions?.PortfolioCondition
            && r.Conditions?.RegionCondition == d.Conditions?.RegionCondition
            && r.Conditions?.SegmentationCondition == d.Conditions?.SegmentationCondition
            && r.Conditions?.SyndicCodeCondition == d.Conditions?.SyndicCodeCondition
            && r.Conditions?.UVCodeCondition == d.Conditions?.UVCodeCondition
            && AreEquivalent(r.Criteres?.AccountManager, d.Criteres?.AccountManager)
            && AreEquivalent(r.Criteres?.Branch, d.Criteres?.Branch)
            && AreEquivalent(r.Criteres?.Clause, d.Criteres?.Clause)
            && AreEquivalent(r.Criteres?.ClientNumber, d.Criteres?.ClientNumber)
            && AreEquivalent(r.Criteres?.ContractCategory, d.Criteres?.ContractCategory)
            && AreEquivalent(r.Criteres?.ContractNumber, d.Criteres?.ContractNumber)
            && AreEquivalent(r.Criteres?.Copht, d.Criteres?.Copht)
            && AreEquivalent(r.Criteres?.DistributorDepartment, d.Criteres?.DistributorDepartment)
            && AreEquivalent(r.Criteres?.DistributorRegion, d.Criteres?.DistributorRegion)
            && AreEquivalent(r.Criteres?.IntermediateName, d.Criteres?.IntermediateName)
            && AreEquivalent(r.Criteres?.NafCode, d.Criteres?.NafCode)
            && AreEquivalent(r.Criteres?.Network, d.Criteres?.Network)
            && AreEquivalent(r.Criteres?.PortfolioCode, d.Criteres?.PortfolioCode)
            && AreEquivalent(r.Criteres?.Segmentation, d.Criteres?.Segmentation)
            && AreEquivalent(r.Criteres?.SyndicCode, d.Criteres?.SyndicCode)
            && AreEquivalent(r.Criteres?.UVCode, d.Criteres?.UVCode);
    }

    private static bool AreEquivalent(ICollection<string>? r, ICollection<string>? d)
    {
        if (r is null || d is null)
        {
            return r is null && d is null;
        }

        return r.SequenceEqual(d);
    }
}
