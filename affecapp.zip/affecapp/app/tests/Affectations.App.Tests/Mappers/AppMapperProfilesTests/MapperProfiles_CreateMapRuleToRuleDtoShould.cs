using Affectations.App.Dtos;
using Affectations.App.Mappers;
using Affectations.Domain.AggregatesRoots.RuleAggregate;
using AutoMapper;

namespace Affectations.App.Tests.Mappers.AppMapperProfilesTests;

public class MapperProfiles_CreateMapRuleToRuleDtoShould
{
    private readonly IMapper _mapper;

    public MapperProfiles_CreateMapRuleToRuleDtoShould()
    {
        _mapper = new MapperConfiguration(cfg => cfg.AddProfile<MapperProfiles>()).CreateMapper();
    }

    [Fact]
    public void ReturnsRuleDto()
    {
        var rule = GetRuleInstance();
        var actualRuleDto = _mapper.Map<RuleDto>(rule);
        var expectedRuleDto = GetRuleDtoInstance();
        Assert.True(AreEquivalent(expectedRuleDto, actualRuleDto));
    }

    private static Rule GetRuleInstance()
    {
        var ruleDetails = new RuleDetails
        {
            RuleName = "SampleRule",
            Statut = "Active",
            StartDate = new DateTime(2023, 12, 31),
            EndDate = new DateTime(2024, 12, 31),
            Comment = "This is a sample rule.",
            CreationDate = new DateTime(2023, 12, 15),
            CreatedBy = "JohnDoe",
            CreatorId = "123",
            UpdateDate = new DateTime(2023, 12, 20),
            UpdatorId = "456"
        };

        var criteres = new Criteria
        {
            Segmentation = new List<string> { "S1" },
            DistributorRegion = new List<string> { "DR1" },
            Network = new List<string> { "N1" },
            Branch = new List<string> { "B1", "B2" },
            Copht = new List<string> { "1" },
            DistributorDepartment = new List<string> { "DD1" },
            ContractCategory = new List<string> { "CC1" },
            IntermediateName = new List<string> { "Name1" },
            PortfolioCode = new List<string> { "P1" },
            Clause = new List<string> { "Clause1" },
            SyndicCode = new List<string> { "CodeSyncdic1" },
            NafCode = new List<string> { "CodeNaf1" },
            ClientNumber = new List<string> { "ClientNumber1" },
            AccountManager = new List<string> { "Manager1" },
            ContractNumber = new List<string> { "Contract1" },
            UVCode = new List<string> { "Uvcode1" }
        };

        var affectation = new Affectation
        {
            AffectedTeam = "TeamA",
            AffectedRegion = "RegionX",
            AffectedEmployee = "John Doe",
            AffectedEmployeeId = "E12345",
            AffectationDate = new DateTime(2024, 01, 15).AddDays(1),
            AffectationDemandDate = new DateTime(2024, 01, 15)
        };
        var conditions = new Conditions
        {
            ContractNumberCondition = "est parmi",
            AccountManagerCondition = "est parmi",
            ClientNumberCondition = "est parmi",
            NafCodeCondition = "est parmi",
            SyndicCodeCondition = "est parmi",
            ClauseCondition = "est parmi",
            PortfolioCondition = "est parmi",
            IntermediateNameCondition = "est parmi",
            CophtCondition = "plus grand ou égal à",
            DepartmentCondition = "est parmi",
            NetworkCondition = "est parmi",
            RegionCondition = "est parmi",
            BranchCondition = "est parmi",
            SegmentationCondition = "est parmi",
            ContractCategoryCondition = "est parmi",
            UVCodeCondition = "est parmi"
        };

        return new Rule(id: 1, ruleDetails, criteres, affectation, conditions);
    }

    private static RuleDto GetRuleDtoInstance()
    {
        var ruleDetailsDto = new RuleDetailsDto
        {
            RuleName = "SampleRule",
            Statut = "Active",
            StartDate = new DateTime(2023, 12, 31),
            EndDate = new DateTime(2024, 12, 31),
            Comment = "This is a sample rule.",
            CreationDate = new DateTime(2023, 12, 15),
            CreatedBy = "JohnDoe",
            CreatorId = "123",
            UpdateDate = new DateTime(2023, 12, 20),
            UpdatorId = "456"
        };

        var criteresDto = new CriteresDto
        {
            Segmentation = "S1",
            DistributorRegion = "DR1",
            Network = "N1",
            Branch = "B1;B2",
            Copht = 1,
            DistributorDepartment = "DD1",
            ContractCategory = "CC1",
            IntermediateName = "Name1",
            PortfolioCode = "P1",
            Clause = "Clause1",
            SyndicCode = "CodeSyncdic1",
            NafCode = "CodeNaf1",
            ClientNumber = "ClientNumber1",
            AccountManager = "Manager1",
            ContractNumber = "Contract1",
            UVCode = "Uvcode1"
        };

        var affectationDto = new AffectationDto
        {
            AffectedTeam = "TeamA",
            AffectedRegion = "RegionX",
            AffectedEmployee = "John Doe",
            AffectedEmployeeId = "E12345",
            AffectationDate = new DateTime(2024, 01, 15).AddDays(1),
            AffectationDemandDate = new DateTime(2024, 01, 15)
        };
        var conditionsDto = new ConditionsDto
        {
            ContractNumberCondition = "est parmi",
            AccountManagerCondition = "est parmi",
            ClientNumberCondition = "est parmi",
            NafCodeCondition = "est parmi",
            SyndicCodeCondition = "est parmi",
            ClauseCondition = "est parmi",
            PortfolioCondition = "est parmi",
            IntermediateNameCondition = "est parmi",
            ProductCondition = "est parmi",
            CophtCondition = "plus grand ou égal à",
            DepartmentCondition = "est parmi",
            NetworkCondition = "est parmi",
            RegionCondition = "est parmi",
            BranchCondition = "est parmi",
            SegmentationCondition = "est parmi",
            ContractCategoryCondition = "est parmi",
        };

        return new RuleDto(id: 1, ruleDetailsDto, criteresDto, affectationDto, conditionsDto);
    }

    private static bool AreEquivalent(RuleDto? r, RuleDto? d)
    {
        if (r is null || d is null)
        {
            return r is null && d is null;
        }

        return r.RuleDetailsDto?.RuleName == d.RuleDetailsDto?.RuleName
            && r.RuleDetailsDto?.Statut == d.RuleDetailsDto?.Statut
            && r.RuleDetailsDto?.StartDate == d.RuleDetailsDto?.StartDate
            && r.RuleDetailsDto?.EndDate == d.RuleDetailsDto?.EndDate
            && r.RuleDetailsDto?.Comment == d.RuleDetailsDto?.Comment
            && r.RuleDetailsDto?.CreationDate == d.RuleDetailsDto?.CreationDate
            && r.RuleDetailsDto?.CreatedBy == d.RuleDetailsDto?.CreatedBy
            && r.RuleDetailsDto?.CreatorId == d.RuleDetailsDto?.CreatorId
            && r.RuleDetailsDto?.UpdateDate == d.RuleDetailsDto?.UpdateDate
            && r.RuleDetailsDto?.UpdatedBy == d.RuleDetailsDto?.UpdatedBy
            && r.RuleDetailsDto?.UpdatorId == d.RuleDetailsDto?.UpdatorId
            && r.CritereDto?.Segmentation == d.CritereDto?.Segmentation
            && r.CritereDto?.DistributorRegion == d.CritereDto?.DistributorRegion
            && r.CritereDto?.Network == d.CritereDto?.Network
            && r.CritereDto?.Branch == d.CritereDto?.Branch
            && r.CritereDto?.Copht == d.CritereDto?.Copht
            && r.CritereDto?.DistributorDepartment == d.CritereDto?.DistributorDepartment
            && r.CritereDto?.ContractCategory == d.CritereDto?.ContractCategory
            && r.CritereDto?.IntermediateName == d.CritereDto?.IntermediateName
            && r.CritereDto?.PortfolioCode == d.CritereDto?.PortfolioCode
            && r.CritereDto?.Clause == d.CritereDto?.Clause
            && r.CritereDto?.SyndicCode == d.CritereDto?.SyndicCode
            && r.CritereDto?.NafCode == d.CritereDto?.NafCode
            && r.CritereDto?.ClientNumber == d.CritereDto?.ClientNumber
            && r.CritereDto?.AccountManager == d.CritereDto?.AccountManager
            && r.CritereDto?.ContractNumber == d.CritereDto?.ContractNumber
            && r.CritereDto?.UVCode == d.CritereDto?.UVCode
            && r.ConditionsDto?.SegmentationCondition == d.ConditionsDto?.SegmentationCondition
            && r.ConditionsDto?.RegionCondition == d.ConditionsDto?.RegionCondition
            && r.ConditionsDto?.NetworkCondition == d.ConditionsDto?.NetworkCondition
            && r.ConditionsDto?.BranchCondition == d.ConditionsDto?.BranchCondition
            && r.ConditionsDto?.CophtCondition == d.ConditionsDto?.CophtCondition
            && r.ConditionsDto?.DepartmentCondition == d.ConditionsDto?.DepartmentCondition
            && r.ConditionsDto?.ContractCategoryCondition == d.ConditionsDto?.ContractCategoryCondition
            && r.ConditionsDto?.IntermediateNameCondition == d.ConditionsDto?.IntermediateNameCondition
            && r.ConditionsDto?.PortfolioCondition == d.ConditionsDto?.PortfolioCondition
            && r.ConditionsDto?.ClauseCondition == d.ConditionsDto?.ClauseCondition
            && r.ConditionsDto?.SyndicCodeCondition == d.ConditionsDto?.SyndicCodeCondition
            && r.ConditionsDto?.NafCodeCondition == d.ConditionsDto?.NafCodeCondition
            && r.ConditionsDto?.ClientNumberCondition == d.ConditionsDto?.ClientNumberCondition
            && r.ConditionsDto?.AccountManagerCondition == d.ConditionsDto?.AccountManagerCondition
            && r.ConditionsDto?.ContractNumberCondition == d.ConditionsDto?.ContractNumberCondition
            && r.ConditionsDto?.ProductCondition == d.ConditionsDto?.ProductCondition
            && r.AffectationDto?.AffectedTeam == d.AffectationDto?.AffectedTeam
            && r.AffectationDto?.AffectedRegion == d.AffectationDto?.AffectedRegion
            && r.AffectationDto?.AffectedEmployee == d.AffectationDto?.AffectedEmployee
            && r.AffectationDto?.AffectedEmployeeId == d.AffectationDto?.AffectedEmployeeId
            && r.AffectationDto?.AffectationDate == d.AffectationDto?.AffectationDate
            && r.AffectationDto?.AffectationDemandDate == d.AffectationDto?.AffectationDemandDate;
    }
}
