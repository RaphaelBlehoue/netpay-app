using Microsoft.EntityFrameworkCore;

namespace Affectations.WORKER.Tests.Hooks;

public static class InMemoryDatabase
{
    public static AffectationsContext Initialize()
    {
        var options = new DbContextOptionsBuilder<AffectationsContext>()
            .UseInMemoryDatabase(databaseName: $"MyInMemoryDb_{Guid.NewGuid()}")
            .Options;

        var affectationsContext = new AffectationsContext(options);

        affectationsContext.TEmployees.Add(
            new TEmployee
            {
                Id = "1",
                LastName = "Beckham",
                FirstName = "Dav"
            }
        );

        affectationsContext.SaveChanges();
        return affectationsContext;
    }
}
