using Affectations.WORKER.Adapter.KafkaEvent;
using AxaFrance.Kafka.FrRoiPeopleActiveUpdatedEvt_V2_0;

namespace Affectations.WORKER.Tests.KafkaEvent;

public class PeopleActiveUploadedEventProcessorTests
{
    private readonly AffectationsContext _affectationContext;
    private readonly Mock<ILogger<EmployeeRepository>> _employeeRepositoryLogger;
    private readonly Mock<ILogger<PeopleActiveUploadedEventProcessor>> _peopleActiveUploadedEventProcessorLogger;

    public PeopleActiveUploadedEventProcessorTests()
    {
        _affectationContext = InMemoryDatabase.Initialize();
        _employeeRepositoryLogger = new Mock<ILogger<EmployeeRepository>>();
        _peopleActiveUploadedEventProcessorLogger = new Mock<ILogger<PeopleActiveUploadedEventProcessor>>();
    }

    [Fact]
    public async Task AddEmployee_WhenNotExist()
    {
        var employeeRepository = new EmployeeRepository(_affectationContext, _employeeRepositoryLogger.Object);
        var peopleActiveUploadedEventProcessor = new PeopleActiveUploadedEventProcessor(
            employeeRepository,
            _peopleActiveUploadedEventProcessorLogger.Object
        );
        var payload = new FrRoiPeopleActiveUpdatedEvtV2Payload
        {
            TechnicalProperties = new Technical_properties_doctype(),
            BusinessProperties = new Business_properties_doctype
            {
                Personne = new Personne
                {
                    Matricule = "2",
                    Nom = "Rooney",
                    Prenom = "Wayne"
                }
            }
        };
        await peopleActiveUploadedEventProcessor.ProcessAsync(payload, CancellationToken.None);
        var result = await _affectationContext.TEmployees.FindAsync("2");

        Assert.NotNull(result);
        Assert.Equal(payload.BusinessProperties.Personne.Matricule, result.Id);
        Assert.Equal(payload.BusinessProperties.Personne.Nom, result.LastName);
        Assert.Equal(payload.BusinessProperties.Personne.Prenom, result.FirstName);
    }
}
