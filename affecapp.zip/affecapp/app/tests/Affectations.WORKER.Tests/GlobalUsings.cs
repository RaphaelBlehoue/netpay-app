global using Affectations.WORKER.Core.Entities;
global using Affectations.WORKER.Infrastructure.Data.Models;
global using Affectations.WORKER.Infrastructure.Repositories;
global using Affectations.WORKER.Tests.Hooks;
global using Microsoft.Extensions.Logging;
global using Moq;
global using TechTalk.SpecFlow;
global using Xunit;
