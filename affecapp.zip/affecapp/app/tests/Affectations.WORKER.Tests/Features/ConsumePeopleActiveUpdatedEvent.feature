
Feature: Consommation de l'événement kafka

En tant qu'utilisateur, je veux consommer l'événement kafka afin de mettre à jour les employés dans la base de données

Rule: Si l'événement kafka contient un nouveau employé, alors les données de l'employé sont ajoutées dans la base de données

    Scenario: L'événement kafka contient un nouveau employé
        Given L'employé est nouveau
            | Id | LastName | FirstName |
            | 2  | Rooney   | Wayne     |
        When L'événement kafka est consommé
        Then Les données de l'employé sont ajoutées

Rule: Si l'événement kafka contient un employé existant, alors les données de l'employé ne sont pas ajoutées de nouveau dans la base de données

    Scenario: L'événement kafka contient un employé existant
        Given L'employé est existant
            | Id | LastName | FirstName |
            | 1  | Beckham   | Dav     |
        When L'événement kafka est consommé
        Then Une exception EmployeeExistsException est soulevé et les données de l'employé ne sont pas ajoutées de nouveau dans la base de données

Rule: Si l'événement kafka contient un employé avec un Id invalide, alors les données de l'employé ne sont pas ajoutées de nouveau dans la base de données

    Scenario: L'événement kafka contient un employé invalide
        Given L'employé est invalide
            | Id | LastName | FirstName |
            |    | Beckham  | Dav     |
        When L'événement kafka est consommé
        Then Une exception est soulevé et les données de l'employé ne sont pas ajoutées de nouveau dans la base de données
