using Affectations.WORKER.Adapter.KafkaEvent;
using Affectations.WORKER.Core.Exceptions;
using AxaFrance.Kafka.FrRoiPeopleActiveUpdatedEvt_V2_0;
using FluentAssertions;
using TechTalk.SpecFlow.Assist;

namespace Affectations.WORKER.Tests.Features;

[Binding]
internal sealed class ConsumePeopleActiveUpdatedEventSteps : BaseActions
{
    private const string ResultCreatedEmployee = nameof(ResultCreatedEmployee);
    private const string ResultEmployeeException = nameof(ResultEmployeeException);

    private Employee _employee = new();

    public ConsumePeopleActiveUpdatedEventSteps(ScenarioContext scenarioContext)
        : base(scenarioContext) { }

    [Given(@"L'employé est nouveau")]
    public void GivenLemployeEstNouveau(Table table)
    {
        _employee = table.CreateInstance<Employee>();
    }

    [Given(@"L'employé est existant")]
    public void GivenLemployeEstExistant(Table table)
    {
        _employee = table.CreateInstance<Employee>();
    }

    [Given(@"L'employé est invalide")]
    public void GivenLemployeEstInvalide(Table table)
    {
        _employee = table.CreateInstance<Employee>();
    }

    [When(@"L'événement kafka est consommé")]
    public async Task WhenLevenementKafkaEstConsommeAsync()
    {
        var employeeRepository = new EmployeeRepository(_affectationContext, _employeeRepositoryLogger.Object);
        var peopleActiveUploadedEventProcessor = new PeopleActiveUploadedEventProcessor(
            employeeRepository,
            _peopleActiveUploadedEventProcessorLogger.Object
        );
        var payload = new FrRoiPeopleActiveUpdatedEvtV2Payload
        {
            TechnicalProperties = new Technical_properties_doctype(),
            BusinessProperties = new Business_properties_doctype
            {
                Personne = new Personne
                {
                    Matricule = _employee.Id,
                    Nom = _employee.LastName,
                    Prenom = _employee.FirstName
                }
            }
        };

        try
        {
            await peopleActiveUploadedEventProcessor.ProcessAsync(payload, CancellationToken.None);
            _scenarioContext[ResultCreatedEmployee] = await _affectationContext.TEmployees.FindAsync(_employee.Id);
        }
        catch (EmployeeNotValidException ex)
        {
            _scenarioContext[ResultEmployeeException] = ex;
        }
        catch (EmployeeExistsException ex)
        {
            _scenarioContext[ResultEmployeeException] = ex;
        }
    }

    [Then(@"Les données de l'employé sont ajoutées")]
    public void ThenLesDonneesDeLemployeSontAjoutees()
    {
        var expectedEmployee = new TEmployee
        {
            Id = "2",
            LastName = "Rooney",
            FirstName = "Wayne"
        };
        var actualEmployee = Assert.IsType<TEmployee>(_scenarioContext[ResultCreatedEmployee]);
        actualEmployee.Should().BeEquivalentTo(expectedEmployee);
    }

    [Then(
        @"Une exception est soulevé et les données de l'employé ne sont pas ajoutées de nouveau dans la base de données"
    )]
    public void ThenUneExceptionEstSouleveEtLesDonneesDeLemployeNeSontPasAjouteesDeNouveauDansLaBaseDeDonnees()
    {
        Assert.IsType<EmployeeNotValidException>(_scenarioContext[ResultEmployeeException]);
    }

    [Then(
        @"Une exception EmployeeExistsException est soulevé et les données de l'employé ne sont pas ajoutées de nouveau dans la base de données"
    )]
    public void ThenUneExceptionEmployeeExistsExceptionEstSouleveEtLesDonneesDeLemployeNeSontPasAjouteesDeNouveauDansLaBaseDeDonnees()
    {
        Assert.IsType<EmployeeExistsException>(_scenarioContext[ResultEmployeeException]);
    }
}
