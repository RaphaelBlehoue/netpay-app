using Affectations.WORKER.Core.Exceptions;
using Microsoft.EntityFrameworkCore;

namespace Affectations.WORKER.Tests.Repositories;

public class EmployeeRepository_AddEmployeeAsyncShould
{
    private readonly AffectationsContext _affectationContext;
    private readonly Mock<ILogger<EmployeeRepository>> _logger;

    public EmployeeRepository_AddEmployeeAsyncShould()
    {
        _affectationContext = InMemoryDatabase.Initialize();
        _logger = new Mock<ILogger<EmployeeRepository>>();
    }

    [Fact]
    public async Task AddEmployee_WhenNotExist()
    {
        var employeeRepository = new EmployeeRepository(_affectationContext, _logger.Object);
        var employee = new Employee
        {
            Id = "2",
            LastName = "Paul",
            FirstName = "Scholes"
        };
        await employeeRepository.AddEmployeeAsync(employee);
        var addedEmployeeEntity = await _affectationContext.TEmployees.FirstAsync(x => x.Id == employee.Id);

        Assert.Equal(employee.Id, addedEmployeeEntity.Id);
        Assert.Equal(employee.LastName, addedEmployeeEntity.LastName);
        Assert.Equal(employee.FirstName, addedEmployeeEntity.FirstName);
    }

    [Fact]
    public async Task NotAddEmployee_WhenIdAlreadyExists()
    {
        var expectedErrorMessage = "L'employé existe déjà.";
        var employeeRepository = new EmployeeRepository(_affectationContext, _logger.Object);
        var existingEmployee = new Employee
        {
            Id = "1",
            LastName = "Beckham",
            FirstName = "Dav"
        };

        var ex = await Assert.ThrowsAsync<EmployeeExistsException>(
            () => employeeRepository.AddEmployeeAsync(existingEmployee)
        );
        Assert.IsType<EmployeeExistsException>(ex);
        Assert.Equal(expectedErrorMessage, ex.Message);
    }
}
