using Affectations.WORKER.Adapter.KafkaEvent;

namespace Affectations.WORKER.Tests;

internal class BaseActions
{
    protected readonly ScenarioContext _scenarioContext;
    protected readonly AffectationsContext _affectationContext;
    protected readonly Mock<ILogger<EmployeeRepository>> _employeeRepositoryLogger;
    protected readonly Mock<ILogger<PeopleActiveUploadedEventProcessor>> _peopleActiveUploadedEventProcessorLogger;

    public BaseActions(ScenarioContext scenarioContext)
    {
        _scenarioContext = scenarioContext;
        _affectationContext = InMemoryDatabase.Initialize();
        _employeeRepositoryLogger = new Mock<ILogger<EmployeeRepository>>();
        _peopleActiveUploadedEventProcessorLogger = new Mock<ILogger<PeopleActiveUploadedEventProcessor>>();
    }
}
