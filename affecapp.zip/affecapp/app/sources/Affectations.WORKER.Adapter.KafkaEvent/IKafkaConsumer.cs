namespace Affectations.WORKER.Adapter.KafkaEvent;

public interface IKafkaConsumer
{
    Task StartConsumingAsync(CancellationToken stoppingToken);
}
