using Affectations.WORKER.Core.Entities;
using Affectations.WORKER.Core.Ports;
using Affectations.WORKER.Core.Repositories;
using AxaFrance.Kafka.FrRoiPeopleActiveUpdatedEvt_V2_0;
using Microsoft.Extensions.Logging;

namespace Affectations.WORKER.Adapter.KafkaEvent;

public class PeopleActiveUploadedEventProcessor : IPeopleActiveUploadedEventProcessor
{
    private readonly IEmployeeRepository _employeeRepository;
    private readonly ILogger<PeopleActiveUploadedEventProcessor> _logger;

    public PeopleActiveUploadedEventProcessor(
        IEmployeeRepository employeeRepository,
        ILogger<PeopleActiveUploadedEventProcessor> logger
    )
    {
        _employeeRepository = employeeRepository;
        _logger = logger;
    }

    public async Task ProcessAsync(FrRoiPeopleActiveUpdatedEvtV2Payload payload, CancellationToken cancellationToken)
    {
        var employeeFromPayload = payload.BusinessProperties.Personne;
        var employee = new Employee(employeeFromPayload.Matricule, employeeFromPayload.Nom, employeeFromPayload.Prenom);

        await _employeeRepository.AddEmployeeAsync(employee);
    }
}
