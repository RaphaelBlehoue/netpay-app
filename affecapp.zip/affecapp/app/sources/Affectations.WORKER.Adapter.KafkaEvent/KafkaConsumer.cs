using Affectations.WORKER.Core.Exceptions;
using Affectations.WORKER.Core.Ports;
using AxaFrance.E2ELogging;
using AxaFrance.Kafka.FrRoiPeopleActiveUpdatedEvt_V2_0;
using Confluent.Kafka;
using Microsoft.Extensions.Logging;

namespace Affectations.WORKER.Adapter.KafkaEvent;

public class KafkaConsumer : IKafkaConsumer
{
    private readonly ILogger<KafkaConsumer> _logger;
    private readonly IConsumer<string, JsonMessage<FrRoiPeopleActiveUpdatedEvtV2Payload>> _consumer;
    private readonly IPeopleActiveUploadedEventProcessor _eventProcessor;
    private readonly ICorrelationContextScopeFactory _correlationContextScopeFactory;

    public KafkaConsumer(
        ILogger<KafkaConsumer> logger,
        IConsumer<string, JsonMessage<FrRoiPeopleActiveUpdatedEvtV2Payload>> consumer,
        IPeopleActiveUploadedEventProcessor eventProcessor,
        ICorrelationContextScopeFactory correlationContextScopeFactory
    )
    {
        _logger = logger;
        _consumer = consumer;
        _eventProcessor = eventProcessor;
        _correlationContextScopeFactory = correlationContextScopeFactory;
    }

    public async Task StartConsumingAsync(CancellationToken stoppingToken)
    {
        try
        {
            var consumeResult = _consumer.Consume(stoppingToken);
            var message = consumeResult.Message?.Value;
            if (message is not null)
            {
                using (_correlationContextScopeFactory.Create(new CorrelationContext(Guid.NewGuid().ToString())))
                {
                    _logger.LogInformation("Start processing: {@Payload}", message.Payload);
                    await _eventProcessor.ProcessAsync(message.Payload, stoppingToken);
                }
            }
        }
        catch (EmployeeNotValidException e)
        {
            _logger.LogError(e, "Erreur technique lors du traitement du payload FrRoiPeopleActiveUpdatedEvtV2Payload.");
        }
        catch (ConsumeException e)
        {
            _logger.LogError(e, "Consume error: {reason}.", e.Error.Reason);
        }
        catch (Exception e)
        {
            _logger.LogError(e, "Consume error: .");
        }
    }
}
