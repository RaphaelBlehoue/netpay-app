namespace Affectations.WORKER.Adapter.KafkaEvent;

public static class Constants
{
    public static readonly string PeopleActiveUpdatedTopic = "fr-roi-peopleActiveUpdatedEvt-v2";
}
