using Affectations.WORKER.Adapter.KafkaEvent;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace Affectations.WORKER.PeopleActiveWorker;

public class Worker : BackgroundService
{
    private readonly ILogger<Worker> _logger;
    private readonly IKafkaConsumer _kafkaConsumer;

    public Worker(ILogger<Worker> logger, IKafkaConsumer kafkaConsumer)
    {
        _logger = logger;
        _kafkaConsumer = kafkaConsumer;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        try
        {
            while (!stoppingToken.IsCancellationRequested)
            {
                _logger.LogInformation("Start listening");
                await _kafkaConsumer.StartConsumingAsync(stoppingToken);
            }
        }
        catch (Exception e)
        {
            _logger.LogError(e, "Erreur technique survenue au niveau de la hosted service.");
        }
    }
}
