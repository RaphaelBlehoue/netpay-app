using System.Diagnostics;
using Affectations.WORKER.Adapter.KafkaEvent;
using Affectations.WORKER.Core.Ports;
using Affectations.WORKER.Core.Repositories;
using Affectations.WORKER.Infrastructure;
using Affectations.WORKER.Infrastructure.Repositories;
using Affectations.WORKER.PeopleActiveWorker;
using AxaFrance.Kafka.FrRoiPeopleActiveUpdatedEvt_V2_0.Consumer;
using AxaFrance.Kafka.FrRoiPeopleActiveUpdatedEvt_V2_0.Extensions;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Serilog;
using Serilog.Debugging;

if (args.Contains("--debug"))
{
    SelfLog.Enable(Console.Out);
}

var hostBuilder = Host.CreateDefaultBuilder(args)
    .ConfigureServices(
        (hostContext, services) =>
        {
            ConfigureKafkaServices(hostContext, services);
            services.AddHostedService<Worker>();
            services.ConfigureInfrastructureServices(hostContext.Configuration);
            services.AddSingleton<IKafkaConsumer, KafkaConsumer>();
            services.AddSingleton<IPeopleActiveUploadedEventProcessor, PeopleActiveUploadedEventProcessor>();
            services.AddSingleton<IEmployeeRepository, EmployeeRepository>();
        }
    );

hostBuilder.UseSerilog();
if (args.Contains("--console") || Debugger.IsAttached)
{
    hostBuilder.UseConsoleLifetime();
}

static void ConfigureKafkaServices(HostBuilderContext hostContext, IServiceCollection services)
{
    services.AddFrRoiPeopleActiveUpdatedEvtV2ConsumerBuilderWithCCloudSupport(
        hostContext.Configuration.GetSection("FrRoiPeopleActiveUpdatedEvtV2:Consumer").Bind,
        hostContext.Configuration.GetSection("FrRoiPeopleActiveUpdatedEvtV2:Encryption").Bind
    );

    services.AddSingleton(provider =>
    {
        var logger = provider.GetRequiredService<ILogger<IFrRoiPeopleActiveUpdatedEvtV2ConsumerBuilder>>();
        var consumer = provider
            .GetRequiredService<IFrRoiPeopleActiveUpdatedEvtV2ConsumerBuilder>()
            .SetLogHandler((_, x) => logger.LogDebug("{message}", x.Message))
            .SetErrorHandler((_, x) => logger.LogError("{code} {reason}", x.Code, x.Reason))
            .Build();
        consumer.Subscribe(Constants.PeopleActiveUpdatedTopic);
        return consumer;
    });
}
hostBuilder.Build().Run();
