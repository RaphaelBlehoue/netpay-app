using System.Globalization;
using Affectations.Domain.AggregatesRoots.RuleAggregate;
using Affectations.Domain.Models;
using Affectations.Infrastructure.Stores;
using AutoMapper;
using Microsoft.IdentityModel.Tokens;

namespace Affectations.Infrastructure.Mappers;

public class MapperProfiles : Profile
{
    private const string dateFormat = "yyyy-MM-ddTHH:mm:ss.fffzzz";

    public MapperProfiles()
    {
        #region RuleDto
        CreateMap<RuleDto, Rule>()
            .ForMember(dest => dest.RuleDetails, opt => opt.MapFrom(src => src.RuleDetails))
            .ForMember(dest => dest.Criteres, opt => opt.MapFrom(src => src.Criteres))
            .ForMember(dest => dest.Affectation, opt => opt.MapFrom(src => src.Affectations))
            .ForMember(dest => dest.Conditions, opt => opt.MapFrom(src => src.Conditions))
            .ReverseMap();
        #endregion

        #region FilterRuleDto
        CreateMap<FilterRuleModel, FiltreRulesDto>()
            .ForMember(dest => dest.Ids, opt => opt.MapFrom(src => src.Ids))
            .ForMember(dest => dest.RuleDetails, opt => opt.MapFrom(src => src.RuleDetails))
            .ForMember(dest => dest.Criterion, opt => opt.MapFrom(src => src.Criteres))
            .ForMember(dest => dest.Affectations, opt => opt.MapFrom(src => src.Affectation))
            .ForMember(dest => dest.Conditions, opt => opt.MapFrom(src => src.Conditions))
            .ReverseMap();
        #endregion

        #region RuleDetails
        CreateMap<RuleDetailDto, RuleDetails>()
            .ForMember(dest => dest.RuleName, opt => opt.MapFrom(src => src.Nom))
            .ForMember(dest => dest.Statut, opt => opt.MapFrom(src => src.Statut))
            .ForMember(
                dest => dest.StartDate,
                opt => opt.MapFrom(src => src.DateDebut.HasValue ? src.DateDebut.Value.DateTime : (DateTime?)null)
            )
            .ForMember(
                dest => dest.EndDate,
                opt => opt.MapFrom(src => src.DateFin.HasValue ? src.DateFin.Value.DateTime : (DateTime?)null)
            )
            .ForMember(dest => dest.Comment, opt => opt.MapFrom(src => src.Commentaire))
            .ForMember(
                dest => dest.CreationDate,
                opt => opt.MapFrom(src => src.DateCreation.HasValue ? src.DateCreation.Value.DateTime : (DateTime?)null)
            )
            .ForMember(dest => dest.CreatedBy, opt => opt.MapFrom(src => src.CreePar))
            .ForMember(dest => dest.CreatorId, opt => opt.MapFrom(src => src.MatriculeCreateur))
            .ForMember(dest => dest.UpdatedBy, opt => opt.MapFrom(src => src.MiseAJourPar))
            .ForMember(
                dest => dest.UpdateDate,
                opt =>
                    opt.MapFrom(src => src.DateMiseAJour.HasValue ? src.DateMiseAJour.Value.DateTime : (DateTime?)null)
            )
            .ForMember(dest => dest.UpdatorId, opt => opt.MapFrom(src => src.MatriculeModificateur))
            .ForMember(dest => dest.Priority, opt => opt.MapFrom(src => src.Priorite));

        CreateMap<RuleDetails, RuleDetailDto>()
            .ForMember(dest => dest.Nom, opt => opt.MapFrom(src => src.RuleName))
            .ForMember(dest => dest.Statut, opt => opt.MapFrom(src => src.Statut))
            .ForMember(dest => dest.DateDebut, opt => opt.MapFrom(src => src.StartDate ?? null))
            .ForMember(dest => dest.DateFin, opt => opt.MapFrom(src => src.EndDate ?? null))
            .ForMember(dest => dest.Commentaire, opt => opt.MapFrom(src => src.Comment))
            .ForMember(dest => dest.DateCreation, opt => opt.MapFrom(src => src.CreationDate ?? null))
            .ForMember(dest => dest.CreePar, opt => opt.MapFrom(src => src.CreatedBy))
            .ForMember(dest => dest.MatriculeCreateur, opt => opt.MapFrom(src => src.CreatorId))
            .ForMember(dest => dest.DateMiseAJour, opt => opt.MapFrom(src => src.UpdateDate ?? null))
            .ForMember(dest => dest.MiseAJourPar, opt => opt.MapFrom(src => src.UpdatedBy))
            .ForMember(dest => dest.MatriculeModificateur, opt => opt.MapFrom(src => src.UpdatorId))
            .ForMember(dest => dest.Priorite, opt => opt.MapFrom(src => src.Priority));

        #endregion

        #region Criteria
        CreateMap<Stores.Criteria, Domain.AggregatesRoots.RuleAggregate.Criteria>()
            .ForMember(dest => dest.RuleId, opt => opt.MapFrom(src => src.RuleId))
            .ForMember(
                dest => dest.Segmentation,
                opt => opt.MapFrom(src => !src.Segmentation.IsNullOrEmpty() ? src.Segmentation : null)
            )
            .ForMember(
                dest => dest.DistributorRegion,
                opt => opt.MapFrom(src => !src.Region.IsNullOrEmpty() ? src.Region : null)
            )
            .ForMember(dest => dest.Network, opt => opt.MapFrom(src => !src.Reseau.IsNullOrEmpty() ? src.Reseau : null))
            .ForMember(
                dest => dest.Branch,
                opt => opt.MapFrom(src => !src.Branche.IsNullOrEmpty() ? src.Branche : null)
            )
            .ForMember(dest => dest.Copht, opt => opt.MapFrom(src => !src.Copht.IsNullOrEmpty() ? src.Copht : null))
            .ForMember(
                dest => dest.DistributorDepartment,
                opt => opt.MapFrom(src => !src.Departement.IsNullOrEmpty() ? src.Departement : null)
            )
            .ForMember(
                dest => dest.ContractCategory,
                opt => opt.MapFrom(src => !src.CategorieContrat.IsNullOrEmpty() ? src.CategorieContrat : null)
            )
            .ForMember(
                dest => dest.IntermediateName,
                opt => opt.MapFrom(src => !src.NomIntermediaire.IsNullOrEmpty() ? src.NomIntermediaire : null)
            )
            .ForMember(
                dest => dest.PortfolioCode,
                opt => opt.MapFrom(src => !src.Portefeuille.IsNullOrEmpty() ? src.Portefeuille : null)
            )
            .ForMember(
                dest => dest.SyndicCode,
                opt => opt.MapFrom(src => !src.CodeSyndic.IsNullOrEmpty() ? src.CodeSyndic : null)
            )
            .ForMember(
                dest => dest.NafCode,
                opt => opt.MapFrom(src => !src.CodeNaf.IsNullOrEmpty() ? src.CodeNaf : null)
            )
            .ForMember(
                dest => dest.ClientNumber,
                opt => opt.MapFrom(src => !src.NumeroClient.IsNullOrEmpty() ? src.NumeroClient : null)
            )
            .ForMember(
                dest => dest.AccountManager,
                opt => opt.MapFrom(src => !src.ChargeDeClientele.IsNullOrEmpty() ? src.ChargeDeClientele : null)
            )
            .ForMember(
                dest => dest.ContractNumber,
                opt => opt.MapFrom(src => !src.NumeroContrat.IsNullOrEmpty() ? src.NumeroContrat : null)
            )
            .ForMember(
                dest => dest.UVCode,
                opt => opt.MapFrom(src => !src.Produit.IsNullOrEmpty() ? src.Produit : null)
            );

        CreateMap<Domain.AggregatesRoots.RuleAggregate.Criteria, Stores.Criteria>()
            .ForMember(dest => dest.RuleId, opt => opt.MapFrom(src => src.RuleId))
            .ForMember(
                dest => dest.Segmentation,
                opt => opt.MapFrom(src => !src.Segmentation.IsNullOrEmpty() ? src.Segmentation : null)
            )
            .ForMember(
                dest => dest.Region,
                opt => opt.MapFrom(src => !src.DistributorRegion.IsNullOrEmpty() ? src.DistributorRegion : null)
            )
            .ForMember(
                dest => dest.Reseau,
                opt => opt.MapFrom(src => !src.Network.IsNullOrEmpty() ? src.Network : null)
            )
            .ForMember(dest => dest.Branche, opt => opt.MapFrom(src => !src.Branch.IsNullOrEmpty() ? src.Branch : null))
            .ForMember(dest => dest.Copht, opt => opt.MapFrom(src => !src.Copht.IsNullOrEmpty() ? src.Copht : null))
            .ForMember(
                dest => dest.Departement,
                opt => opt.MapFrom(src => !src.DistributorDepartment.IsNullOrEmpty() ? src.DistributorDepartment : null)
            )
            .ForMember(
                dest => dest.CategorieContrat,
                opt => opt.MapFrom(src => !src.ContractCategory.IsNullOrEmpty() ? src.ContractCategory : null)
            )
            .ForMember(
                dest => dest.NomIntermediaire,
                opt => opt.MapFrom(src => !src.IntermediateName.IsNullOrEmpty() ? src.IntermediateName : null)
            )
            .ForMember(
                dest => dest.Portefeuille,
                opt => opt.MapFrom(src => !src.PortfolioCode.IsNullOrEmpty() ? src.PortfolioCode : null)
            )
            .ForMember(
                dest => dest.CodeSyndic,
                opt => opt.MapFrom(src => !src.SyndicCode.IsNullOrEmpty() ? src.SyndicCode : null)
            )
            .ForMember(
                dest => dest.CodeNaf,
                opt => opt.MapFrom(src => !src.NafCode.IsNullOrEmpty() ? src.NafCode : null)
            )
            .ForMember(
                dest => dest.NumeroClient,
                opt => opt.MapFrom(src => !src.ClientNumber.IsNullOrEmpty() ? src.ClientNumber : null)
            )
            .ForMember(
                dest => dest.ChargeDeClientele,
                opt => opt.MapFrom(src => !src.AccountManager.IsNullOrEmpty() ? src.AccountManager : null)
            )
            .ForMember(
                dest => dest.NumeroContrat,
                opt => opt.MapFrom(src => !src.ContractNumber.IsNullOrEmpty() ? src.ContractNumber : null)
            )
            .ForMember(
                dest => dest.Produit,
                opt => opt.MapFrom(src => !src.UVCode.IsNullOrEmpty() ? src.UVCode : null)
            );

        CreateMap<CriteriaModel, CriterionDto>()
            .ForMember(
                dest => dest.Region,
                opt => opt.MapFrom(src => !src.DistributorRegion.IsNullOrEmpty() ? src.DistributorRegion : null)
            )
            .ForMember(
                dest => dest.Reseau,
                opt => opt.MapFrom(src => !src.Network.IsNullOrEmpty() ? src.Network : null)
            )
            .ForMember(dest => dest.Branche, opt => opt.MapFrom(src => !src.Branch.IsNullOrEmpty() ? src.Branch : null))
            .ForMember(dest => dest.Copht, opt => opt.MapFrom(src => src.Copht.HasValue ? src.Copht : null))
            .ForMember(
                dest => dest.Departement,
                opt => opt.MapFrom(src => !src.DistributorDepartment.IsNullOrEmpty() ? src.DistributorDepartment : null)
            )
            .ForMember(
                dest => dest.CategorieContrat,
                opt => opt.MapFrom(src => !src.ContractCategory.IsNullOrEmpty() ? src.ContractCategory : null)
            )
            .ForMember(
                dest => dest.NomIntermediaire,
                opt => opt.MapFrom(src => !src.IntermediateName.IsNullOrEmpty() ? src.IntermediateName : null)
            )
            .ForMember(
                dest => dest.Portefeuille,
                opt => opt.MapFrom(src => !src.PortfolioCode.IsNullOrEmpty() ? src.PortfolioCode : null)
            )
            .ForMember(
                dest => dest.CodeSyndic,
                opt => opt.MapFrom(src => !src.SyndicCode.IsNullOrEmpty() ? src.SyndicCode : null)
            )
            .ForMember(
                dest => dest.CodeNaf,
                opt => opt.MapFrom(src => !src.NafCode.IsNullOrEmpty() ? src.NafCode : null)
            )
            .ForMember(
                dest => dest.NumeroClient,
                opt => opt.MapFrom(src => !src.ClientNumber.IsNullOrEmpty() ? src.ClientNumber : null)
            )
            .ForMember(
                dest => dest.ChargeDeClientele,
                opt => opt.MapFrom(src => !src.AccountManager.IsNullOrEmpty() ? src.AccountManager : null)
            )
            .ForMember(
                dest => dest.NumeroContrat,
                opt => opt.MapFrom(src => !src.ContractNumber.IsNullOrEmpty() ? src.ContractNumber : null)
            )
            .ForMember(
                dest => dest.Produit,
                opt => opt.MapFrom(src => !src.UVCode.IsNullOrEmpty() ? src.UVCode : null)
            );

        #endregion

        #region Affectation

        CreateMap<AffectationDto, Affectation>()
            .ForMember(dest => dest.AffectedTeam, opt => opt.MapFrom(src => src.AffecteEquipe))
            .ForMember(dest => dest.AffectedRegion, opt => opt.MapFrom(src => src.AffecteRegion))
            .ForMember(dest => dest.AffectedEmployee, opt => opt.MapFrom(src => src.AffecteCollaborateur))
            .ForMember(dest => dest.AffectedEmployeeId, opt => opt.MapFrom(src => src.MatriculeCollaborateur))
            .ForMember(dest => dest.AffectationDate, opt => opt.MapFrom(src => src.DateAffectation))
            .ForMember(dest => dest.AffectationDemandDate, opt => opt.MapFrom(src => src.DateDemandeAffectation));
        CreateMap<Affectation, AffectationDto>()
            .ForMember(dest => dest.AffecteEquipe, opt => opt.MapFrom(src => src.AffectedTeam))
            .ForMember(dest => dest.AffecteRegion, opt => opt.MapFrom(src => src.AffectedRegion))
            .ForMember(dest => dest.AffecteCollaborateur, opt => opt.MapFrom(src => src.AffectedEmployee))
            .ForMember(dest => dest.MatriculeCollaborateur, opt => opt.MapFrom(src => src.AffectedEmployeeId))
            .ForMember(
                dest => dest.DateAffectation,
                opt =>
                    opt.MapFrom(src =>
                        src.AffectationDate != null
                            ? src.AffectationDate.Value.ToString(dateFormat, CultureInfo.InvariantCulture)
                            : null
                    )
            )
            .ForMember(
                dest => dest.DateDemandeAffectation,
                opt =>
                    opt.MapFrom(src =>
                        src.AffectationDemandDate != null
                            ? src.AffectationDemandDate.Value.ToString(dateFormat, CultureInfo.InvariantCulture)
                            : null
                    )
            );

        #endregion

        #region Conditions

        CreateMap<Conditions, ConditionsDto>()
            .ForMember(
                dest => dest.ConditionChargeDeClientele,
                opt =>
                    opt.MapFrom(src =>
                        !src.AccountManagerCondition.IsNullOrEmpty() ? src.AccountManagerCondition : null
                    )
            )
            .ForMember(
                dest => dest.ConditionNumeroClient,
                opt => opt.MapFrom(src => !src.ClientNumberCondition.IsNullOrEmpty() ? src.ClientNumberCondition : null)
            )
            .ForMember(
                dest => dest.ConditionCodeNaf,
                opt => opt.MapFrom(src => !src.NafCodeCondition.IsNullOrEmpty() ? src.NafCodeCondition : null)
            )
            .ForMember(
                dest => dest.ConditionCodeSyndic,
                opt => opt.MapFrom(src => !src.SyndicCodeCondition.IsNullOrEmpty() ? src.SyndicCodeCondition : null)
            )
            .ForMember(
                dest => dest.ConditionClause,
                opt => opt.MapFrom(src => !src.ClauseCondition.IsNullOrEmpty() ? src.ClauseCondition : null)
            )
            .ForMember(
                dest => dest.ConditionPortefeuille,
                opt => opt.MapFrom(src => !src.PortfolioCondition.IsNullOrEmpty() ? src.PortfolioCondition : null)
            )
            .ForMember(
                dest => dest.ConditionNomIntermediaire,
                opt =>
                    opt.MapFrom(src =>
                        !src.IntermediateNameCondition.IsNullOrEmpty() ? src.IntermediateNameCondition : null
                    )
            )
            .ForMember(
                dest => dest.ConditionProduit,
                opt => opt.MapFrom(src => !src.UVCodeCondition.IsNullOrEmpty() ? src.UVCodeCondition : null)
            )
            .ForMember(
                dest => dest.ConditionCopht,
                opt => opt.MapFrom(src => !src.CophtCondition.IsNullOrEmpty() ? src.CophtCondition : null)
            )
            .ForMember(
                dest => dest.ConditionDepartement,
                opt => opt.MapFrom(src => !src.DepartmentCondition.IsNullOrEmpty() ? src.DepartmentCondition : null)
            )
            .ForMember(
                dest => dest.ConditionReseau,
                opt => opt.MapFrom(src => !src.NetworkCondition.IsNullOrEmpty() ? src.NetworkCondition : null)
            )
            .ForMember(
                dest => dest.ConditionRegion,
                opt => opt.MapFrom(src => !src.RegionCondition.IsNullOrEmpty() ? src.RegionCondition : null)
            )
            .ForMember(
                dest => dest.ConditionBranche,
                opt => opt.MapFrom(src => !src.BranchCondition.IsNullOrEmpty() ? src.BranchCondition : null)
            )
            .ForMember(
                dest => dest.ConditionSegmentation,
                opt => opt.MapFrom(src => !src.SegmentationCondition.IsNullOrEmpty() ? src.SegmentationCondition : null)
            )
            .ForMember(
                dest => dest.ConditionNumeroContrat,
                opt =>
                    opt.MapFrom(src =>
                        !src.ContractNumberCondition.IsNullOrEmpty() ? src.ContractNumberCondition : null
                    )
            )
            .ForMember(
                dest => dest.ConditionCategorieContrat,
                opt =>
                    opt.MapFrom(src =>
                        !src.ContractCategoryCondition.IsNullOrEmpty() ? src.ContractCategoryCondition : null
                    )
            );

        CreateMap<ConditionsDto, Conditions>()
            .ForMember(
                dest => dest.AccountManagerCondition,
                opt =>
                    opt.MapFrom(src =>
                        !src.ConditionChargeDeClientele.IsNullOrEmpty() ? src.ConditionChargeDeClientele : null
                    )
            )
            .ForMember(
                dest => dest.ClientNumberCondition,
                opt => opt.MapFrom(src => !src.ConditionNumeroClient.IsNullOrEmpty() ? src.ConditionNumeroClient : null)
            )
            .ForMember(
                dest => dest.NafCodeCondition,
                opt => opt.MapFrom(src => !src.ConditionCodeNaf.IsNullOrEmpty() ? src.ConditionCodeNaf : null)
            )
            .ForMember(
                dest => dest.SyndicCodeCondition,
                opt => opt.MapFrom(src => !src.ConditionCodeSyndic.IsNullOrEmpty() ? src.ConditionCodeSyndic : null)
            )
            .ForMember(
                dest => dest.ClauseCondition,
                opt => opt.MapFrom(src => !src.ConditionClause.IsNullOrEmpty() ? src.ConditionClause : null)
            )
            .ForMember(
                dest => dest.PortfolioCondition,
                opt => opt.MapFrom(src => !src.ConditionPortefeuille.IsNullOrEmpty() ? src.ConditionPortefeuille : null)
            )
            .ForMember(
                dest => dest.IntermediateNameCondition,
                opt =>
                    opt.MapFrom(src =>
                        !src.ConditionNomIntermediaire.IsNullOrEmpty() ? src.ConditionNomIntermediaire : null
                    )
            )
            .ForMember(
                dest => dest.UVCodeCondition,
                opt => opt.MapFrom(src => !src.ConditionProduit.IsNullOrEmpty() ? src.ConditionProduit : null)
            )
            .ForMember(
                dest => dest.CophtCondition,
                opt => opt.MapFrom(src => !src.ConditionCopht.IsNullOrEmpty() ? src.ConditionCopht : null)
            )
            .ForMember(
                dest => dest.DepartmentCondition,
                opt => opt.MapFrom(src => !src.ConditionDepartement.IsNullOrEmpty() ? src.ConditionDepartement : null)
            )
            .ForMember(
                dest => dest.NetworkCondition,
                opt => opt.MapFrom(src => !src.ConditionReseau.IsNullOrEmpty() ? src.ConditionReseau : null)
            )
            .ForMember(
                dest => dest.RegionCondition,
                opt => opt.MapFrom(src => !src.ConditionRegion.IsNullOrEmpty() ? src.ConditionRegion : null)
            )
            .ForMember(
                dest => dest.BranchCondition,
                opt => opt.MapFrom(src => !src.ConditionBranche.IsNullOrEmpty() ? src.ConditionBranche : null)
            )
            .ForMember(
                dest => dest.SegmentationCondition,
                opt => opt.MapFrom(src => !src.ConditionSegmentation.IsNullOrEmpty() ? src.ConditionSegmentation : null)
            )
            .ForMember(
                dest => dest.ContractNumberCondition,
                opt =>
                    opt.MapFrom(src => !src.ConditionNumeroContrat.IsNullOrEmpty() ? src.ConditionNumeroContrat : null)
            )
            .ForMember(
                dest => dest.ContractCategoryCondition,
                opt =>
                    opt.MapFrom(src =>
                        !src.ConditionCategorieContrat.IsNullOrEmpty() ? src.ConditionCategorieContrat : null
                    )
            );

        #endregion

        #region PagedData<Rule>
        CreateMap<PagedData<Rule>, PaginationResponseRuleDto>()
            .ForMember(dest => dest.NumPage, opt => opt.MapFrom(src => src.Page))
            .ForMember(dest => dest.TotalPages, opt => opt.MapFrom(src => src.TotalPages))
            .ForMember(dest => dest.Size, opt => opt.MapFrom(src => src.Size))
            .ForMember(dest => dest.Content, opt => opt.MapFrom(src => src.Data))
            .ForMember(dest => dest.TotaleRegles, opt => opt.MapFrom(src => src.TotalData))
            .ReverseMap();

        #endregion

        #region RuleMassUpdate
        CreateMap<RuleMassUpdate, BulkUpdateDto>()
            .ForMember(dest => dest.Ids, opt => opt.MapFrom(src => src.Ids))
            .ForMember(dest => dest.MatriculeCollaborateur, opt => opt.MapFrom(src => src.AffectedEmployeeId))
            .ForMember(dest => dest.AffecteCollaborateur, opt => opt.MapFrom(src => src.AffectedEmployee))
            .ForMember(dest => dest.AffecteEquipe, opt => opt.MapFrom(src => src.AffectedTeam))
            .ForMember(dest => dest.Commentaire, opt => opt.MapFrom(src => src.Comment))
            .ForMember(dest => dest.DateFin, opt => opt.MapFrom(src => src.EndDate ?? null));

        #endregion
    }
}
