using System.Linq.Expressions;
using Affectations.Domain.Specifications;
using Affectations.Infrastructure.Data.Models;
using Affectations.Infrastructure.Models;

namespace Affectations.Infrastructure.Specifications;

public class RuleCriterionLabelSearchSpecification : PagedDataSearch, ISpecification
{
    private static Expression<Func<TRuleCriterion, bool>> _expression = x => true;

    public RuleCriterionLabelSearchSpecification(string categoryCode, string labelStartsWithFilter)
    {
        _expression = x =>
            x.RuleCriterionCategoryCode == categoryCode
            && (
                (!string.IsNullOrEmpty(x.Label) && x.Label.StartsWith(labelStartsWithFilter))
                || (x.Code.StartsWith(labelStartsWithFilter))
            );
    }

    public static Expression<Func<TRuleCriterion, bool>> ToExpression(
        RuleCriterionLabelSearchSpecification ruleCriterionLabelSearchSpecification
    ) => _expression;
}
