using System.Linq.Expressions;
using Affectations.Domain.Specifications;
using Affectations.Infrastructure.Data.Models;
using Affectations.Infrastructure.Models;

namespace Affectations.Infrastructure.Specifications;

public class EmployeeLastNameSearchSpecification : PagedDataSearch, ISpecification
{
    private static Expression<Func<TEmployee, bool>> _expression = x => true;

    public EmployeeLastNameSearchSpecification(string lastNameStartsWithFilter)
    {
        _expression = x => !string.IsNullOrEmpty(x.LastName) && x.LastName.StartsWith(lastNameStartsWithFilter);
    }

    public static Expression<Func<TEmployee, bool>> ToExpression(
        EmployeeLastNameSearchSpecification employeeLastNameSearchSpecification
    ) => _expression;
}
