namespace Affectations.Infrastructure.Configurations;

public class ServicesOptionsSettings
{
    public const string ConfigurationKey = "ServicesOptions:ClientMRMApiOptions";
    public required Uri EndpointUrl { get; set; }
}
