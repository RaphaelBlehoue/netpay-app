namespace Affectations.Infrastructure.Configurations;

public class RetryOptions
{
    public bool IsEnabled { get; set; }
    public int Retries { get; set; }
    public int DelayInMS { get; set; }
}
