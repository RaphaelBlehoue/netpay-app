namespace Affectations.Infrastructure.Configurations;

public class ResilienceOptions
{
    public const string Resilience = "Resilience";
    public RetryOptions? Retry { get; set; }
}
