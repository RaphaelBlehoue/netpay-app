using Affectations.Domain.Repositories;
using Affectations.Domain.Services;
using Affectations.Infrastructure.Configurations;
using Affectations.Infrastructure.Mappers;
using Affectations.Infrastructure.Repositories;
using Affectations.Infrastructure.Stores;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Polly;
using Polly.Extensions.Http;
using Serilog;

namespace Affectations.Infrastructure;

public static class InfrastructureServiceCollection
{
    public static void ConfigureInfrastructureServices(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddScoped<IEmployeeService, EmployeeRepository>();
        services.AddScoped<IRuleCriterionRepository, RuleCriterionRepository>();
        services.AddScoped<IRuleCriterionService, RuleCriterionRepository>();
        services.AddScoped<IRuleRepository, RuleRepository>();
        services.AddScoped<ITeamRepository, TeamRepository>();

        var resilienceConfig = configuration.GetRequiredSection(ResilienceOptions.Resilience).Get<ResilienceOptions>();
        services.Configure<ResilienceOptions>(configuration.GetRequiredSection(ResilienceOptions.Resilience));
        services.AddScoped<IRulesStore, RulesStore>();
        var servicesOptionsSettings = configuration
            .GetRequiredSection(ServicesOptionsSettings.ConfigurationKey)
            .Get<ServicesOptionsSettings>()!;
        services
            .AddHttpClient<IRulesStore, RulesStore>(httpClient =>
            {
                httpClient.BaseAddress = servicesOptionsSettings.EndpointUrl;
            })
            .AddPolicyHandler(
                (_, request) =>
                {
                    if (IsIdempotent(request.Method))
                    {
                        return GetRetryPolicy(resilienceConfig);
                    }
                    return Policy.NoOpAsync<HttpResponseMessage>();
                }
            );
        ;

        services.AddAutoMapper(typeof(MapperProfiles));
    }

    private static IAsyncPolicy<HttpResponseMessage> GetRetryPolicy(ResilienceOptions config)
    {
        return HttpPolicyExtensions
            .HandleTransientHttpError()
            .OrResult(msg => msg.StatusCode != System.Net.HttpStatusCode.OK)
            .WaitAndRetryAsync(
                config.Retry.Retries,
                retryAttempt => TimeSpan.FromMilliseconds(config.Retry.DelayInMS),
                (exception, timespan, retryCount, context) =>
                {
                    Log.Error(
                        $"Retry attempt {retryCount} failed with exception: {exception.Exception} Result: {exception.Result}"
                    );
                }
            );
    }

    private static bool IsIdempotent(HttpMethod method)
    {
        return method == HttpMethod.Get || method == HttpMethod.Put || method == HttpMethod.Delete;
    }
}
