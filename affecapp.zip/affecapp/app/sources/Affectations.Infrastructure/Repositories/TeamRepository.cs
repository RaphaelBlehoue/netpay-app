using Affectations.Domain.Entities;
using Affectations.Domain.Repositories;
using Affectations.Infrastructure.Data.Models;
using Microsoft.EntityFrameworkCore;

namespace Affectations.Infrastructure.Repositories;

public class TeamRepository : ITeamRepository
{
    private readonly AffectationsContext _affectationsContext;

    public TeamRepository(AffectationsContext affectationsContext)
    {
        _affectationsContext = affectationsContext;
    }

    public async Task<Team[]> GetTeamsAsync()
    {
        var teams = await _affectationsContext
            .TTeams.Select(static x => new Team
            {
                Code = x.Code,
                Name = x.Name,
                RegionCode = x.RegionCode
            })
            .ToArrayAsync();

        return teams;
    }
}
