using System.Net;
using Affectations.Domain.AggregatesRoots.RuleAggregate;
using Affectations.Domain.Exceptions;
using Affectations.Domain.Models;
using Affectations.Domain.Repositories;
using Affectations.Infrastructure.Stores;
using AutoMapper;

namespace Affectations.Infrastructure.Repositories;

public class RuleRepository : IRuleRepository
{
    private readonly IRulesStore _ruleStore;
    private readonly IMapper _mapper;

    public RuleRepository(IRulesStore ruleStore, IMapper mapper)
    {
        _ruleStore = ruleStore;
        _mapper = mapper;
    }

    public async Task<Rule> GetRuleByIdAsync(long id)
    {
        try
        {
            var result = await _ruleStore.GetRuleByIdAsync(id);
            return _mapper.Map<Rule>(result);
        }
        catch (ClientMRMApiException clientApiEx)
        {
            if (
                clientApiEx.StatusCode == (int)HttpStatusCode.OK
                || clientApiEx.StatusCode == (int)HttpStatusCode.NotFound
            )
            {
                throw new RuleNotFoundException(id, clientApiEx.StatusCode);
            }
            throw new RuleException(clientApiEx.Message);
        }
    }

    public async Task<Rule> AddRuleAsync(Rule rule)
    {
        try
        {
            var result = await _ruleStore.AddRuleAsync(_mapper.Map<RuleDto>(rule));
            var ruleAdded = _mapper.Map<Rule>(result);
            return ruleAdded;
        }
        catch (ClientMRMApiException clientApiEx) when (clientApiEx.StatusCode == (int)HttpStatusCode.BadRequest)
        {
            throw new RuleException("Bad request", clientApiEx);
        }
        catch (ClientMRMApiException clientApiEx) when (clientApiEx.StatusCode == (int)HttpStatusCode.NotFound)
        {
            throw new RuleException("Not found", clientApiEx);
        }
        catch (ClientMRMApiException clientApiEx)
        {
            throw new RuleException(clientApiEx.Message);
        }
        catch (Exception ex)
        {
            throw new RuleException(ex.Message);
        }
    }

    public async Task<Rule> UpdateRuleAsync(Rule rule)
    {
        try
        {
            await _ruleStore.UpdateRuleAsync(_mapper.Map<RuleDto>(rule));
            return rule;
        }
        catch (ClientMRMApiException clientApiEx) when (clientApiEx.StatusCode == (int)HttpStatusCode.BadRequest)
        {
            throw new RuleException("Bad request", clientApiEx);
        }
        catch (ClientMRMApiException clientApiEx) when (clientApiEx.StatusCode == (int)HttpStatusCode.NotFound)
        {
            throw new RuleException("Not found", clientApiEx);
        }
        catch (ClientMRMApiException clientApiEx)
        {
            throw new RuleException(clientApiEx.Message);
        }
        catch (Exception ex)
        {
            throw new RuleException(ex.Message);
        }
    }

    public async Task<PagedData<Rule>> SearchRulesAsync(int page, int size, FilterRuleModel rule)
    {
        try
        {
            var ruleDto = _mapper.Map<FiltreRulesDto>(rule);
            var result = await _ruleStore.GetAllRulesAsync(page, size, ruleDto);
            return _mapper.Map<PagedData<Rule>>(result);
        }
        catch (ClientMRMApiException clientApiEx) when (clientApiEx.StatusCode == (int)HttpStatusCode.BadRequest)
        {
            throw new RuleException("Bad request", clientApiEx);
        }
        catch (ClientMRMApiException clientApiEx) when (clientApiEx.StatusCode == (int)HttpStatusCode.NotFound)
        {
            throw new RuleException("Not found", clientApiEx);
        }
        catch (ClientMRMApiException clientApiEx)
        {
            throw new RuleException(clientApiEx.Message);
        }
        catch (Exception ex)
        {
            throw new RuleException(ex.Message);
        }
    }

    public async Task<int> UpdateRulesAsync(RuleMassUpdate ruleMassUpdate)
    {
        try
        {
            var bulkUpdateDto = _mapper.Map<BulkUpdateDto>(ruleMassUpdate);
            return await _ruleStore.UpdateRulesAsync(bulkUpdateDto);
        }
        catch (ClientMRMApiException clientApiEx) when (clientApiEx.StatusCode == (int)HttpStatusCode.BadRequest)
        {
            throw new RuleException("Bad request", clientApiEx);
        }
        catch (ClientMRMApiException clientApiEx) when (clientApiEx.StatusCode == (int)HttpStatusCode.NotFound)
        {
            throw new RuleException("Not found", clientApiEx);
        }
        catch (ClientMRMApiException clientApiEx)
        {
            throw new RuleException(clientApiEx.Message);
        }
        catch (Exception ex)
        {
            throw new RuleException(ex.Message);
        }
    }

    public async Task<ICollection<Rule>> ExportRules(FilterRuleModel rule)
    {
        try
        {
            var ruleDto = _mapper.Map<FiltreRulesDto>(rule);
            if (ruleDto.Ids.Any())
            {
                ruleDto.RuleDetails = null;
                ruleDto.Affectations = null;
                ruleDto.Criterion = null;
                ruleDto.Conditions = null;
            }
            var rules = await _ruleStore.ExportReglesAsync(ruleDto);
            if (rules is null)
            {
                throw new RuleException("Not found");
            }

            return _mapper.Map<ICollection<Rule>>(rules);
        }
        catch (ClientMRMApiException clientApiEx) when (clientApiEx.StatusCode == (int)HttpStatusCode.BadRequest)
        {
            throw new RuleException("Bad request", clientApiEx);
        }
        catch (ClientMRMApiException clientApiEx) when (clientApiEx.StatusCode == (int)HttpStatusCode.NotFound)
        {
            throw new RuleException("Not found", clientApiEx);
        }
        catch (ClientMRMApiException clientApiEx)
        {
            throw new RuleException(clientApiEx.Message);
        }
        catch (Exception ex)
        {
            throw new RuleException(ex.Message);
        }
    }
}
