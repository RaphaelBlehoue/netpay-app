using Affectations.Domain.Entities;
using Affectations.Domain.Models;
using Affectations.Domain.Repositories;
using Affectations.Domain.Services;
using Affectations.Domain.Specifications;
using Affectations.Infrastructure.Data.Models;
using Affectations.Infrastructure.Specifications;
using Microsoft.EntityFrameworkCore;

namespace Affectations.Infrastructure.Repositories;

public class RuleCriterionRepository : IRuleCriterionRepository, IRuleCriterionService
{
    private readonly AffectationsContext _affectationsContext;

    public RuleCriterionRepository(AffectationsContext affectationsContext)
    {
        _affectationsContext = affectationsContext;
    }

    public async Task<string[]> GetRuleCriteriaByCategorieCode(string code)
    {
        var queryResult = await _affectationsContext
            .TRuleCriteria.Where(x => x.RuleCriterionCategoryCode == code)
            .Select(static x => x.Code)
            .ToArrayAsync();
        return queryResult;
    }

    public Task<RuleCriterionCategory[]> GetRuleCriteriaAsync(int rowCountPerCriterion)
    {
        return _affectationsContext
            .TRuleCriterionCategories.Select(ruleCriterionCategory => new RuleCriterionCategory
            {
                Code = ruleCriterionCategory.Code,
                Label = ruleCriterionCategory.Label,
                RuleCriteria = ruleCriterionCategory
                    .TRuleCriteria.OrderBy(ruleCriterion => ruleCriterion.Label)
                    .Take(rowCountPerCriterion)
                    .Select(static ruleCriterion => new RuleCriterion
                    {
                        Code = ruleCriterion.Code,
                        Label = ruleCriterion.Label
                    })
                    .ToArray()
            })
            .ToArrayAsync();
    }

    public async Task<PagedData<RuleCriterion>> SearchRuleCriteriaAsync(ISpecification specification)
    {
        var ruleCriterionLabelSearchSpecification = (specification as RuleCriterionLabelSearchSpecification);

        var entitiesToSkip =
            (ruleCriterionLabelSearchSpecification.PageNumber - 1) * ruleCriterionLabelSearchSpecification.PageSize;

        var queryResult = _affectationsContext
            .TRuleCriteria.Where(
                RuleCriterionLabelSearchSpecification.ToExpression(ruleCriterionLabelSearchSpecification)
            )
            .Select(static x => new RuleCriterion { Code = x.Code, Label = x.Label });

        var paginatedQuery = queryResult
            .OrderBy(x => x.Label)
            .Skip(entitiesToSkip)
            .Take(ruleCriterionLabelSearchSpecification.PageSize);

        var count = await queryResult.CountAsync();
        var totalpages = 0;
        if (ruleCriterionLabelSearchSpecification.PageSize > 0)
        {
            totalpages =
                (count / ruleCriterionLabelSearchSpecification.PageSize)
                + (count % ruleCriterionLabelSearchSpecification.PageSize > 0 ? 1 : 0);
        }

        return new PagedData<RuleCriterion>
        {
            Data = paginatedQuery,
            TotalPages = totalpages,
            Page = ruleCriterionLabelSearchSpecification.PageNumber,
            Size = ruleCriterionLabelSearchSpecification.PageSize,
            TotalData = count
        };
    }
}
