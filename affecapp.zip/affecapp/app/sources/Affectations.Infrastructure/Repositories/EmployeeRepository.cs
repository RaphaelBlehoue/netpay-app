using Affectations.Domain.Entities;
using Affectations.Domain.Models;
using Affectations.Domain.Services;
using Affectations.Domain.Specifications;
using Affectations.Infrastructure.Data.Models;
using Affectations.Infrastructure.Specifications;
using Microsoft.EntityFrameworkCore;

namespace Affectations.Infrastructure.Repositories;

public class EmployeeRepository : IEmployeeService
{
    private readonly AffectationsContext _affectationsContext;

    public EmployeeRepository(AffectationsContext affectationsContext)
    {
        _affectationsContext = affectationsContext;
    }

    public async Task<PagedData<Employee>> SearchEmployeesAsync(ISpecification specification)
    {
        var employeeLastNameSearchSpecification = (specification as EmployeeLastNameSearchSpecification);

        var entitiesToSkip =
            (employeeLastNameSearchSpecification.PageNumber - 1) * employeeLastNameSearchSpecification.PageSize;

        var queryResult = _affectationsContext
            .TEmployees.Where(EmployeeLastNameSearchSpecification.ToExpression(employeeLastNameSearchSpecification))
            .Select(static x => new Employee
            {
                Id = x.Id,
                LastName = x.LastName,
                FirstName = x.FirstName
            });

        var paginatedQuery = queryResult
            .OrderBy(x => x.LastName)
            .Skip(entitiesToSkip)
            .Take(employeeLastNameSearchSpecification.PageSize);

        var count = await queryResult.CountAsync();
        var totalpages = 0;
        if (employeeLastNameSearchSpecification.PageSize > 0)
        {
            totalpages =
                (count / employeeLastNameSearchSpecification.PageSize)
                + (count % employeeLastNameSearchSpecification.PageSize > 0 ? 1 : 0);
        }

        return new PagedData<Employee>
        {
            Data = paginatedQuery,
            TotalPages = totalpages,
            Page = employeeLastNameSearchSpecification.PageNumber,
            Size = employeeLastNameSearchSpecification.PageSize,
            TotalData = count
        };
    }
}
