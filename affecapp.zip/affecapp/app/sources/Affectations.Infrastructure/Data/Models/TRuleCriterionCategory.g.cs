﻿using System;
using System.Collections.Generic;

namespace Affectations.Infrastructure.Data.Models;

public partial class TRuleCriterionCategory
{
    public string Code { get; set; } = null!;

    public string? Label { get; set; }

    public virtual ICollection<TRuleCriterion> TRuleCriteria { get; set; } = new List<TRuleCriterion>();
}
