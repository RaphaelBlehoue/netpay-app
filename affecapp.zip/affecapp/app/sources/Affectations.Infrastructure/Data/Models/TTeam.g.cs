namespace Affectations.Infrastructure.Data.Models;

public partial class TTeam
{
    public string Code { get; set; } = null!;

    public string Name { get; set; } = null!;

    public string RegionCode { get; set; } = null!;
}
