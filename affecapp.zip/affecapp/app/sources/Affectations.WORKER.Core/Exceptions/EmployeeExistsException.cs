namespace Affectations.WORKER.Core.Exceptions;

[Serializable]
public class EmployeeExistsException : Exception
{
    public EmployeeExistsException()
        : base("Le traitement d'ajout d'employé est en erreur!") { }

    public EmployeeExistsException(string message)
        : base(message) { }

    public EmployeeExistsException(string message, Exception innerException)
        : base(message, innerException) { }
}
