namespace Affectations.WORKER.Core.Exceptions;

[Serializable]
public class EmployeeNotValidException : Exception
{
    public EmployeeNotValidException()
        : base("Le traitement d'ajout d'employé est en erreur!") { }

    public EmployeeNotValidException(string message)
        : base(message) { }

    public EmployeeNotValidException(string message, Exception innerException)
        : base(message, innerException) { }
}
