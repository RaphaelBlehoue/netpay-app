using AxaFrance.Kafka.FrRoiPeopleActiveUpdatedEvt_V2_0;

namespace Affectations.WORKER.Core.Ports;

public interface IPeopleActiveUploadedEventProcessor
{
    Task ProcessAsync(FrRoiPeopleActiveUpdatedEvtV2Payload payload, CancellationToken cancellationToken);
}
