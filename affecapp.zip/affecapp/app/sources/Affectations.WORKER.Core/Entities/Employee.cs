using Affectations.WORKER.Core.Exceptions;

namespace Affectations.WORKER.Core.Entities;

public class Employee
{
    public string Id { get; set; } = null!;
    public string? LastName { get; set; }
    public string? FirstName { get; set; }

    public Employee() { }

    public Employee(string id, string? lastName, string? firstName)
    {
        if (string.IsNullOrEmpty(id))
        {
            throw new EmployeeNotValidException("Le matricule de l'employé n'est pas valide.");
        }

        Id = id;
        LastName = lastName;
        FirstName = firstName;
    }
}
