using Affectations.WORKER.Core.Entities;

namespace Affectations.WORKER.Core.Repositories;

public interface IEmployeeRepository
{
    Task AddEmployeeAsync(Employee employee);
}
