using System.Globalization;
using Affectations.App.Constants;
using Affectations.App.Dtos;
using Affectations.Domain.AggregatesRoots.RuleAggregate;
using Affectations.Domain.Models;
using AutoMapper;
using Microsoft.IdentityModel.Tokens;

namespace Affectations.App.Mappers;

public class MapperProfiles : Profile
{
    private const string format = "dd/MM/yyyy HH:mm:ss";
    private const char ValueSeparator = ';';

    public const string MRMCophtConditionsString = ">=";
    public const string BFFCophtConditionsString = "plus grand ou égal à";

    private static Conditions GetConditionsFromRules(RulePersistance rule)
    {
        return new Conditions
        {
            AccountManagerCondition = rule.Rules.TryGetValue(CriteriaNames.AccountManager, out var accountManager)
                ? accountManager.Condition
                : null,
            ClientNumberCondition = rule.Rules.TryGetValue(CriteriaNames.ClientNumber, out var clientNumber)
                ? clientNumber.Condition
                : null,
            NafCodeCondition = rule.Rules.TryGetValue(CriteriaNames.NafCode, out var nafCode)
                ? nafCode.Condition
                : null,
            SyndicCodeCondition = rule.Rules.TryGetValue(CriteriaNames.SyndicCode, out var syndicCode)
                ? syndicCode.Condition
                : null,
            ClauseCondition = rule.Rules.TryGetValue(CriteriaNames.Clause, out var clause) ? clause.Condition : null,
            PortfolioCondition = rule.Rules.TryGetValue(CriteriaNames.Portfolio, out var portfolio)
                ? portfolio.Condition
                : null,
            IntermediateNameCondition = rule.Rules.TryGetValue(CriteriaNames.IntermediateName, out var intermediateName)
                ? intermediateName.Condition
                : null,
            UVCodeCondition = rule.Rules.TryGetValue(CriteriaNames.UVCode, out var uvcode) ? uvcode.Condition : null,
            CophtCondition = rule.Rules.TryGetValue(CriteriaNames.Copht, out _) ? MRMCophtConditionsString : null,
            DepartmentCondition = rule.Rules.TryGetValue(CriteriaNames.Department, out var department)
                ? department.Condition
                : null,
            NetworkCondition = rule.Rules.TryGetValue(CriteriaNames.Network, out var network)
                ? network.Condition
                : null,
            RegionCondition = rule.Rules.TryGetValue(CriteriaNames.Region, out var region) ? region.Condition : null,
            BranchCondition = rule.Rules.TryGetValue(CriteriaNames.Branch, out var branch) ? branch.Condition : null,
            SegmentationCondition = rule.Rules.TryGetValue(CriteriaNames.Segmentation, out var segmentation)
                ? segmentation.Condition
                : null,
            ContractCategoryCondition = rule.Rules.TryGetValue(CriteriaNames.ContractCategory, out var contractCategory)
                ? contractCategory.Condition
                : null,
            ContractNumberCondition = rule.Rules.TryGetValue(CriteriaNames.ContractNumber, out var contractNumber)
                ? contractNumber.Condition
                : null
        };
    }

    private static Criteria GetCriteresFromRules(RulePersistance rule)
    {
        return new Criteria
        {
            AccountManager = rule.Rules.TryGetValue(CriteriaNames.AccountManager.ToString(), out var accountManager)
                ? accountManager.Values
                : null,
            ClientNumber = rule.Rules.TryGetValue(CriteriaNames.ClientNumber.ToString(), out var clientNumber)
                ? clientNumber.Values
                : null,
            NafCode = rule.Rules.TryGetValue(CriteriaNames.NafCode.ToString(), out var nafCode) ? nafCode.Values : null,
            SyndicCode = rule.Rules.TryGetValue(CriteriaNames.SyndicCode.ToString(), out var syndicCode)
                ? syndicCode.Values
                : null,
            Clause = rule.Rules.TryGetValue(CriteriaNames.Clause.ToString(), out var clause) ? clause.Values : null,
            PortfolioCode = rule.Rules.TryGetValue(CriteriaNames.Portfolio.ToString(), out var portfolio)
                ? portfolio.Values
                : null,
            IntermediateName = rule.Rules.TryGetValue(
                CriteriaNames.IntermediateName.ToString(),
                out var intermediateName
            )
                ? intermediateName.Values
                : null,
            UVCode = rule.Rules.TryGetValue(CriteriaNames.UVCode.ToString(), out var product) ? product.Values : null,
            Copht = rule.Rules.TryGetValue(CriteriaNames.Copht.ToString(), out var copht) ? copht.Values : null,
            DistributorDepartment = rule.Rules.TryGetValue(CriteriaNames.Department.ToString(), out var department)
                ? department.Values
                : null,
            Network = rule.Rules.TryGetValue(CriteriaNames.Network.ToString(), out var network) ? network.Values : null,
            DistributorRegion = rule.Rules.TryGetValue(CriteriaNames.Region.ToString(), out var region)
                ? region.Values
                : null,
            Branch = rule.Rules.TryGetValue(CriteriaNames.Branch.ToString(), out var branch) ? branch.Values : null,
            Segmentation = rule.Rules.TryGetValue(CriteriaNames.Segmentation.ToString(), out var segmentation)
                ? segmentation.Values
                : null,
            ContractCategory = rule.Rules.TryGetValue(
                CriteriaNames.ContractCategory.ToString(),
                out var contractCategory
            )
                ? contractCategory.Values
                : null,
            ContractNumber = rule.Rules.TryGetValue(CriteriaNames.ContractNumber.ToString(), out var contractNumber)
                ? contractNumber.Values
                : null
        };
    }

    private static CriteresDto GetCriteresDtoFromCriteria(Criteria criteria)
    {
        return new CriteresDto
        {
            AccountManager = !criteria.AccountManager.IsNullOrEmpty()
                ? GetDelimitedStringValue(criteria.AccountManager)
                : null,
            ClientNumber = !criteria.ClientNumber.IsNullOrEmpty()
                ? GetDelimitedStringValue(criteria.ClientNumber)
                : null,
            NafCode = !criteria.NafCode.IsNullOrEmpty() ? GetDelimitedStringValue(criteria.NafCode) : null,
            SyndicCode = !criteria.SyndicCode.IsNullOrEmpty() ? GetDelimitedStringValue(criteria.SyndicCode) : null,
            Clause = !criteria.Clause.IsNullOrEmpty() ? GetDelimitedStringValue(criteria.Clause) : null,
            PortfolioCode = !criteria.PortfolioCode.IsNullOrEmpty()
                ? GetDelimitedStringValue(criteria.PortfolioCode)
                : null,
            IntermediateName = !criteria.IntermediateName.IsNullOrEmpty()
                ? GetDelimitedStringValue(criteria.IntermediateName)
                : null,
            UVCode = !criteria.UVCode.IsNullOrEmpty() ? GetDelimitedStringValue(criteria.UVCode) : null,
            Copht = !criteria.Copht.IsNullOrEmpty() ? GetFirstDecimalValue(criteria.Copht) : null,
            DistributorDepartment = !criteria.DistributorDepartment.IsNullOrEmpty()
                ? GetDelimitedStringValue(criteria.DistributorDepartment)
                : null,
            Network = !criteria.Network.IsNullOrEmpty() ? GetDelimitedStringValue(criteria.Network) : null,
            DistributorRegion = !criteria.DistributorRegion.IsNullOrEmpty()
                ? GetDelimitedStringValue(criteria.DistributorRegion)
                : null,
            Branch = !criteria.Branch.IsNullOrEmpty() ? GetDelimitedStringValue(criteria.Branch) : null,
            Segmentation = !criteria.Segmentation.IsNullOrEmpty()
                ? GetDelimitedStringValue(criteria.Segmentation)
                : null,
            ContractCategory = !criteria.ContractCategory.IsNullOrEmpty()
                ? GetDelimitedStringValue(criteria.ContractCategory)
                : null,
            ContractNumber = !criteria.ContractNumber.IsNullOrEmpty()
                ? GetDelimitedStringValue(criteria.ContractNumber)
                : null
        };
    }

    public MapperProfiles()
    {
        #region RuleDto
        CreateMap<Rule, RuleDto>()
            .ForMember(dest => dest.RuleDetailsDto, opt => opt.MapFrom(src => src.RuleDetails))
            .ForMember(dest => dest.CritereDto, opt => opt.MapFrom(src => GetCriteresDtoFromCriteria(src.Criteres)))
            .ForMember(dest => dest.AffectationDto, opt => opt.MapFrom(src => src.Affectation))
            .ForMember(dest => dest.ConditionsDto, opt => opt.MapFrom(src => src.Conditions));
        #endregion

        #region FilterRuleDto
        CreateMap<RuleDto, FilterRuleModel>()
            .ForMember(dest => dest.RuleDetails, opt => opt.MapFrom(src => src.RuleDetailsDto))
            .ForMember(dest => dest.Criteres, opt => opt.MapFrom(src => src.CritereDto))
            .ForMember(dest => dest.Affectation, opt => opt.MapFrom(src => src.AffectationDto))
            .ForMember(dest => dest.Conditions, opt => opt.MapFrom(src => src.ConditionsDto));
        CreateMap<FilterRuleDto, FilterRuleModel>()
            .ForMember(dest => dest.RuleDetails, opt => opt.MapFrom(src => src.RuleDetailsDto))
            .ForMember(dest => dest.Criteres, opt => opt.MapFrom(src => src.CritereDto))
            .ForMember(dest => dest.Affectation, opt => opt.MapFrom(src => src.AffectationDto))
            .ForMember(dest => dest.Conditions, opt => opt.MapFrom(src => src.ConditionsDto));
        #endregion

        #region RulePersistance
        CreateMap<RulePersistance, Rule>()
            .ForMember(dest => dest.RuleDetails, opt => opt.MapFrom(src => src.RuleDetailsDto))
            .ForMember(dest => dest.Affectation, opt => opt.MapFrom(src => src.AffectationDto))
            .ForMember(dest => dest.Conditions, opt => opt.MapFrom(src => GetConditionsFromRules(src)))
            .ForMember(dest => dest.Criteres, opt => opt.MapFrom(src => GetCriteresFromRules(src)));
        #endregion

        #region RuleDetails
        CreateMap<RuleDetails, RuleDetailsDto>()
            .ForMember(
                dest => dest.StartDate,
                opt =>
                    opt.MapFrom(src =>
                        src.StartDate != null
                            ? DateTime.ParseExact(
                                src.StartDate.Value.ToString(format, CultureInfo.InvariantCulture),
                                format,
                                CultureInfo.InvariantCulture
                            )
                            : (DateTime?)null
                    )
            )
            .ForMember(
                dest => dest.EndDate,
                opt =>
                    opt.MapFrom(src =>
                        src.EndDate != null
                            ? DateTime.ParseExact(
                                src.EndDate.Value.ToString(format, CultureInfo.InvariantCulture),
                                format,
                                CultureInfo.InvariantCulture
                            )
                            : (DateTime?)null
                    )
            )
            .ForMember(
                dest => dest.CreationDate,
                opt =>
                    opt.MapFrom(src =>
                        src.CreationDate != null
                            ? DateTime.ParseExact(
                                src.CreationDate.Value.ToString(format, CultureInfo.InvariantCulture),
                                format,
                                CultureInfo.InvariantCulture
                            )
                            : (DateTime?)null
                    )
            )
            .ForMember(
                dest => dest.UpdateDate,
                opt =>
                    opt.MapFrom(src =>
                        src.UpdateDate != null
                            ? DateTime.ParseExact(
                                src.UpdateDate.Value.ToString(format, CultureInfo.InvariantCulture),
                                format,
                                CultureInfo.InvariantCulture
                            )
                            : (DateTime?)null
                    )
            );

        CreateMap<RuleDetailsDto, RuleDetails>();
        #endregion

        #region Criteres
        CreateMap<CriteresDto, CriteriaModel>();
        #endregion

        #region Affectation
        CreateMap<Affectation, AffectationDto>()
            .ForMember(
                dest => dest.AffectationDate,
                opt =>
                    opt.MapFrom(src =>
                        src.AffectationDate != null
                            ? DateTime.ParseExact(
                                src.AffectationDate.Value.ToString(format, CultureInfo.InvariantCulture),
                                format,
                                CultureInfo.InvariantCulture
                            )
                            : (DateTime?)null
                    )
            )
            .ForMember(
                dest => dest.AffectationDemandDate,
                opt =>
                    opt.MapFrom(src =>
                        src.AffectationDemandDate != null
                            ? DateTime.ParseExact(
                                src.AffectationDemandDate.Value.ToString(format, CultureInfo.InvariantCulture),
                                format,
                                CultureInfo.InvariantCulture
                            )
                            : (DateTime?)null
                    )
            );

        CreateMap<AffectationDto, Affectation>();
        #endregion

        #region Conditions
        CreateMap<Conditions, ConditionsDto>()
            .ForMember(
                dest => dest.CophtCondition,
                opt => opt.MapFrom(src => !src.CophtCondition.IsNullOrEmpty() ? BFFCophtConditionsString : null)
            )
            .ForMember(dest => dest.ProductCondition, opt => opt.MapFrom(src => src.UVCodeCondition));
        CreateMap<ConditionsDto, Conditions>()
            .ForMember(dest => dest.UVCodeCondition, opt => opt.MapFrom(src => src.ProductCondition));

        #endregion

        #region PagedData<Rule>
        CreateMap<PagedData<Rule>, PagedData<RuleDto>>()
            .ForMember(dest => dest.Data, opt => opt.MapFrom(src => src.Data))
            .ReverseMap();
        #endregion

        #region RuleMassUpdate
        CreateMap<RuleMassUpdateDto, RuleMassUpdate>()
            .ForMember(dest => dest.Ids, opt => opt.MapFrom(src => src.Ids))
            .ForMember(dest => dest.AffectedEmployee, opt => opt.MapFrom(src => src.AffectedEmployee))
            .ForMember(dest => dest.AffectedEmployeeId, opt => opt.MapFrom(src => src.AffectedEmployeeId))
            .ForMember(dest => dest.AffectedTeam, opt => opt.MapFrom(src => src.AffectedTeam))
            .ForMember(dest => dest.Comment, opt => opt.MapFrom(src => src.Comment))
            .ForMember(
                dest => dest.EndDate,
                opt =>
                    opt.MapFrom(src =>
                        src.EndDate != null
                            ? DateTime.ParseExact(
                                src.EndDate.Value.ToString(format, CultureInfo.InvariantCulture),
                                format,
                                CultureInfo.InvariantCulture
                            )
                            : (DateTime?)null
                    )
            );
        #endregion

        #region Export
        CreateMap<Rule, RuleDtoExport>()
            .ForMember(dest => dest.RuleId, opt => opt.MapFrom(src => src.Id))
            .ForMember(dest => dest.Branche, opt => opt.MapFrom(src => string.Join(',', src.Criteres.Branch)))
            .ForMember(dest => dest.Region, opt => opt.MapFrom(src => string.Join(',', src.Criteres.DistributorRegion)))
            .ForMember(
                dest => dest.Segmentation,
                opt => opt.MapFrom(src => string.Join(',', src.Criteres.Segmentation))
            )
            .ForMember(dest => dest.Reseau, opt => opt.MapFrom(src => string.Join(',', src.Criteres.Network)))
            .ForMember(dest => dest.Copht, opt => opt.MapFrom(src => string.Join(',', src.Criteres.Copht)))
            .ForMember(
                dest => dest.Departement,
                opt => opt.MapFrom(src => string.Join(',', src.Criteres.DistributorDepartment))
            )
            .ForMember(
                dest => dest.Categorie,
                opt => opt.MapFrom(src => string.Join(',', src.Criteres.ContractCategory))
            )
            .ForMember(dest => dest.UVCode, opt => opt.MapFrom(src => string.Join(',', src.Criteres.UVCode)))
            .ForMember(
                dest => dest.Nom_Intermidiaire,
                opt => opt.MapFrom(src => string.Join(',', src.Criteres.IntermediateName))
            )
            .ForMember(
                dest => dest.Code_Portefeuille,
                opt => opt.MapFrom(src => string.Join(',', src.Criteres.PortfolioCode))
            )
            .ForMember(dest => dest.Clause, opt => opt.MapFrom(src => string.Join(',', src.Criteres.Clause)))
            .ForMember(dest => dest.Code_Syndic, opt => opt.MapFrom(src => string.Join(',', src.Criteres.SyndicCode)))
            .ForMember(dest => dest.Code_Naf, opt => opt.MapFrom(src => string.Join(',', src.Criteres.NafCode)))
            .ForMember(
                dest => dest.Numero_Client,
                opt => opt.MapFrom(src => string.Join(',', src.Criteres.ClientNumber))
            )
            .ForMember(
                dest => dest.charge_De_Clientele,
                opt => opt.MapFrom(src => string.Join(',', src.Criteres.AccountManager))
            )
            .ForMember(
                dest => dest.Numero_Contrat,
                opt => opt.MapFrom(src => string.Join(',', src.Criteres.ContractNumber))
            )
            .ForMember(dest => dest.Statut, opt => opt.MapFrom(src => src.RuleDetails.Statut))
            .ForMember(dest => dest.Commentaire_Metier, opt => opt.MapFrom(src => src.RuleDetails.Comment))
            .ForMember(
                dest => dest.DateCreation,
                opt => opt.MapFrom(src => src.RuleDetails.CreationDate.Value.ToString("dd/MM/yyyy HH:mm"))
            )
            .ForMember(
                dest => dest.DateDebut,
                opt => opt.MapFrom(src => src.RuleDetails.StartDate.Value.ToString("dd/MM/yyyy HH:mm"))
            )
            .ForMember(
                dest => dest.DateFin,
                opt => opt.MapFrom(src => src.RuleDetails.EndDate.Value.ToString("dd/MM/yyyy HH:mm"))
            )
            .ForMember(
                dest => dest.DateMaj,
                opt => opt.MapFrom(src => src.RuleDetails.UpdateDate.Value.ToString("dd/MM/yyyy HH:mm"))
            )
            .ForMember(dest => dest.MatriculeCreation, opt => opt.MapFrom(src => src.RuleDetails.CreatorId))
            .ForMember(dest => dest.MatriculeMaj, opt => opt.MapFrom(src => src.RuleDetails.UpdatorId))
            .ForMember(dest => dest.Priotite, opt => opt.MapFrom(src => src.RuleDetails.Priority))
            .ForMember(dest => dest.Equipe, opt => opt.MapFrom(src => src.Affectation.AffectedTeam))
            .ForMember(dest => dest.Collaborateur, opt => opt.MapFrom(src => src.Affectation.AffectedEmployee))
            .ForMember(dest => dest.Commentaire_Metier, opt => opt.MapFrom(src => src.RuleDetails.Comment))
            .ReverseMap();
        #endregion
    }

    private static string? GetDelimitedStringValue(ICollection<string>? criterion)
    {
        if (criterion == null)
        {
            return null;
        }

        return !string.IsNullOrEmpty(
            string.Join(ValueSeparator, criterion).Replace(ValueSeparator.ToString(), string.Empty)
        )
            ? string.Join(ValueSeparator, criterion)
            : null;
    }

    private static decimal? GetFirstDecimalValue(ICollection<string>? criterion)
    {
        if (criterion == null)
        {
            return null;
        }

        return !string.IsNullOrEmpty(criterion.Single())
            ? decimal.Parse(criterion.Single(), CultureInfo.InvariantCulture)
            : null;
    }
}
