using System.Net;
using Affectations.App.Configuration.Authorization;
using Affectations.App.Configuration.RuleCriterionOptions;
using Affectations.App.Dtos;
using Affectations.App.Extensions;
using Affectations.App.Factories;
using Affectations.Domain.Entities;
using Affectations.Domain.Exceptions;
using Affectations.Domain.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using IRuleCriterionService = Affectations.App.Services.IRuleCriterionService;

namespace Affectations.App.Controllers.v1;

[ApiController]
[Route("api/v{version:apiVersion}/[controller]")]
public class RuleCriteriaController : ControllerBase
{
    private readonly IRuleCriterionService _ruleCriterionService;
    private readonly ILogger<RuleCriteriaController> _logger;
    private readonly RuleCriterionOptions _ruleCriterionOptions;

    public RuleCriteriaController(
        IRuleCriterionService ruleCriterionService,
        ILogger<RuleCriteriaController> logger,
        IOptions<RuleCriterionOptions> ruleCriteriaOptions
    )
    {
        _ruleCriterionService = ruleCriterionService;
        _logger = logger;
        _ruleCriterionOptions = ruleCriteriaOptions.Value;
    }

    [HttpGet]
    [ProducesResponseType(typeof(IDictionary<string, RuleCriterionCategory>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(typeof(ProblemDetails), StatusCodes.Status500InternalServerError)]
    [Authorize(Policy = AuthorizationConfiguration.HasUserProfilePolicy)]
    public async Task<IResult> GetRuleCriteriaAsync()
    {
        try
        {
            _logger.LogInformation("L'appel de récupération des référentiels a été lancé.");
            var result = await _ruleCriterionService.GetRuleCriteriaAsync(_ruleCriterionOptions.RowCountPerCriterion);
            return Results.Ok(result);
        }
        catch (RuleCriterionException e)
        {
            return Results.BadRequest(
                new CustomProblemDetailsFactory().CreateProblemDetails(
                    HttpContext,
                    (int)HttpStatusCode.BadRequest,
                    detail: e?.Message
                )
            );
        }
    }

    [HttpPost("[action]"), ActionName("search")]
    [ProducesResponseType(typeof(PagedData<RuleCriterion>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [Authorize(Policy = AuthorizationConfiguration.HasUserProfilePolicy)]
    public async Task<IResult> SearchRuleCriteriaAsync([FromBody] RuleCriterionSearchDto ruleCriterionSearchDto)
    {
        var userEmail = HttpContext.GetUserEmail();
        _logger.LogInformation("La recherche des critères a été appelée par {userEmail}.", userEmail);
        var result = await _ruleCriterionService.SearchRuleCriteriaAsync(ruleCriterionSearchDto);
        return Results.Ok(result);
    }
}
