using System.Net.Mime;
using Affectations.App.Configuration.Authorization;
using Affectations.App.Configuration.OpenApi;
using Affectations.App.Dtos;
using Affectations.App.Extensions;
using Affectations.App.Factories;
using Affectations.App.Services;
using Affectations.Domain.Exceptions;
using Affectations.Domain.Models;
using AxaFrance.E2ELogging;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Affectations.App.Controllers.v1;

[ApiController]
[Route("api/v{version:apiVersion}/[controller]")]
public class RulesController : ControllerBase
{
    private readonly IRuleService _ruleService;
    private readonly ILogger<RulesController> _logger;

    public RulesController(IRuleService ruleService, ILogger<RulesController> logger)
    {
        _ruleService = ruleService;
        _logger = logger;
    }

    [HttpGet("{id}", Name = "GetRuleById")]
    [ProducesResponseType(typeof(RuleDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [Authorize(Policy = AuthorizationConfiguration.HasUserProfilePolicy)]
    public async Task<IResult> GetRuleByIdAsync(long id)
    {
        try
        {
            _logger.LogInformation("la règle {id} a été appelée.", id);
            var result = await _ruleService.GetRuleByIdAsync(id);
            return Results.Ok(result);
        }
        catch (RuleNotFoundException e)
        {
            return CustomHttpResultFactory.CreateHttpResult(HttpContext, e);
        }
    }

    [HttpPost(Name = "AddRule")]
    [ProducesResponseType(typeof(RuleDto), StatusCodes.Status201Created)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [Authorize(Policy = AuthorizationConfiguration.HasUpdateProfilePolicy)]
    public async Task<IActionResult> AddRuleAsync([FromBody] RuleCreationDto createdRule)
    {
        try
        {
            var rule = GetCreationRulePersistance(createdRule);
            var userEmail = HttpContext.GetUserEmail();
            _logger.LogAddingRule(rule.RuleDetailsDto?.RuleName, userEmail);
            var result = await _ruleService.AddRuleAsync(rule);
            return CreatedAtRoute("GetRuleById", new { id = result?.Id }, result);
        }
        catch (RuleException e)
        {
            var errorType = new RuleErrorFeature { RuleError = RuleErrorType.InvalidRuleError };
            HttpContext.Features.Set(errorType);
            HttpContext.Features.Set(e);
            var correlationContextAccessor =
                HttpContext.RequestServices.GetRequiredService<ICorrelationContextAccessor>();
            HttpContext.Features.Set(correlationContextAccessor.CorrelationContext);

            return BadRequest();
        }
    }

    [HttpPut("{id}", Name = "UpdateRule")]
    [ProducesResponseType(typeof(RuleDto), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [Authorize(Policy = AuthorizationConfiguration.HasUpdateProfilePolicy)]
    public async Task<IActionResult> UpdateRuleAsync([FromRoute] long id, [FromBody] RuleCreationDto updatedRule)
    {
        try
        {
            var rule = GetUpdateRulePersistance(updatedRule);
            var userEmail = HttpContext.GetUserEmail();
            _logger.LogUpdatingRule(updatedRule.Id, userEmail);
            var result = await _ruleService.UpdateRuleAsync(rule);
            return Ok(result);
        }
        catch (RuleException e)
        {
            var errorType = new RuleErrorFeature { RuleError = RuleErrorType.InvalidRuleError };
            HttpContext.Features.Set(errorType);
            HttpContext.Features.Set(e);
            var correlationContextAccessor =
                HttpContext.RequestServices.GetRequiredService<ICorrelationContextAccessor>();
            HttpContext.Features.Set(correlationContextAccessor.CorrelationContext);

            return BadRequest();
        }
    }

    [HttpPost("[action]"), ActionName("Search")]
    [ProducesResponseType(typeof(PagedData<RuleDto>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [Authorize(Policy = AuthorizationConfiguration.HasUserProfilePolicy)]
    public async Task<IActionResult> SearchRulesAsync(
        [FromQuery] int page,
        [FromQuery] int size,
        [FromBody] RuleDto ruleDto
    )
    {
        try
        {
            var userEmail = HttpContext.GetUserEmail();
            _logger.LogSearchRules(userEmail);
            int pageMRM = 0;
            if (page > 0)
            {
                pageMRM = page - 1;
            }
            var result = await _ruleService.SearchRulesAsync(pageMRM, size, ruleDto);
            return Ok(result);
        }
        catch (RuleException e) when (e.Message.Equals("Bad request"))
        {
            var errorType = new RuleErrorFeature { RuleError = RuleErrorType.InvalidRuleError };
            HttpContext.Features.Set(errorType);
            HttpContext.Features.Set(e);
            var correlationContextAccessor =
                HttpContext.RequestServices.GetRequiredService<ICorrelationContextAccessor>();
            HttpContext.Features.Set(correlationContextAccessor.CorrelationContext);

            return BadRequest();
        }
        catch (RuleException e) when (e.Message.Equals("Not found"))
        {
            var errorType = new RuleErrorFeature { RuleError = RuleErrorType.InvalidRuleError };
            HttpContext.Features.Set(errorType);
            HttpContext.Features.Set(e);
            var correlationContextAccessor =
                HttpContext.RequestServices.GetRequiredService<ICorrelationContextAccessor>();
            HttpContext.Features.Set(correlationContextAccessor.CorrelationContext);

            return NotFound();
        }
    }

    [HttpPut(Name = "UpdateRules")]
    [ProducesResponseType(typeof(int), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    [Authorize(Policy = AuthorizationConfiguration.HasUpdateProfilePolicy)]
    public async Task<IActionResult> UpdateRulesAsync([FromBody] RuleMassUpdateDto ruleMassUpdateDto)
    {
        try
        {
            var userEmail = HttpContext.GetUserEmail();
            _logger.LogUpdatingRules(string.Join(",", ruleMassUpdateDto.Ids), userEmail);
            var resultCountRuleModified = await _ruleService.UpdateRulesAsync(ruleMassUpdateDto);
            return Ok(resultCountRuleModified);
        }
        catch (RuleException e)
        {
            var errorType = new RuleErrorFeature { RuleError = RuleErrorType.InvalidRuleError };
            HttpContext.Features.Set(errorType);
            HttpContext.Features.Set(e);
            var correlationContextAccessor =
                HttpContext.RequestServices.GetRequiredService<ICorrelationContextAccessor>();
            HttpContext.Features.Set(correlationContextAccessor.CorrelationContext);

            return BadRequest();
        }
    }

    [HttpPost("[action]"), ActionName("Export")]
    [ProducesFileResultWithContentType(MediaTypeNames.Text.Csv)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [Authorize(Policy = AuthorizationConfiguration.HasUserProfilePolicy)]
    public async Task<IActionResult> ExportRules([FromBody] FilterRuleDto exportFilter)
    {
        try
        {
            var userEmail = HttpContext.GetUserEmail();
            _logger.LogExportRules(userEmail);
            var csvFile = await _ruleService.ExportRuleCsv(exportFilter);
            return File(csvFile.FileContents, csvFile.ContentType, csvFile.FileName);
        }
        catch (RuleException e) when (e.Message.Equals("Bad request"))
        {
            var errorType = new RuleErrorFeature { RuleError = RuleErrorType.InvalidRuleError };
            HttpContext.Features.Set(errorType);
            HttpContext.Features.Set(e);
            var correlationContextAccessor =
                HttpContext.RequestServices.GetRequiredService<ICorrelationContextAccessor>();
            HttpContext.Features.Set(correlationContextAccessor.CorrelationContext);

            return BadRequest();
        }
        catch (RuleException e) when (e.Message.Equals("Not found"))
        {
            var errorType = new RuleErrorFeature { RuleError = RuleErrorType.InvalidRuleError };
            HttpContext.Features.Set(errorType);
            HttpContext.Features.Set(e);
            var correlationContextAccessor =
                HttpContext.RequestServices.GetRequiredService<ICorrelationContextAccessor>();
            HttpContext.Features.Set(correlationContextAccessor.CorrelationContext);

            return NotFound();
        }
    }

    private RulePersistance GetCreationRulePersistance(RuleCreationDto createdRule)
    {
        RuleDetailsDto ruleDetails = new RuleDetailsDto()
        {
            Comment = createdRule.RuleDetailsDto?.Comment,
            RuleName = createdRule.RuleDetailsDto?.RuleName,
            Statut = createdRule.RuleDetailsDto?.Statut,
            StartDate = createdRule.RuleDetailsDto?.StartDate,
            EndDate = createdRule.RuleDetailsDto?.EndDate,
            CreatedBy = User.GetUserName(),
            CreatorId = User.GetUserId(),
            CreationDate = DateTime.Now,
        };
        RulePersistance rule = new RulePersistance()
        {
            AffectationDto = createdRule.AffectationDto,
            RuleDetailsDto = ruleDetails,
            Rules = createdRule.Rules,
        };
        return rule;
    }

    private RulePersistance GetUpdateRulePersistance(RuleCreationDto createdRule)
    {
        RuleDetailsDto ruleDetails = new RuleDetailsDto()
        {
            Comment = createdRule.RuleDetailsDto?.Comment,
            RuleName = createdRule.RuleDetailsDto?.RuleName,
            Statut = createdRule.RuleDetailsDto?.Statut,
            StartDate = createdRule.RuleDetailsDto?.StartDate,
            EndDate = createdRule.RuleDetailsDto?.EndDate,
            UpdatedBy = User.GetUserName(),
            UpdatorId = User.GetUserId(),
            UpdateDate = DateTime.Now,
        };
        RulePersistance rule = new RulePersistance()
        {
            Id = createdRule.Id,
            AffectationDto = createdRule.AffectationDto,
            RuleDetailsDto = ruleDetails,
            Rules = createdRule.Rules,
        };
        return rule;
    }
}
