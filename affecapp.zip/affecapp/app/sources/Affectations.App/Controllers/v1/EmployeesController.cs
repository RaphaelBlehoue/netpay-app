using Affectations.App.Configuration.Authorization;
using Affectations.App.Dtos;
using Affectations.App.Extensions;
using Affectations.App.Services;
using Affectations.Domain.Entities;
using Affectations.Domain.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Affectations.App.Controllers.v1;

[ApiController]
[Route("api/v{version:apiVersion}/[controller]")]
public class EmployeesController : ControllerBase
{
    private readonly IEmployeeService _employeeService;
    private readonly ILogger<EmployeesController> _logger;

    public EmployeesController(IEmployeeService dataService, ILogger<EmployeesController> logger)
    {
        _employeeService = dataService;
        _logger = logger;
    }

    [HttpPost("[action]"), ActionName("search")]
    [ProducesResponseType(typeof(PagedData<Employee>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [Authorize(Policy = AuthorizationConfiguration.HasUserProfilePolicy)]
    public async Task<IResult> SearchRulesAsync([FromBody] EmployeeSearchDto employeeSearchDto)
    {
        var userEmail = HttpContext.GetUserEmail();
        _logger.LogInformation("La recherche des données des employés a été appelée par {userEmail}.", userEmail);
        var result = await _employeeService.SearchEmployeesAsync(employeeSearchDto);
        return Results.Ok(result);
    }
}
