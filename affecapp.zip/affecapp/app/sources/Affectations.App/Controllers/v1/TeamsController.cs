using System.Net;
using Affectations.App.Configuration.Authorization;
using Affectations.App.Extensions;
using Affectations.App.Factories;
using Affectations.App.Services;
using Affectations.Domain.Entities;
using Affectations.Domain.Exceptions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Affectations.App.Controllers.v1;

[ApiController]
[Route("api/v{version:apiVersion}/[controller]")]
public class TeamsController : ControllerBase
{
    private readonly ILogger<TeamsController> _logger;
    private readonly ITeamService _teamService;

    public TeamsController(ITeamService teamService, ILogger<TeamsController> logger)
    {
        _teamService = teamService;
        _logger = logger;
    }

    [HttpGet(Name = "GetTeams")]
    [ProducesResponseType(typeof(IEnumerable<Team>), StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status401Unauthorized)]
    [ProducesResponseType(StatusCodes.Status403Forbidden)]
    [ProducesResponseType(StatusCodes.Status404NotFound)]
    [Authorize(Policy = AuthorizationConfiguration.HasUserProfilePolicy)]
    public async Task<IResult> GetTeamsAsync()
    {
        try
        {
            string userEmail = HttpContext.GetUserEmail();
            _logger.LogGetTeams(userEmail);
            var result = await _teamService.GetTeamsAsync();
            return Results.Ok(result);
        }
        catch (TeamException e)
        {
            return Results.Problem(
                new CustomProblemDetailsFactory().CreateProblemDetails(
                    HttpContext,
                    (int)HttpStatusCode.InternalServerError,
                    detail: e.Message
                )
            );
        }
    }
}
