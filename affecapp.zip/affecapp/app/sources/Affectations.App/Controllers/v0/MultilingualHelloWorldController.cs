using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Affectations.App.Controllers.v0;

[AllowAnonymous]
[ApiVersion("0.0")]
[Route("api/v{version:apiVersion}/[controller]/translations")]
[ApiController]
public class MultilingualHelloWorldController : ControllerBase
{
    internal const string DefaultResult = "Hello, World!";

    [HttpGet("deprecated")]
    [ProducesResponseType(typeof(string), StatusCodes.Status200OK)]
    public IResult GetDeprecated()
    {
        return Results.Ok(DefaultResult);
    }
}
