using System.Text.RegularExpressions;
using Affectations.App.Dtos;
using Affectations.App.Enums;
using Affectations.Domain.Exceptions;
using Microsoft.IdentityModel.Tokens;

namespace Affectations.App.Validations;

public static partial class RuleValidation
{
    private const int NafCodeLength = 7;
    private const int SyndicCodeLength = 5;
    private const int ClientNumberLength = 10;
    private const int AccountManagerLength = 7;
    private const int ContractNumberLength = 16;

    [GeneratedRegex(@"\b\d{3}[A-Z012]\d{3}\b", RegexOptions.IgnoreCase)]
    private static partial Regex NafCodeRegex();

    [GeneratedRegex(@"^\d+$", RegexOptions.IgnoreCase)]
    private static partial Regex ClientNumberRegex();

    [GeneratedRegex(@"^S\d{6}$", RegexOptions.IgnoreCase)]
    private static partial Regex AccountManagerRegex();

    public static void BusinessRule(RulePersistance ruleDto)
    {
        if (ruleDto != null)
        {
            ValidateGeneralInformation(ruleDto);
            if (!ruleDto.Rules.IsNullOrEmpty())
            {
                ValidateRuleCriteria(ruleDto.Rules);
            }
        }
    }

    public static void ValidateGeneralInformation(RulePersistance ruleDto)
    {
        if (ruleDto.RuleDetailsDto != null && !ruleDto.RuleDetailsDto.StartDate.HasValue)
        {
            throw new RuleException("Date de début est obligatoire");
        }
    }

    public static void ValidateRuleCriteria(Dictionary<string, CriterionDto> rules)
    {
        if (!rules.IsNullOrEmpty())
        {
            var nafCodes = rules.TryGetValue(CriteriaEnum.NafCode.ToString(), out var nafCode) ? nafCode.Values : null;
            if (!nafCodes.IsNullOrEmpty())
            {
                ValidateNafCode(nafCodes);
            }
            var syndicCodes = rules.TryGetValue(CriteriaEnum.SyndicCode.ToString(), out var syndicCode)
                ? syndicCode.Values
                : null;
            if (!syndicCodes.IsNullOrEmpty())
            {
                ValidateSyndicCode(syndicCodes);
            }
            var clientNumbers = rules.TryGetValue(CriteriaEnum.ClientNumber.ToString(), out var clientNumber)
                ? clientNumber.Values
                : null;
            if (!clientNumbers.IsNullOrEmpty())
            {
                ValidateClientNumber(clientNumbers);
            }

            var accountManagers = rules.TryGetValue(CriteriaEnum.AccountManager.ToString(), out var accountManager)
                ? accountManager.Values
                : null;
            if (!accountManagers.IsNullOrEmpty())
            {
                ValidateAccountManager(accountManagers);
            }

            var contractNumbers = rules.TryGetValue(CriteriaEnum.ContractNumber.ToString(), out var contractNumber)
                ? contractNumber.Values
                : null;
            if (!contractNumbers.IsNullOrEmpty())
            {
                ValidateContractNumber(contractNumbers);
            }
        }
    }

    public static void ValidateNafCode(string[] nafCodes)
    {
        foreach (string code in nafCodes)
        {
            if (code.Length > NafCodeLength)
            {
                throw new RuleException($"Le Code NAF ne doit pas dépasser {NafCodeLength} caractères.");
            }
            if (!NafCodeRegex().IsMatch(code))
            {
                throw new RuleException("Le Code NAF, Le format à respecter est : xxxxxxx.");
            }
        }
    }

    public static void ValidateSyndicCode(string[] syndicCodes)
    {
        foreach (string code in syndicCodes)
        {
            if (code.Length != SyndicCodeLength)
            {
                throw new RuleException($"Code Syndic : {SyndicCodeLength} caractères obligatoires.");
            }
        }
    }

    public static void ValidateClientNumber(string[] clientNumbers)
    {
        foreach (string clientNumber in clientNumbers)
        {
            if (clientNumber.Length > ClientNumberLength)
            {
                throw new RuleException($"N° client : ne doit pas dépasser {ClientNumberLength} caractères.");
            }
            if (!ClientNumberRegex().IsMatch(clientNumber))
            {
                throw new RuleException("N° client : seuls les caractères numériques sont acceptés.");
            }
        }
    }

    public static void ValidateAccountManager(string[] accountManagers)
    {
        foreach (string manager in accountManagers)
        {
            if (manager.Length > AccountManagerLength)
            {
                throw new RuleException(
                    $"Chargé de clientèle : ne doit pas dépasser {AccountManagerLength} caractères."
                );
            }
            if (!AccountManagerRegex().IsMatch(manager))
            {
                throw new RuleException("Chargé de clientèle : Veuillez respecter le format : S000000.");
            }
        }
    }

    public static void ValidateContractNumber(string[] contractNumbers)
    {
        foreach (string contractNumber in contractNumbers)
        {
            if (contractNumber.Length > ContractNumberLength)
            {
                throw new RuleException($"N° contrat : ne doit pas dépasser {ContractNumberLength} caractères.");
            }
        }
    }
}
