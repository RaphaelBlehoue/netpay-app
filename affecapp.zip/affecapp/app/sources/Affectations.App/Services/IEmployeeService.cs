using Affectations.App.Dtos;
using Affectations.Domain.Entities;
using Affectations.Domain.Models;

namespace Affectations.App.Services;

public interface IEmployeeService
{
    Task<PagedData<Employee>> SearchEmployeesAsync(EmployeeSearchDto employeeSearchDto);
}
