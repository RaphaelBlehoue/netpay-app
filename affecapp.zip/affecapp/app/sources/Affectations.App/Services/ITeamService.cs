using Affectations.Domain.Entities;

namespace Affectations.App.Services;

public interface ITeamService
{
    Task<IEnumerable<Team>> GetTeamsAsync();
}
