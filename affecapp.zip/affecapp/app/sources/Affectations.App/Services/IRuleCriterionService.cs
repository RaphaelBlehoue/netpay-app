using Affectations.App.Dtos;
using Affectations.Domain.Entities;
using Affectations.Domain.Models;

namespace Affectations.App.Services;

public interface IRuleCriterionService
{
    Task<IDictionary<string, RuleCriterionCategory>> GetRuleCriteriaAsync(int rowCountPerCriterion);

    Task<PagedData<RuleCriterion>> SearchRuleCriteriaAsync(RuleCriterionSearchDto ruleCriterionSearchDto);
}
