using Affectations.Domain.Entities;
using Affectations.Domain.Repositories;

namespace Affectations.App.Services;

public class TeamService : ITeamService
{
    private readonly ITeamRepository _teamRepository;

    public TeamService(ITeamRepository teamRepository)
    {
        _teamRepository = teamRepository;
    }

    public async Task<IEnumerable<Team>> GetTeamsAsync()
    {
        return await _teamRepository.GetTeamsAsync();
    }
}
