using Affectations.App.Dtos;
using Affectations.Domain.Entities;
using Affectations.Domain.Models;
using Affectations.Domain.Repositories;
using Affectations.Infrastructure.Specifications;
using DomainRuleCriterionService = Affectations.Domain.Services.IRuleCriterionService;

namespace Affectations.App.Services;

public class RuleCriterionService : IRuleCriterionService
{
    private readonly IRuleCriterionRepository _ruleCriterionRepository;
    private readonly DomainRuleCriterionService _ruleCriterionService;

    public RuleCriterionService(
        IRuleCriterionRepository ruleCriterionRepository,
        DomainRuleCriterionService ruleCriterionService
    )
    {
        _ruleCriterionRepository = ruleCriterionRepository;
        _ruleCriterionService = ruleCriterionService;
    }

    public async Task<IDictionary<string, RuleCriterionCategory>> GetRuleCriteriaAsync(int rowCountPerCriterion)
    {
        var ruleCriterionCategories = await _ruleCriterionRepository.GetRuleCriteriaAsync(rowCountPerCriterion);
        var dictionary = ruleCriterionCategories.ToDictionary(item => item.Code, item => item);
        return dictionary;
    }

    public async Task<PagedData<RuleCriterion>> SearchRuleCriteriaAsync(RuleCriterionSearchDto ruleCriterionSearchDto)
    {
        var ruleCriterionLabelSearchSpecification = new RuleCriterionLabelSearchSpecification(
            ruleCriterionSearchDto.CategoryCode,
            ruleCriterionSearchDto.LabelStartsWithFilter
        )
        {
            PageNumber = ruleCriterionSearchDto.PageNumber,
            PageSize = ruleCriterionSearchDto.PageSize,
        };

        return await _ruleCriterionService.SearchRuleCriteriaAsync(ruleCriterionLabelSearchSpecification);
    }
}
