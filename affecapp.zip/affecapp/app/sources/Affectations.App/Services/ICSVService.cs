namespace Affectations.App.Services;

public interface ICSVService
{
    string WriteCSV<T>(T item);
}
