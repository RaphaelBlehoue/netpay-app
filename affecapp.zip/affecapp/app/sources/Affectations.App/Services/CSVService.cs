namespace Affectations.App.Services;

using System.Globalization;
using System.Text;
using CsvHelper;
using CsvHelper.Configuration;

public class CSVService : ICSVService
{
    public string WriteCSV<T>(T item)
    {
        using (var memoryStream = new MemoryStream())
        {
            using (var writer = new StreamWriter(memoryStream))
            {
                var config = new CsvConfiguration(CultureInfo.InvariantCulture) { Delimiter = ";" };
                using (var csv = new CsvWriter(writer, config))
                {
                    csv.WriteRecords((System.Collections.IEnumerable)item);
                }
            }
            return Encoding.UTF8.GetString(memoryStream.ToArray());
        }
    }
}
