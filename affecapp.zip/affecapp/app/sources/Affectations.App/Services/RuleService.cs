using System.Text;
using Affectations.App.Constants;
using Affectations.App.Dtos;
using Affectations.App.Models;
using Affectations.App.Validations;
using Affectations.Domain.AggregatesRoots.RuleAggregate;
using Affectations.Domain.Models;
using Affectations.Domain.Repositories;
using AutoMapper;
using Microsoft.IdentityModel.Tokens;

namespace Affectations.App.Services;

public class RuleService : IRuleService
{
    private readonly IRuleRepository _ruleRepository;
    private readonly IRuleCriterionRepository _ruleCriterionRepository;
    private readonly ICSVService _csvService;
    private readonly IMapper _mapper;
    private const string All = "*";

    public RuleService(
        IRuleRepository ruleRepository,
        IRuleCriterionRepository ruleCriterionRepository,
        IMapper mapper,
        ICSVService csvService
    )
    {
        _ruleRepository = ruleRepository;
        _ruleCriterionRepository = ruleCriterionRepository;
        _mapper = mapper;
        _csvService = csvService;
    }

    public async Task<RuleDto> GetRuleByIdAsync(long id)
    {
        var rule = await _ruleRepository.GetRuleByIdAsync(id);
        return _mapper.Map<RuleDto>(rule);
    }

    public async Task<RuleDto> AddRuleAsync(RulePersistance ruleDto)
    {
        RuleValidation.BusinessRule(ruleDto);
        var rule = _mapper.Map<Rule>(ruleDto);
        if (!rule.Criteres.Branch.IsNullOrEmpty() && rule.Criteres.Branch.Contains(All))
        {
            var criteria = await _ruleCriterionRepository.GetRuleCriteriaByCategorieCode(CategoryCode.BRANCH);
            if (criteria.Any())
            {
                rule.Criteres.Branch = criteria.ToList();
            }
        }
        if (!rule.Criteres.DistributorRegion.IsNullOrEmpty() && rule.Criteres.DistributorRegion.Contains(All))
        {
            var criteria = await _ruleCriterionRepository.GetRuleCriteriaByCategorieCode(
                CategoryCode.DISTRIBUTION_REGION
            );
            if (criteria.Any())
            {
                rule.Criteres.DistributorRegion = criteria.ToList();
            }
        }
        if (!rule.Criteres.Segmentation.IsNullOrEmpty() && rule.Criteres.Segmentation.Contains(All))
        {
            var criteria = await _ruleCriterionRepository.GetRuleCriteriaByCategorieCode(CategoryCode.SEGMENTATION);
            if (criteria.Any())
            {
                rule.Criteres.Segmentation = criteria.ToList();
            }
        }
        if (!rule.Criteres.Network.IsNullOrEmpty() && rule.Criteres.Network.Contains(All))
        {
            var criteria = await _ruleCriterionRepository.GetRuleCriteriaByCategorieCode(CategoryCode.NETWORKS);
            if (criteria.Any())
            {
                rule.Criteres.Network = criteria.ToList();
            }
        }
        if (!rule.Criteres.DistributorDepartment.IsNullOrEmpty() && rule.Criteres.DistributorDepartment.Contains(All))
        {
            var criteria = await _ruleCriterionRepository.GetRuleCriteriaByCategorieCode(
                CategoryCode.DISTRIBUTION_DEPARTMENT
            );
            if (criteria.Any())
            {
                rule.Criteres.DistributorDepartment = criteria.ToList();
            }
        }
        if (!rule.Criteres.ContractCategory.IsNullOrEmpty() && rule.Criteres.ContractCategory.Contains(All))
        {
            var criteria = await _ruleCriterionRepository.GetRuleCriteriaByCategorieCode(
                CategoryCode.QP_CONTRACT_CATEGORY
            );
            if (criteria.Any())
            {
                rule.Criteres.ContractCategory = criteria.ToList();
            }
        }
        var _rule = await _ruleRepository.AddRuleAsync(rule);
        return _mapper.Map<RuleDto>(_rule);
    }

    public async Task<RuleDto> UpdateRuleAsync(RulePersistance ruleDto)
    {
        RuleValidation.BusinessRule(ruleDto);
        var _rule = await _ruleRepository.UpdateRuleAsync(_mapper.Map<Rule>(ruleDto));
        return _mapper.Map<RuleDto>(_rule);
    }

    public async Task<PagedData<RuleDto>> SearchRulesAsync(int page, int size, RuleDto ruleDto)
    {
        var _rule = _mapper.Map<FilterRuleModel>(ruleDto);
        var result = await _ruleRepository.SearchRulesAsync(page, size, _rule);
        return _mapper.Map<PagedData<RuleDto>>(result);
    }

    public async Task<int> UpdateRulesAsync(RuleMassUpdateDto? ruleMassUpdateDto)
    {
        var ruleMassUpdate = _mapper.Map<RuleMassUpdate>(ruleMassUpdateDto);
        return await _ruleRepository.UpdateRulesAsync(ruleMassUpdate);
    }

    public async Task<CustomFile> ExportRuleCsv(FilterRuleDto exportRule)
    {
        var filterRuleModel = _mapper.Map<FilterRuleModel>(exportRule);
        var result = await _ruleRepository.ExportRules(filterRuleModel);
        var rules = _mapper.Map<IEnumerable<RuleDtoExport>>(result);
        string csvContent = _csvService.WriteCSV(rules);

        string timestamp = DateTime.Now.ToString("yyyyMMdd-HHmmss");
        StringBuilder fileName = new StringBuilder();
        fileName.Append("exprgl-");
        if (!exportRule.Ids.IsNullOrEmpty() && exportRule.Ids.Count == 1)
        {
            fileName.Append($"{exportRule.Ids.FirstOrDefault()}-{timestamp}.csv");
        }
        else
        {
            fileName.Append($"list-{timestamp}.csv");
        }

        return new CustomFile
        {
            ContentType = "text/csv",
            FileContents = Encoding.UTF8.GetBytes(csvContent),
            FileName = fileName.ToString()
        };
    }
}
