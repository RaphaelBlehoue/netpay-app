using Affectations.App.Dtos;
using Affectations.Domain.Entities;
using Affectations.Domain.Models;
using Affectations.Infrastructure.Specifications;
using EmployeeServiceDomain = Affectations.Domain.Services;

namespace Affectations.App.Services;

public class EmployeeService : IEmployeeService
{
    private readonly EmployeeServiceDomain.IEmployeeService _employeeService;

    public EmployeeService(EmployeeServiceDomain.IEmployeeService employeeService)
    {
        _employeeService = employeeService;
    }

    public async Task<PagedData<Employee>> SearchEmployeesAsync(EmployeeSearchDto employeeSearchDto)
    {
        var employeeLastNameSearchSpecification = new EmployeeLastNameSearchSpecification(
            employeeSearchDto.LastNameStartsWithFilter
        )
        {
            PageNumber = employeeSearchDto.PageNumber,
            PageSize = employeeSearchDto.PageSize,
        };

        return await _employeeService.SearchEmployeesAsync(employeeLastNameSearchSpecification);
    }
}
