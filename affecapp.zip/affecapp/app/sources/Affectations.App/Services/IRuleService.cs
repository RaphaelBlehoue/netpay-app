using Affectations.App.Dtos;
using Affectations.App.Models;
using Affectations.Domain.Models;

namespace Affectations.App.Services;

public interface IRuleService
{
    Task<RuleDto> GetRuleByIdAsync(long id);
    Task<RuleDto> AddRuleAsync(RulePersistance ruleDto);
    Task<RuleDto> UpdateRuleAsync(RulePersistance ruleDto);
    Task<PagedData<RuleDto>> SearchRulesAsync(int page, int size, RuleDto ruleDto);
    Task<int> UpdateRulesAsync(RuleMassUpdateDto? ruleMassUpdateDto);
    Task<CustomFile> ExportRuleCsv(FilterRuleDto exportRule);
}
