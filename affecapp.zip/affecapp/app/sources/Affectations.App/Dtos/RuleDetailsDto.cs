namespace Affectations.App.Dtos;

public record RuleDetailsDto
{
    public string? RuleName { get; init; }
    public string? Statut { get; init; }
    public DateTime? StartDate { get; init; }
    public DateTime? EndDate { get; init; }
    public string? Comment { get; init; }
    public DateTime? CreationDate { get; init; }
    public string? CreatedBy { get; init; }
    public string? CreatorId { get; init; }
    public DateTime? UpdateDate { get; init; }
    public string? UpdatedBy { get; init; }
    public string? UpdatorId { get; init; }
    public string? Priority { get; init; }
}
