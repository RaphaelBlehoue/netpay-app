namespace Affectations.App.Dtos;

public class RuleMassUpdateDto
{
    public required long[] Ids { get; set; }
    public string? AffectedEmployee { get; set; }
    public string? AffectedEmployeeId { get; set; }
    public string? AffectedTeam { get; set; }
    public string? Comment { get; set; }
    public DateTime? EndDate { get; set; }
}
