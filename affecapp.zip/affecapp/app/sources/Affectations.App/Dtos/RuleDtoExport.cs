using CsvHelper.Configuration.Attributes;

namespace Affectations.App.Dtos;

public class RuleDtoExport
{
    [Name("Id règle")]
    public int RuleId { get; set; }
    public string Branche { get; set; }

    [Name("Région distributeur")]
    public string Region { get; set; }
    public string Segmentation { get; set; }

    [Name("Réseaux")]
    public string Reseau { get; set; }

    [Name("COPHT (€)")]
    public string Copht { get; set; }

    [Name("Département distributeur")]
    public string Departement { get; set; }

    [Name("Catégorie contrat QP")]
    public string Categorie { get; set; }

    [Name("Code UV")]
    public string UVCode { get; set; }

    [Name("Nom intermédiaire")]
    public string Nom_Intermidiaire { get; set; }

    [Name("Code portefeuille")]
    public string Code_Portefeuille { get; set; }
    public string Clause { get; set; }

    [Name("Code Syndic")]
    public string Code_Syndic { get; set; }

    [Name("Code NAF")]
    public string Code_Naf { get; set; }

    [Name("N° client AXAPAC")]
    public string Numero_Client { get; set; }

    [Name("Chargé de clientèle")]
    public string charge_De_Clientele { get; set; }

    [Name("N° contrat")]
    public string Numero_Contrat { get; set; }
    public string Statut { get; set; }
    public string Equipe { get; set; }
    public string Collaborateur { get; set; }
    public string Commentaire_Metier { get; set; }

    [Name("Date de création")]
    public string DateCreation { get; set; }

    [Name("Matricule de création")]
    public string MatriculeCreation { get; set; }

    [Name("Date de début")]
    public string DateDebut { get; set; }

    [Name("Date de fin")]
    public string DateFin { get; set; }

    [Name("DateTime de maj")]
    public string DateMaj { get; set; }

    [Name("Matricule de maj")]
    public string MatriculeMaj { get; set; }

    [Name("Priorité")]
    public string Priotite { get; set; }
}
