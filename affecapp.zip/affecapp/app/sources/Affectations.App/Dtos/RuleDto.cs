namespace Affectations.App.Dtos;

public record RuleDto
{
    public long Id { get; init; }
    public RuleDetailsDto? RuleDetailsDto { get; init; }
    public CriteresDto? CritereDto { get; init; }
    public AffectationDto? AffectationDto { get; init; }
    public ConditionsDto? ConditionsDto { get; init; }

    public RuleDto(
        long id,
        RuleDetailsDto ruleDetailsDto,
        CriteresDto critereDto,
        AffectationDto affectationDto,
        ConditionsDto conditionsDto
    )
    {
        Id = id;
        RuleDetailsDto = ruleDetailsDto;
        CritereDto = critereDto;
        AffectationDto = affectationDto;
        ConditionsDto = conditionsDto;
    }

    public RuleDto() { }
}
