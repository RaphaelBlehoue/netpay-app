namespace Affectations.App.Dtos;

public class RuleCreationDto
{
    public long Id { get; init; }
    public RuleDetailsCreationDto? RuleDetailsDto { get; init; }
    public AffectationDto? AffectationDto { get; init; }
    public Dictionary<string, CriterionDto> Rules { get; init; }

    public RuleCreationDto(
        long id,
        RuleDetailsCreationDto ruleDetailsDto,
        AffectationDto affectationDto,
        Dictionary<string, CriterionDto> rules
    )
    {
        Id = id;
        RuleDetailsDto = ruleDetailsDto;
        AffectationDto = affectationDto;
        Rules = rules;
    }

    public RuleCreationDto() { }
}
