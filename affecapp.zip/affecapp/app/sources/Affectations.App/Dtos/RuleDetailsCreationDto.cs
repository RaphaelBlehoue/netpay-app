namespace Affectations.App.Dtos;

public record RuleDetailsCreationDto
{
    public string? RuleName { get; init; }
    public string? Statut { get; init; }
    public DateTime? StartDate { get; init; }
    public DateTime? EndDate { get; init; }
    public string? Comment { get; init; }
}
