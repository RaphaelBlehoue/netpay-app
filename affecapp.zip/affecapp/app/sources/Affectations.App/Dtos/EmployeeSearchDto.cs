using Affectations.Infrastructure.Models;

namespace Affectations.App.Dtos;

public class EmployeeSearchDto : PagedDataSearch
{
    public required string LastNameStartsWithFilter { get; set; }
}
