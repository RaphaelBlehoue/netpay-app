namespace Affectations.App.Dtos;

public class RulePersistance
{
    public long Id { get; init; }
    public RuleDetailsDto? RuleDetailsDto { get; init; }
    public AffectationDto? AffectationDto { get; init; }
    public Dictionary<string, CriterionDto> Rules { get; init; }

    public RulePersistance(
        long id,
        RuleDetailsDto ruleDetailsDto,
        AffectationDto affectationDto,
        Dictionary<string, CriterionDto> rules
    )
    {
        Id = id;
        RuleDetailsDto = ruleDetailsDto;
        AffectationDto = affectationDto;
        Rules = rules;
    }

    public RulePersistance()
    {
        Rules = new Dictionary<string, CriterionDto>();
    }
}
