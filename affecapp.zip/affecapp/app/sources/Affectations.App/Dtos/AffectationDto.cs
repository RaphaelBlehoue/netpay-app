namespace Affectations.App.Dtos;

public record AffectationDto
{
    public string? AffectedTeam { get; init; }
    public string? AffectedRegion { get; init; }
    public string? AffectedEmployee { get; init; }
    public string? AffectedEmployeeId { get; init; }
    public DateTime? AffectationDate { get; init; }
    public DateTime? AffectationDemandDate { get; init; }
}
