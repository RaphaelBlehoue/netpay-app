namespace Affectations.App.Dtos;

public record CriteresDto
{
    public string? Segmentation { get; init; }
    public string? DistributorRegion { get; init; }
    public string? Network { get; init; }
    public string? Branch { get; init; }
    public decimal? Copht { get; init; }
    public string? DistributorDepartment { get; init; }
    public string? ContractCategory { get; init; }
    public string? UVCode { get; init; }
    public string? IntermediateName { get; init; }
    public string? PortfolioCode { get; init; }
    public string? Clause { get; init; }
    public string? SyndicCode { get; init; }
    public string? NafCode { get; init; }
    public string? ClientNumber { get; init; }
    public string? AccountManager { get; init; }
    public string? ContractNumber { get; init; }
}
