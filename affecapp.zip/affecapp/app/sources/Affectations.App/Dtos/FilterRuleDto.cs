namespace Affectations.App.Dtos;

public record FilterRuleDto
{
    public ICollection<long> Ids { get; init; }
    public RuleDetailsDto? RuleDetailsDto { get; init; }
    public CriteresDto? CritereDto { get; init; }
    public AffectationDto? AffectationDto { get; init; }
    public ConditionsDto? ConditionsDto { get; init; }

    public FilterRuleDto(
        ICollection<long> ids,
        RuleDetailsDto ruleDetailsDto,
        CriteresDto critereDto,
        AffectationDto affectationDto,
        ConditionsDto conditionsDto
    )
    {
        Ids = ids;
        RuleDetailsDto = ruleDetailsDto;
        CritereDto = critereDto;
        AffectationDto = affectationDto;
        ConditionsDto = conditionsDto;
    }

    public FilterRuleDto() { }
}
