using Affectations.Infrastructure.Models;

namespace Affectations.App.Dtos;

public class RuleCriterionSearchDto : PagedDataSearch
{
    public required string CategoryCode { get; set; }
    public required string LabelStartsWithFilter { get; set; }
}
