namespace Affectations.App.Dtos;

public record CriterionDto
{
    public string Condition { get; init; }
    public string[] Values { get; init; }
}
