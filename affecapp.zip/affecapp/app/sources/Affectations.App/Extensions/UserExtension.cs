using System.Security.Claims;

namespace Affectations.App.Extensions;

public static class UserExtension
{
    public static string? GetUserEmail(this HttpContext httpContext)
    {
        return httpContext?.User?.FindFirst(ClaimTypes.Email)?.Value;
    }

    public static string? GetUserName(this ClaimsPrincipal user)
    {
        return user.Claims.FirstOrDefault(claim => claim.Type == "name")?.Value;
    }

    public static string? GetUserId(this ClaimsPrincipal user)
    {
        return user.Claims.FirstOrDefault(claim => claim.Type == "axa_uid_racf")?.Value;
    }
}
