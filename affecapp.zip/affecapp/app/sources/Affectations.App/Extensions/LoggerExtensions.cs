namespace Affectations.App.Extensions;

public static partial class LoggerExtensions
{
    [LoggerMessage(
        EventId = 1,
        Level = LogLevel.Information,
        Message = "l'ajout de la règle {ruleName} par {userEmail}"
    )]
    public static partial void LogAddingRule(this ILogger logger, string? ruleName, string? userEmail);

    [LoggerMessage(
        EventId = 2,
        Level = LogLevel.Information,
        Message = "la modification de la règle {ruleId} par {userEmail}"
    )]
    public static partial void LogUpdatingRule(this ILogger logger, long? ruleId, string? userEmail);

    [LoggerMessage(
        EventId = 3,
        Level = LogLevel.Information,
        Message = "La liste des règles avec critères a été appellée. par {userEmail}"
    )]
    public static partial void LogSearchRules(this ILogger logger, string? userEmail);

    [LoggerMessage(
        EventId = 4,
        Level = LogLevel.Information,
        Message = " la liste des équipes a été appelée par {userEmail}"
    )]
    public static partial void LogGetTeams(this ILogger logger, string? userEmail);

    [LoggerMessage(
        EventId = 5,
        Level = LogLevel.Information,
        Message = "Modification en masse des règles {ruleIds} par {userEmail}"
    )]
    public static partial void LogUpdatingRules(this ILogger logger, string ruleIds, string? userEmail);

    [LoggerMessage(
        EventId = 6,
        Level = LogLevel.Information,
        Message = "L'export de règles est exécuté par {userEmail}"
    )]
    public static partial void LogExportRules(this ILogger logger, string? userEmail);
}
