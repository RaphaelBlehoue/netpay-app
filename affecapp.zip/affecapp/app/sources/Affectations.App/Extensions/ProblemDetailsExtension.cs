using System.Net;
using Affectations.App.Factories;
using Affectations.Domain.Exceptions;
using AxaFrance.E2ELogging;

namespace Affectations.App.Extensions;

public static class ProblemDetailsExtension
{
    public static IServiceCollection AddCustomProblemDetails(this IServiceCollection services)
    {
        services.AddProblemDetails(options =>
        {
            options.CustomizeProblemDetails = (context) => CustomizeRuleProblemDetails(context);
        });

        return services;
    }

    private static void CustomizeRuleProblemDetails(ProblemDetailsContext context)
    {
        var ruleErrorFeature = context.HttpContext.Features.Get<RuleErrorFeature>();
        var exception = context.HttpContext.Features.Get<RuleException>();
        var correlationContext = context.HttpContext.Features.Get<CorrelationContext>();
        if (ruleErrorFeature is not null)
        {
            (string? Detail, int status) details = ruleErrorFeature.RuleError switch
            {
                RuleErrorType.InvalidRuleError => (exception?.Message, (int)HttpStatusCode.BadRequest),
                RuleErrorType.RuleNotFoundError => (exception?.Message, (int)HttpStatusCode.NotFound),
                _ => ("Default error message", (int)HttpStatusCode.InternalServerError)
            };
            context.ProblemDetails.Status = details.status;
            context.ProblemDetails.Detail = details.Detail;

            if (correlationContext != null)
            {
                context.ProblemDetails.Extensions.Add("correlation-id", correlationContext.CorrelationId);
            }
        }
    }
}
