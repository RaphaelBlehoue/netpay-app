using System.Text.Json;
using Affectations.App.Configuration.Authorization;
using Affectations.App.Configuration.ControllerNaming;
using Affectations.App.Configuration.Https;
using Affectations.App.Configuration.LoggingAndMonitoring;
using Affectations.App.Configuration.OpenApi;
using Affectations.App.Configuration.RuleCriterionOptions;
using Affectations.App.Configuration.Services;
using Affectations.App.Configuration.Versioning;
using Affectations.App.Extensions;
using Affectations.Infrastructure;
using Affectations.Infrastructure.Data.Models;
using AxaFrance.AspNetCore.Monitoring;
using AxaFrance.E2ELogging.AspNetCore;
using Microsoft.AspNetCore.Mvc.ApplicationModels;
using Microsoft.EntityFrameworkCore;
using Serilog;

var builder = WebApplication.CreateBuilder(args);
var services = builder.Services;

builder.AddLoggingAndMonitoring(args);

var authorizationConfiguration = builder.GetRequiredAuthorizationConfiguration();
builder.AddAuthenticationAndAuthorization(authorizationConfiguration);

services.Configure<RuleCriterionOptions>(builder.Configuration.GetSection(nameof(RuleCriterionOptions)));

services
    .AddControllers(config =>
    {
        config.Conventions.Add(new RouteTokenTransformerConvention(new KebabCaseParameterTransformer()));
    })
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
    });
services.AddCustomProblemDetails();

if (builder.Environment.IsDevelopment())
{
    services.AddSpaStaticFiles(configuration =>
    {
        configuration.RootPath = "ClientApp/dist";
    });
}

var connectionString = builder.Configuration.GetSection("ConnectionStrings")["affectationsdb"];

services.AddDbContext<AffectationsContext>(options =>
{
    options.UseSqlServer(connectionString, providerOptions => providerOptions.EnableRetryOnFailure());
    options.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTrackingWithIdentityResolution);
});

builder.AddEndpointsApiExplorerWithVersioning();

services.AddProblemDetails();

services.ConfigureServices();

services.ConfigureInfrastructureServices(builder.Configuration);

// configure other services (e.g. services.ConfigureInfrastructureServices(...);

builder.AddOpenApiWithAffectationsAppConfiguration(authorizationConfiguration);

var app = builder.Build();

app.UseE2ELogging();
app.UseHttpsOrFollowProtocol();
app.UseOpenApiWithKyrAppConfiguration();
app.UseExceptionHandler();
app.UseStatusCodePages();

if (app.Environment.IsDevelopment())
{
    app.UseStaticFiles();
    app.UseSpaStaticFiles();
    app.UseDeveloperExceptionPage();
}

app.UseMonitoring();
app.UseSerilogRequestLogging();

app.UseRouting();

app.UseAuthentication();

app.UseBff();
app.UseAuthorization();

// ASP0014 is a false positive here, as declaring these endpoints at app level would alter the app behavior
#pragma warning disable ASP0014
app.UseEndpoints(config =>
{
    config.MapBffManagementEndpoints();
    config
        .MapControllers()
        .SkipAntiforgery()
        .RequireAuthorization(AuthorizationConfiguration.HasAnyProfilePolicy)
        .AsBffApiEndpoint();
});
#pragma warning restore ASP0014

if (app.Environment.IsDevelopment())
{
    app.UseSpa(spa =>
    {
        spa.Options.SourcePath = "ClientApp";
        if (app.Environment.IsDevelopment())
        {
            spa.UseProxyToSpaDevelopmentServer("http://localhost:13370");
        }
    });
}

app.Run();
