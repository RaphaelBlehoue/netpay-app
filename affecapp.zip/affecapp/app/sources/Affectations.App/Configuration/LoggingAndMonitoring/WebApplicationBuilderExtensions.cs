﻿using AxaFrance.E2ELogging;
using AxaFrance.ProductMonitoring;
using Microsoft.IdentityModel.Logging;
using Serilog;
using Serilog.Debugging;

namespace Affectations.App.Configuration.LoggingAndMonitoring;

public static class WebApplicationBuilderExtensions
{
    public static void AddLoggingAndMonitoring(this WebApplicationBuilder builder, string[] args)
    {
        if (args.Contains("--debug"))
        {
            SelfLog.Enable(Console.Out);
        }

        builder.Host.UseSerilog();

        if (builder.Environment.IsDevelopment())
        {
            IdentityModelEventSource.ShowPII = true;
        }

        builder.Services.AddE2ELogging();
        builder.Services.AddProductMonitoring(builder.Configuration.GetSection("ProductMonitoring").Bind);

        Log.Logger = new LoggerConfiguration().ReadFrom.Configuration(builder.Configuration).CreateLogger();
        builder.Logging.AddSerilog(Log.Logger, true);
    }
}
