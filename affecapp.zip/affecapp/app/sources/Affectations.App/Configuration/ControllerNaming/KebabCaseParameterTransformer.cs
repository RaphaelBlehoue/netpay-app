﻿using System.Text.RegularExpressions;

namespace Affectations.App.Configuration.ControllerNaming;

public class KebabCaseParameterTransformer : IOutboundParameterTransformer
{
    private const string ReplacementPattern = "$1-$2";

    private static readonly Regex PascalCaseBoundary =
        new("([a-z])([A-Z])", RegexOptions.Compiled | RegexOptions.CultureInvariant, TimeSpan.FromMilliseconds(100));

    public string? TransformOutbound(object? value)
    {
        if (!(value is string parsedValue) || string.IsNullOrEmpty(parsedValue))
        {
            return null;
        }

        return PascalCaseBoundary.Replace(parsedValue, ReplacementPattern).ToLowerInvariant();
    }
}
