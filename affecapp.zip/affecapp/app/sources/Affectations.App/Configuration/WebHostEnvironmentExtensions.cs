﻿namespace Affectations.App.Configuration;

public static class WebHostEnvironmentExtensions
{
    private const string LocalDockerEnvironmentName = "LocalDocker";

    public static bool IsLocalDocker(this IWebHostEnvironment environment) =>
        environment.IsEnvironment(LocalDockerEnvironmentName);
}
