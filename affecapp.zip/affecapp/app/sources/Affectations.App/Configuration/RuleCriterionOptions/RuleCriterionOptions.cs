namespace Affectations.App.Configuration.RuleCriterionOptions;

public class RuleCriterionOptions
{
    private const int DefaultMaxRow = 200;

    public required int RowCountPerCriterion { get; set; } = DefaultMaxRow;
}
