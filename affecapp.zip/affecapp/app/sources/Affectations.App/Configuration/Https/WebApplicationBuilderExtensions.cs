using Microsoft.AspNetCore.HttpOverrides;

namespace Affectations.App.Configuration.Https;

public static class WebApplicationBuilderExtensions
{
    private const string ForwardedHostHeaderName = "X-Original-Host";
    private const string FollowForwardedProtocolConfigurationKey = "Affectations:FollowForwardedProtocol";

    /**
     * When the application is deployed behind a reverse proxy, the reverse proxy may be responsible for terminating TLS connections.
     * In this case, the application should not redirect to HTTPS, but should instead trust the X-Forwarded-Proto header from the reverse proxy.
     * This header is added to the request by the reverse proxy and contains the scheme used to make the request.
     *
     * This is the case in a OpenShift deployment, where the route is configured to terminate TLS connections.
     */
    public static void UseHttpsOrFollowProtocol(this WebApplication app)
    {
        var followForwardedProtocol = app.Configuration.GetValue<bool>(FollowForwardedProtocolConfigurationKey);
        if (followForwardedProtocol)
        {
            var forwardedHeadersOptions = new ForwardedHeadersOptions
            {
                ForwardedHeaders = app.Environment.IsEnvironment("LocalDocker")
                    ? ForwardedHeaders.XForwardedProto
                    : ForwardedHeaders.All,
                ForwardedHostHeaderName = ForwardedHostHeaderName
            };

            forwardedHeadersOptions.KnownNetworks.Clear();
            forwardedHeadersOptions.KnownProxies.Clear();

            app.UseForwardedHeaders(forwardedHeadersOptions);
            return;
        }

        app.UseHttpsRedirection();
        app.UseHsts();
    }
}
