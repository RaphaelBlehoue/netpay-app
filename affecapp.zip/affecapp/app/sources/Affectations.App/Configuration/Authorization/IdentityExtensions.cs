﻿using System.Security.Claims;
using System.Security.Principal;

namespace Affectations.App.Configuration.Authorization;

internal static class IdentityExtensions
{
    internal const string MemberOfClaimType = "member_of";

    internal static Claim[] GetMemberOfClaims(this IIdentity? identity) =>
        identity is not ClaimsIdentity claimsIdentity
            ? Array.Empty<Claim>()
            : claimsIdentity.FindAll(MemberOfClaimType).ToArray();
}
