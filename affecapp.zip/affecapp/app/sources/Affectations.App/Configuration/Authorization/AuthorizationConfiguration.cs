using Microsoft.IdentityModel.Tokens;

namespace Affectations.App.Configuration.Authorization;

public class AuthorizationConfiguration
{
    public const string DefaultIdentityProvider = "MAAM";
    public const string ConfigurationSectionKey = nameof(AuthorizationConfiguration);
    public const string IdentityProviderToUseKey = "IdentityProviderToUse";

    public const string HasAnyProfilePolicy = nameof(HasAnyProfilePolicy);
    public const string HasUpdateProfilePolicy = nameof(HasUpdateProfilePolicy);
    public const string HasUserProfilePolicy = nameof(HasUserProfilePolicy);
    public const string HasConfigProfilePolicy = nameof(HasConfigProfilePolicy);
    public required Uri Authority { get; set; }
    public required string CallbackPath { get; set; }
    public required string ClientId { get; set; }
    public required JsonWebKey Jwk { get; set; }
    public Uri? Proxy { get; set; }
    public required string[] RequestedScopes { get; set; }
}
