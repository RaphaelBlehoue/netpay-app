using System.Net;
using System.Security.Claims;
using AxaFrance.AspNetCore.Authorization.Jwt.SiteMinder;
using AxaFrance.Extensions.OpenIdConnect.ClientAssertions.PrivateKeyJwt;
using IdentityModel;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Authorization.Infrastructure;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;

namespace Affectations.App.Configuration.Authorization;

public static class HostApplicationBuilderExtensions
{
    private const string AuthenticationCookieName = "affectations-authentication";
    private const string ConfigRole = "IAM_BAFFO_CONFIG";
    private const string UpdateRole = "IAM_BAFFO_UPDATE";
    private const string UserRole = "IAM_BAFFO_USER";

    public static void AddAuthenticationAndAuthorization(
        this IHostApplicationBuilder builder,
        AuthorizationConfiguration authorizationConfiguration
    )
    {
        builder.Services.AddBff(options =>
        {
            const string duendeLicenceKeyConfigurationKey = "Duende:LicenseKey";
            options.LicenseKey = builder.Configuration.GetValue<string>(duendeLicenceKeyConfigurationKey);
        });

        builder
            .Services.AddAuthorizationBuilder()
            .AddPolicy(
                AuthorizationConfiguration.HasAnyProfilePolicy,
                policy =>
                    policy
                        .RequireAuthenticatedUser()
                        .AddRequirements(new RolesAuthorizationRequirement(new[] { ConfigRole, UpdateRole, UserRole }))
            )
            .AddPolicy(
                AuthorizationConfiguration.HasConfigProfilePolicy,
                config => config.AddRequirements(new RolesAuthorizationRequirement(new[] { ConfigRole }))
            )
            .AddPolicy(
                AuthorizationConfiguration.HasUpdateProfilePolicy,
                policy => policy.AddRequirements(new RolesAuthorizationRequirement(new[] { UpdateRole }))
            )
            .AddPolicy(
                AuthorizationConfiguration.HasUserProfilePolicy,
                policy => policy.AddRequirements(new RolesAuthorizationRequirement(new[] { UserRole }))
            );

        builder
            .Services.AddAuthentication(options =>
            {
                options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = OpenIdConnectDefaults.AuthenticationScheme;
                options.DefaultSignOutScheme = OpenIdConnectDefaults.AuthenticationScheme;
            })
            .AddCookie(
                CookieAuthenticationDefaults.AuthenticationScheme,
                options =>
                {
                    options.Cookie.Name = AuthenticationCookieName;
                    options.Cookie.HttpOnly = true;
                    options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
                    options.Cookie.SameSite = SameSiteMode.Strict;
                    const int cookieExpiration = 20;
                    options.ExpireTimeSpan = TimeSpan.FromMinutes(cookieExpiration);
                    options.SlidingExpiration = true;
                }
            )
            .AddOpenIdConnect(
                OpenIdConnectDefaults.AuthenticationScheme,
                options =>
                {
                    options.AuthenticationMethod = OpenIdConnectRedirectBehavior.RedirectGet;
                    options.Authority = authorizationConfiguration.Authority.ToString();
                    options.ClientId = authorizationConfiguration.ClientId;
                    options.CallbackPath = authorizationConfiguration.CallbackPath;
                    options.RequireHttpsMetadata = !builder.Environment.IsDevelopment();
                    options.ResponseMode = OpenIdConnectResponseMode.Query;
                    options.ResponseType = OpenIdConnectResponseType.Code;
                    options.SaveTokens = true;

                    // Add the custom event to produce a Client Assertion
                    options.Events.OnAuthorizationCodeReceived = context =>
                    {
                        context.TokenEndpointRequest!.ClientAssertionType = OidcConstants
                            .ClientAssertionTypes
                            .JwtBearer;

                        // explicitly null the client_id and the client_secret to prevent being sent to the token endpoint in plaintext
                        context.TokenEndpointRequest.ClientId = null;
                        context.TokenEndpointRequest.ClientSecret = null;

                        context.TokenEndpointRequest.ClientAssertion = PrivateKeyJwtAssertionHelper.GenerateToken(
                            new PrivateKeyJwtAssertionOptions
                            {
                                Audience = authorizationConfiguration.Authority.ToString().TrimEnd('/'),
                                ClientId = authorizationConfiguration.ClientId,
                                Jwk = authorizationConfiguration.Jwk
                            }
                        );

                        return Task.CompletedTask;
                    };

                    foreach (var scope in authorizationConfiguration.RequestedScopes)
                    {
                        options.Scope.Add(scope);
                    }

                    if (authorizationConfiguration.Proxy is not null)
                    {
                        options.BackchannelHttpHandler = new HttpClientHandler
                        {
                            Proxy = new WebProxy { Address = authorizationConfiguration.Proxy }
                        };
                    }

                    options.Events.OnTokenValidated = builder.GetRolesMappingMethod();
                }
            );
    }

    private static string GetIdentityProviderToUseKey(this IHostApplicationBuilder builder) =>
        builder.Configuration.GetValue<string>(
            $"{AuthorizationConfiguration.ConfigurationSectionKey}:{AuthorizationConfiguration.IdentityProviderToUseKey}"
        ) ?? AuthorizationConfiguration.DefaultIdentityProvider;

    private static Func<TokenValidatedContext, Task> GetRolesMappingMethod(this IHostApplicationBuilder builder) =>
        builder.GetIdentityProviderToUseKey() switch
        {
            AuthorizationConfiguration.DefaultIdentityProvider
                => static context =>
                {
                    var profiles = context.Principal!.Identity.GetWacProfiles();
                    var claims = profiles.Select(profile => new Claim(ClaimTypes.Role, profile));
                    ((ClaimsIdentity)context.Principal.Identity!).AddClaims(claims);
                    return Task.CompletedTask;
                },
            _
                => static context =>
                {
                    if (context.Principal!.Identity is not ClaimsIdentity claimsIdentity)
                    {
                        return Task.CompletedTask;
                    }

                    var profiles = claimsIdentity.GetMemberOfClaims();
                    var claims = profiles.Select(memberOfClaim => new Claim(ClaimTypes.Role, memberOfClaim.Value));
                    claimsIdentity.AddClaims(claims);
                    return Task.CompletedTask;
                }
        };

    public static AuthorizationConfiguration GetRequiredAuthorizationConfiguration(this IHostApplicationBuilder builder)
    {
        var authorizationConfigurationSection = builder.Configuration.GetRequiredSection(
            AuthorizationConfiguration.ConfigurationSectionKey
        );
        var identityProviderToUse = builder.GetIdentityProviderToUseKey();

        return identityProviderToUse is not AuthorizationConfiguration.DefaultIdentityProvider
            ? authorizationConfigurationSection
                .GetRequiredSection(identityProviderToUse)
                .Get<AuthorizationConfiguration>()!
            // the default configuration is the root section to avoid breaking changes
            : authorizationConfigurationSection.Get<AuthorizationConfiguration>()!;
    }
}
