using Affectations.App.Configuration.Authorization;
using NSwag;
using NSwag.Generation.Processors.Security;

namespace Affectations.App.Configuration.OpenApi;

public static class WebApplicationBuilderExtensions
{
    private const string ApiName = "Affectations BFF";
    private const string ApiDescription =
        "The Affectations BFF API. An API providing data from the backend and connected APIs/WS.";
    private const string AuthorizeEndpoint = "/authorize";
    private const string TokenEndpoint = "/token";

    public static void AddOpenApiWithAffectationsAppConfiguration(
        this WebApplicationBuilder builder,
        AuthorizationConfiguration authorizationConfiguration
    )
    {
        if (!builder.Environment.IsDevelopment() && !builder.Environment.IsLocalDocker())
        {
            return;
        }

        builder.AddOpenApiWithAffectationsAppConfigurationForVersions(authorizationConfiguration, 0, 1);
    }

    private static void AddOpenApiWithAffectationsAppConfigurationForVersions(
        this WebApplicationBuilder builder,
        AuthorizationConfiguration configuration,
        params int[] versions
    )
    {
        foreach (var v in versions)
        {
            builder.Services.AddOpenApiDocument(config =>
            {
                var groupName = $"v{v}";
                config.DocumentName = groupName;
                config.ApiGroupNames = new[] { groupName };

                config.OperationProcessors.Add(new DeprecatedAnnotationProcessor());
                config.OperationProcessors.Add(new OperationSecurityScopeProcessor(ApiName));
                config.OperationProcessors.Add(new ProducesFileResultWithContentTypeOperationFilter());

                config.PostProcess = document =>
                {
                    document.Info.Version = groupName;
                    document.Info.Title = ApiName;
                    document.Info.Description = ApiDescription;
                };

                config.AddSecurity(
                    ApiName,
                    new OpenApiSecurityScheme
                    {
                        Type = OpenApiSecuritySchemeType.OAuth2,
                        Flows = new OpenApiOAuthFlows
                        {
                            AuthorizationCode = new OpenApiOAuthFlow
                            {
                                AuthorizationUrl = string.Concat(configuration.Authority, AuthorizeEndpoint),
                                TokenUrl = string.Concat(configuration.Authority, TokenEndpoint),
                                Scopes = configuration.RequestedScopes.ToDictionary(key => key, value => value)
                            }
                        }
                    }
                );
            });
        }
    }
}
