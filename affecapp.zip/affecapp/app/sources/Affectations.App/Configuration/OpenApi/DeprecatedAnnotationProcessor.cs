﻿using Microsoft.AspNetCore.Mvc.ApiExplorer;
using NSwag.Generation.AspNetCore;
using NSwag.Generation.Processors;
using NSwag.Generation.Processors.Contexts;

namespace Affectations.App.Configuration.OpenApi;

public class DeprecatedAnnotationProcessor : IOperationProcessor
{
    public bool Process(OperationProcessorContext context)
    {
        var netCoreContext = context as AspNetCoreOperationProcessorContext;
        var apiDescription = netCoreContext!.ApiDescription;
        var operation = netCoreContext.OperationDescription.Operation;
        operation.IsDeprecated |= apiDescription.IsDeprecated();
        return true;
    }
}
