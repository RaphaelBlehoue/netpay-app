namespace Affectations.App.Configuration.OpenApi;

[AttributeUsage(AttributeTargets.Method)]
public sealed class ProducesFileResultWithContentTypeAttribute : Attribute
{
    public ProducesFileResultWithContentTypeAttribute(string contentType)
    {
        ContentType = contentType;
    }

    public string ContentType { get; }
}
