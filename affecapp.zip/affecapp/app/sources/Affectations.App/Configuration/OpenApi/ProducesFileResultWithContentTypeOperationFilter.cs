using System.Globalization;
using NJsonSchema;
using NSwag;
using NSwag.Generation.Processors;
using NSwag.Generation.Processors.Contexts;

namespace Affectations.App.Configuration.OpenApi;

public class ProducesFileResultWithContentTypeOperationFilter : IOperationProcessor
{
    private const string BinaryFormat = "binary";
    private static readonly string Status200Ok = Convert.ToString(
        StatusCodes.Status200OK,
        CultureInfo.InvariantCulture
    );

    public bool Process(OperationProcessorContext context)
    {
        var requestAttribute = context
            .MethodInfo.GetCustomAttributes(typeof(ProducesFileResultWithContentTypeAttribute), false)
            .Cast<ProducesFileResultWithContentTypeAttribute>()
            .FirstOrDefault();

        if (requestAttribute == null)
        {
            return true;
        }

        var response = new OpenApiResponse();
        response.Content.Add(
            requestAttribute.ContentType,
            new OpenApiMediaType
            {
                Schema = new JsonSchema { Type = JsonObjectType.String, Format = BinaryFormat }
            }
        );
        context.OperationDescription.Operation.Responses.Add(Status200Ok, response);

        return true;
    }
}
