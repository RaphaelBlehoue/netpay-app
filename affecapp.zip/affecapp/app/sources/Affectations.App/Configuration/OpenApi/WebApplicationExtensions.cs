using Microsoft.AspNetCore.Mvc.ApiExplorer;
using NSwag.AspNetCore;

namespace Affectations.App.Configuration.OpenApi;

public static class WebApplicationExtensions
{
    private const string XForwardedHost = "X-Forwarded-Host";
    private const string XForwardedPort = "X-Forwarded-Port";
    private const string XForwardedProto = "X-Forwarded-Proto";

    public static void UseOpenApiWithKyrAppConfiguration(this WebApplication app)
    {
        if (!app.Environment.IsDevelopment() && !app.Environment.IsLocalDocker())
        {
            return;
        }

        var apiVersionDescriptionProvider = app.Services.GetRequiredService<IApiVersionDescriptionProvider>();

        app.UseOpenApi(WithForwardedHeaders);
        app.UseSwaggerUi(options =>
        {
            options.SwaggerRoutes.Clear();
            foreach (var description in apiVersionDescriptionProvider.ApiVersionDescriptions.Reverse())
            {
                options.SwaggerRoutes.Add(
                    new SwaggerUiRoute(description.GroupName, $"/swagger/{description.GroupName}/swagger.json")
                );
            }
        });
    }

    private static void WithForwardedHeaders(OpenApiDocumentMiddlewareSettings options)
    {
        options.PostProcess = (document, request) =>
        {
            if (!request.Headers.TryGetValue(XForwardedHost, out var hosts))
            {
                return;
            }

            var host = hosts[0]!;

            if (!request.Headers.TryGetValue(XForwardedPort, out var ports))
            {
                return;
            }

            var port = ports[0]!;

            if (!request.Headers.TryGetValue(XForwardedProto, out var schemes))
            {
                return;
            }

            var scheme = schemes[0]!;

            document.Servers.Add(new() { Url = $"{scheme}://{host}:{port}" });
            var servers = document.Servers.Reverse().ToArray();
            document.Servers.Clear();
            foreach (var server in servers)
            {
                document.Servers.Add(server);
            }
        };
    }
}
