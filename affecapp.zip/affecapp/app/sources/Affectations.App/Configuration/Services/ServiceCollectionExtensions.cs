using Affectations.App.Mappers;
using Affectations.App.Services;

namespace Affectations.App.Configuration.Services;

public static class ServiceCollectionExtensions
{
    public static void ConfigureServices(this IServiceCollection serviceCollection)
    {
        serviceCollection.AddScoped<IEmployeeService, EmployeeService>();
        serviceCollection.AddScoped<IRuleCriterionService, RuleCriterionService>();
        serviceCollection.AddScoped<IRuleService, RuleService>();
        serviceCollection.AddScoped<ICSVService, CSVService>();
        serviceCollection.AddAutoMapper(typeof(MapperProfiles));
        serviceCollection.AddScoped<ITeamService, TeamService>();
    }
}
