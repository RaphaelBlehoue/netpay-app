﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Versioning;

namespace Affectations.App.Configuration.Versioning;

public static class WebApplicationBuilderExtensions
{
    public static void AddEndpointsApiExplorerWithVersioning(this WebApplicationBuilder builder)
    {
        builder.Services.AddApiVersioning(o =>
        {
            o.ReportApiVersions = true;
            o.AssumeDefaultVersionWhenUnspecified = true;
            o.DefaultApiVersion = new ApiVersion(1, 0);
            o.ApiVersionReader = new UrlSegmentApiVersionReader();
        });
        builder.Services.AddVersionedApiExplorer(o =>
        {
            o.GroupNameFormat = "'v'VVV";
            o.SubstituteApiVersionInUrl = true;
        });
        builder.Services.AddEndpointsApiExplorer();
    }
}
