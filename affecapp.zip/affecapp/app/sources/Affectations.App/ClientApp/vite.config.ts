import eslintPlugin from '@nabla/vite-plugin-eslint';
import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';
import checker from 'vite-plugin-checker';
import svgr from 'vite-plugin-svgr';
import tsconfigPaths from 'vite-tsconfig-paths';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [
    react(),
    svgr(),
    checker({
      typescript: true,
    }),
    eslintPlugin({
      formatter: 'stylish',
      eslintOptions: {
        cache: false,
      },
    }),
    tsconfigPaths(),
  ],
  envPrefix: 'VITE_',
  server: {
    port: 13370,
  },
  resolve: {
    alias: {
      '~assets': '/src/assets',
    },
  },
  css: {
    preprocessorOptions: {
      scss: {
        additionalData: `@import "src/main.scss";`,
      },
    },
  },
  define: {
    /*
     * we use the custom variable `affectations_app_version` to be able to get the whole semver version
     * in case of this version not being found in the environment variables, we fallback to the `npm_package_version`
     * which is the version of the package.json
     */
    APP_VERSION: JSON.stringify(process.env.affectations_app_version ?? process.env.npm_package_version ?? 'unknown'),
  },
});
