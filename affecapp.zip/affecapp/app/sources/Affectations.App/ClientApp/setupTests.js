import * as matchers from '@testing-library/jest-dom/matchers';
import { cleanup } from '@testing-library/react';
import { toHaveNoViolations } from 'jest-axe';
import { afterAll, afterEach, beforeAll, expect } from 'vitest';
import { setJestCucumberConfiguration } from 'jest-cucumber';
import { server } from './src/mocks/server';
import 'whatwg-fetch';
import { setGlobalOrigin } from 'undici';


expect.extend(toHaveNoViolations);
expect.extend(matchers);

setJestCucumberConfiguration({
  loadRelativePath: true
});

beforeEach(() => {
  setGlobalOrigin(window.location.origin);
});

beforeAll(() => {
  server.listen({ onUnhandledRequest: 'warn' });
});


afterEach(() => {
  cleanup();
  setGlobalOrigin(undefined);
  server.resetHandlers();
});

afterAll(() => server.close());
