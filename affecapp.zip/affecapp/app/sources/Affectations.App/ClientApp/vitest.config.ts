import react from '@vitejs/plugin-react';
import svgr from 'vite-plugin-svgr';
import tsconfigPaths from 'vite-tsconfig-paths';
import { defineConfig } from 'vitest/config';

export default defineConfig({
  plugins: [react(), tsconfigPaths(), svgr()],
  resolve: {
    mainFields: ['module', 'main', 'jsnext:main', 'jsnext'],
  },
  test: {
    globals: true,
    globalSetup: './globalSetup.ts',
    include: ['**/*.(spec|test|steps).[jt]s?(x)'],
    watch: false,
    clearMocks: true,
    css: {
      modules: {
        classNameStrategy: 'non-scoped',
      },
    },
    reporters: ['default', 'vitest-sonar-reporter'],
    outputFile: 'test-report.xml',
    api: {
      port: 3000,
    },
    coverage: {
      enabled: true,
      reporter: ['lcov', 'clover', 'json', 'html'],
      provider: 'v8',
      exclude: [
        'src/**/*.types.ts',
        'src/index.jsx',
        'src/**/index.js',
        'src/**/*.stories.js',
        'src/**/testsUtils.jsx',
        'src/setupTests.js',
        'src/**/shared-steps.js',
        'src/**/environment.js',
        'src/**/*.specs.js',
        'src/**/*.steps.js',
        'src/**/*.steps.ts',
        'src/**/*.steps.tsx',
        'src/**/*.d.ts',
        'src/__mocks__/**/*',
        'src/__features__/**/*',
        'src/__tests__/**/*',
        'src/**/__tests__/**/*',
      ],
    },
    environment: 'jsdom',
    setupFiles: ['./setupTests.js'],
    deps: {
      inline: ['specflow-emulator', 'whatwg-fetch'],
    },
  },
  define: {
    /*
     * we use the custom variable `affectations_app_version` to be able to get the whole semver version
     * in case of this version not being found in the environment variables, we fallback to the `npm_package_version`
     * which is the version of the package.json
     */
    APP_VERSION: JSON.stringify(process.env.affectations_app_version ?? process.env.npm_package_version ?? 'unknown'),
  },
});
