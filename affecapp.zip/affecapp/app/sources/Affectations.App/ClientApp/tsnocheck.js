/* tslint:disable */
/* eslint-disable */
// ReSharper disable InconsistentNaming

import { readFile, writeFile } from 'fs/promises';
import { fileURLToPath } from 'url';
import { dirname, resolve } from 'path';

// Obtient le chemin du fichier actuel
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
 
const filePath = resolve(__dirname, 'src/api/bff-clients.generated.ts');
const tsNoCheckComment = '// @ts-nocheck\n';
 
async function addTsNoCheck() {
  try {
    const data = await readFile(filePath, 'utf8');
 
    if (!data.startsWith(tsNoCheckComment)) {
      const updatedData = tsNoCheckComment + data;
      await writeFile(filePath, updatedData, 'utf8');
      console.log('ts-nocheck comment added.');
    }
  } catch (err) {
    console.error(err);
  }
}
 
addTsNoCheck();