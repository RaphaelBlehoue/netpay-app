import { http, HttpResponse } from 'msw';

import { getUrl } from '@affectations/mocks/url';

import getAllTeams from './mocks/get-teams.json';

export const getTeamsMock = () =>
  http.get(getUrl('teams'), async () => {
    return HttpResponse.json(getAllTeams);
  });
