import { http, HttpResponse } from 'msw';

import { StatusCodes } from '@affectations/utils/http';
import { IFilterRuleDto } from '@affectations/api/bff-clients.generated';
import { getUrl } from '@affectations/mocks/url';

export const exportRules = (status = StatusCodes.OK, apiUrl = 'rules/export') =>
  http.post(getUrl(apiUrl), async ({ request }) => {
    const exportFilter = (await request.json()) as IFilterRuleDto;

    let csvContent = 'id,name,description\n';
    if (exportFilter.ids && exportFilter.ids.length > 0) {
      exportFilter.ids.forEach(id => {
        csvContent += `=${id},name${id},description${id}\n`;
      });
    } else {
      csvContent += '1,name1,description1\n';
      csvContent += '2,name2,description2\n';
    }

    const timestamp = new Date().toISOString().replace(/[-:]/g, '').replace(/\..+/, '');
    const fileName =
      exportFilter.ids && exportFilter.ids.length === 1
        ? `exprgl-${exportFilter.ids[0]}-${timestamp}.csv`
        : `exprgl-list-${timestamp}.csv`;

    return HttpResponse.text(csvContent, {
      status: status,
      headers: {
        'Content-Type': 'text/csv',
        'Content-Disposition': `attachment; filename="${fileName}"`,
      },
    });
  });
