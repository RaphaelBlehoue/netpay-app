import { convertParamsToNumber } from './utils';

describe('convertParamsToNumber', () => {
  it('should convert a string to a number', () => {
    const result = convertParamsToNumber('123');
    expect(result).toBe(123);
  });

  it('should convert a single-element string array to a number', () => {
    const result = convertParamsToNumber(['456']);
    expect(result).toBe(456);
  });

  it('should return undefined for undefined value', () => {
    const expectedUndefined = undefined;
    const result = convertParamsToNumber(expectedUndefined);
    expect(result).toBeUndefined();
  });

  it('should return undefined for an empty array', () => {
    const result = convertParamsToNumber([]);
    expect(result).toBeUndefined();
  });

  it('should return undefined for an invalid string', () => {
    const result = convertParamsToNumber('hello');
    expect(result).toBeUndefined();
  });

  it('should return undefined for an array with multiple elements', () => {
    const result = convertParamsToNumber(['1', '2']);
    expect(result).toBeUndefined();
  });
});
