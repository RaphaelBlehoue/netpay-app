export const convertParamsToNumber = (params: string | readonly string[] | undefined): number | undefined => {
  if (typeof params === 'string' || (Array.isArray(params) && params.length === 1)) {
    const stringValue = Array.isArray(params) ? params[0] : params;
    const numberValue = Number(stringValue);
    if (!isNaN(numberValue)) {
      return numberValue;
    }
  }
  return undefined;
};
