import { http, HttpResponse } from 'msw';

import { EmployeeSearchDto } from '@affectations/api/bff-clients.generated';
import { getUrl } from '@affectations/mocks/url';

import employeeData from './mocks/get-all-employees.json';

export const searchCollaborators = () =>
  http.post(getUrl('employees/search'), async ({ request }) => {
    const { lastNameStartsWithFilter, pageNumber, pageSize } = (await request.json()) as EmployeeSearchDto;

    const total = Math.floor(employeeData.length / (pageSize ?? 1));
    const modulo = employeeData.length % (pageSize ?? 1) > 0 ? 1 : 0;

    if (!lastNameStartsWithFilter) {
      return HttpResponse.json({
        data: [],
        page: pageNumber,
        size: pageSize,
        totalPages: 0,
        totalData: 0,
      });
    }

    const data = employeeData.filter(
      x =>
        x.firstName.toLocaleLowerCase().startsWith(lastNameStartsWithFilter.toLocaleLowerCase()) ||
        x.lastName.toLocaleLowerCase().startsWith(lastNameStartsWithFilter.toLocaleLowerCase())
    );

    return HttpResponse.json({
      data,
      page: pageNumber,
      size: pageSize,
      totalPages: total + modulo,
      totalData: employeeData.length,
    });
  });
