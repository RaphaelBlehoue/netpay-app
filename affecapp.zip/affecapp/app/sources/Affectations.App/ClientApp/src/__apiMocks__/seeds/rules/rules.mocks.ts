import { http, HttpResponse } from 'msw';

import { convertParamsToNumber } from '@affectations/__apiMocks__/utils';
import { getUrl } from '@affectations/mocks/url';

import { IRuleDto } from '@affectations/api/bff-clients.generated';
import hundredRules from './mocks/get-hundred-rules.json';
import getRulesByIdModalityActiveWithoutEndDate from './mocks/get-rules-by-id-200-active-and-now-without-enddate.json';
import getRulesByIdModalityActiveAndNow from './mocks/get-rules-by-id-200-active-and-now.json';
import getRulesByIdModalityDraftWithoutEndDate from './mocks/get-rules-by-id-200-draft-and-now-without-enddate.json';
import getRuleWithOutUpdate from './mocks/get-rules-by-id-200-modality-all.json';
import getRuleWithOutEmploye from './mocks/get-rules-by-id-200-with-employe.json';
import getRuleWithOutRegion from './mocks/get-rules-by-id-200-without-region.json';
import getRulesByIdModalityDraftAndNow from './mocks/get-rules-by-id-200-draft-and-now.json';
import getRulesByIdModality from './mocks/get-rules-by-id-200.json';
import postRulesAffectation from './mocks/post-rules-201.json';

export const API_URL = `${window.location.origin}`;

const useCaseRulesById = new Map([
  [1, { value: getRulesByIdModality }],
  [2, { value: getRulesByIdModalityActiveAndNow }],
  [3, { value: getRulesByIdModalityDraftAndNow }],
  [4, { value: getRulesByIdModalityActiveWithoutEndDate }],
  [5, { value: getRulesByIdModalityDraftWithoutEndDate }],
  [6, { value: getRuleWithOutUpdate }],
  [7, { value: getRuleWithOutEmploye }],
  [8, { value: getRuleWithOutRegion }],
]);


export const getRulesByIdConsultationMock = () =>
  http.get(getUrl('rules/:rulesId'), async ({ params }) => {
    const { rulesId } = params;
    const paramKeyNumber = convertParamsToNumber(rulesId) ?? 1;
    const currentJsonData = useCaseRulesById.get(paramKeyNumber);
    return HttpResponse.json(currentJsonData?.value);
  });
export const searchRule = (rules = hundredRules) =>
  http.post(getUrl('rules/search'), async ({ request }) => {
    const url = new URL(request.url);
    const page = parseInt(url.searchParams.get('page') ?? '0');
    const size = parseInt(url.searchParams.get('size') ?? '0');
    const total = Math.floor(rules.length / size);
    const modulo = rules.length % size > 0 ? 1 : 0;

    const data = rules.sort((x, y) => x.id - y.id).slice((page - 1) * size, page * size);
    return HttpResponse.json({ data, page, size, totalPages: total + modulo, totalData: rules.length });
  });

export const createRules = () =>
  http.post(getUrl('rules'), async ({ request }) => {
    const info = await request.json() as IRuleDto;
    const currentData = postRulesAffectation;
    const partialruleDetailsDto = {
      ...currentData.ruleDetailsDto,
      statut: info.ruleDetailsDto?.statut
    };
    const updatedConst = {
      ...currentData,
      id: 5,
      ruleDetailsDto: partialruleDetailsDto
    };
    return HttpResponse.json(updatedConst, { status: 201 });
  });
