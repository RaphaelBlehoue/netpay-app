import { http, HttpResponse } from 'msw';

import {
  PagedDataOfRuleCriterion,
  RuleCriterion,
  RuleCriterionSearchDto,
} from '@affectations/api/bff-clients.generated';
import { PORTEFOLIO_CODE, STATIC_ALL_VALUE_CRITERIA } from '@affectations/features/TermsOfTheWizardRules/utils';
import { getUrl } from '@affectations/mocks/url';
import { TAutoCompleteData } from '@affectations/types';

import getRulesCriteria from './mocks/get-rules-criteria.json';

export const API_URL = `${window.location.origin}`;

export const getRulesCriteriaMock = () =>
  http.get(getUrl('rule-criteria'), async () => {
    return HttpResponse.json(getRulesCriteria);
  });

export const searchRulesCriteriaMock = () =>
  http.post(getUrl('rule-criteria/search'), async ({ request }) => {
    const body = (await request.json()) as RuleCriterionSearchDto;

    const data = (
      getRulesCriteria[(body.categoryCode as never) ?? PORTEFOLIO_CODE] as {
        ruleCriteria: RuleCriterion[];
      }
    ).ruleCriteria;
    const filtered = data.filter(
      x => body.labelStartsWithFilter && x.code?.toLocaleLowerCase() === body.labelStartsWithFilter.toLocaleLowerCase()
    );
    const result = {
      data: filtered,
      totalPages: Math.ceil(data.length / (body.pageSize ?? 1)),
      page: body.pageNumber,
      totalData: data.length,
      size: body.pageSize,
      init: () => { },
      toJSON: () => ({
        data: filtered,
        totalPages: Math.ceil(data.length / (body.pageSize ?? 1)),
        page: body.pageNumber,
        totalData: data.length,
        size: body.pageSize,
      }),
    } satisfies PagedDataOfRuleCriterion;
    return HttpResponse.json(result);
  });

export const postCriteriaSearch = () =>
  http.post(getUrl('rule-criteria/search'), async ({ request }) => {

    const {
      categoryCode,
      labelStartsWithFilter,
      pageNumber,
      pageSize
    } = (await request.json()) as RuleCriterionSearchDto;

    const {
      currentAutoCompleteData,
      doesIncludeCategoryCode,
      modulo, totalOccurrent
    } = getCategoryAndCurrentAutoComplete({ categoryCode, pageSize });

    if (!labelStartsWithFilter || !doesIncludeCategoryCode) {
      return HttpResponse.json({
        data: [],
        page: pageNumber,
        size: pageSize,
        totalPages: 0,
        totalData: 0,
      });
    }

    const data = currentAutoCompleteData.filter(
      x =>
        x.label.toLocaleLowerCase().startsWith(labelStartsWithFilter.toLocaleLowerCase()) ||
        x.code.toLocaleLowerCase().startsWith(labelStartsWithFilter.toLocaleLowerCase())
    );

    return HttpResponse.json({
      data,
      page: pageNumber,
      size: pageSize,
      totalPages: totalOccurrent + modulo,
      totalData: currentAutoCompleteData.length,
    });
  });

const getCategoryAndCurrentAutoComplete = ({
  categoryCode,
  pageSize,
}: {
  categoryCode: string | undefined;
  pageSize: number | undefined;
}) => {
  let currentAutoCompleteData: TAutoCompleteData[] = [];
  let doesIncludeCategoryCode: boolean = false;
  if (categoryCode === PORTEFOLIO_CODE) {
    currentAutoCompleteData = getRulesCriteria.PORTFOLIO_CODE.ruleCriteria;
  }

  if (categoryCode === STATIC_ALL_VALUE_CRITERIA.INTERMEDIARY_NAME) {
    currentAutoCompleteData = getRulesCriteria.INTERMEDIARY_NAME.ruleCriteria;
  }

  const totalOccurrent = Math.floor(currentAutoCompleteData.length / (pageSize ?? 1));
  const modulo = currentAutoCompleteData.length % (pageSize ?? 1) > 0 ? 1 : 0;
  if (categoryCode !== undefined) {
    doesIncludeCategoryCode = [PORTEFOLIO_CODE, STATIC_ALL_VALUE_CRITERIA.INTERMEDIARY_NAME].includes(categoryCode);
  }
  return {
    currentAutoCompleteData,
    doesIncludeCategoryCode,
    modulo,
    totalOccurrent,
  };
};
