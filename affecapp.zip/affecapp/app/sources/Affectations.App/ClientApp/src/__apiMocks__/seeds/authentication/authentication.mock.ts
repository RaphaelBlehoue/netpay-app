import { http, HttpResponse } from 'msw';

import { API_URL } from '../rules/rules.mocks';
import claims from './mocks/claims.json';

export const getUserMock = () => http.get(`${API_URL}/bff/user`, async () => HttpResponse.json(claims));
