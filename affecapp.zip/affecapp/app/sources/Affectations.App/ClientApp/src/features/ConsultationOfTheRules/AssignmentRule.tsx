import './AssignmentRule.scss';

import { Loader } from '@affectations/components';

import { rowRulesType } from '../commonTypes';
import { RowAssignmentRules } from './components/RowAssignmentRules';

export interface IAssigmentRules {
  assigmentRulesMapping: rowRulesType[];
  isLoading?: boolean;
  isSuccess?: boolean;
  sectionTitle?: string;
}
const AssignmentRule = ({ assigmentRulesMapping, isLoading, isSuccess, sectionTitle }: IAssigmentRules) => (
  <>
    <h2 className="af-title">{sectionTitle}</h2>
    <section className="assignment-rules" aria-label="container affection rules">
      <Loader isLoading={isLoading}>
        {isSuccess &&
          assigmentRulesMapping &&
          assigmentRulesMapping.map(({ label, content }, index) => (
            <RowAssignmentRules id={`rules-${index + 1}`} key={`block-${label}`} label={label} content={content} />
          ))}
      </Loader>
    </section>
  </>
);
export { AssignmentRule };
