import { render, screen } from '@testing-library/react';
import { defineFeature, DefineStepFunction, loadFeature } from 'jest-cucumber';

import ConfirmationMessage from '@affectations/components/ui/NotificationRuleMessage/ConfirmationMessage';
import { wait } from '@affectations/hooks';

const feature = loadFeature('../features/CreatingRuleConfirmationMessage.feature');

const givenRenderConfirmationMessage = (given: DefineStepFunction) => {
  given(/^La date de création (.*) et le statut (.*)$/, (tempDateCreation: string, statut: string) => {
    const dateCreation = new Date(tempDateCreation);
    render(<ConfirmationMessage status={statut} creationDate={dateCreation} />);
  });
};

const whenShowRuleDetails = (when: DefineStepFunction) => {
  let alertComponent: HTMLElement;
  when('La page de consultation et le message de confirmation sont affichés', async () => {
    alertComponent = await screen.findByRole('alert');
    expect(alertComponent).toBeInTheDocument();
  });
};
const thenConfirmationMessageIsDisplayed = (then: DefineStepFunction) => {
  then(/^Je devrais voir le message: (.*) affiché$/, async (message: string) => {
    await wait(1000);
    const confirmationMsg = await screen.findByText(message);
    expect(confirmationMsg).toBeInTheDocument();
  });
};

defineFeature(feature, test => {
  test('La règle est enregistrée avec le statut brouillon avec des erreurs', ({ given, when, then }) => {
    givenRenderConfirmationMessage(given);

    whenShowRuleDetails(when);

    thenConfirmationMessageIsDisplayed(then);
  });

  test('La règle est enregistrée avec le statut active', ({ given, when, then }) => {
    givenRenderConfirmationMessage(given);

    whenShowRuleDetails(when);

    thenConfirmationMessageIsDisplayed(then);
  });
  test('La règle est enregistrée avec le statut brouillon', ({ given, when, then }) => {
    givenRenderConfirmationMessage(given);

    whenShowRuleDetails(when);

    thenConfirmationMessageIsDisplayed(then);
  });
});
