Feature: Page d'Accueil - Tableau d'affichage des règles

    en tant que Utilisateur IAM_BAFFO_USER
    Je veux voir mes règles d'affectation remontées par ma recherche dans un tableau
    Afin de pouvoir visualiser mes règles rapidement

    Rule: Affichage du nombre de résultat (titre)

        Scenario Outline: <ruleCount> règles sont retournées
            Given Je reçois <ruleCount> règles
            When Je suis sur la page d'Accueil
            Then Le titre "<expected>" est visible

            Examples:
                | ruleCount | expected                |
                | 1         | 1 règle d'affectation   |
                | 10        | 10 règles d'affectation |
                | 20        | 20 règles d'affectation |
                | 30        | 30 règles d'affectation |
                | 40        | 40 règles d'affectation |

    Rule: Affichage des données du tableau

        Scenario: Je vois les differentes colonnes
            Given Je recois cette liste de règles
                | id | status | region               | branche         | segmentation | department | intermediate                        | walletCode | network | contractNumber   | team     | collaborator | accountManager | clientNumber | uvProductCode | clause | syndicCode | nafCode    | copth    | contractCategory | priorisation | ruleName                | comment | process | startDate           | endtDate            | userMaj          | updateDate          |
                | 1  | Active | Auvergne-Rhône-Alpes | Transport autre | est parmi    | 01         | Alain&Nicole 123 - Boutique/Magasin | 0000012345 | Reseau  | 000E012345678912 | GC_RC_MS | collaborator | manager        | 000E012345   | 1A234         | 012345 | 012345789  | 12345ABCDE | égal à 1 | contractCategory | high         | Remplacement de Mélanie | comment | process | 2024-01-01T23:00:00 | 2025-01-01T23:00:00 | Jérôme CAGNONCLE | 2024-04-01T10:55:02 |
            When Je suis sur la page d'Accueil
            Then Les colonnes suivantes sont visibles
                | column                    |
                | Statut                    |
                | Région d'affectation      |
                | Branche                   |
                | Segmentation              |
                | Département               |
                | Département               |
                | Nom d'intermédiaire       |
                | Code portefeuille         |
                | Réseau                    |
                | N° contrat                |
                | Equipe d'affectation      |
                | Affectation collaborateur |
                | Chargé de clientèle       |
                | N° client                 |
                | Code UV Produit           |
                | Clause                    |
                | Code syndic               |
                | Code NAF                  |
                | COPHT (€)                 |
                | Catégorie du contrat QP   |
                | Priorisation              |
                | Nom de la règle           |
                | Commentaire               |
                | Date de début             |
                | Date de fin               |
                | Mise à jour par           |
                | Date de modification      |
                | ID règle                  |

        Scenario: Je recois des règles à afficher
            Given Je recois cette liste de règles
                | id | status  | region                 | branche           | segmentation | department | intermediate                          | walletCode  | network  | contractNumber    | team       | collaborator   | accountManager | clientNumber | uvProductCode | clause  | syndicCode | nafCode     | copth    | contractCategory   | priorisation | ruleName                  | comment   | process   | startDate           | endtDate            | userMaj            | updateDate          |
                | 1  | Expirée | Auvergne-Rhône-Alpes   | Transport autre   | est parmi    | 01         | Alain&Nicole 123 - Boutique/Magasin   | 0000012345  | Reseau   | 000E012345678912  | GC_RC_MS   | collaborator   | manager        | 000E012345   | 1A234         | 012345  | 012345789  | 12345ABCDE  | égal à 1 | contractCategory   | high         | Remplacement de Mélanie   | comment   | process   | 2024-01-01T23:00:00 | 2025-01-01T23:00:00 | Jérôme CAGNONCLE   | 2024-04-01T10:55:02 |
                | 2  | Expirée | Auvergne-Rhône-Alpes 1 | Transport autre 1 | est parmi 1  | 02         | Alain&Nicole 123 - Boutique/Magasin 1 | 00000123451 | Reseau 1 | 000E0123456789121 | GC_RC_MS_1 | collaborator 1 | manager 1      | 000E0123451  | 1A2311        | 0123451 | 0123457819 | 12345ABCDE1 | égal à 2 | contractCategory 1 | high 1       | Remplacement de Mélanie 1 | comment 1 | process 1 | 2024-02-01T21:00:00 | 2026-01-01T23:00:00 | Jérôme CAGNONCLE 1 | 2024-05-01T10:50:02 |
                | 3  | Expirée | Auvergne-Rhône-Alpes 2 | Transport autre 2 | est parmi 2  | 03         | Alain&Nicole 123 - Boutique/Magasin 2 | 00000123452 | Reseau 2 | 000E0123456789123 | GC_RC_MS_2 | collaborator 2 | manager 2      | 000E0123452  | 1A2312        | 0123452 | 0123457812 | 12345ABCDE2 | égal à 3 | contractCategory 2 | high 2       | Remplacement de Mélanie 2 | comment 2 | process 1 | 2024-03-01T20:00:00 | 2027-01-01T23:00:00 | Jérôme CAGNONCLE 2 | 2024-06-01T10:45:02 |
            When Je suis sur la page d'Accueil
            Then Toutes les règles s'affichent

        Scenario: Je ne recois aucune règles à afficher
            Given Je recois cette liste de règles
                | id | status | region | branche | segmentation | department | intermediate | walletCode | network | contractNumber | team | collaborator | accountManager | clientNumber | uvProductCode | clause | syndicCode | nafCode | copth | contractCategory | priorisation | ruleName | comment | process | startDate | endtDate | userMaj | updateDate |
            When Je suis sur la page d'Accueil
            Then Le titre "Aucune règle d'affectation correspond à votre recherche." est visible
            And Le tableau n'est pas visible

        Scenario: Les valeurs multiples sont tronquées
            Given Je recois cette liste de règles
                | id | status    | region                 | branche           | segmentation | department | intermediate                                                                                                    | walletCode              | network  | contractNumber                      | team       | collaborator   | accountManager | clientNumber            | uvProductCode | clause        | syndicCode                       | nafCode                 | copth    | contractCategory   | priorisation | ruleName                  | comment   | process   | startDate           | endtDate            | userMaj            | updateDate          |
                | 1  | Active    | Auvergne-Rhône-Alpes   | Transport autre   | est parmi    | 01         | Alain&Nicole 123 - Boutique/Magasin;Alain&Nicole 123 - Boutique/Magasin 1;Alain&Nicole 123 - Boutique/Magasin 2 | 0000012345              | Reseau   | 000E012345678912                    | GC_RC_MS   | collaborator   | manager        | 000E012345              | 1A234         | 012345;012389 | 012345789                        | 12345ABCDE              | égal à 1 | contractCategory   | high         | Remplacement de Mélanie   | comment   | process   | 2024-01-01T23:00:00 | 2025-01-01T23:00:00 | Jérôme CAGNONCLE   | 2024-04-01T10:55:02 |
                | 2  | Brouillon | Auvergne-Rhône-Alpes 1 | Transport autre 1 | est parmi 1  | 02         | Alain&Nicole 123 - Boutique/Magasin 1                                                                           | 00000123451;00000123423 | Reseau 1 | 000E0123456789121                   | GC_RC_MS_1 | collaborator 1 | manager 1      | 000E0123451             | 1A2311;1A2323 | 0123451       | 0123457819;0123457814;0123457810 | 12345ABCDE1             | égal à 2 | contractCategory 1 | high 1       | Remplacement de Mélanie 1 | comment 1 | process 1 | 2024-02-01T21:00:00 | 2026-01-01T23:00:00 | Jérôme CAGNONCLE 1 | 2024-05-01T10:50:02 |
                | 3  | Expirée   | Auvergne-Rhône-Alpes 2 | Transport autre 2 | est parmi 2  | 03         | Alain&Nicole 123 - Boutique/Magasin 2                                                                           | 00000123452             | Reseau 2 | 000E0123456789123;000E0123456789198 | GC_RC_MS_2 | collaborator 2 | manager 2      | 000E0123452;000E0123456 | 1A2312        | 0123452       | 0123457812                       | 12345ABCDE2;12345ABCDE6 | égal à 3 | contractCategory 2 | high 2       | Remplacement de Mélanie 2 | comment 2 | process 1 | 2024-03-01T20:00:00 | 2027-01-01T23:00:00 | Jérôme CAGNONCLE 2 | 2024-06-01T10:45:02 |
                | 4  |           | Auvergne-Rhône-Alpes 3 | Transport autre 3 | est parmi 3  | 04         |                                                                                                                 |                         | Reseau 3 |                                     | GC_RC_MS_3 | collaborator 3 | manager 3      | 000E0123451;000E0123453 | 1A2313        | 0123458       | 0123457818                       | 12345ABCDE2             | égal à 4 | contractCategory 3 | high 3       | Remplacement de Mélanie 3 | comment 3 | process 3 | 2025-03-01T20:00:00 | 2021-01-01T23:00:00 | Jérôme CAGNONCLE 3 | 2023-06-01T10:45:02 |
            When Je suis sur la page d'Accueil
            Then Les données suivantes sont visibles
                | id | status    | region                 | branche           | segmentation | department | intermediate                            | walletCode      | network  | contractNumber        | team       | collaborator   | accountManager | clientNumber    | uvProductCode | clause     | syndicCode     | nafCode         | copth    | contractCategory   | priorisation | ruleName                  | comment   | process   | startDate           | endtDate            | userMaj            | updateDate          |
                | 1  | Active    | Auvergne-Rhône-Alpes   | Transport autre   | est parmi    | 01         | Alain&Nicole 123 - Boutique/Magasin;... | 0000012345      | Reseau   | 000E012345678912      | GC_RC_MS   | collaborator   | manager        | 000E012345      | 1A234         | 012345;... | 012345789      | 12345ABCDE      | égal à 1 | contractCategory   | high         | Remplacement de Mélanie   | comment   | process   | 2024-01-01T23:00:00 | 2025-01-01T23:00:00 | Jérôme CAGNONCLE   | 2024-04-01T10:55:02 |
                | 2  | Brouillon | Auvergne-Rhône-Alpes 1 | Transport autre 1 | est parmi 1  | 02         | Alain&Nicole 123 - Boutique/Magasin 1   | 00000123451;... | Reseau 1 | 000E0123456789121     | GC_RC_MS_1 | collaborator 1 | manager 1      | 000E0123451     | 1A2311;...    | 0123451    | 0123457819;... | 12345ABCDE1     | égal à 2 | contractCategory 1 | high 1       | Remplacement de Mélanie 1 | comment 1 | process 1 | 2024-02-01T21:00:00 | 2026-01-01T23:00:00 | Jérôme CAGNONCLE 1 | 2024-05-01T10:50:02 |
                | 3  | Expirée   | Auvergne-Rhône-Alpes 2 | Transport autre 2 | est parmi 2  | 03         | Alain&Nicole 123 - Boutique/Magasin 2   | 00000123452     | Reseau 2 | 000E0123456789123;... | GC_RC_MS_2 | collaborator 2 | manager 2      | 000E0123452;... | 1A2312        | 0123452    | 0123457812     | 12345ABCDE2;... | égal à 3 | contractCategory 2 | high 2       | Remplacement de Mélanie 2 | comment 2 | process 1 | 2024-03-01T20:00:00 | 2027-01-01T23:00:00 | Jérôme CAGNONCLE 2 | 2024-06-01T10:45:02 |

    Rule: Configuration des filtres
        Background: Je me rend sur la page d'accueil
            Given Je recois cette liste de règles
                | id | status    | region | branche           | segmentation | department | intermediate                          | walletCode  | network  | contractNumber    | team       | collaborator   | accountManager | clientNumber | uvProductCode | clause  | syndicCode | nafCode     | copth    | contractCategory   | priorisation | ruleName                  | comment   | process   | startDate           | endtDate            | userMaj            | updateDate          |
                | 1  | Active    | z      | Transport autre   | est parmi    | 01         | Alain&Nicole 123 - Boutique/Magasin   | 0000012345  | Reseau   | 000E012345678912  | GC_RC_MS   | collaborator   | manager        | 000E012345   | 1A234         | 012345  | 012345789  | 12345ABCDE  | égal à 1 | contractCategory   | high         | Remplacement de Mélanie   | comment   | process   | 2024-01-01T23:00:00 | 2025-01-01T23:00:00 | Jérôme CAGNONCLE   | 2024-04-01T10:55:02 |
                | 2  | Brouillon | y      | Transport autre 1 | est parmi 1  | 02         | Alain&Nicole 123 - Boutique/Magasin 1 | 00000123451 | Reseau 1 | 000E0123456789121 | GC_RC_MS_1 | collaborator 1 | manager 1      | 000E0123451  | 1A2311        | 0123451 | 0123457819 | 12345ABCDE1 | égal à 2 | contractCategory 1 | high 1       | Remplacement de Mélanie 1 | comment 1 | process 1 | 2024-02-01T21:00:00 | 2026-01-01T23:00:00 | Jérôme CAGNONCLE 1 | 2024-05-01T10:50:02 |
                | 3  | Expirée   | x      | Transport autre 2 | est parmi 2  | 03         | Alain&Nicole 123 - Boutique/Magasin 2 | 00000123452 | Reseau 2 | 000E0123456789123 | GC_RC_MS_2 | collaborator 2 | manager 2      | 000E0123452  | 1A2312        | 0123452 | 0123457812 | 12345ABCDE2 | égal à 3 | contractCategory 2 | high 2       | Remplacement de Mélanie 2 | comment 2 | process 1 | 2024-03-01T20:00:00 | 2027-01-01T23:00:00 | Jérôme CAGNONCLE 2 | 2024-06-01T10:45:02 |
            When Je suis sur la page d'Accueil

        Scenario: Filtre du tableau croisant
            When Je sélectionne le triangle pointant vers le haut de la colonne region
            Then La première region est x
            And La deuxieme region est y
            And La derniere region est z

        Scenario: Reinitialisation des filtres
            When Je sélectionne le triangle pointant vers le haut de la colonne region
            And Je sélectionne le triangle pointant vers le haut de la colonne region
            Then La première region est z
            And La deuxieme region est y
            And La derniere region est x

    Rule: Boutton d'actions
        Background: Je me rends sur la page d'accueil
            Given Je recois cette liste de règles
                | id | status    | region | branche           | segmentation | department | intermediate                          | walletCode  | network  | contractNumber    | team       | collaborator   | accountManager | clientNumber | uvProductCode | clause  | syndicCode | nafCode     | copth    | contractCategory   | priorisation | ruleName                  | comment   | process   | startDate           | endtDate            | userMaj            | updateDate          |
                | 1  | Active    | z      | Transport autre   | est parmi    | 01         | Alain&Nicole 123 - Boutique/Magasin   | 0000012345  | Reseau   | 000E012345678912  | GC_RC_MS   | collaborator   | manager        | 000E012345   | 1A234         | 012345  | 012345789  | 12345ABCDE  | égal à 1 | contractCategory   | high         | Remplacement de Mélanie   | comment   | process   | 2024-01-01T23:00:00 | 2025-01-01T23:00:00 | Jérôme CAGNONCLE   | 2024-04-01T10:55:02 |
                | 2  | Brouillon | y      | Transport autre 1 | est parmi 1  | 02         | Alain&Nicole 123 - Boutique/Magasin 1 | 00000123451 | Reseau 1 | 000E0123456789121 | GC_RC_MS_1 | collaborator 1 | manager 1      | 000E0123451  | 1A2311        | 0123451 | 0123457819 | 12345ABCDE1 | égal à 2 | contractCategory 1 | high 1       | Remplacement de Mélanie 1 | comment 1 | process 1 | 2024-02-01T21:00:00 | 2026-01-01T23:00:00 | Jérôme CAGNONCLE 1 | 2024-05-01T10:50:02 |
                | 3  | Expirée   | x      | Transport autre 2 | est parmi 2  | 03         | Alain&Nicole 123 - Boutique/Magasin 2 | 00000123452 | Reseau 2 | 000E0123456789123 | GC_RC_MS_2 | collaborator 2 | manager 2      | 000E0123452  | 1A2312        | 0123452 | 0123457812 | 12345ABCDE2 | égal à 3 | contractCategory 2 | high 2       | Remplacement de Mélanie 2 | comment 2 | process 1 | 2024-03-01T20:00:00 | 2027-01-01T23:00:00 | Jérôme CAGNONCLE 2 | 2024-06-01T10:45:02 |
            When Je suis sur la page d'Accueil
            Then Le bouton "Exporter" est désactivé
            And Le bouton "Modifier" est désactivé

        Scenario: Une règle est sélectionnée
            When Je clique sur la case à cocher de la première règle
            Then Il est possible de cliquer sur le bouton "Exporter"
            And Il est possible de cliquer sur le bouton "Modifier"

        Scenario: Toutes les règles ont été désélectionnées
            When Je clique sur la case à cocher de la première règle
            When Je clique sur la case à cocher de la première règle
            Given Le bouton "Exporter" est désactivé
            And Le bouton "Modifier" est désactivé

    Rule: Consultation unitaire
        Scenario Outline: Cliquer sur la cellule "<field>" redirige vers la consultation de la regle avec pour identifiant "<id>"
            Given Je recois cette liste de règles
                | id | status    | region   | branche           | segmentation | department | intermediate                          | walletCode  | network  | contractNumber    | team       | collaborator   | accountManager | clientNumber | uvProductCode | clause  | syndicCode | nafCode     | copth    | contractCategory   | priorisation | ruleName                  | comment   | process   | startDate           | endtDate            | userMaj            | updateDate          |
                | 1  | Active    | region 1 | Transport autre   | est parmi    | 01         | Alain&Nicole 123 - Boutique/Magasin   | 0000012345  | Reseau   | 000E012345678912  | GC_RC_MS   | collaborator   | manager        | 000E012345   | 1A234         | 012345  | 012345789  | 12345ABCDE  | égal à 1 | contractCategory   | high         | Remplacement de Mélanie   | comment   | process   | 2024-01-01T23:00:00 | 2025-01-01T23:00:00 | Jérôme CAGNONCLE   | 2024-04-01T10:55:02 |
                | 2  | Brouillon | region 2 | Transport autre 1 | est parmi 1  | 02         | Alain&Nicole 123 - Boutique/Magasin 1 | 00000123451 | Reseau 1 | 000E0123456789121 | GC_RC_MS_1 | collaborator 1 | manager 1      | 000E0123451  | 1A2311        | 0123451 | 0123457819 | 12345ABCDE1 | égal à 2 | contractCategory 1 | high 1       | Remplacement de Mélanie 1 | comment 1 | process 1 | 2024-02-01T21:00:00 | 2026-01-01T23:00:00 | Jérôme CAGNONCLE 1 | 2024-05-01T10:50:02 |
                | 3  | Expirée   | region 3 | Transport autre 2 | est parmi 2  | 03         | Alain&Nicole 123 - Boutique/Magasin 2 | 00000123452 | Reseau 2 | 000E0123456789123 | GC_RC_MS_2 | collaborator 2 | manager 2      | 000E0123452  | 1A2312        | 0123452 | 0123457812 | 12345ABCDE2 | égal à 3 | contractCategory 2 | high 2       | Remplacement de Mélanie 2 | comment 2 | process 1 | 2024-03-01T20:00:00 | 2027-01-01T23:00:00 | Jérôme CAGNONCLE 2 | 2024-06-01T10:45:02 |
            When Je suis sur la page d'Accueil
            And Je click sur la cellule <field>
            Then Je suis redirigé sur la page de consultation à l'identifie <id>

            Examples:
                | field                                 | id |
                | Active                                | 1  |
                | Transport autre 2                     | 2  |
                | Alain&Nicole 123 - Boutique/Magasin 2 | 3  |
                | est parmi                             | 1  |
                | Reseau 1                              | 2  |

    Rule: Trie du nombre des règles affichées dans le tableau
        Scenario: 25 règles sont visibles par défaut
            Given Je suis sur la page d'Accueil
            Then Je dois avoir 25 résultats par défaut affichés dans le tableau des résultats

        Scenario: Le nombre d'element à afficher peut varier entre 50, 100, 150 et 200
            Given Je suis sur la page d'Accueil
            Then Je peux choisir d'afficher mes règles par 50 / 75 / 100 / 150 / 200 résultats maximum par page

    Rule: Modifier le nombre de règles à afficher
        Scenario Outline: <maxCount> règles sont visibles lorsque <maxCount> sont sélectionnées

            Given Je suis sur la page d'Accueil
            When Je sélection <maxCount> comme nombre de règles à afficher
            Then J'ai <maxCount> règles affichées

            Examples:
                | maxCount |
                | 25       |
                | 50       |
                | 100      |

    Rule: Pagination
        Scenario: Pour 25 résultats trouvés 1 seule page est visible
            Given Je reçois 25 règles
            When Je suis sur la page d'Accueil
            Then Je dois voir 1 page dans la pagination

        Scenario Outline: Pour un maximum de 25 règles par page j'obtiens <nbrePage> pages pour <maxCount>
            Given Je reçois <maxCount> règles
            When Je suis sur la page d'Accueil
            Then Je dois voir <nbrePage> pages dans la pagination
            And Le wording "Suivant »" est visible
            And Le wording "« Précédent" est invisible

            Examples:
                | maxCount | nbrePage |
                | 50       | 2        |
                | 100      | 4        |

        Scenario Outline: Pour un maximum de 25 règles par page et la page 2 sélectionnées j'obtiens <nbrePage> pages pour <maxCount>
            Given Je reçois <maxCount> règles
            When Je suis sur la page d'Accueil
            And Je selectionne la page 2
            Then Je dois voir <nbrePage> pages dans la pagination
            And Le wording "« Précédent" est visible

            Examples:
                | maxCount | nbrePage |
                | 50       | 2        |
                | 100      | 4        |


        Scenario Outline: Pour un maximum de 25 règles par page et la deniere page sélectionnées j'obtiens <nbrePage> pages pour <maxCount>
            Given Je reçois <maxCount> règles
            When Je suis sur la page d'Accueil
            And Je selectionne la page <nbrePage>
            Then Je dois voir <nbrePage> pages dans la pagination
            And Le wording "Suivant »" est invisible
            And Le wording "« Précédent" est visible

            Examples:
                | maxCount | nbrePage |
                | 50       | 2        |
                | 100      | 4        |

        Scenario: Changement du nombre maximum d'élément à affiché par page
            Given Je reçois 50 règles
            When Je suis sur la page d'Accueil
            And Je sélection 50 comme nombre de règles à afficher
            Then Je dois voir 1 page dans la pagination










