import { Team } from '@affectations/api/bff-clients.generated';

import { getRegionValueByCode } from '../utils';

const teamMock: Team[] = [
  {
    code: 'ES_AUTO_NE',
    name: 'ES_AUTO_NE',
    regionCode: '65',
  },
  {
    code: 'ES_AUTO_OUEST',
    name: 'ES_AUTO_OUEST',
    regionCode: '66',
  },
  {
    code: 'ES_AUTO_SE',
    name: 'ES_AUTO_SE',
    regionCode: '67',
  },
  {
    code: 'ES_AUTO_SO',
    name: 'ES_AUTO_SO',
    regionCode: '68',
  },
] as Team[];

describe('getRegionValueByCode', () => {
  it.each([
    ['ES_AUTO_NE', { affectationRegion: 'Nord Est', affectationCode: '65' }],
    ['ES_AUTO_OUEST', { affectationRegion: 'Ouest', affectationCode: '66' }],
    ['ES_AUTO_SE', { affectationRegion: 'Sud Est', affectationCode: '67' }],
    ['ES_AUTO_SO', { affectationRegion: 'Sud Ouest', affectationCode: '68' }],
  ])('Should return code region and label for input %s', (input, expectedOutput) => {
    expect(getRegionValueByCode(input, teamMock)).toEqual(expectedOutput);
  });
});
