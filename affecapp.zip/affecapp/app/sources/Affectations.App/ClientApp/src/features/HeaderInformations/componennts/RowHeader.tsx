import { Badge } from '@affectations/components';
import { BadgeStatusName } from '@affectations/components/ui/Badge/types';
import { rowHeaderType } from '@affectations/features/commonTypes';

const RowHeader = ({ title, createContent, updateContent, badgeStatus, status }: rowHeaderType) => {
  return (
    <section className="headerInformations-rules__header">
      <div className="headerInformations-rules__header-head">
        <h2>{title?.toUpperCase()}</h2>
        <div className="badge-content">
          <Badge classModifiers={badgeStatus} status={status ?? BadgeStatusName.Sucess} />
        </div>
      </div>
      <div className="headerInformations-rules__header-content">
        <span>{createContent}</span>
        {updateContent?.toString() !== null && <span>{updateContent}</span>}
      </div>
    </section>
  );
};

export { RowHeader };
