Feature: Authentication
    en tant qu'utilisateur, je veux pouvoir m'authentifier afin d'accéder à mon espace personnel sécurisé.

    Scenario: L'utilisateur n'est pas authentifié
        Given le serveur d'authentification retourne un status 401 pour la requête sur /bff/user
        When J'accede à la page d'accueil de l'application
        Then Je suis redirigé vers la page de connexion


    Scenario: L'utilisateur authentifie et sans role
        Given le serveur d'authentification retourne un message de succes avec les claims
            | type         | value    |
            | axa_uid_racf | S000000  |
            | name         | John Doe |
            | sid          | 1234     |
        When J'accede à la page d'accueil de l'application
        Then Je suis redirigé vers la page forbidden

    Scenario: L'utilisateur authentifie
        Given le serveur d'authentification retourne un message de succes avec les claims
            | type                                                         | value          |
            | axa_uid_racf                                                 | S000000        |
            | name                                                         | John Doe       |
            | sid                                                          | 1234           |
            | http://schemas.microsoft.com/ws/2008/06/identity/claims/role | IAM_KYR_USER   |
            | http://schemas.microsoft.com/ws/2008/06/identity/claims/role | IAM_KYR_UPDATE |
            | http://schemas.microsoft.com/ws/2008/06/identity/claims/role | IAM_KYR_DELETE |
            | http://schemas.microsoft.com/ws/2008/06/identity/claims/role | IAM_KYR_EXPORT |
        When J'accede à la page d'accueil de l'application
        Then Je ne suis pas redirigé

    Rule: Erreur 403 à la connexion Easy Affection
        Scenario: L'utilisateur n'est pas habilité
            Given le serveur d'authentification retourne un status 403 pour la requête sur /bff/user
            When J'accede à la page d'accueil de l'application
            Then Je vois le message "Erreur : La page n'a pas pu être chargée, car nous ne parvenons pas à vous authentifier."
            And Je vois le message "Merci de contacter le support IT pour demander une habilitation à l'outil EASY Affectation."
            And Le CTA "Recharger la page" est visible
