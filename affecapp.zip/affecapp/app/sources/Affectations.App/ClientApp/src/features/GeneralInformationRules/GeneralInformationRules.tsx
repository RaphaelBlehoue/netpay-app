import { DateInput, InputWithCounter } from '@affectations/components';

import '@axa-fr/react-toolkit-form-input-date/dist/af-date.css';
import './style.scss';

import { FC, useCallback, useEffect, useMemo } from 'react';
import { Control, Controller, UseFormTrigger, UseFormWatch, Validate } from 'react-hook-form';

import { IAffectationFormInputs } from '@affectations/types';

const SECTION_TITLE = 'Informations générales';
const FIELD_RULE_NAME = "Nom de la règle d'affectation";
const FIELD_RULE_START_DATE = 'Date de début';
const FIELD_RULE_END_DATE = 'Date de fin';
const DATE_NOW = new Date().toISOString().split('T')[0];

const REQUIRED_FIELD_MESSAGE = 'Ce champs est obligatoire';
const START_DATE_LESS_MESSAGE = "Veuillez saisir une date ultérieure à aujourd'hui";
const END_DATE_LESS_MESSAGE = 'Veuillez saisir une date ultérieure à la date de début';
type Props = {
  control: Control<IAffectationFormInputs>;
  watch: UseFormWatch<IAffectationFormInputs>;
  trigger: UseFormTrigger<IAffectationFormInputs>;
};

const isDateGreaterOrEqual = (date: Date, compareTo: string, errorMessage: string) => {
  const compareToDate = new Date(compareTo);
  return date.getTime() >= compareToDate.getTime() || errorMessage;
};

const GeneralInformationRules: FC<Props> = ({ control, watch, trigger }) => {
  const watchedStartDate = watch('startDate');

  const maxDateForEnd = useMemo(() => {
    if (watchedStartDate) {
      return watchedStartDate.toISOString().split('T')[0];
    }
    return DATE_NOW;
  }, [watchedStartDate]);

  const validateStartDate = useCallback((date: Date) => {
    const current = new Date(date);
    const currentDateNow = DATE_NOW ?? '';
    return isDateGreaterOrEqual(current, currentDateNow, START_DATE_LESS_MESSAGE);
  }, []);

  const validateEndDate = useCallback<Validate<Date | undefined, IAffectationFormInputs>>(
    date => {
      if (date && !watchedStartDate) {
        return END_DATE_LESS_MESSAGE;
      }
      if (!watchedStartDate || !date) {
        return undefined;
      }
      const current = new Date(date);
      const compareTo = watchedStartDate.toISOString().split('T')[0];
      return isDateGreaterOrEqual(current, compareTo ?? '', END_DATE_LESS_MESSAGE);
    },
    [watchedStartDate]
  );

  useEffect(() => {
    trigger('endDate');
  }, [trigger, watchedStartDate]);

  return (
    <div id="rule-info">
      <h2 className="af-title">{SECTION_TITLE}</h2>
      <InputWithCounter
        id="name-affectation"
        control={control as unknown as Control}
        label={FIELD_RULE_NAME}
        maxLength={50}
        name="name"
      />
      <Controller
        name="startDate"
        rules={{ required: REQUIRED_FIELD_MESSAGE, validate: validateStartDate }}
        control={control}
        render={({ field, fieldState }) => {
          const error = fieldState.error?.message;
          return (
            <DateInput
              {...field}
              crossOrigin=""
              id="start-date"
              label={FIELD_RULE_START_DATE}
              classModifier="required"
              min={DATE_NOW}
              helpMessage="jj/mm/aaaa"
              onChange={(date: { value: Date }) => field.onChange(date.value)}
              onClear={() => field.onChange(null)}
              message={error}
              forceDisplayMessage={true}
            />
          );
        }}
      />
      <Controller
        name="endDate"
        rules={{ required: false, validate: validateEndDate }}
        control={control}
        render={({ field, fieldState }) => (
          <DateInput
            {...field}
            crossOrigin=""
            label={FIELD_RULE_END_DATE}
            min={maxDateForEnd}
            helpMessage="jj/mm/aaaa"
            onChange={(date: { value: Date }) => field.onChange(date.value)}
            onClear={() => field.onChange(null)}
            message={fieldState.error?.message}
          />
        )}
      />
    </div>
  );
};

export default GeneralInformationRules;
