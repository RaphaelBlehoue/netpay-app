import { act, screen, waitFor, within } from '@testing-library/react';
import { UserEvent } from '@testing-library/user-event/dist/types/setup/setup';
import { defineFeature, DefineStepFunction, loadFeature } from 'jest-cucumber';
import { useForm } from 'react-hook-form';

import { IAffectationFormInputs } from '@affectations/types';
import { renderSetup } from '@affectations/test-utils';

import { AddTermsOfTheWizardRules } from '../AddTermsOfTheWizardRules';

const feature = loadFeature('../features/AddTermsOfTheWizardRules.feature');

const DS_CLASSNAME = 'af-btn--disabled';

const expectedCountLineIncludeTrHead = (expected: number): number => 1 + Number(expected);

const FormSectionTermsOfTheRules = ({ max, ...props }: { max: number }) => {
  const { reset, watch, control } = useForm<IAffectationFormInputs>({ mode: 'all' });
  return <AddTermsOfTheWizardRules control={control} watch={watch} reset={reset} maxline={max} {...props} />;
};

defineFeature(feature, test => {
  let userSetup: UserEvent;
  let tableComponent: HTMLElement;
  let button: HTMLElement;
  const seeTheTableComponentDisplay = (given: DefineStepFunction, numberMaxLine: number) => {
    given(/^je vois le composant table afficher$/, async () => {
      const { user } = renderSetup(<FormSectionTermsOfTheRules max={numberMaxLine} />);
      userSetup = user;
    });
  };

  const shouldSeeDefaultLineInTab = (and: DefineStepFunction, TrElement: HTMLElement[] | undefined) => {
    and(/^je dois voir "(.*)" lignes par default afficher dans le Tableau$/, async countLine => {
      tableComponent = await screen.findByRole('table');
      await waitFor(async () => {
        TrElement = await within(tableComponent).findAllByRole('rowgroup');
      });
      expect(TrElement).toHaveLength(2);
      await waitFor(async () => {
        const rowsTr: HTMLElement[] = await within(tableComponent).findAllByRole('row');
        expect(rowsTr).toHaveLength(expectedCountLineIncludeTrHead(countLine));
      });
    });
  };

  const givenNewLineInTab = (and: DefineStepFunction) => {
    and(/^j'ajoute (\d+) ligne à mon formulaire Tableau$/, async _countLine => {
      button = screen.getByRole('button', { name: /Ajouter un critère/i });
      await userSetup.click(button);
      await userSetup.click(button);
    });
  };

  const shouldSeeNewLineInTab = (then: DefineStepFunction) => {
    then(/^Je devrais voir "(.*)" lignes afficher dans le formulaire$/, async countLine => {
      await waitFor(async () => {
        const rows: HTMLElement[] = await within(tableComponent).findAllByRole('row');
        expect(rows).toHaveLength(expectedCountLineIncludeTrHead(countLine));
      });
    });
  };

  const shouldHaveCriteriaButton = (and: DefineStepFunction) => {
    and(/^le button avec le titre Ajouter un critère$/, async () => {
      button = screen.getByRole('button', { name: /Ajouter un critère/i });
      expect(button).toBeInTheDocument();
    });
  };

  const whenClickAddCriteria = (when: DefineStepFunction) => {
    when(/^Je clique sur le button Ajouter critère$/, async () => {
      await userSetup.click(button);
    });
  };

  const whenCanSeeTableAndContent = (when: DefineStepFunction) => {
    when('les lignes par defaut du formulaire son afficher', () => {
      tableComponent = screen.getByRole('table');
      expect(tableComponent).toBeInTheDocument();
    });
  };

  const maxQuotaIsNotAchieved = (and: DefineStepFunction, TrElement: HTMLElement[] | undefined) => {
    and(/^le quota maximun de "(.*)" lignes n'est pas atteint$/, async maxline => {
      waitFor(() => {
        TrElement = within(tableComponent).getAllByRole('rowgroup');
        expect(TrElement).not.toHaveLength(maxline);
      });
    });
  };

  const shouldSeeButtonIconRemove = (and: DefineStepFunction) => {
    and(/^Je devrais voir le button icon remove "(.*)"$/, async buttonName => {
      waitFor(async () => {
        const buttonIcon = await screen.findByRole('button', { name: buttonName });
        expect(buttonIcon).toBeInTheDocument();
      });
    });
  };

  test('Affichage du formulaire de modalités de la règle', ({ given, when, then }) => {
    let headElement: HTMLElement;
    seeTheTableComponentDisplay(given, 16);
    when('je dois voir le titre du formulaire afficher', async () => {
      headElement = screen.getByRole('heading', { name: /Modalités de la règle/i });
      await act(async () => {
        expect(headElement).toBeInTheDocument();
      });
    });

    then(/^je dois voir le texte du titre "(.*)"$/, async headTitle => {
      await waitFor(() => {
        expect(headElement).toHaveTextContent(headTitle);
      });
    });
  });

  test('Verification de la présence des trois lignes par defaut', ({ given, when, then }) => {
    let trBodyNodeElement: HTMLElement[] | undefined;
    seeTheTableComponentDisplay(given, 16);
    whenCanSeeTableAndContent(when);
    shouldSeeDefaultLineInTab(then, trBodyNodeElement);
  });

  test('Le button "Ajouter un critère" est présent sur la page', ({ given, when, then }) => {
    seeTheTableComponentDisplay(given, 16);
    whenCanSeeTableAndContent(when);
    then(/^je dois le button avec le titre Ajouter un critère et une icon$/, async () => {
      await waitFor(() => {
        expect(screen.getByRole('button', { name: /Ajouter un critère/i })).toBeInTheDocument();
      });
    });
  });

  test('Le button "Ajouter un critère" ne doit pas être désactivé', ({ given, when, and, then }) => {
    let trBodyNodeElement: HTMLElement[] | undefined;
    seeTheTableComponentDisplay(given, 16);
    shouldHaveCriteriaButton(and);
    maxQuotaIsNotAchieved(when, trBodyNodeElement);
    then(/^le button Ajouter critère ne devrai pas être desactivé$/, () => {
      expect(button).not.toBeDisabled();
    });
  });

  test('Le formulaire des modalites de la règle doit avoir 4 lignes afficher après un premier ajout', ({
    given,
    and,
    when,
    then,
  }) => {
    let trBodyNodeElement: HTMLElement[] | undefined;
    seeTheTableComponentDisplay(given, 16);
    shouldSeeDefaultLineInTab(and, trBodyNodeElement);
    shouldHaveCriteriaButton(and);
    whenClickAddCriteria(when);
    shouldSeeNewLineInTab(then);
  });

  test('Le button "Ajouter un critère" doit est désactivé', ({ given, and, when, then }) => {
    let trBodyNodeElement: HTMLElement[] | undefined;
    seeTheTableComponentDisplay(given, 4);
    shouldSeeDefaultLineInTab(and, trBodyNodeElement);
    shouldHaveCriteriaButton(and);
    maxQuotaIsNotAchieved(and, trBodyNodeElement);
    whenClickAddCriteria(when);
    then(/^Je devrais voir "(.*)" lignes afficher dans le formulaire$/, async countLine => {
      const rows: HTMLElement[] = within(tableComponent).getAllByRole('row');
      await waitFor(() => {
        expect(rows).toHaveLength(expectedCountLineIncludeTrHead(countLine));
      });
    });

    and(/^le button avec le titre Ajouter un critère doit être desactivé$/, async () => {
      await waitFor(() => {
        expect(button).toBeDisabled();
        expect(button).toHaveClass(DS_CLASSNAME);
      });
    });
  });

  test('Le button "icon remove" est présent sur la ligne ajoutée', ({ given, and, when, then }) => {
    let trBodyNodeElement: HTMLElement[] | undefined;
    seeTheTableComponentDisplay(given, 16);
    shouldSeeDefaultLineInTab(and, trBodyNodeElement);
    shouldHaveCriteriaButton(and);
    whenClickAddCriteria(when);
    shouldSeeNewLineInTab(then);
    shouldSeeButtonIconRemove(and);
  });

  test('Le formulaire possede 5 lignes, après suppression nous devrions avoir 4 lignes', ({
    given,
    and,
    when,
    then,
  }) => {
    let buttonIcon: HTMLElement;
    let trBodyNodeElement: HTMLElement[] | undefined;
    seeTheTableComponentDisplay(given, 16);
    shouldSeeDefaultLineInTab(and, trBodyNodeElement);
    shouldHaveCriteriaButton(and);
    givenNewLineInTab(and);
    shouldSeeNewLineInTab(and);
    and(/^Je devrais voir "(.*)" button icons remove afficher$/, async buttonIconCount => {
      await waitFor(() => {
        const buttons = screen.getAllByRole('button', { name: /remove rule/i });
        expect(buttons).toHaveLength(buttonIconCount);
      });
    });

    when(/^Je clique sur le button icon remove "(.*)"$/, async _buttonName => {
      buttonIcon = await waitFor(() => screen.getByRole('button', { name: /remove rule3/i }));
      await userSetup.click(buttonIcon);
    });
    shouldSeeNewLineInTab(then);
  });

  test('Le formulaire possede 5 lignes, après suppression total nous devrions les 3 lignes par defaut', ({
    given,
    and,
    when,
    then,
  }) => {
    let buttonRemoveAll: HTMLElement;
    let trBodyNodeElement: HTMLElement[] | undefined;
    seeTheTableComponentDisplay(given, 16);
    shouldSeeDefaultLineInTab(and, trBodyNodeElement);
    shouldHaveCriteriaButton(and);
    givenNewLineInTab(and);
    shouldSeeNewLineInTab(and);
    and(/^Je devrais voir "(.*)" button icons remove afficher$/, async buttonIconCount => {
      await waitFor(() => {
        const buttons = screen.getAllByRole('button', { name: /remove rule/i });
        expect(buttons).toHaveLength(buttonIconCount);
      });
    });

    when(/^Je clique sur le button icon remove "(.*)"$/, async _buttonName => {
      buttonRemoveAll = await waitFor(() => screen.getByRole('button', { name: /Réinitialiser les critères/i }));
      await userSetup.click(buttonRemoveAll);
    });

    shouldSeeNewLineInTab(then);
  });
});
