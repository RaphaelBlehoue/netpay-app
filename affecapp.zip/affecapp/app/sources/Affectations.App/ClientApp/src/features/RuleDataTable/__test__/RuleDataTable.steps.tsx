import { act, render, screen, waitFor, within } from '@testing-library/react';
import userEvent, { type UserEvent } from '@testing-library/user-event';
import { defineFeature, DefineStepFunction, loadFeature } from 'jest-cucumber';
import { http, HttpResponse } from 'msw';
import { createMemoryRouter } from 'react-router-dom';

import { getStatusConsultation, TStatus } from '@affectations/pages/Consultation/utils';
import hundred from '@affectations/__apiMocks__/seeds/rules/mocks/get-hundred-rules.json';
import { searchRule as searchRuleMock } from '@affectations/__apiMocks__/seeds/rules/rules.mocks';
import {
  AffectationDto,
  ConditionsDto,
  CriteresDto,
  RuleDetailsDto,
  RuleDto,
} from '@affectations/api/bff-clients.generated';
import { AppContextProvider } from '@affectations/contexts/AppContextProvider';
import { server } from '@affectations/mocks/server';
import { getUrl } from '@affectations/mocks/url';
import { Router } from '@affectations/Router';
import { configRoutes } from '@affectations/routes';

import { Rule } from '../type';

const feature = loadFeature('../features/RuleDataTable.feature');

let user: UserEvent;

const mockRequest = (body: object | undefined) => {
  const url = getUrl('rules/search');
  server.use(
    http.post(url, () => {
      return HttpResponse.json(body);
    })
  );
};

const getTableRows = async () => {
  const table = await screen.findByRole('table');
  return within(table).getAllByRole('row');
};

const whenClickCellsToRedirect = async (and: DefineStepFunction) => {
  and(/^Je click sur la cellule (.*)$/, async (name: string) => {
    const table = await waitFor(() => screen.getByRole('table'));
    if (name === 'Active') {
      const cell = document.querySelector('span.af-badge.af-badge--success');
      if (cell) {
        await user.click(cell);
      }
    } else {
      const cell = await waitFor(() => within(table).getByText(name));
      await user.click(cell);
    }
  });
};

const assertRowContentText = async (index: number, value: string) => {
  const rows = await getTableRows();
  const row = rows[index];
  expect(row).toHaveTextContent(value);
};

const givenIReceiveThisData = (given: DefineStepFunction, context: { rules: Rule[] } = { rules: [] }) => {
  given('Je recois cette liste de règles', (data: Rule[]) => {
    context.rules = data;
    const rules = data.map<RuleDto>(x => {
      const tempStartDate = x.startDate ? new Date(x.startDate) : undefined;
      const tempEndDate = x.endtDate ? new Date(x.endtDate) : undefined;
      const currentStatus: TStatus = getStatusConsultation(tempStartDate, tempEndDate, x?.status);
      return new RuleDto({
        id: parseInt(x.id),
        ruleDetailsDto: new RuleDetailsDto({
          statut: currentStatus.statusLabel,
          ruleName: x.ruleName,
          comment: x.comment,
          startDate: x.startDate ? new Date(x.startDate) : undefined,
          endDate: x.endtDate ? new Date(x.endtDate) : undefined,
          updateDate: x.updateDate ? new Date(x.updateDate) : undefined,
          updatedBy: x.userMaj,
          priority: x.priorisation,
        }),
        affectationDto: new AffectationDto({
          affectedRegion: x.region,
          affectedTeam: x.team,
          affectedEmployee: x.collaborator,
        }),
        critereDto: new CriteresDto({
          branch: x.branche,
          segmentation: x.segmentation,
          distributorDepartment: x.department,
          intermediateName: x.intermediate,
          portfolioCode: x.walletCode,
          network: x.network,
          contractNumber: x.contractNumber,
          accountManager: x.accountManager,
          clientNumber: x.clientNumber,
          uvCode: x.uvProductCode,
          syndicCode: x.syndicCode,
          nafCode: x.nafCode,
          copht: x.copth,
          contractCategory: x.contractCategory,
        }),
        conditionsDto: new ConditionsDto({
          clauseCondition: x.clause,
        }),
      });
    });
    mockRequest({ data: rules, totalRules: data.length });
  });
};

const givenIReceiveRules = (given: DefineStepFunction) =>
  given(/Je reçois (.*) règles?$/i, (nbrRule: string) => {
    const rules = hundred.slice(0, Number(nbrRule));
    server.resetHandlers();
    server.use(searchRuleMock(rules));
  });

const thenICanSeePageInPagination = (given: DefineStepFunction) =>
  given(/Je dois voir (.*) pages? dans la pagination$/i, async (maxPage: string) => {
    const pageList = await screen.findByRole('navigation', {
      name: 'pagination',
    });
    const list = within(pageList).getByRole('list');
    const items = within(list).getAllByRole('listitem');
    const lastPage = items[items.length - 2];
    expect(lastPage).toHaveTextContent(maxPage);
  });

const whenISelectOnePageSize = (when: DefineStepFunction) =>
  when(/Je sélection (.*) comme nombre de règles à afficher$/i, async (pageSize: string) => {
    const select = await waitFor(() =>
      screen.getByRole('combobox', {
        name: 'Afficher',
      })
    );
    await user.selectOptions(select, pageSize);
    expect(select).toHaveValue(pageSize);
    const pageList = await waitFor(() =>
      screen.getByRole('navigation', {
        name: 'pagination',
      })
    );
    const list = within(pageList).getByRole('list');
    const activePage = within(list)
      .getAllByRole('listitem')
      .find(x => x.classList.contains('af-pager__item--active'))!;
    expect(activePage).toHaveTextContent('1');
  });

const thenISeeThisNumberOfRules = (then: DefineStepFunction) =>
  then(/J'ai (.*) règles? affichées?$/i, (ruleCount: string) => {
    const count = Number(ruleCount);
    const table = screen.getByRole('table');
    const trs = within(table).getAllByRole('row');
    expect(trs.length).toBe(count + 1);
  });

const thenICanClickPaginationWording = (then: DefineStepFunction) =>
  then(/Le wording "(.*)" est visible$/i, (name: string) => {
    const pageList = screen.getByRole('navigation', {
      name: 'pagination',
    });
    const list = within(pageList).getByRole('list');
    let wording = within(list).queryByRole('button', { name });
    if (!wording) {
      wording = within(list).queryByRole('link', { name });
    }
    expect(wording).toBeInTheDocument();
  });

const thenICantClickPaginationWording = (then: DefineStepFunction) =>
  then(/Le wording "(.*)" est invisible$/i, (name: string) => {
    const pageList = screen.getByRole('navigation', {
      name: 'pagination',
    });
    const list = within(pageList).getByRole('list');
    const regex = new RegExp(`${name}`, 'i');
    const wording = within(list).getByText(regex);
    expect(wording.tagName).toBe('SPAN');
  });

const andISelectThePage = (and: DefineStepFunction) =>
  and(/^Je selectionne la page (\d+)$/i, async (name: string) => {
    const pageList = await waitFor(() =>
      screen.getByRole('navigation', {
        name: 'pagination',
      })
    );
    const list = within(pageList).getByRole('list');
    const wording = within(list).getByRole('link', { name });
    await user.click(wording);
  });

const thenTitleIsVisible = (then: DefineStepFunction) =>
  then(/Le titre "(.*)" est visible/i, async (msg: string) => {
    const title = await waitFor(() => screen.getByRole('heading', { level: 2, name: msg }));
    expect(title).toBeInTheDocument();
  });

const renderHomePage = async () =>
  await waitFor(() =>
    render(<Router router={createMemoryRouter(configRoutes, { initialEntries: ['/'] })} />, {
      wrapper: AppContextProvider,
    })
  );

const whenIAmOnTheHomePage = (when: DefineStepFunction) =>
  when("Je suis sur la page d'Accueil", async () => {
    await renderHomePage();
  });

const whenIClickOnSortButton = (when: DefineStepFunction) =>
  when('Je sélectionne le triangle pointant vers le haut de la colonne region', async () => {
    const regionHead = await waitFor(() => screen.getByRole('columnheader', { name: "Région d'affectation" }));
    const sortButton = within(regionHead).getByRole('button');
    await act(() => user.click(sortButton));
  });

const thenAllRulesAreDisplayed = (then: DefineStepFunction, context: { rules: Rule[] }) =>
  then("Toutes les règles s'affichent", async () => {
    const table = await waitFor(() => within(screen.getByRole('table')));
    context.rules.forEach(x => {
      expect(table.getByText(x.id)).toBeInTheDocument();
      expect(
        table.getAllByText(getStatusConsultation(new Date(x.startDate), new Date(x.endtDate), x?.status).statusLabel)
      ).toHaveLength(3);
      expect(table.getByText(x.region)).toBeInTheDocument();
      expect(table.getByText(x.branche)).toBeInTheDocument();
      expect(table.getByText(x.segmentation)).toBeInTheDocument();
      expect(table.getByText(x.department)).toBeInTheDocument();
      expect(table.getByText(x.intermediate)).toBeInTheDocument();
      expect(table.getByText(x.walletCode)).toBeInTheDocument();
      expect(table.getByText(x.network)).toBeInTheDocument();
      expect(table.getByText(x.contractNumber)).toBeInTheDocument();
      expect(table.getByText(x.team)).toBeInTheDocument();
      expect(table.getByText(x.collaborator)).toBeInTheDocument();
      expect(table.getByText(x.accountManager)).toBeInTheDocument();
      expect(table.getByText(x.clientNumber)).toBeInTheDocument();
      expect(table.getByText(x.uvProductCode)).toBeInTheDocument();
      expect(table.getByText(x.clause)).toBeInTheDocument();
      expect(table.getByText(x.syndicCode)).toBeInTheDocument();
      expect(table.getByText(x.nafCode)).toBeInTheDocument();
      expect(table.getByText(x.copth?.toString() ?? '')).toBeInTheDocument();
      expect(table.getByText(x.contractCategory)).toBeInTheDocument();
      expect(table.getByText(x.ruleName)).toBeInTheDocument();
      expect(table.getByText(x.comment)).toBeInTheDocument();
      expect(table.getByText(x.userMaj)).toBeInTheDocument();
      expect(table.getByText(x.priorisation)).toBeInTheDocument();
      const startDate = new Date(x.startDate);
      expect(table.getByText(startDate.toLocaleDateString('fr-FR'))).toBeInTheDocument();
      const endDate = new Date(x.endtDate);
      expect(table.getByText(endDate.toLocaleDateString('fr-FR'))).toBeInTheDocument();
      const updateDate = new Date(x.updateDate);
      expect(table.getByText(updateDate.toLocaleDateString('fr-FR'))).toBeInTheDocument();
    });
  });

const whenIClickOnFirstRuleCheckbox = (when: DefineStepFunction) =>
  when('Je clique sur la case à cocher de la première règle', async () => {
    const rows = await getTableRows();
    const firstRule = within(rows[1]!);
    const checkbox = firstRule.getByRole('checkbox');
    await user.click(checkbox);
  });

const thenTheFirstRegionIs = (then: DefineStepFunction) =>
  then(/La première region est (.*)/i, async region => {
    assertRowContentText(1, region);
  });

const thenTheSecondRegionIs = (then: DefineStepFunction) =>
  then(/La deuxieme region est (.*)/i, region => {
    assertRowContentText(2, region);
  });

const thenTheThirdRegionIs = (then: DefineStepFunction) =>
  then(/La derniere region est (.*)/i, region => {
    assertRowContentText(3, region);
  });

const thenButtonIsDisable = (then: DefineStepFunction) =>
  then(/Le bouton "(.*)" est désactivé/i, (name: string) => {
    const button = screen.getByRole('button', { name });
    expect(button).toBeInTheDocument();
    expect(button).toHaveAttribute('disabled');
    expect(button).toHaveAttribute('aria-disabled', 'true');
  });

const thenButtonAreEnable = (then: DefineStepFunction) =>
  then(/Il est possible de cliquer sur le bouton "(.*)"/i, (name: string) => {
    const button = screen.getByRole('button', { name });
    expect(button).toBeInTheDocument();
    expect(button).not.toHaveAttribute('disabled');
    expect(button).toHaveAttribute('aria-disabled', 'false');
  });

defineFeature(feature, test => {
  beforeEach(() => {
    user = userEvent.setup();
    server.resetHandlers();
  });

  test('Je vois les differentes colonnes', ({ given, when, then }) => {
    givenIReceiveThisData(given);
    whenIAmOnTheHomePage(when);
    then('Les colonnes suivantes sont visibles', async (headers: { column: string }[]) => {
      const table = await waitFor(() => within(screen.getByRole('table')));
      const columns = headers.map(x => x.column);
      columns.forEach(name => {
        const header = table.getByRole('columnheader', { name });
        expect(header).toBeInTheDocument();
      });
    });
  });

  test('<ruleCount> règles sont retournées', ({ given, when, then }) => {
    givenIReceiveRules(given);
    whenIAmOnTheHomePage(when);
    thenTitleIsVisible(then);
  });

  test('Je recois des règles à afficher', ({ given, when, then }) => {
    const shareData = {
      rules: [],
    };
    givenIReceiveThisData(given, shareData);
    whenIAmOnTheHomePage(when);
    thenAllRulesAreDisplayed(then, shareData);
  });

  test('Je ne recois aucune règles à afficher', ({ given, when, then, and }) => {
    givenIReceiveThisData(given);
    whenIAmOnTheHomePage(when);
    thenTitleIsVisible(then);
    and("Le tableau n'est pas visible", () => {
      const table = screen.queryByRole('table');
      expect(table).not.toBeInTheDocument();
    });
  });

  test('Les valeurs multiples sont tronquées', ({ given, when, then }) => {
    givenIReceiveThisData(given);
    whenIAmOnTheHomePage(when);
    then('Les données suivantes sont visibles', async (data: Rule[]) => {
      const table = await waitFor(() => within(screen.getByRole('table')));
      data.forEach(x => {
        expect(table.getByText(x.id)).toBeInTheDocument();
        expect(
          table.getAllByText(getStatusConsultation(new Date(x.startDate), new Date(x.endtDate), 'Active').statusLabel)
        ).toHaveLength(2);
        expect(
          table.getAllByText(
            getStatusConsultation(new Date(x.startDate), new Date(x.endtDate), 'Brouillon').statusLabel
          )
        ).toHaveLength(1);
        expect(table.getByText(x.region)).toBeInTheDocument();
        expect(table.getByText(x.branche)).toBeInTheDocument();
        expect(table.getByText(x.segmentation)).toBeInTheDocument();
        expect(table.getByText(x.department)).toBeInTheDocument();
        expect(table.getByText(x.intermediate)).toBeInTheDocument();
        expect(table.getByText(x.walletCode)).toBeInTheDocument();
        expect(table.getByText(x.network)).toBeInTheDocument();
        expect(table.getByText(x.contractNumber)).toBeInTheDocument();
        expect(table.getByText(x.team)).toBeInTheDocument();
        expect(table.getByText(x.collaborator)).toBeInTheDocument();
        expect(table.getByText(x.accountManager)).toBeInTheDocument();
        expect(table.getByText(x.clientNumber)).toBeInTheDocument();
        expect(table.getByText(x.uvProductCode)).toBeInTheDocument();
        expect(table.getByText(x.clause)).toBeInTheDocument();
        expect(table.getByText(x.syndicCode)).toBeInTheDocument();
        expect(table.getByText(x.nafCode)).toBeInTheDocument();
        expect(table.getByText(x.copth?.toString() ?? '')).toBeInTheDocument();
        expect(table.getByText(x.contractCategory)).toBeInTheDocument();
        expect(table.getByText(x.ruleName)).toBeInTheDocument();
        expect(table.getByText(x.comment)).toBeInTheDocument();
        expect(table.getByText(x.userMaj)).toBeInTheDocument();
        expect(table.getByText(x.priorisation)).toBeInTheDocument();
        const startDate = new Date(x.startDate);
        expect(table.getByText(startDate.toLocaleDateString('fr-FR'))).toBeInTheDocument();
        const endDate = new Date(x.endtDate);
        expect(table.getByText(endDate.toLocaleDateString('fr-FR'))).toBeInTheDocument();
        const updateDate = new Date(x.updateDate);
        expect(table.getByText(updateDate.toLocaleDateString('fr-FR'))).toBeInTheDocument();
      });
    });
  });

  test('Filtre du tableau croisant', ({ given, when, then, and }) => {
    givenIReceiveThisData(given);
    whenIAmOnTheHomePage(when);
    whenIClickOnSortButton(when);
    thenTheFirstRegionIs(then);
    thenTheSecondRegionIs(and);
    thenTheThirdRegionIs(and);
  });

  test('Reinitialisation des filtres', ({ given, when, then, and }) => {
    givenIReceiveThisData(given);
    whenIAmOnTheHomePage(when);
    whenIClickOnSortButton(when);
    whenIClickOnSortButton(when);
    thenTheFirstRegionIs(then);
    thenTheSecondRegionIs(and);
    thenTheThirdRegionIs(and);
  });

  test('Une règle est sélectionnée', ({ given, when, then }) => {
    givenIReceiveThisData(given);

    whenIAmOnTheHomePage(when);

    thenButtonIsDisable(then);
    thenButtonIsDisable(then);

    whenIClickOnFirstRuleCheckbox(when);

    thenButtonAreEnable(then);
    thenButtonAreEnable(then);
  });

  test('Toutes les règles ont été désélectionnées', ({ given, when, then }) => {
    givenIReceiveThisData(given);

    whenIAmOnTheHomePage(when);

    thenButtonIsDisable(then);
    thenButtonIsDisable(then);

    whenIClickOnFirstRuleCheckbox(when);
    whenIClickOnFirstRuleCheckbox(when);

    thenButtonIsDisable(then);
    thenButtonIsDisable(then);
  });

  test('Cliquer sur la cellule "<field>" redirige vers la consultation de la regle avec pour identifiant "<id>"', ({
    given,
    when,
    then,
    and,
  }) => {
    givenIReceiveThisData(given);
    whenIAmOnTheHomePage(when);
    whenClickCellsToRedirect(and);

    then(/^Je suis redirigé sur la page de consultation à l'identifie (.*)$/, async () => {
      const head = await waitFor(() =>
        screen.getByRole('heading', {
          name: 'Consultation',
          level: 1,
        })
      );
      expect(head).toBeInTheDocument();
    });
  });

  test('25 règles sont visibles par défaut', ({ given, then }) => {
    whenIAmOnTheHomePage(given);
    then('Je dois avoir 25 résultats par défaut affichés dans le tableau des résultats', async () => {
      const table = await waitFor(() => screen.getByRole('table'));
      const trs = within(table).getAllByRole('row');
      expect(trs).toHaveLength(26);
    });
  });

  test("Le nombre d'element à afficher peut varier entre 50, 100, 150 et 200", ({ given, then }) => {
    whenIAmOnTheHomePage(given);
    then("Je peux choisir d'afficher mes règles par 50 / 75 / 100 / 150 / 200 résultats maximum par page", async () => {
      const select = await screen.findByRole('combobox', {
        name: 'Afficher',
      });
      expect(select).toHaveValue('25');
      const options = [25, 50, 100, 150, 200];
      options.forEach(opt => {
        const selector = within(select).getByRole('option', { name: opt.toString() });
        expect(selector).toBeInTheDocument();
      });
    });
  });

  test('<maxCount> règles sont visibles lorsque <maxCount> sont sélectionnées', ({ given, when, then }) => {
    whenIAmOnTheHomePage(given);
    whenISelectOnePageSize(when);
    thenISeeThisNumberOfRules(then);
  });

  test('Pour 25 résultats trouvés 1 seule page est visible', ({ given, when, then }) => {
    givenIReceiveRules(given);
    whenIAmOnTheHomePage(when);
    thenICanSeePageInPagination(then);
  });

  test("Pour un maximum de 25 règles par page j'obtiens <nbrePage> pages pour <maxCount>", ({
    given,
    when,
    then,
    and,
  }) => {
    givenIReceiveRules(given);
    whenIAmOnTheHomePage(when);
    thenICanSeePageInPagination(then);
    thenICanClickPaginationWording(and);
    thenICantClickPaginationWording(and);
  });

  test(
    'Pour un maximum de 25 règles par' + " page et la page 2 sélectionnées j'obtiens <nbrePage> pages pour <maxCount>",
    ({ given, when, then, and }) => {
      givenIReceiveRules(given);
      whenIAmOnTheHomePage(when);
      andISelectThePage(and);
      thenICanSeePageInPagination(then);
      thenICanClickPaginationWording(and);
    }
  );

  test(
    'Pour un maximum de 25 règles par page et la deniere' +
      " page sélectionnées j'obtiens <nbrePage> pages pour <maxCount>",
    ({ given, when, then, and }) => {
      givenIReceiveRules(given);
      whenIAmOnTheHomePage(when);
      andISelectThePage(and);
      thenICanSeePageInPagination(then);
      thenICantClickPaginationWording(and);
      thenICanClickPaginationWording(and);
    }
  );

  test("Changement du nombre maximum d'élément à affiché par page", ({ given, when, then, and }) => {
    givenIReceiveRules(given);
    whenIAmOnTheHomePage(when);
    whenISelectOnePageSize(and);
    thenICanSeePageInPagination(then);
  });
});
