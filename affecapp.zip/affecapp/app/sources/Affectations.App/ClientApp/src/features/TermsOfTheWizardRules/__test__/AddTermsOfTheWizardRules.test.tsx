import { formatterModality } from '../utils';
import {
  expectResponseInput,
  expectResponseInputPartial,
  expectResponseOutput,
  expectResponseOutputPartial,
} from './data.mock';

describe('AddTermsOfTheWizardRules', () => {
  it('Formatter: Should return all rules consutltion with all data', () => {
    expect(formatterModality(expectResponseInput)).toHaveLength(16);
    expect(formatterModality(expectResponseInput)).toEqual(expectResponseOutput);
  });
  it('Formatter: Should return partial rules with partial data', () => {
    expect(formatterModality(expectResponseInputPartial)).toHaveLength(11);
    expect(formatterModality(expectResponseInputPartial)).toEqual(expectResponseOutputPartial);
  });
});
