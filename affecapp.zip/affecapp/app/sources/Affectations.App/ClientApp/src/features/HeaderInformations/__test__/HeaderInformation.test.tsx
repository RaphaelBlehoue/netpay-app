import { act, screen, waitFor } from '@testing-library/react';

import { handleExportOneRule } from '@affectations/pages/Consultation/utils';
import { renderSetup } from '@affectations/test-utils';

import { HeaderInformation, IHeaderInfoRulesMapping } from '../HeaderInformation';
import { mockConsultationHeader, TMockComponentProps } from './test-utils';

const EXPECTED_WORDING_MODAL = 'Êtes-vous sûr de vouloir exporter cette règle ?';

vi.mock('@affectations/pages/utils/handleExportOneRule', () => ({
  handleExportOneRule: vi.fn(),
}));

describe('HeaderInformation', () => {
  let props: TMockComponentProps;
  beforeEach(() => {
    props = {
      statusLabel: 'Active',
      startDate: '2024-01-01T23:00:00',
      endDate: '2024-01-31T23:00:00',
      hasUpdated: false,
      rule: { rulesId: 1 },
      mutationExportFn: vi.fn(),
    };
  });

  afterEach(() => {
    vi.clearAllMocks();
  });

  it('should open modal box when click export button', async () => {
    const currenDataMock: IHeaderInfoRulesMapping = mockConsultationHeader(props);
    const { user } = await waitFor(() => renderSetup(<HeaderInformation {...currenDataMock} />));
    const exportBtnOpenModal = screen.getByRole('dialog', { name: /Exporter règle/i });
    await act(() => user.click(exportBtnOpenModal));
    const findWording = await screen.findByText(EXPECTED_WORDING_MODAL);
    expect(findWording).toBeVisible();
  });

  it('should call handleExport when click export in modal', async () => {
    const currenDataMock: IHeaderInfoRulesMapping = mockConsultationHeader(props);
    const { user } = await waitFor(() =>
      renderSetup(<HeaderInformation handleRuleExport={handleExportOneRule} {...currenDataMock} />)
    );
    const exportBtn = screen.getByRole('dialog', { name: /Exporter règle/i });
    await act(() => user.click(exportBtn));
    const exportBtnInModal = screen.getByText(/confirmer/i);
    expect(exportBtnInModal).toBeVisible();
    act(() => user.click(exportBtnInModal));
    waitFor(() => expect(handleExportOneRule).toHaveBeenCalledTimes(1));
  });
});
