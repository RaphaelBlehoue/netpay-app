export const getFileNumberToExport = (count?: number) => `Être-vous sûr de vouloir exporter ${count ?? 0} ligne(s)`;
