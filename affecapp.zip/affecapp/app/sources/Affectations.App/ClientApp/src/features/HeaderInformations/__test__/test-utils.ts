import { BadgeClassModifiers } from '@affectations/components/ui/Badge/types';
import { DateFormats, formatDate } from '@affectations/utils';
import { IHeaderInfoRulesMapping } from '../HeaderInformation';
import { TRulesQueryParams } from '@affectations/api/rules/types';
import { UseMutateFunction } from '@tanstack/react-query';
import { FileResponse, FilterRuleDto } from '@affectations/api/bff-clients.generated';
import { TError } from '@affectations/api/types';



export type TMockComponentProps = {
  statusLabel: string;
  startDate: string;
  endDate?: string;
  hasUpdated: boolean;
  rule?: TRulesQueryParams;
  mutationExportFn?: UseMutateFunction<FileResponse, TError, FilterRuleDto>;
  handleRuleExport?: (
    ruleId: TRulesQueryParams,
    FnMutation: UseMutateFunction<FileResponse, TError, FilterRuleDto>
  ) => void;
};

export type TMockDisplayOptions = {
  hasUpdate: boolean;
  hasEndDate: boolean;
};

export const mockConsultationHeader = ({
  statusLabel,
  startDate,
  endDate,
  hasUpdated,
  ...props
}: TMockComponentProps): IHeaderInfoRulesMapping => {
  return {
    rowHeaderMapping: {
      title: 'REMPLACEMENT DE MÉLANIE',
      status: statusLabel,
      badgeStatus: BadgeClassModifiers.Danger,
      createContent: 'Crée par Olivier SAILLY, le 01/01/2023 à 09h05',
      ...(hasUpdated && { updateContent: 'Mise à jour par Jérôme CAGNONCLE, le 01/03/2023 à 10h55' }),
    },
    rowRulesMapping: [
      {
        label: 'Date de début',
        content: formatDate(new Date(startDate), DateFormats.DATE),
      },
      {
        label: 'Date de fin',
        content: endDate ? formatDate(new Date(endDate), DateFormats.DATE) : '',
      },
    ],
    isLoading: false,
    isSuccess: true,
    ...props
  };
};
