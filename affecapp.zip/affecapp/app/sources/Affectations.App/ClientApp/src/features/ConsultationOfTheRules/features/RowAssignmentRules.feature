Feature: Consultation regle - Affectation - IARDENT-54664

  Rule: Affichage des données de l'Affectation

    Scenario: Affichage des données provenant de l'api
      Given Je recupère les données d'une règle provenant de mon bff
      When je constate que je reçois une reponse de success du bff
      Then je dois voir afficher sur ma page les données suivantes
        | label                     | valeur                                      |
        | Affecter à l'équipe       | ES_AUTO_NE                                  |
        | Affecter au collaborateur | BONTEMS PATRICK (S123456)                   |
        | Région d'affectation      | NE                                          |
        | Commentaire               | 27/02/023 - Rajout par numcnt (ancienne QP) |
