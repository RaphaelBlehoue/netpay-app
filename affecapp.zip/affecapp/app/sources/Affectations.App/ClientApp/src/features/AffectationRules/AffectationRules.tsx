import {
  Control,
  FieldErrors,
  UseFormClearErrors,
  UseFormResetField,
  UseFormSetError,
  UseFormSetValue,
  UseFormWatch,
} from 'react-hook-form';

import { IAffectationFormInputs } from '@affectations/types';

import './AffectationRules.scss';

import React, { useCallback, useEffect, useMemo } from 'react';
import clsx from 'clsx';

import {
  AsyncAutoCompleteController,
  SelectController,
  TextareaInputController,
  TOption,
} from '@affectations/components';
import { affectationFormSchema } from '@affectations/pages/affectations/utils';
import { Team } from '@affectations/api/bff-clients.generated';

import { getRegionValueByCode, isNotInputValid, regionType } from './utils';

const SECTION_TITLE = 'Affectation';
const TEAM = "Affectation à l'équipe";
const COLLABORATEUR = 'Affectation au collaborateur';
const NETWORKS = "Région l'affection";
const COMMENT = 'Commentaire';
const MAX_SEARCH_COLLABORATORS_COUNT = 10;

type IAffectionRules = {
  control: Control<IAffectationFormInputs>;
  filterEmployeeAsync: (inputValue: string) => Promise<TOption[]>;
  teamsOptions?: TOption[];
  teams: Team[];
  watch: UseFormWatch<IAffectationFormInputs>;
  setValue?: UseFormSetValue<IAffectationFormInputs>;
  errors?: FieldErrors<IAffectationFormInputs>;
  setError?: UseFormSetError<IAffectationFormInputs>;
  clearErrors?: UseFormClearErrors<IAffectationFormInputs>;
  resetField?: UseFormResetField<IAffectationFormInputs>;
};
const AffectionRules = ({
  control,
  filterEmployeeAsync,
  teamsOptions,
  teams,
  watch,
  setValue,
  setError,
  clearErrors,
  resetField,
  errors,
}: IAffectionRules) => {
  const currentTeam = watch('teams');
  const handleEmployeeChange = useCallback(
    async (inputValue: string) => {
      if (isNotInputValid(inputValue)) {
        return [];
      }
      const data = await filterEmployeeAsync(inputValue);
      if (!data.length) {
        setError && setError('collaborater', { type: 'noMatch', message: 'Aucun resultat' });
        return [];
      } else {
        clearErrors && clearErrors(['collaborater']);
      }
      return data.slice(0, MAX_SEARCH_COLLABORATORS_COUNT);
    },
    [filterEmployeeAsync, setError, clearErrors]
  );

  const handlerOnKeyBoard = useCallback(
    (e: React.KeyboardEvent) => {
      e.stopPropagation();
      resetField && resetField('collaborater');
    },
    [resetField]
  );
  const region: string | regionType = useMemo(() => {
    if (!currentTeam) {
      return '';
    }
    return getRegionValueByCode(currentTeam, teams);
  }, [currentTeam, teams]) as regionType;
  useEffect(() => {
    setValue && setValue('regions', region.affectationCode);
  }, [region, setValue]);

  return (
    <>
      <h2 className="af-title">{SECTION_TITLE}</h2>
      <section className="affectation-rules" aria-label="affectation rules">
        <section className="affectation-rules__row">
          <div className="list-group">
            <span className="input-required">{TEAM}</span>
          </div>
          <div className="list-group">
            <SelectController
              name="teams"
              options={teamsOptions || []}
              rules={affectationFormSchema.TEAM}
              selectAdditionnalClassName="text"
              control={control as unknown as Control}
              id="teams"
              aria-label="teams-input"
            />
          </div>
        </section>
        <section className="affectation-rules__row">
          <div className="list-group">
            <span>{COLLABORATEUR}</span>
          </div>
          <div className="list-group">
            <AsyncAutoCompleteController
              control={control}
              name="collaborater"
              inputId="employee-field"
              classNamePrefix="employe-af__container"
              className={clsx('employe-af', { 'af-form__multi--error': !!errors?.collaborater?.message })}
              loadOptions={handleEmployeeChange}
              onkeydownHandler={handlerOnKeyBoard}
              noOptionsMessage={() => null}
              cacheOptions
              placeholder="Rechercher..."
              defaultOptions
              errors={errors?.collaborater?.message}
            />
          </div>
        </section>
        <section className="affectation-rules__row">
          <div className="list-group">
            <span>{NETWORKS}</span>
          </div>
          <div className="list-group">
            <strong>{region.affectationRegion}</strong>
          </div>
        </section>
        <section className="affectation-rules__row">
          <div className="list-group">
            <span>{COMMENT}</span>
          </div>
          <div className="list-group">
            <TextareaInputController control={control as unknown as Control} name="comment" maxLength={200} />
          </div>
        </section>
      </section>
    </>
  );
};
export { AffectionRules };
