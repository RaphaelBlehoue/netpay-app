import { clsx } from 'clsx';

import { rowRulesType } from '@affectations/features/commonTypes';

const FIRST_RULES = 'rules-1';
const RowAssignmentRules = ({ label, content, id }: rowRulesType) => {
  const isFirst = id === FIRST_RULES;
  return (
    <section className="assignment-rules__row" id={id}>
      <div className="list-group">
        <span className={clsx('list-label', isFirst && 'input-required')}>{label}</span>
      </div>
      <div className="list-group">
        <strong>{content}</strong>
      </div>
    </section>
  );
};

export { RowAssignmentRules };
