import { TableContainer } from '@affectations/components/ui/Table/TableContainer';

import './TermsOfTheWizardRules.scss';

import { Loader } from '@affectations/components';

import { TtermsOfRulesData } from './utils';

export interface ITermsOfTheWizardRules {
  rulesMapping: TtermsOfRulesData;
  isLoading?: boolean;
  isSuccess?: boolean;
  sectionTitle?: string;
}

const TermsOfTheWizardRules = ({ rulesMapping, isLoading, isSuccess, sectionTitle }: ITermsOfTheWizardRules) => {
  return (
    <>
      <h2 className="af-title">{sectionTitle}</h2>
      <Loader isLoading={isLoading}>
        <div className="af-terms-of-the-wizard-rules">
          <div className="af-terms-of-the-wizard-rules__list">
            {isSuccess && (
              <TableContainer
                title="Modalites-de-la-regle"
                headerColumns={rulesMapping.columns}
                dataRows={rulesMapping.modalityData}
              />
            )}
          </div>
        </div>
      </Loader>
    </>
  );
};
export { TermsOfTheWizardRules };
