import { screen, waitFor } from '@testing-library/react';
import { defineFeature, DefineStepFunction, loadFeature } from 'jest-cucumber';
import { useForm } from 'react-hook-form';
import { select as selectOptionEvent } from 'react-select-event';

import { MultiSelectController } from '@affectations/components';
import { renderSetup } from '@affectations/test-utils';

const feature = loadFeature('../features/FormSelectCriteriaValueRules.feature');

const FAKE_OPTIONS_SELECT = [
  { label: 'Tous/toutes', value: '*' },
  { label: 'Option 2', value: 'opt2' },
  { label: 'Option 3', value: 'opt3' },
  { label: 'Option 4', value: 'opt4' },
  { label: 'Option 5', value: 'opt5' },
];

const selectOptions = async (input: HTMLElement, options: string[] | string) => {
  await waitFor(() => selectOptionEvent(input, options));
};

const MultiInjected = () => {
  const form = useForm();
  return (
    <form aria-label={'Modality criteria-values'}>
      <label htmlFor={'modality-values'}>Criteria-values</label>
      <MultiSelectController
        control={form.control}
        name="rules"
        options={FAKE_OPTIONS_SELECT}
        inputId={'modality-values'}
        isMulti
      />
    </form>
  );
};

const givenMultiSelectOptions = (given: DefineStepFunction) => {
  given("j'ai une liste deroulante ouverte avec des valeurs", async () => {
    const getFomrValue = await waitFor(() => screen.getByRole('form', { name: 'Modality criteria-values' }));
    expect(getFomrValue).toHaveFormValues({ rules: '' });
  });
};

const whenTickThanOneOrManyValueOtherThanAll = (when: DefineStepFunction, options: string[] | []) => {
  when(/^je coche une ou plusieurs valeurs autre que Tous\/toutes$/, async () => {
    await waitFor(async () => {
      selectOptions(screen.getByLabelText('Criteria-values'), options);
    });
  });
};
const whenTickTheValueAll = (when: DefineStepFunction, options: string[] | []) => {
  when('je coche la valeur Tous / toutes', async () => {
    await waitFor(async () => {
      selectOptions(screen.getByLabelText('Criteria-values'), options);
    });
  });
};

const whenTickAllTheValuesInTheList = (when: DefineStepFunction, options: string[] | []) => {
  when(/^je coche toute les valeurs de la liste deroulante$/, async () => {
    await waitFor(async () => {
      selectOptions(screen.getByLabelText('Criteria-values'), options);
    });
  });
};

const thenHaveCheckedValuesDisplay = async (then: DefineStepFunction, expectedValues: string[] | string) => {
  then(/^je dois avoir la ou les valeurs cochées affichées dans la liste$/, async () => {
    const expected = await waitFor(() => screen.getByRole('form', { name: 'Modality criteria-values' }));
    expect(expected).toHaveFormValues({ rules: expectedValues });
  });
};

const thenHaveCheckAllValueDisplay = (then: DefineStepFunction, expectedValues: string[] | string) => {
  then('je dois avoir la valeurs Tous / toutes affichée et toutes les valeurs cochées dans la liste', async () => {
    const expected = await waitFor(() => screen.getByRole('form', { name: 'Modality criteria-values' }));
    expect(expected).toHaveFormValues({ rules: expectedValues });
  });
};

defineFeature(feature, test => {
  beforeEach(() => {
    renderSetup(<MultiInjected />);
  });

  test("Affichage d'une valeur sélectionnée dans le champs de saisie autre que Tous/toutes", ({
    given,
    when,
    then,
  }) => {
    givenMultiSelectOptions(given);
    whenTickThanOneOrManyValueOtherThanAll(when, ['Option 2']);
    thenHaveCheckedValuesDisplay(then, 'opt2');
  });

  test('Affichage de plusieurs valeurs sélectionnées dans le champs de saisie autre que Tous/toutes', ({
    given,
    when,
    then,
  }) => {
    givenMultiSelectOptions(given);
    whenTickThanOneOrManyValueOtherThanAll(when, ['Option 2', 'Option 3']);
    thenHaveCheckedValuesDisplay(then, ['opt2', 'opt3']);
  });

  test('Affichage de la valeur "Tous/toutes" dans le champs de saisie quand toute est coché', ({
    given,
    when,
    then,
  }) => {
    givenMultiSelectOptions(given);
    whenTickTheValueAll(when, ['Tous/toutes']);
    thenHaveCheckAllValueDisplay(then, '*');
  });

  test('Affichage de la valeur "Tous/toutes" dans le champs de saisie quand toutes les valeurs sont cochées', ({
    given,
    when,
    then,
  }) => {
    givenMultiSelectOptions(given);

    whenTickAllTheValuesInTheList(when, ['Option 2', 'Option 3', 'Option 4', 'Option 5']);

    then('je dois avoir la valeurs Tous / toutes affichée et toutes les valeurs cochées dans la liste', async () => {
      const expected = await waitFor(() => screen.getByRole('form', { name: 'Modality criteria-values' }));
      await waitFor(() => expect(expected).toHaveFormValues({ rules: '*' }));
    });
  });
});
