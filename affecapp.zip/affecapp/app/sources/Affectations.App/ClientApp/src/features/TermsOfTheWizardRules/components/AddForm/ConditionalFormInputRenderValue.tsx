import { useCallback, useMemo } from 'react';
import { Control, FieldValues, Path, UseFormGetValues, UseFormSetValue } from 'react-hook-form';

import {
  AsyncAutoCompleteController,
  MultiSelectController,
  NumberInputController,
  TextInput,
  TOption,
} from '@affectations/components';
import { isNotInputValid } from '@affectations/features/AffectationRules/utils';
import { TFieldArray } from '@affectations/types';

import {
  AUTO_COMPLETE_FIELD_VALUE_CRITERIA,
  INPUT_FIELD_CONDITION_CRITERIA,
  IS_VALUE_AUTOCOMPLETE_FIELD,
  IS_VALUE_IMPORT,
  IS_VALUE_MULTI,
  IS_VALUE_NUMBER_FIELD,
  MULTI_SELECT_VALUE_CRITERIA,
} from '../../utils';

import './ConditionalFormInputRenderValue.scss';

type TConditionalFormInputRenderValue<TFieldValuesPath extends FieldValues> = {
  name: Path<TFieldValuesPath>;
  control?: Control<TFieldValuesPath>;
  setValue?: UseFormSetValue<TFieldValuesPath>;
  getValues?: UseFormGetValues<TFieldValuesPath>;
  options: TOption[];
  valuedState?: TFieldArray;
  filterAutoCompleteAsync: (inputValue: string) => Promise<TOption[]>;
};

const MAX_SEARCH_AUTOCOMPLETE_COUNT = 10;
const ConditionalFormInputRenderValue = <TFieldValuesPath extends FieldValues>({
  name,
  control,
  setValue,
  getValues,
  options,
  valuedState,
  filterAutoCompleteAsync,
}: TConditionalFormInputRenderValue<TFieldValuesPath>) => {
  const handleAutoCompleteChange = useCallback(
    async (inputValue: string) => {
      if (isNotInputValid(inputValue)) {
        return [];
      }
      const data = (await filterAutoCompleteAsync(inputValue)) ?? [];
      return data.slice(0, MAX_SEARCH_AUTOCOMPLETE_COUNT);
    },
    [filterAutoCompleteAsync]
  );

  const showInputField: string | undefined = useMemo(() => {
    if (!valuedState?.criteria) {
      return 'default';
    }
    if (MULTI_SELECT_VALUE_CRITERIA.includes(valuedState.criteria)) {
      return IS_VALUE_MULTI;
    }
    if (INPUT_FIELD_CONDITION_CRITERIA.includes(valuedState.criteria)) {
      return IS_VALUE_NUMBER_FIELD;
    }
    if (AUTO_COMPLETE_FIELD_VALUE_CRITERIA.includes(valuedState.criteria)) {
      return IS_VALUE_AUTOCOMPLETE_FIELD;
    }
    return IS_VALUE_IMPORT;
  }, [valuedState?.criteria]);

  switch (showInputField) {
    case IS_VALUE_NUMBER_FIELD:
      return <NumberInputController name={name} control={control} />;
    case IS_VALUE_AUTOCOMPLETE_FIELD:
      return (
        <AsyncAutoCompleteController
          control={control as unknown as Control}
          name={name}
          inputId="autocomplete-field"
          classNamePrefix="autocomplete-rules"
          className="autocomplete-rules__container"
          currentValueCriteria={valuedState}
          loadOptions={handleAutoCompleteChange}
          noOptionsMessage={data => (!isNotInputValid(data.inputValue) ? 'Aucun résultat' : null)}
          cacheOptions
          placeholder="Rechercher..."
          defaultOptions
        />
      );
    case IS_VALUE_MULTI:
      return (
        <MultiSelectController
          name={name}
          isMulti
          className="select-rules__container"
          classNamePrefix="select-rules"
          control={control}
          setValue={setValue}
          getValues={getValues}
          options={options}
          id={name}
        />
      );
    default:
      return <TextInput name={name} currentValueCriteria={valuedState} control={control as unknown as Control} />;
  }
};
export { ConditionalFormInputRenderValue };
