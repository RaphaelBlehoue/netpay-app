import { screen, waitFor } from '@testing-library/react';
import { defineFeature, DefineStepFunction, loadFeature } from 'jest-cucumber';

import { getStatusConsultation, TStatus } from '@affectations/pages/Consultation/utils';
import { renderSetup } from '@affectations/test-utils';
import { DateFormats, formatDate } from '@affectations/utils';

import { HeaderInformation, IHeaderInfoRulesMapping } from '../HeaderInformation';
import { mockConsultationHeader, TMockComponentProps, TMockDisplayOptions } from './test-utils';

const feature = loadFeature('../features/HeaderInformation.feature');

defineFeature(feature, test => {
  beforeEach(async () => {});

  afterEach(() => {
    vi.clearAllTimers();
  });

  const givenIAmRetrievingDataFromBff = (given: DefineStepFunction, MockComponentProps: TMockComponentProps) => {
    given(/je recupère les données provenant du bff/, async () => {
      const currenDataMock: IHeaderInfoRulesMapping = mockConsultationHeader(MockComponentProps);
      waitFor(() => renderSetup(<HeaderInformation {...currenDataMock} />));
    });
  };

  const andStartDateRulesIs = async (and: DefineStepFunction, props: TMockComponentProps) => {
    and(/^la date de début de la règle est "(.*)"$/, async startDate => {
      waitFor(() => expect(props.startDate).toBe(startDate));
    });
  };

  const andEndDateRulesIs = async (and: DefineStepFunction, props: TMockComponentProps) => {
    and(/^la date de fin de la règle est "(.*)"$/, async endDate => {
      waitFor(() => expect(props.endDate).toBe(endDate));
    });
  };

  const andEndDateRulesHaveNotDefined = async (and: DefineStepFunction) => {
    and("la date de fin de la règle est n'est pas definie", () => {
      const fakeEndDate = '31/01/2023';
      waitFor(() => expect(screen.findByText(fakeEndDate)).not.toBeInTheDocument());
    });
  };

  const whenNowDayIs = (when: DefineStepFunction) => {
    when(/^la date du jour est "(.*)"$/, nowDate => {
      const today = new Date(nowDate);
      vi.useFakeTimers();
      vi.setSystemTime(today);
      expect(Date.now()).toBe(today.valueOf());
    });
  };

  const andRulesHaveNeverUpdated = async (and: DefineStepFunction) => {
    and(/la règle n'a jamais été mise a jour/, async () => {
      const expectedUpdateInfo = 'Mise à jour par Jérôme CAGNONCLE, le 01/03/2023 à 10h55' as string;
      waitFor(() => expect(screen.findByText(expectedUpdateInfo)).not.toBeInTheDocument());
    });
  };

  const andRulesUpdatedIs = async (and: DefineStepFunction) => {
    and(/^la date de mise a jour est "(.*)"$/, async updateDate => {
      const expectedDate = formatDate(new Date(updateDate), DateFormats.DATE_TIME);
      waitFor(() => expect(screen.findByText(expectedDate)).toBeInTheDocument());
      waitFor(() => expect(screen.findByText(expectedDate)).toEqual('01/03/2023 à 10h55'));
    });
  };

  const andStatusGiveByBffIs = (and: DefineStepFunction) => {
    and(/^la règle est "(.*)"$/, async status => {
      waitFor(() => expect(screen.findByText(status)).toBeInTheDocument());
    });
  };

  const thenShouldSeeTheDisplay = async (
    then: DefineStepFunction,
    props: TMockComponentProps,
    options: TMockDisplayOptions
  ) => {
    then('je dois voir afficher les informations suivantes', async dataTable => {
      const { startDate, endDate, ruleName, status, createContent, updateContent } = dataTable[0];
      const setEndDate: Date | undefined = props?.endDate ? new Date(props.endDate) : undefined;
      const currentStatus: TStatus = getStatusConsultation(new Date(props?.startDate), setEndDate, props.statusLabel);
      waitFor(() => expect(screen.findByText(startDate)).toBeInTheDocument());
      waitFor(() => expect(screen.findByText(ruleName)).toBeInTheDocument());
      waitFor(() => expect(screen.findByText(createContent)).toBeInTheDocument());
      waitFor(() => expect(screen.findByText(status)).toEqual(currentStatus.statusLabel));
      options.hasEndDate && waitFor(() => expect(screen.findByText(endDate)).toBeInTheDocument());
      options.hasUpdate && waitFor(() => expect(screen.findByText(updateContent)).not.toBeVisible());
    });
  };

  test("Affichage de la règle sans l'information de mise a jour", ({ given, and, when, then }) => {
    const propsValue: TMockComponentProps = {
      statusLabel: 'Active',
      startDate: '2024-01-01T23:00:00',
      endDate: '2024-01-31T23:00:00',
      hasUpdated: false,
    };
    givenIAmRetrievingDataFromBff(given, propsValue);
    andStartDateRulesIs(and, propsValue);
    andEndDateRulesIs(and, propsValue);
    whenNowDayIs(when);
    andRulesHaveNeverUpdated(and);
    thenShouldSeeTheDisplay(then, propsValue, { hasEndDate: true, hasUpdate: false });
  });
  test('Règle expirée', ({ given, and, when, then }) => {
    const propsValue: TMockComponentProps = {
      statusLabel: 'Active',
      startDate: '2024-01-01T23:00:00',
      endDate: '2024-01-31T23:00:00',
      hasUpdated: true,
    };

    givenIAmRetrievingDataFromBff(given, propsValue);
    andStartDateRulesIs(and, propsValue);
    andEndDateRulesIs(and, propsValue);
    whenNowDayIs(when);
    andRulesUpdatedIs(and);
    thenShouldSeeTheDisplay(then, propsValue, { hasEndDate: true, hasUpdate: true });
  });

  test('Règle active', ({ given, and, when, then }) => {
    const propsValue: TMockComponentProps = {
      statusLabel: 'Active',
      startDate: '2024-01-01T23:00:00',
      endDate: '2024-01-31T23:00:00',
      hasUpdated: true,
    };

    givenIAmRetrievingDataFromBff(given, propsValue);
    andStartDateRulesIs(and, propsValue);
    andEndDateRulesIs(and, propsValue);
    whenNowDayIs(when);
    andStatusGiveByBffIs(and);
    andRulesUpdatedIs(and);
    thenShouldSeeTheDisplay(then, propsValue, { hasEndDate: true, hasUpdate: true });
  });

  test('Règle en brouillon', ({ given, and, when, then }) => {
    const propsValue: TMockComponentProps = {
      statusLabel: 'Brouillon',
      startDate: '2024-01-01T23:00:00',
      endDate: '2024-01-31T23:00:00',
      hasUpdated: true,
    };
    givenIAmRetrievingDataFromBff(given, propsValue);
    andStartDateRulesIs(and, propsValue);
    andEndDateRulesIs(and, propsValue);
    whenNowDayIs(when);
    andStatusGiveByBffIs(and);
    andRulesUpdatedIs(and);
    thenShouldSeeTheDisplay(then, propsValue, { hasEndDate: true, hasUpdate: true });
  });

  test('Règle active sans date de fin', ({ given, and, when, then }) => {
    const propsValue: TMockComponentProps = {
      statusLabel: 'Active',
      startDate: '2024-01-01T23:00:00',
      hasUpdated: true,
    };
    givenIAmRetrievingDataFromBff(given, propsValue);
    andStartDateRulesIs(and, propsValue);
    andEndDateRulesHaveNotDefined(and);
    whenNowDayIs(when);
    andStatusGiveByBffIs(and);
    andRulesUpdatedIs(and);
    thenShouldSeeTheDisplay(then, propsValue, { hasEndDate: false, hasUpdate: true });
  });

  test('Règle en brouillon sans date de fin', ({ given, and, when, then }) => {
    const propsValue: TMockComponentProps = {
      statusLabel: 'Brouillon',
      startDate: '2024-01-01T23:00:00',
      hasUpdated: true,
    };
    givenIAmRetrievingDataFromBff(given, propsValue);
    andStartDateRulesIs(and, propsValue);
    andEndDateRulesHaveNotDefined(and);
    whenNowDayIs(when);
    andStatusGiveByBffIs(and);
    andRulesUpdatedIs(and);
    thenShouldSeeTheDisplay(then, propsValue, { hasEndDate: false, hasUpdate: true });
  });
});
