import { act, screen, waitFor } from '@testing-library/react';
import { UserEvent } from '@testing-library/user-event';
import { defineFeature, DefineStepFunction, loadFeature } from 'jest-cucumber';
import { useForm } from 'react-hook-form';
import { Mock } from 'vitest';

import { Button } from '@affectations/components';
import { useModelAffectationRules } from '@affectations/pages/affectations/useViewModelAffectationRules';
import { BUTTON_TITLE } from '@affectations/pages/affectations/utils';
import { AppContextProvider } from '@affectations/contexts/AppContextProvider';
import { CONSULTATION_RULE_ID_DETAIL } from '@affectations/routes/configRoute';
import { renderMemoryRouter } from '@affectations/test-utils';
import { IAffectationFormInputs } from '@affectations/types';

import { AffectionRules } from '../AffectationRules';

const feature = loadFeature('../features/AffectationRules.feature');

const teamOptions = [
  {
    label: 'ES_AUTO_NE',
    value: 'ES_AUTO_NE',
  },
  {
    label: 'ES_AUTO_OUEST',
    value: 'ES_AUTO_OUEST',
  },
  {
    label: 'ES_AUTO_SE',
    value: 'ES_AUTO_SE',
  },
  {
    label: 'ES_AUTO_SO',
    value: 'ES_AUTO_SO',
  },
];

const FormAffectationRules = ({ mockAsyncFn, ...props }: { mockAsyncFn: Mock }) => {
  const { teams } = useModelAffectationRules();
  const {
    setError,
    clearErrors,
    watch,
    resetField,
    setValue,
    control,
    handleSubmit,
    formState: { errors },
  } = useForm<IAffectationFormInputs>({
    mode: 'all',
  });
  const onFormSubmit = async (data: IAffectationFormInputs) => {
    return data;
  };

  return (
    <form>
      <AffectionRules
        filterEmployeeAsync={mockAsyncFn}
        teams={teams || []}
        teamsOptions={teamOptions}
        control={control}
        watch={watch}
        setError={setError}
        clearErrors={clearErrors}
        resetField={resetField}
        setValue={setValue}
        errors={errors}
        {...props}
      />
      <Button title={BUTTON_TITLE.active} type="submit" onClick={handleSubmit(onFormSubmit)} />
    </form>
  );
};

defineFeature(feature, test => {
  let userSetup: UserEvent;
  let selectCondition: HTMLElement;
  let collaboratorField: HTMLElement;
  let mockfilterEmployeeAsync: Mock;

  const shouldSeeAffectationComponent = (given: DefineStepFunction) => {
    given('je vois la section Affectation du formulaire', async () => {
      const initialEntries: string[] = [CONSULTATION_RULE_ID_DETAIL];
      mockfilterEmployeeAsync = vi.fn().mockReturnValue(Promise.resolve({ data: [] }));

      await waitFor(() => {
        const { user } = renderMemoryRouter(
          <AppContextProvider>
            <FormAffectationRules mockAsyncFn={mockfilterEmployeeAsync} />
          </AppContextProvider>,
          { initialEntries }
        );
        userSetup = user;
      });
    });
  };

  const whenSendFormAffectation = (when: DefineStepFunction) => {
    when('je clique sur le bouton submit', async () => {
      await act(() => userSetup.click(screen.getByRole('button', { name: BUTTON_TITLE.active })));
    });
  };

  const shouldseeFormErrors = (then: DefineStepFunction) => {
    then(
      /^je dois voir "(.*)" erreur\(s\) de validation avec le text "(.*)"$/,
      async (countRules: number, errorAlert: string) => {
        // strict regex
        const expected = new RegExp(`^${errorAlert}$`, 'i');
        const rulesElt = await screen.findAllByText(expected);
        expect(rulesElt).toHaveLength(countRules);
      }
    );
  };

  const whenISearchCollaborators = (when: DefineStepFunction) =>
    when(/je saisie une donnée "(.*)" qui n'existe pas/i, async (input: string) => {
      waitFor(() => {
        collaboratorField = screen.getByRole('combobox', { name: /collaborater/i });
      });
      await userSetup.type(collaboratorField, input);
    });

  const whenSelectTeamField = (when: DefineStepFunction) => {
    when(/^je selectionne "(.*)" comme valeur de team$/, async (labelSelected: string) => {
      waitFor(() => {
        selectCondition = screen.getByRole('combobox', { name: /teams-input/i });
      });
      await act(() => userSetup.selectOptions(selectCondition, labelSelected));
    });
  };

  test("Affichage de l'erreur de règle de valeur obligatoire", ({ given, when, then }) => {
    shouldSeeAffectationComponent(given);
    whenSendFormAffectation(when);
    shouldseeFormErrors(then);
  });

  test('Affichage du nom de la valeur de region', ({ given, when, then }) => {
    shouldSeeAffectationComponent(given);
    whenSelectTeamField(when);
    then(/^je dois voir "(.*)" comme nom de region afficher$/, async ExpectNameRegion => {
      const expected = new RegExp(`^${ExpectNameRegion}$`, 'i');
      const rulesElt = await screen.findAllByText(expected);
      expect(rulesElt).toHaveLength(1);
    });
  });

  test("Affichage du message d'erreur de l'autocomplétion", ({ given, when, then, and }) => {
    shouldSeeAffectationComponent(given);
    whenISearchCollaborators(when);
    shouldseeFormErrors(then);
    and(/^le champs doit avoir la donnée "(.*)"$/, async (input: string) => {
      expect(mockfilterEmployeeAsync).toHaveBeenCalledWith(input);
    });
  });
});
