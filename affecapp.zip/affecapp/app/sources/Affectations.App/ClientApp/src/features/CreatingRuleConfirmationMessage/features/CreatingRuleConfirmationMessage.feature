Feature: Message confirmation

    en tant que Utilisateur IAM_BAFFO_USER
    Je veux voir des messages de confirmation
    Afin de savoir le statut de la règle créée.

    Scenario: La règle est enregistrée avec le statut Active
        Given La date de création 2024-03-12T10:00:00 et le statut Active
        When La page de consultation et le message de confirmation sont affichés
        Then Je devrais voir le message: La règle a bien été activée le 12/03/2024 à 10:00. affiché

    Scenario:  La règle est enregistrée avec le statut Brouillon
        Given La date de création 2024-03-12T10:00:00 et le statut Brouillon
        When La page de consultation et le message de confirmation sont affichés
        Then Je devrais voir le message: La règle a bien été enregistrée en brouillon le 12/03/2024 à 10:00. affiché

    Scenario:  La règle est enregistrée avec le statut brouillon avec des erreurs
        Given La date de création 2024-03-12T10:00:00 et le statut draft_error
        When La page de consultation et le message de confirmation sont affichés
        Then Je devrais voir le message: La règle a bien été enregistrée en brouillon malgré la présence d'erreurs sur certains champs le 12/03/2024 à 10:00. affiché
