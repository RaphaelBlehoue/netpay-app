import { TOption } from '@affectations/components';
import { Column } from '@affectations/components/ui/Table/utils';
import { IRuleDto } from '@affectations/api/bff-clients.generated';
import { TFieldArray } from '@affectations/types';

export type HeaderDataType = {
  criteres?: string;
  conditions?: string;
  valeur?: string | number;
};

export type TtermsOfRulesData = {
  columns: Column<HeaderDataType>[];
  modalityData: HeaderDataType[];
};

export const START_TO_SHOW_ICON_REMOVE = 2;
export const CELL_CLASSNAME = 'af-table__cell';
export const PORTEFOLIO_CODE = 'PORTFOLIO_CODE';

export const MULTI_SELECT_VALUE_CRITERIA: string[] = [
  'BRANCH',
  'DISTRIBUTION_REGION',
  'SEGMENTATION',
  'NETWORKS',
  'QP_CONTRACT_CATEGORY',
  'DISTRIBUTION_DEPARTMENT',
];

export const IS_AMONG_LIST: Array<string> = [
  ...MULTI_SELECT_VALUE_CRITERIA,
  'CODE_SYNDIC',
  'AXAPAC',
  'ACCOUNT_MANAGER',
  'CONTRACT_NUMBER',
  'UVCODE',
  'CLAUSE',
  'CODE_PORTEFEUILLE',
];

export const AUTO_COMPLETE_FIELD_VALUE_CRITERIA: Array<string> = ['INTERMEDIARY_NAME', 'CODE_PORTEFEUILLE'];

export const INPUT_FIELD_CONDITION_CRITERIA: string[] = ['COPHT'];

export const FAKE_OPTIONS_SELECT = [
  { label: 'Option 1', value: 'opt1' },
  { label: 'Option 2', value: 'opt2' },
  { label: 'Option 3', value: 'opt3' },
  { label: 'Option 4', value: 'opt4' },
  { label: 'Option 5', value: 'opt5' },
  { label: 'Option 6', value: 'opt6' },
  { label: 'Option 7', value: 'opt7' },
];

export const optionsConditions = [
  { label: 'Est égal à', value: 'est égal à' },
  { label: 'Est parmi', value: 'est parmi' },
  { label: 'Commence par', value: 'commence par' },
  { label: 'Contient', value: 'contient' },
];

export const HEADER_TABLE: { columns: Column<HeaderDataType>[] } = {
  columns: [
    { title: 'Critères', key: 'criteres' },
    { title: 'Conditions', key: 'conditions' },
    { title: 'Valeur(s)', key: 'valeur' },
  ],
};

export const DEFAULT_MODALITIES: TFieldArray = {
  criteria: '',
  condition: '',
  rules: [],
};

export const IS_ONE_OF = 'est parmi';
export const IS_VALUE_MULTI = 'IS_VALUE_MULTI';
export const IS_VALUE_IMPORT = 'IS_VALUE_IMPORT';
export const IS_VALUE_NUMBER_FIELD = 'IS_VALUE_NUMBER_FIELD';
export const IS_VALUE_AUTOCOMPLETE_FIELD = 'IS_VALUE_AUTOCOMPLETE_FIELD';
export const GREATER_OR_EQUAL_TO = 'plus grand ou égal à';
export const STARTWITH = 'Selectionner';
const START_REMOVE_ID = 2;
const END_REMOVE_ID = 16;
export const REMOVE_IDS_LIST = Array.from({ length: 16 }, (_, i) => i + 1).slice(START_REMOVE_ID, END_REMOVE_ID);

export const formatRulesModality = (data: IRuleDto | undefined): HeaderDataType[] | [] => {
  if (data === undefined) {
    return [];
  }
  const { critereDto, conditionsDto } = data;
  return [
    {
      criteres: staticCriteria.segmentation,
      conditions: conditionsDto?.segmentationCondition,
      valeur: critereDto?.segmentation,
    },
    {
      criteres: staticCriteria.distributorRegion,
      conditions: conditionsDto?.regionCondition,
      valeur: critereDto?.distributorRegion,
    },
    {
      criteres: staticCriteria.network,
      conditions: conditionsDto?.networkCondition,
      valeur: critereDto?.network,
    },
    {
      criteres: staticCriteria.branch,
      conditions: conditionsDto?.branchCondition,
      valeur: critereDto?.branch,
    },
    {
      criteres: staticCriteria.copht,
      conditions: conditionsDto?.cophtCondition,
      valeur: withFormatterNumber(critereDto?.copht),
    },
    {
      criteres: staticCriteria.distributorDepartment,
      conditions: conditionsDto?.departmentCondition,
      valeur: critereDto?.distributorDepartment,
    },
    {
      criteres: staticCriteria.contractCategory,
      conditions: conditionsDto?.contractCategoryCondition,
      valeur: critereDto?.contractCategory,
    },
    {
      criteres: staticCriteria.uvCode,
      conditions: conditionsDto?.productCondition,
      valeur: critereDto?.uvCode,
    },
    {
      criteres: staticCriteria.intermediateName,
      conditions: conditionsDto?.intermediateNameCondition,
      valeur: critereDto?.intermediateName,
    },
    {
      criteres: staticCriteria.portfolioCode,
      conditions: conditionsDto?.portfolioCondition,
      valeur: critereDto?.portfolioCode,
    },
    {
      criteres: staticCriteria.clause,
      conditions: conditionsDto?.clauseCondition,
      valeur: critereDto?.clause,
    },
    {
      criteres: staticCriteria.syndicCode,
      conditions: conditionsDto?.syndicCodeCondition,
      valeur: critereDto?.syndicCode,
    },
    {
      criteres: staticCriteria.nafCode,
      conditions: conditionsDto?.nafCodeCondition,
      valeur: critereDto?.nafCode,
    },
    {
      criteres: staticCriteria.clientNumber,
      conditions: conditionsDto?.clientNumberCondition,
      valeur: critereDto?.clientNumber,
    },
    {
      criteres: staticCriteria.accountManager,
      conditions: conditionsDto?.accountManagerCondition,
      valeur: critereDto?.accountManager,
    },
    {
      criteres: staticCriteria.contractNumber,
      conditions: conditionsDto?.contractNumberCondition,
      valeur: critereDto?.contractNumber,
    },
  ];
};

export const formatterModality = (rules: IRuleDto | undefined): HeaderDataType[] => {
  return formatRulesModality(rules).reduce<HeaderDataType[]>((acc: HeaderDataType[], item: HeaderDataType) => {
    if (item.valeur?.toString().length && item.valeur !== '') {
      acc.push(item);
    }
    return acc;
  }, []);
};

const staticCriteria = {
  segmentation: 'segmentation',
  distributorRegion: 'Région distributeur',
  network: 'Reseau',
  branch: 'Branche',
  copht: 'COPHT (€)',
  distributorDepartment: 'Département distributeur',
  contractCategory: 'Catégorie du contrat QP',
  uvCode: 'Code UV produit',
  intermediateName: 'Nom intermédiaire',
  portfolioCode: 'Code portefeuille',
  clause: 'Clause',
  syndicCode: 'Code Syndic',
  nafCode: 'Code NAF',
  clientNumber: 'N° client AXAPAC',
  accountManager: 'Chargé de clientèle',
  contractNumber: 'N° contrat',
};

export enum DEFAULT_CRITERIA_KEY {
  BRANCH = 'BRANCH',
  DISTRIBUTION_REGION = 'DISTRIBUTION_REGION',
  SEGMENTATION = 'SEGMENTATION',
}

export enum STATIC_ALL_VALUE_CRITERIA {
  BRANCH = 'BRANCH',
  DISTRIBUTION_REGION = 'DISTRIBUTION_REGION',
  SEGMENTATION = 'SEGMENTATION',
  CLAUSE = 'CLAUSE',
  INTERMEDIARY_NAME = 'INTERMEDIARY_NAME',
  NETWORKS = 'NETWORKS',
  DISTRIBUTION_DEPARTMENT = 'DISTRIBUTION_DEPARTMENT',
  QP_CONTRACT_CATEGORY = 'QP_CONTRACT_CATEGORY',
  UVCODE = 'UVCODE',
  AXAPAC = 'AXAPAC',
  ACCOUNT_MANAGER = 'ACCOUNT_MANAGER',
  CONTRACT_NUMBER = 'CONTRACT_NUMBER',
  COPHT = 'COPHT',
  CODE_NAF = 'CODE_NAF',
  CODE_SYNDIC = 'CODE_SYNDIC',
  CODE_PORTEFEUILLE = 'CODE_PORTEFEUILLE',
}

export const INIT_MODALITIES = {
  modalities: [
    {
      criteria: DEFAULT_CRITERIA_KEY.BRANCH,
      condition: IS_ONE_OF,
      rules: [],
    },
    {
      criteria: DEFAULT_CRITERIA_KEY.DISTRIBUTION_REGION,
      condition: IS_ONE_OF,
      rules: [],
    },
    {
      criteria: DEFAULT_CRITERIA_KEY.SEGMENTATION,
      condition: IS_ONE_OF,
      rules: [],
    },
  ],
};

export const STATIC_CRITERIA = [
  { label: 'Branche', value: 'BRANCH' },
  { label: 'Clause', value: 'CLAUSE' },
  { label: 'Départment distributeur', value: 'DISTRIBUTION_DEPARTMENT' },
  { label: 'Région distributeur', value: 'DISTRIBUTION_REGION' },
  { label: 'Nom intermédiaire', value: 'INTERMEDIARY_NAME' },
  { label: 'Réseaux', value: 'NETWORKS' },
  { label: 'Catégorie contrat QP', value: 'QP_CONTRACT_CATEGORY' },
  { label: 'Segmentation', value: 'SEGMENTATION' },
  { label: 'Code UV', value: 'UVCODE' },
  { label: 'N° client AXAPAC', value: 'AXAPAC' },
  { label: 'Chargé de clientèle', value: 'ACCOUNT_MANAGER' },
  { label: 'N° contrat', value: 'CONTRACT_NUMBER' },
  { label: 'COPHT (€)', value: 'COPHT' },
  { label: 'Code NAF', value: 'CODE_NAF' },
  { label: 'Code Syndic', value: 'CODE_SYNDIC' },
  { label: 'Code portefeuille', value: 'CODE_PORTEFEUILLE' },
];

export const STATIC_FILTER_CRITERIA = STATIC_CRITERIA.filter(
  (item, _index) => !Object.keys(DEFAULT_CRITERIA_KEY).includes(item.value)
);

export const findLabelByValue = (value: string | undefined): string => {
  if (value === undefined) {
    return '';
  }
  const findData: TOption | undefined = STATIC_CRITERIA.find((item, _index) => item.value === value) ?? undefined;
  return findData !== undefined ? findData.label : '';
};

export const withFormatterNumber = (numberData: number | undefined) => {
  if (numberData === undefined || numberData === null) {
    return '';
  }
  return new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 2 }).format(numberData);
};

export const removeEmptyObject = (obj: Record<string, string>, id?: string) => {
  return Object.entries(id === undefined ? obj : { ...obj, [id]: '' })
    .filter(([_key, value]) => value !== '')
    .reduce((acc, current) => ({ ...acc, [current[0]]: current[1] }), {});
};

export const ALL_WORDING_OBJECT = {
  code: '*',
  label: 'Tous / toutes',
};

export const setConditionField = (currentState: string | undefined) => {
  if (!currentState) {
    return 'default';
  }
  if (IS_AMONG_LIST.includes(currentState)) {
    return IS_ONE_OF;
  }
  if (INPUT_FIELD_CONDITION_CRITERIA.includes(currentState)) {
    return GREATER_OR_EQUAL_TO;
  }
  return STARTWITH;
};
