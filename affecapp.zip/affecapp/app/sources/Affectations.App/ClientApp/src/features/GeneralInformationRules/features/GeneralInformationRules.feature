Feature: Formulaire des informations generales d'une règle

    en tant qu'utilisateur je voudrais renseigner les informations générales d'une règle dans un formulaire

    Scenario Outline: Saisie dans le champ nom de la règle
        Given Je rends le formulaire
        When Le texte "<input>" est saisi dans le champ nom de la règle
        Then Le champs nom de la règle a pour valeur "<current>"
        And Le compteur de caractères affiche "<counter>"
        Examples:
            | input                                                          | current                                            | counter |
            |                                                                |                                                    | 0/50    |
            | Nullam eleifend                                                | Nullam eleifend                                    | 15/50   |
            | Nullam eleifend justo in nisl In hac                           | Nullam eleifend justo in nisl In hac               | 36/50   |
            | Nullam eleifend justo in nisl In hac habitasse platea dictumst | Nullam eleifend justo in nisl In hac habitasse pla | 50/50   |

    Rule: Contrôle du champ date de début
        Scenario: La date de début est inférieure à celle d'aujourd'hui
            Given Je rends le formulaire
            When Je saisit une date d'hier dans le champ date de début
            Then Le message "Veuillez saisir une date ultérieure à aujourd'hui" s'affiche

        Scenario: La date de début n'est pas renseignée
            Given Je rends le formulaire
            When Je click sur le champ de date de début
            And Je click sur un autre champ dans le formulaire
            Then Le message "Ce champs est obligatoire" s'affiche
        Scenario: La date minimum du champs date de début est celle d'aujourd'hui
            Given Je rends le formulaire
            Then le champ date de début a pour valeur minimum la date d'aujourd'hui
        Scenario: L'utilisateur saisit une date valide
            Given Je rends le formulaire
            When Je saisie une date d'aujourd'hui dans le champs date de début
            Then la valeur du champs date de début est est celle d'aujourd'hui

    Rule: Contrôle du champ date de fin
        Scenario: La date minimum du champ date de fin est celle d'aujourd'hui
            Given Je rends le formulaire
            Then le champ date de fin a pour valeur minimum la date d'aujourd'hui

        Scenario: La date de début est renseignée
            Given Je rends le formulaire
            When Je saisie la date de demain dans le champ date de fin
            Then le champ date de fin a pour valeur minimum la date de demain

        Scenario: La date de début est supérieure à celle de fin
            Given Je rends le formulaire
            When Je saisie une date d'aujourd'hui dans le champs date de début
            And Je saisie la date d'hier dans le champs date de fin
            Then Le message "Veuillez saisir une date ultérieure à la date de début" s'affiche

        Scenario: La date de début est modifiée alors que celle de fin a une valeur inférieure
            Given Je rends le formulaire
            When Je saisie une date d'aujourd'hui dans le champs date de début
            And Je saisie une date d'aujourd'hui dans le champs date de fin
            And Je saisie une date demain dans le champs date de début
            Then Le message "Veuillez saisir une date ultérieure à la date de début" s'affiche

        Scenario: La date de fin est renseignée mais la date de début ne l'est pas
            Given Je rends le formulaire
            When Je saisie la date de demain dans le champ date de fin
            Then Le message "Veuillez saisir une date ultérieure à la date de début" s'affiche

