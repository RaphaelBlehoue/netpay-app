import { useId, useMemo } from 'react';
import { Control, Path } from 'react-hook-form';

import { SelectController, TextInputController, TOption } from '@affectations/components';
import { affectationConditionFormSchema } from '@affectations/pages/affectations/utils';
import { IAffectationFormInputs } from '@affectations/types';
import { capitalize } from '@affectations/utils';

import { GREATER_OR_EQUAL_TO, IS_ONE_OF, optionsConditions, setConditionField, STARTWITH } from '../../utils';

type TConditionalFormInputRenderCondition = {
  control: Control<IAffectationFormInputs>;
  conditionState?: string;
  fieldName: Path<IAffectationFormInputs>;
  options?: React.OptionHTMLAttributes<HTMLOptionElement>[] | TOption[];
};

const ConditionalFormInputRenderCondition = ({
  control,
  conditionState,
  fieldName,
}: TConditionalFormInputRenderCondition) => {
  const keys = useId();
  const showInputField: string | undefined = useMemo(() => {
    return setConditionField(conditionState);
  }, [conditionState]);

  switch (showInputField) {
    case IS_ONE_OF:
      return (
        <TextInputController
          label={capitalize(IS_ONE_OF)}
          control={control as unknown as Control}
          name={fieldName}
          aria-label={fieldName}
          inputContainerClassName="af-form__text"
          inputFieldClassName="af-form__input-text af-form__disabled"
          placeholder={fieldName}
          type="hidden"
          isDisabled
        />
      );
    case GREATER_OR_EQUAL_TO:
      return (
        <TextInputController
          label={GREATER_OR_EQUAL_TO}
          control={control as unknown as Control}
          name={fieldName}
          value={GREATER_OR_EQUAL_TO}
          aria-label={fieldName}
          inputContainerClassName="af-form__text"
          inputFieldClassName="af-form__input-text af-form__disabled"
          placeholder={fieldName}
          type="hidden"
          isDisabled
        />
      );
    case STARTWITH:
      return (
        <SelectController
          name={fieldName}
          rules={affectationConditionFormSchema.DEFAULT}
          options={optionsConditions || []}
          selectAdditionnalClassName="text"
          control={control as unknown as Control}
          id={fieldName}
          aria-label={fieldName}
        />
      );
    default:
      return (
        <SelectController
          key={keys}
          name={fieldName}
          rules={affectationConditionFormSchema.DEFAULT}
          options={[] as React.OptionHTMLAttributes<HTMLOptionElement>[]}
          selectAdditionnalClassName="text"
          control={control as unknown as Control}
          id={fieldName}
          aria-label={fieldName}
        />
      );
  }
};

export { ConditionalFormInputRenderCondition };
