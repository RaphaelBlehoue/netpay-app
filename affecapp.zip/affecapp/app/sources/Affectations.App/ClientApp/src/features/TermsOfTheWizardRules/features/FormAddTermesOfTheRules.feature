Feature:  Création d'une règle - Configuration critères/conditions - Saisie manuelle IARDENT-53696

  Rule: Affichage des règles de validation des champs inputs

    Scenario: Affichage  d'erreur de règle de valeur obligatoire
      Given je vois la section modalities du formulaire
      When je clique sur le bouton submit
      Then je dois voir "3" erreur(s) de validation avec le text "Veuillez renseigner une valeur."

    Scenario: Affichage d'erreur de règle de condition obligatoire
      Given je vois la section modalities du formulaire
      And j'ajoute une nouvelle ligne de formulaire
      When je clique sur le bouton submit
      Then je dois voir "3" erreur(s) de validation avec le text "Veuillez renseigner une valeur."
      And  je dois voir "1" erreur(s) de validation avec le text "Veuillez renseigner une condition."

    Scenario: Affichage d'erreur de valeur obligatoire Code Syndic
      Given je vois la section modalities du formulaire
      And j'ajoute une nouvelle ligne de formulaire
      And je selectionne "Code Syndic" comme critères
      And je vois "Est parmi" afficher comme condition
      When je clique sur le bouton submit
      Then je dois voir "4" erreur(s) de validation avec le text "Veuillez renseigner une valeur."

    Scenario: Affichage d'erreur de valeur obligatoire Code Syndic Format maximum
      Given je vois la section modalities du formulaire
      And j'ajoute une nouvelle ligne de formulaire
      And je selectionne "Code Syndic" comme critères
      And je vois "Est parmi" afficher comme condition
      And je saisie la valeur "1AXA" dans mon input
      When je clique sur le bouton submit
      Then je dois voir "3" erreur(s) de validation avec le text "Veuillez renseigner une valeur."
      And  je dois voir "1" erreur(s) de validation avec le text "Le format a respecter est : 5 caractères maximum"

    Scenario: Affichage d'erreur de valeur obligatoire Code Naf Format maximum
      Given je vois la section modalities du formulaire
      And j'ajoute une nouvelle ligne de formulaire
      And je selectionne "Code NAF" comme critères
      And je selectionne "Est parmi" comme condition
      And je saisie la valeur "1234AU" dans mon input
      When je clique sur le bouton submit
      Then je dois voir "3" erreur(s) de validation avec le text "Veuillez renseigner une valeur."
      And  je dois voir "1" erreur(s) de validation avec le text "Le format a respecter est : 7 caractères maximum"

    Scenario: Affichage d'erreur de valeur obligatoire Code Naf Format regex
      Given je vois la section modalities du formulaire
      And j'ajoute une nouvelle ligne de formulaire
      And je selectionne "Code NAF" comme critères
      And je selectionne "Est parmi" comme condition
      And je saisie la valeur "1234AXA" dans mon input
      When je clique sur le bouton submit
      Then je dois voir "3" erreur(s) de validation avec le text "Veuillez renseigner une valeur."
      And  je dois voir "1" erreur(s) de validation avec le text "Le format a respecter est : "xxxxxxx""

    Scenario: Affichage d'erreur de valeur obligatoire Code Portefeuille
      Given je vois la section modalities du formulaire
      And j'ajoute une nouvelle ligne de formulaire
      And je selectionne "Code portefeuille" comme critères
      And je vois "Est parmi" afficher comme condition
      When je clique sur le bouton submit
      Then je dois voir "4" erreur(s) de validation avec le text "Veuillez renseigner une valeur."

    Scenario: Affichage d'erreur de valeur obligatoire Nom intermediaire condition et valeur
      Given je vois la section modalities du formulaire
      And j'ajoute une nouvelle ligne de formulaire
      When je selectionne "Nom intermédiaire" comme critères
      And je clique sur le bouton submit
      Then je dois voir "1" erreur(s) de validation avec le text "Veuillez renseigner une condition."
      And je dois voir "4" erreur(s) de validation avec le text "Veuillez renseigner une valeur."

    Scenario: Affichage d'erreur de valeur obligatoire Nom intermediaire valeur
      Given je vois la section modalities du formulaire
      And j'ajoute une nouvelle ligne de formulaire
      And je selectionne "Nom intermédiaire" comme critères
      And je vois une nouvelle liste de selection
      And je selectionne "Est égal à" comme condition
      When je clique sur le bouton submit
      Then je dois voir "4" erreur(s) de validation avec le text "Veuillez renseigner une valeur."
