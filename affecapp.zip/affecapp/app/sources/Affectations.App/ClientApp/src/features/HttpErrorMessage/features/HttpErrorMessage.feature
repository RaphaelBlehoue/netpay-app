Feature: Message app KO

    en tant que Utilisateur IAM_BAFFO_USER
    Je veux voir des messages d'erreur
    Afin de comprendre ce qui ne fonctionne pas.

    Scenario: Aucune message d'erreur n'est initialement visible
        Then Aucun message d'erreur n'est affiché

    Rule: Affichage d'un message d'erreur avec une référence d'erreur
        Scenario: Une erreur HTTP est declanche avec une référence
            And la requête sur la route /api/error retourne une erreur 400 avec la référence "43d3e157-6344-4d91-aa99-fe065520ab3f"
            When je click sur le bouton pour émettre la requête
            Then le message: Une erreur technique est survenue, merci de contacter l'équipe IT avec la référence suivante "43d3e157-6344-4d91-aa99-fe065520ab3f". s'affiche sur la page

    Rule: Affichage de l'erreur 500
        Scenario: Une erreur 500 est déclenchée
            And la requête sur la route /api/error retourne une erreur 500 avec la référence ""
            When je click sur le bouton pour émettre la requête
            Then le message: Une erreur est survenue, Easy Affectation est momentanément indisponible. Veuillez réessayer ultérieurement. s'affiche sur la page

    Rule: Affichage de l'erreur 401
        Scenario: Une erreur 401 est déclenchée
            And la requête sur la route /api/error retourne une erreur 401 avec la référence ""
            When je click sur le bouton pour émettre la requête
            Then le message: Vous avez été déconnecté de l'application Easy Affectation car vous êtes resté inactif pendant 20 min. Veuillez rafraîchir la page. s'affiche sur la page

    Rule: Remplacer un message d'erreur existant avec un nouveau
        Background: Affichage d'un message de déconnexion
            And la requête sur la route /api/error retourne une erreur 401 avec la référence ""
            When je click sur le bouton pour émettre la requête
            Then le message: Vous avez été déconnecté de l'application Easy Affectation car vous êtes resté inactif pendant 20 min. Veuillez rafraîchir la page. s'affiche sur la page
        Scenario: Un message d'erreur 401 est remplacé par un message d'erreur 500
            And la requête sur la route /api/error retourne une erreur 500 avec la référence ""
            When je click sur le bouton pour émettre la requête
            Then le message: Une erreur est survenue, Easy Affectation est momentanément indisponible. Veuillez réessayer ultérieurement. s'affiche sur la page
            And le message "Vous avez été déconnecté de l'application Easy Affectation car vous êtes resté inactif pendant 20 min. Veuillez rafraîchir la page." n'est pas visisible
