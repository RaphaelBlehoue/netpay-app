import { RenderResult } from '@testing-library/react';
import { defineFeature, loadFeature } from 'jest-cucumber';

import { headerColums } from '@affectations/pages/Consultation/useViewModelConsultationDetail';
import modalityByIdMockJson from '@affectations/__apiMocks__/seeds/rules/mocks/get-rules-by-id-200-modality-all.json';
import { RuleDto } from '@affectations/api/bff-clients.generated';
import { renderSetup } from '@affectations/test-utils';

import { ITermsOfTheWizardRules, TermsOfTheWizardRules } from '../TermsOfTheWizardRules';
import { formatRulesModality, HeaderDataType } from '../utils';

const feature = loadFeature('../features/TermsOfTheWizardRules.feature');

defineFeature(feature, test => {
  let result: RenderResult;
  let dataMapping: HeaderDataType[] | [];
  let termsOfTheWizardRulesProps: ITermsOfTheWizardRules;
  test('Affichage des dmodalités de la règle', ({ given, when, then }) => {
    given(/^Je recupère les données d'une règle provenant de mon bff$/, async () => {
      const dataJson: RuleDto = JSON.parse(JSON.stringify(modalityByIdMockJson));
      dataMapping = formatRulesModality(dataJson) as HeaderDataType[];
      termsOfTheWizardRulesProps = {
        rulesMapping: {
          columns: headerColums,
          modalityData: dataMapping,
        },
        isLoading: false,
        isSuccess: true,
        sectionTitle: 'Modalités de règle',
      };
    });

    when(/^je constate que je reçois une reponse de success du bff$/, async () => {
      result = renderSetup(<TermsOfTheWizardRules {...termsOfTheWizardRulesProps} />);
      expect(await result.findByText(/Modalités de règle/)).toBeInTheDocument();
    });
    then(/^je dois voir afficher les données suivantes$/, async modalityData => {
      const expectedData = modalityData.map((data: [string, string, string], index: number) => ({ index, data }));

      for (const { index, data } of expectedData) {
        // eslint-disable-next-line @typescript-eslint/no-unused-vars
        const [critere, _conditions, valeur] = Object.values(data);
        const eltDomCritere = await result.findByText(critere as string | number);
        const eltDomValue = await result.findByText(valeur as string | number);
        expect(eltDomCritere).toBeInTheDocument();
        expect(eltDomCritere.textContent).toEqual(dataMapping[index]?.criteres);
        expect(await result.findAllByText('est parmi')).toHaveLength(13);
        expect(await result.findAllByText('égal à')).toHaveLength(1);
        expect(await result.findAllByText('commence par')).toHaveLength(1);
        expect(eltDomValue).toBeInTheDocument();
        expect(eltDomValue.textContent).toEqual(dataMapping[index]?.valeur);
      }
    });
  });
});
