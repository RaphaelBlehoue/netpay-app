Feature: Section filtres & recherche

    en tant que Utilisateur IAM_BAFFO_USER
    je veux un tableau
    afin de de pouvoir faire de la recherche de règle facilement et rapidement

    Rule: Voir une section filtre et recherche
        Scenario: Les differents filtres sont visibles
            Given Je rends les filtres
            Then les champs suivants sont visibles
                | field                    |
                | Région d'affectation     |
                | Equipe d'affectation     |
                | Collaborateur            |
                | Segmentation             |
                | Branche                  |
                | Réseaux                  |
                | Région distributeur      |
                | Département distributeur |
                | Statut de la règle       |
                | N° Contrat               |
                | Nom d'intermédiaire      |
                | Code portefeuille        |
                | N° Client AXAPAC         |
                | Chargée de clientèle     |
                | Code UV produit          |
                | Clause                   |
                | Code syndic              |
                | Code NAF                 |

    Rule: Menu deroulant
        Background: Navigation sur la page d'accueil
            Given Je rends les filtres

        Scenario: Les menus de region s'affichent
            When Je click sur le select des "Région d'affectation"
            Then La sélection s'affiche pour "Région d'affectation"
            And Les options "Région d'affectation" suivantes sont visibles
                | option        |
                | Ile de France |
                | Nord Est      |
                | Ouest         |
                | Sud Est       |
                | Sud Ouest     |
        Scenario: Les menus de segmentations s'affichent
            When Je click sur le select des "Segmentation"
            Then La sélection s'affiche pour "Segmentation"
            And Les options "Segmentation" suivantes sont visibles
                | option |
                | MB     |
                | ES     |
                | GC     |
        Scenario: Les menus de branches s'affichent
            When Je click sur le select des "Branche"
            Then La sélection s'affiche pour "Branche"
            And Les options "Branche" suivantes sont visibles
                | option           |
                | Auto             |
                | Construction     |
                | RI               |
                | DAB Autre        |
                | MRP              |
                | Collectivité     |
                | RT               |
                | Immeuble         |
                | RC               |
                | RC Chasse        |
                | Transport        |
                | Transport autre  |
                | Caution          |
                | Risques spéciaux |
        Scenario: Les menus de Réseaux s'affichent
            When Je click sur le select des "Réseaux"
            Then La sélection s'affiche pour "Réseaux"
            And Les options "Réseaux" suivantes sont visibles
                | option   |
                | Agent    |
                | Courtier |
                | Salarié  |
        Scenario: Les menus de Région distributeur s'affichent
            When Je click sur le select des "Région distributeur"
            Then La sélection s'affiche pour "Région distributeur"
            And Les options "Région distributeur" suivantes sont visibles
                | option        |
                | Ile de france |
                | Nord Est      |
                | Ouest         |
                | Sud Est       |
                | Sud Ouest     |
        Scenario: Les menus de Département distributeur s'affichent
            When Je click sur le select des "Département distributeur"
            Then La sélection s'affiche pour "Département distributeur"
            And Les options "Département distributeur" suivantes sont visibles
                | option        |
                | Ile de france |
                | Nord Est      |
                | Ouest         |
                | Sud Est       |
                | Sud Ouest     |
        Scenario: Les menus de Statut de la règle s'affichent
            When Je click sur le select des "Statut de la règle"
            Then La sélection s'affiche pour "Statut de la règle"
            And Les options "Statut de la règle" suivantes sont visibles
                | option    |
                | Active    |
                | Brouillon |
                | Expirée   |

    Rule: Reinitialiser la recherche
        Scenario: Le formulaire est Réinitialisé
            Given Je rends les filtres
            When Je remplis des champs du filtres
            And je click sur le bouton de Réinitialisation des champs
            Then Les champs du formulaire sont vides

    Rule: Critère "collaborateur" autocomplétion
        Scenario: La saisie dans le champs "collaborateur" retourne plus de 10 résultats
            Given Je rends les filtres avec les collaborateurs
                | id | lastName     | firstName     |
                | 1  | last name 1  | first name 1  |
                | 2  | last name 2  | first name 2  |
                | 3  | last name 3  | first name 3  |
                | 4  | last name 4  | first name 4  |
                | 5  | last name 5  | first name 5  |
                | 6  | last name 6  | first name 6  |
                | 7  | last name 7  | first name 7  |
                | 8  | last name 8  | first name 8  |
                | 9  | last name 9  | first name 9  |
                | 10 | last name 10 | first name 10 |
                | 11 | last name 11 | first name 11 |
                | 12 | last name 12 | first name 12 |
                | 13 | last name 13 | first name 13 |
                | 14 | last name 14 | first name 14 |
            When Je recherche les collaborateurs "last"
            Then Je vois les collaborateurs
                | id | lastName     | firstName     |
                | 1  | last name 1  | first name 1  |
                | 2  | last name 2  | first name 2  |
                | 3  | last name 3  | first name 3  |
                | 4  | last name 4  | first name 4  |
                | 5  | last name 5  | first name 5  |
                | 6  | last name 6  | first name 6  |
                | 7  | last name 7  | first name 7  |
                | 8  | last name 8  | first name 8  |
                | 9  | last name 9  | first name 9  |
                | 10 | last name 10 | first name 10 |
            And La fonction de recherche est appelée

        Scenario: La saisie dans le champs "collaborateur" ne retourne aucun resultat
            Given Je rends les filtres avec les collaborateurs
                | id | lastName | firstName |
            When Je recherche les collaborateurs "last"
            Then Le texte "Aucun résultat" s'affiche
            And La fonction de recherche est appelée

        Scenario: La saisie dans les champs "collaborateur" commence par des espaces
            Given Je rends les filtres avec les collaborateurs
                | id | lastName | firstName |
            When Je recherche les collaborateurs " last"
            Then La fonction de recherche n'est pas appelée

    Rule: Code syndic
        Background: Navigation sur la page d'accueil
            Given Je rends les filtres

        Scenario Outline: La saisie de "<input>" met "<expected>" dans code syndic
            When Je saisis "<input>" dans le champ "Code syndic"
            Then J'ai le texte "<expected>" dans "Code syndic"

            Examples:
                | input   | expected |
                | 1a      | 1        |
                | 123     | 123      |
                | 1234qa  | 1234     |
                | 12345   | 12345    |
                | 12345as | 12345    |
                | 123456  | 12345    |

        Scenario: Je saisis moins de 5 caractères dans code syndic
            When Je saisis "123" dans le champ "Code syndic"
            Then Le message "Veuillez respecter le format : 5 caractères." est visible

    Rule: Code NAF
        Background: Navigation sur la page d'accueil
            Given Je rends les filtres

        Scenario Outline: La saisie de "<input>" met "<expected>" dans code NAF
            When Je saisis "<input>" dans le champ "Code NAF"
            Then J'ai le texte "<expected>" dans "Code NAF"

            Examples:
                | input      | expected |
                | a          | a        |
                | abc        | abc      |
                | abcd       | abcd     |
                | abcde      | abcde    |
                | abcdef     | abcdef   |
                | abcdefg    | abcdefg  |
                | abcdefgh   | abcdefg  |
                | abcdefghi  | abcdefg  |
                | abcdefghij | abcdefg  |

        Scenario: Je saisis moins de 7 caractères dans code NAF
            When Je saisis "abc" dans le champ "Code NAF"
            Then Le message "Veuillez respecter le format : 7 caractères." est visible

        Scenario Outline: La saisie de "<input>" dans code NAF ne declancle pas de message d'erreur
            When Je saisis "<input>" dans le champ "Code NAF"
            Then Le message 'Le format à respecter est : " PRXMATCH ("/\\b\\d{3}[A-Z012]\\d{3}\\b/' n'est pas visible
            Examples:
                | input   |
                | 100A100 |
                | 100A101 |
                | 100A102 |
                | 100A103 |
                | 100A104 |
                | 100A105 |
                | 100A106 |
                | 100A107 |

        Scenario Outline: La saisie de "<input>" dans code NAF declancle un message d'erreur
            When Je saisis "<input>" dans le champ "Code NAF"
            Then Le message 'Le format à respecter est : " PRXMATCH ("/\b\d{3}[A-Z012]\d{3}\b/' est visible
            Examples:
                | input     |
                | 12A3456   |
                | 12B3D456  |
                | a123A456z |
                | A123456   |
                | 123456A   |
                | 123 A456  |
                | 123A 456  |

    Rule: N° client AXAPAC
        Background: Navigation sur la page d'accueil
            Given Je rends les filtres

        Scenario Outline: La saisie de "<input>" met "<expected>" dans N° client AXAPAC
            When Je saisis "<input>" dans le champ "N° client AXAPAC"
            Then J'ai le texte "<expected>" dans "N° client AXAPAC"

            Examples:
                | input          | expected   |
                | 123456         | 0000123456 |
                | 123456a        | 0000123456 |
                | 1234567        | 0001234567 |
                | 1234567@qwe    | 0001234567 |
                | 12345678       | 0012345678 |
                | 123456789      | 0123456789 |
                | 1234567890     | 1234567890 |
                | 12345678901    | 1234567890 |
                | 123456789012   | 1234567890 |
                | 1234567890123  | 1234567890 |
                | 12345678901234 | 1234567890 |

    Rule: Chargée de clientèle
        Background: Navigation sur la page d'accueil
            Given Je rends les filtres

        Scenario Outline: La saisie de "<input>" met "<expected>" dans Chargée de clientèle
            When Je saisis "<input>" dans le champ "Chargée de clientèle"
            Then J'ai le texte "<expected>" dans "Chargée de clientèle"

            Examples:
                | input      | expected |
                | a          | a        |
                | abc        | abc      |
                | abcd       | abcd     |
                | abcde      | abcde    |
                | abcdef     | abcdef   |
                | abcdefg    | abcdefg  |
                | abcdefgh   | abcdefg  |
                | abcdefghi  | abcdefg  |
                | abcdefghij | abcdefg  |

        Scenario Outline: La saisie de "<input>" dans Chargée de clientèle affiche une erreure
            When Je saisis "<input>" dans le champ "Chargée de clientèle"
            Then Le message "Veuillez respecter le format : 7 caractères maximum." est visible

            Examples:
                | input      |
                | a          |
                | abc        |
                | abcd       |
                | abcde      |
                | abcdef     |
                | abcdefg    |
                | abcdefgh   |
                | abcdefghi  |
                | abcdefghij |
                | SS234575   |
                | SSA34575   |
                | SSAB4575   |
                | SSAB457@   |
                | SSAB4R7@   |

        Scenario Outline: La saisie de "<input>" dans Chargée de clientèle n'affiche pas une erreure
            When Je saisis "<input>" dans le champ "Chargée de clientèle"
            Then Le message "Veuillez respecter le format : 7 caractères maximum" n'est pas visible

            Examples:
                | input    |
                | S1234567 |
                | S1234568 |
                | S1234569 |
                | S1234570 |
                | S1234571 |
                | S1234572 |
                | S1234573 |
                | S1234574 |
                | S1234575 |

    Rule: Code UV Produit
        Background: Navigation sur la page d'accueil
            Given Je rends les filtres

        Scenario Outline: La saisie de "<input>" met "<expected>" dans Code UV Produit
            When Je saisis "<input>" dans le champ "Code UV Produit"
            Then J'ai le texte "<expected>" dans "Code UV Produit"

            Examples:
                | input    | expected |
                | 1        | 1        |
                | 1a       | 1        |
                | 1234     | 1234     |
                | 1234b    | 1234     |
                | 12345    | 12345    |
                | 123456   | 12345    |
                | 123456a  | 12345    |
                | 1234567  | 12345    |
                | 12345678 | 12345    |

    Rule: Clause
        Background: Navigation sur la page d'accueil
            Given Je rends les filtres

        Scenario Outline: La saisie de "<input>" met "<expected>" dans clause
            When Je saisis "<input>" dans le champ "Clause"
            Then J'ai le texte "<expected>" dans "Clause"

            Examples:
                | input    | expected |
                | 1        | 1        |
                | 1a       | 1        |
                | 1234     | 1234     |
                | 1234b    | 1234     |
                | 12345    | 12345    |
                | 123456   | 123456   |
                | 123456a  | 123456   |
                | 1234567  | 123456   |
                | 12345678 | 123456   |

        Scenario Outline: La saisie de "<input>" dans Clause affiche une erreure
            When Je saisis "<input>" dans le champ "Clause"
            Then Le message "Respecter le format de 6 chiffres." est visible

            Examples:
                | input |
                | 1acd  |
                | 21aa  |
                | 1234e |

    Rule: N° contrat
        Background: Navigation sur la page d'accueil
            Given Je rends les filtres

        Scenario Outline: La saisie de "<input>" met "<expected>" dans N° contrat
            When Je saisis "<input>" dans le champ "N° contrat"
            Then J'ai le texte "<expected>" dans "N° contrat"

            Examples:
                | input               | expected         |
                | 1                   | 0000000000000001 |
                | 1a                  | 000000000000001a |
                | 1a)                 | 000000000000001a |
                | 1a=                 | 000000000000001a |
                | 1234                | 0000000000001234 |
                | 1234b               | 000000000001234b |
                | 1234b$              | 000000000001234b |
                | 12345               | 0000000000012345 |
                | 123456              | 0000000000123456 |
                | 123456a             | 000000000123456a |
                | 1234567             | 0000000001234567 |
                | 12345678            | 0000000012345678 |
                | 123456789           | 0000000123456789 |
                | 1234567890123456    | 1234567890123456 |
                | 12345678901234567   | 1234567890123456 |
                | 123456789012345678  | 1234567890123456 |
                | 1234567890123456789 | 1234567890123456 |

    Rule: Code portefeuille
        Scenario Outline: La saisie de "<input>" dans Code portefeuille affiche une erreure
            Given Je rends les filtres
            When Je saisis "<input>" dans le champ "Code portefeuille"
            Then Le message "Veuillez respecter le format de 10 caractères obligatoires." est visible

            Examples:
                | input     |
                | 123       |
                | 1234      |
                | 12345     |
                | 123456    |
                | 1234567   |
                | 123456789 |

        Scenario Outline: La saisie de "<input>" met "<expected>" dans Code portefeuille
            Given Je rends les filtres
            When Je saisis "<input>" dans le champ "Code portefeuille"
            Then J'ai le texte "<expected>" dans "Code portefeuille"

            Examples:
                | input         | expected   |
                | 123456789     | 123456789  |
                | 1234567890    | 1234567890 |
                | 12345678901   | 1234567890 |
                | 123456789012  | 1234567890 |
                | 1234567890123 | 1234567890 |

        Scenario: Le Code portefeuille saisie n'existe pas
            Given La recherche du code portefeuille ne retourne aucun resultat
            When Je saisis "1234567890" dans le champ "Code portefeuille"
            Then Le message "Aucun résultat." est visible

        Scenario: Le Code portefeuille saisie existe
            Given La recherche du code portefeuille retourne une valeur
            When Je saisis "1234567890" dans le champ "Code portefeuille"
            Then Le message "Aucun résultat." n'est pas visible



