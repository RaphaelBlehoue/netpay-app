import { useCallback, useEffect, useMemo, useState } from 'react';
import Table from '@axa-fr/react-toolkit-table';
import clsx from 'clsx';
import { Control, UseFormGetValues, UseFormSetValue } from 'react-hook-form';

import { SelectController, TextInputController, TOption } from '@affectations/components';
import { ReactComponent as IcRemove } from '@affectations/assets/remove_icon.svg';
import { IRuleCriterionCategory } from '@affectations/api/bff-clients.generated';
import { IRuleCategory } from '@affectations/api/rulesCriteria/useGetRulesCriteria';
import { IAffectationFormInputs, TFieldArray } from '@affectations/types';

import {
  ALL_WORDING_OBJECT,
  CELL_CLASSNAME,
  DEFAULT_CRITERIA_KEY,
  findLabelByValue,
  PORTEFOLIO_CODE,
  setConditionField,
  START_TO_SHOW_ICON_REMOVE,
  STATIC_ALL_VALUE_CRITERIA,
} from '../../utils';
import { ConditionalFormInputRenderCondition } from './ConditionalFormInputRenderCondition';
import { ConditionalFormInputRenderValue } from './ConditionalFormInputRenderValue';

import './DynamicTermsOfTheFormFieldRules.scss';

import { CriteriaName } from '@affectations/api/citeria';
import { usePostCriteriaSearch } from '@affectations/api/rulesCriteria/usePostCriteriaSearch';

const { Tr, Td } = Table;

interface IDynamicTermsOfTheFormFieldRules {
  control: Control<IAffectationFormInputs>;
  optionsCriteria: TOption[];
  optionsCondition: TOption[];
  setValue?: UseFormSetValue<IAffectationFormInputs>;
  getValues?: UseFormGetValues<IAffectationFormInputs>;
  valued?: TFieldArray;
  index: number;
  labelIcon?: string;
  dataId: string;
  currentMuliSelectOptions?: Record<string, IRuleCategory>;
  onRemove: (id: number) => void;
  onSelectedChange?: (value?: string) => void;
  onSelectUpdate?: (value: Record<number, string>) => void;
}
const DynamicTermsOfTheFormFieldRules = ({
  optionsCriteria,
  optionsCondition,
  labelIcon,
  setValue,
  getValues,
  onRemove,
  onSelectUpdate = () => {},
  currentMuliSelectOptions,
  control,
  valued,
  dataId,
  index,
}: IDynamicTermsOfTheFormFieldRules) => {
  const [currentCriteria, setCurrentCriteria] = useState<CriteriaName>(STATIC_ALL_VALUE_CRITERIA.INTERMEDIARY_NAME);
  const { searchCriteriaPost } = usePostCriteriaSearch({ criteria: currentCriteria });
  const [availableCurrent, setAvailableCurrent] = useState<TOption>();
  const currentOptionsCriteria = useMemo(() => {
    if (!availableCurrent) {
      return optionsCriteria;
    }
    return [...optionsCriteria, availableCurrent];
  }, [availableCurrent, optionsCriteria]);

  const currentCriteriaValue = useMemo(() => {
    const current = valued?.criteria;
    if (!current) {
      return [];
    }
    if (currentMuliSelectOptions === undefined) {
      return [];
    }
    const ruleCriteria = currentMuliSelectOptions[current]?.ruleCriteria;
    const updatedRuleCriteria = ruleCriteria !== undefined ? [ALL_WORDING_OBJECT, ...ruleCriteria] : [];
    return updatedRuleCriteria.reduce<IRuleCriterionCategory[]>((acc, element) => {
      const currrentElement = {
        label: element?.label,
        value: element?.code,
      };
      return [...acc, currrentElement];
    }, []);
  }, [currentMuliSelectOptions, valued?.criteria]);

  const setConditionChange = useCallback(
    (currentValue: string | undefined) => {
      const conditionValues = setConditionField(currentValue);
      setValue && setValue(`modalities.${index}.condition`, conditionValues);
    },
    [index, setValue]
  );

  const handleSelectChange = () => {
    const oldValue = valued?.criteria;
    setConditionChange(oldValue);
    oldValue && setAvailableCurrent(optionsCriteria.find(Item => oldValue === Item.value));
    onSelectUpdate({
      [dataId]: oldValue ?? '',
    });
  };

  const isDefaultField = useMemo(() => {
    if (!valued || !valued.criteria) {
      return false;
    }
    const criteria = valued.criteria;
    return (
      criteria === DEFAULT_CRITERIA_KEY.BRANCH ||
      criteria === DEFAULT_CRITERIA_KEY.DISTRIBUTION_REGION ||
      criteria === DEFAULT_CRITERIA_KEY.SEGMENTATION
    );
  }, [valued]);

  const setDefaultLabel = useMemo(() => {
    return isDefaultField && findLabelByValue(valued?.criteria);
  }, [isDefaultField, valued?.criteria]);

  useEffect(() => {
    if (valued?.criteria === STATIC_ALL_VALUE_CRITERIA.CODE_PORTEFEUILLE) {
      setCurrentCriteria(PORTEFOLIO_CODE);
    } else {
      setCurrentCriteria(STATIC_ALL_VALUE_CRITERIA.INTERMEDIARY_NAME);
    }
  }, [valued?.criteria]);

  return (
    <Tr className="af-table__tr">
      <Td className={clsx(CELL_CLASSNAME, 'af-field__criteria')}>
        {isDefaultField ? (
          <TextInputController
            name={`modalities.${index}.criteria`}
            label={setDefaultLabel || ''}
            control={control as unknown as Control}
            aria-label={valued?.criteria}
            inputContainerClassName="af-form__text"
            inputFieldClassName="af-form__input-text af-form__disabled"
            value={valued?.criteria}
            placeholder={`modalities.${index}.criteria`}
            type="hidden"
            isDisabled
            hasRequiredContent
          />
        ) : (
          <SelectController
            name={`modalities.${index}.criteria`}
            options={currentOptionsCriteria}
            selectAdditionnalClassName="text"
            control={control as unknown as Control}
            onSelectChange={handleSelectChange}
            id={`modalities.${index}.criteria`}
            aria-label={`modalities.${index}.criteria`}
            placeholder="- Sélectionner -"
          />
        )}
      </Td>
      <Td className={clsx(CELL_CLASSNAME, 'af-field__condition')}>
        <ConditionalFormInputRenderCondition
          control={control}
          fieldName={`modalities.${index}.condition`}
          conditionState={valued?.criteria}
          options={optionsCondition}
        />
      </Td>
      <Td className={clsx(CELL_CLASSNAME, 'af-field-rules__cell-dynamic')}>
        <ConditionalFormInputRenderValue
          name={`modalities.${index}.rules`}
          control={control}
          filterAutoCompleteAsync={searchCriteriaPost}
          setValue={setValue}
          getValues={getValues}
          valuedState={valued}
          options={currentCriteriaValue as TOption[]}
        />
        {index > START_TO_SHOW_ICON_REMOVE && (
          <div className="af-field-rules">
            <button
              type="button"
              className="af-field-rules__remove-btn"
              aria-label={`${labelIcon}${index}`}
              onClick={() => onRemove(index)}
            >
              <IcRemove />
            </button>
          </div>
        )}
      </Td>
    </Tr>
  );
};

export { DynamicTermsOfTheFormFieldRules };
