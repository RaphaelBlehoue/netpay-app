import { act, render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { defineFeature, DefineStepFunction, loadFeature } from 'jest-cucumber';
import { Mock } from 'vitest';

import { TOption } from '@affectations/components';
import collaboratorsMock from '@affectations/__apiMocks__/seeds/employees/mocks/get-all-employees.json';

import RuleFilters, { type FilterFields } from '../RuleFilters';

const feature = loadFeature('../features/RuleFilters.feature');

let user = userEvent.setup();

const fields: FilterFields = {
  affectationRegions: [
    { label: 'Ile de France', value: '1', isSelected: false },
    { label: 'Nord Est', value: '2', isSelected: false },
    { label: 'Ouest', value: '3', isSelected: false },
    { label: 'Sud Est', value: '4', isSelected: false },
    { label: 'Sud Ouest', value: '5', isSelected: false },
  ],
  affectationTeams: [
    { label: 'Tester', value: '11', isSelected: false },
    { label: 'Tester 1', value: '112', isSelected: false },
    { label: 'Tester 1', value: '1123', isSelected: false },
  ],
  segmentations: [
    { label: 'MB', value: '1', isSelected: false },
    { label: 'ES', value: '2', isSelected: false },
    { label: 'GC', value: '3', isSelected: false },
  ],
  branches: [
    { label: 'Auto', value: '1', isSelected: false },
    { label: 'Construction', value: '2', isSelected: false },
    { label: 'RI', value: '3', isSelected: false },
    { label: 'DAB Autre', value: '4', isSelected: false },
    { label: 'MRP', value: '5', isSelected: false },
    { label: 'Collectivité', value: '6', isSelected: false },
    { label: 'RT', value: '7', isSelected: false },
    { label: 'Immeuble', value: '8', isSelected: false },
    { label: 'RC', value: '9', isSelected: false },
    { label: 'RC Chasse', value: '10', isSelected: false },
    { label: 'Transport', value: '11', isSelected: false },
    { label: 'Transport autre', value: '12', isSelected: false },
    { label: 'Caution', value: '13', isSelected: false },
    { label: 'Risques spéciaux', value: '14', isSelected: false },
  ],
  networks: [
    { label: 'Agent', value: '1', isSelected: false },
    { label: 'Courtier', value: '2', isSelected: false },
    { label: 'Salarié', value: '3', isSelected: false },
  ],
  regionDistributions: [
    { label: 'Ile de france', value: '1', isSelected: false },
    { label: 'Nord Est', value: '2', isSelected: false },
    { label: 'Ouest', value: '3', isSelected: false },
    { label: 'Sud Est', value: '4', isSelected: false },
    { label: 'Sud Ouest', value: '5', isSelected: false },
  ],
  departmentDistributions: [
    { label: 'Ile de france', value: '1', isSelected: false },
    { label: 'Nord Est', value: '2', isSelected: false },
    { label: 'Ouest', value: '3', isSelected: false },
    { label: 'Sud Est', value: '4', isSelected: false },
    { label: 'Sud Ouest', value: '5', isSelected: false },
  ],
  ruleStatus: [
    { label: 'Active', value: '1', isSelected: false },
    { label: 'Brouillon', value: '2', isSelected: false },
    { label: 'Expirée', value: '3', isSelected: false },
  ],
};

const filterColors = (inputValue: string) => {
  return collaboratorsMock
    .map<TOption>(x => ({ label: `${x.lastName} ${x.firstName} - ${x.id}`, value: x.id }))
    .filter(x => x.label.toLowerCase().startsWith(inputValue.toLowerCase()));
};
const promiseOptions = (inputValue: string) =>
  new Promise<TOption[]>(resolve => {
    setTimeout(() => {
      resolve(filterColors(inputValue));
    }, 1000);
  });

const searchCriteria = vi.fn().mockReturnValue(Promise.resolve({ data: [{}] }));

const selectAllItems = async (label: string) => {
  const btn = screen.getByLabelText(`${label} button`);
  userEvent.click(btn);
  const select = screen.getByLabelText(`${label} select`);
  const all = within(select).getByText(/toutes \(/i);
  await userEvent.click(all);
  const regex = new RegExp(`${label} \\(`);
  expect(screen.getByText(regex)).toBeInTheDocument();
};

const givenHomePageNavigation = (given: DefineStepFunction) =>
  given('Je rends les filtres', async () => {
    await waitFor(() =>
      render(
        <RuleFilters
          criterias={fields}
          filterCollaboratorsAsync={promiseOptions}
          searchCriteria={searchCriteria}
          onSubmit={() => {}}
        />
      )
    );
  });

const whenIClickOnSelect = (when: DefineStepFunction) =>
  when(/Je click sur le select des "(.*)"/i, async (select: string) => {
    const list = screen.getByLabelText(`${select} button`);
    const options = screen.getByLabelText(`${select} select`);
    expect(options).toBeInTheDocument();
    expect(options).not.toHaveClass('visible');
    await act(() => userEvent.click(list));
  });

const thenSelectIsVisible = (then: DefineStepFunction) =>
  then(/La sélection s'affiche pour "(.*)"/i, (select: string) => {
    const options = screen.getByLabelText(`${select} select`);
    expect(options).toBeInTheDocument();
    expect(options).toHaveClass('visible');
  });

const andOptionsAreVisible = (and: DefineStepFunction) =>
  and(/Les options "(.*)" suivantes sont visibles/i, async (select: string, options: { option: string }[]) => {
    const selectField = await waitFor(() => screen.getByLabelText(`${select} select`));
    await Promise.all(
      options.map(async ({ option }) => {
        const opt = await waitFor(() => within(selectField).getByText(option));
        expect(opt).toBeInTheDocument();
        expect(opt).toBeVisible();
      })
    );
  });

let mockSearch: Mock | undefined = undefined;

const givenIRenderFiltersWithCollaboratorsSearch = (given: DefineStepFunction) =>
  given(
    'Je rends les filtres avec les collaborateurs',
    async (data: { lastName: string; firstName: string; id: string }[]) => {
      const mockCollaboration = data.map(x => ({ label: `${x.lastName} ${x.firstName} - ${x.id}`, value: x.id }));
      mockSearch = vi.fn().mockReturnValue(Promise.resolve(mockCollaboration));
      await waitFor(() =>
        render(<RuleFilters criterias={fields} filterCollaboratorsAsync={mockSearch as never} onSubmit={() => {}} />)
      );
    }
  );

let optionsCountBeforeSearch = 0;

const whenISearchCollaborators = (when: DefineStepFunction) =>
  when(/Je recherche les collaborateurs "(.*)"/i, async (input: string) => {
    const collaboratorField = screen.getByLabelText(/Collaborateur/i);
    optionsCountBeforeSearch = screen.getAllByRole('option').length ?? 0;
    await user.type(collaboratorField, input);
    expect(collaboratorField).toHaveValue(input);
  });

const thenISeeCollaboratorResults = (then: DefineStepFunction) =>
  then('Je vois les collaborateurs', async (data: { lastName: string; firstName: string; id: string }[]) => {
    data.forEach(x => {
      const option = screen.getByText(`${x.lastName} ${x.firstName} - ${x.id}`);
      expect(option).toBeInTheDocument();
    });

    const optionsCountAfterSearch = screen.getAllByRole('option').length ?? 0;
    expect(optionsCountAfterSearch - 10).toBe(optionsCountBeforeSearch);
  });

const thenTheSearchFunctionIsCalled = (then: DefineStepFunction) =>
  then('La fonction de recherche est appelée', () => expect(mockSearch).toHaveBeenCalled());

const thenTheSearchFunctionIsNotCalled = (then: DefineStepFunction) =>
  then("La fonction de recherche n'est pas appelée", () => expect(mockSearch).not.toHaveBeenCalled());

const whenIWritteTextInField = (when: DefineStepFunction) =>
  when(/^Je saisis "(.*)" dans le champ "(.*)"$/i, async (inputText: string, fieldName: string) => {
    const name = new RegExp(fieldName, 'i');
    const field = screen.getByRole('textbox', { name });
    await user.type(field, inputText);
    await user.tab();
  });

const thenTheInputContainsThisText = (then: DefineStepFunction) =>
  then(/^J'ai le texte "(.*)" dans "(.*)"$/i, (expectedText: string, fieldName: string) => {
    const name = new RegExp(fieldName, 'i');
    const field = screen.getByRole('textbox', { name });
    expect(field).toHaveValue(expectedText);
  });

const thenTheMessageIsVisible = (then: DefineStepFunction) =>
  then(/^Le message "(.*)" est visible$/i, async (msg: string) => {
    const message = await screen.findByText(msg);
    expect(message).toBeInTheDocument();
  });

const thenTheMessageIsNotVisible = (then: DefineStepFunction) =>
  then(/^Le message "(.*)" n'est pas visible$/i, async (msg: string) => {
    const message = await waitFor(() => screen.queryByText(msg));
    expect(message).not.toBeInTheDocument();
  });

defineFeature(feature, test => {
  beforeEach(() => {
    user = userEvent.setup();
  });

  test('Les differents filtres sont visibles', ({ then, given }) => {
    givenHomePageNavigation(given);
    then('les champs suivants sont visibles', async (data: { field: string }[]) => {
      await Promise.all(
        data.map(async ({ field }) => {
          const label = await waitFor(() => screen.getByText(field, { exact: true }));
          expect(label).toBeInTheDocument();
          expect(label).toBeVisible();
        })
      );
    });
  });

  test("Les menus de region s'affichent", ({ when, then, and, given }) => {
    givenHomePageNavigation(given);
    whenIClickOnSelect(when);
    thenSelectIsVisible(then);
    andOptionsAreVisible(and);
  });

  test("Les menus de segmentations s'affichent", ({ when, then, and, given }) => {
    givenHomePageNavigation(given);
    whenIClickOnSelect(when);
    thenSelectIsVisible(then);
    andOptionsAreVisible(and);
  });

  test("Les menus de branches s'affichent", ({ when, then, and, given }) => {
    givenHomePageNavigation(given);
    whenIClickOnSelect(when);
    thenSelectIsVisible(then);
    andOptionsAreVisible(and);
  });

  test("Les menus de Réseaux s'affichent", ({ when, then, and, given }) => {
    givenHomePageNavigation(given);
    whenIClickOnSelect(when);
    thenSelectIsVisible(then);
    andOptionsAreVisible(and);
  });

  test("Les menus de Région distributeur s'affichent", ({ when, then, and, given }) => {
    givenHomePageNavigation(given);
    whenIClickOnSelect(when);
    thenSelectIsVisible(then);
    andOptionsAreVisible(and);
  });

  test("Les menus de Département distributeur s'affichent", ({ when, then, and, given }) => {
    givenHomePageNavigation(given);
    whenIClickOnSelect(when);
    thenSelectIsVisible(then);
    andOptionsAreVisible(and);
  });

  test("Les menus de Statut de la règle s'affichent", ({ when, then, and, given }) => {
    givenHomePageNavigation(given);
    whenIClickOnSelect(when);
    thenSelectIsVisible(then);
    andOptionsAreVisible(and);
  });

  test('Le formulaire est Réinitialisé', ({ when, and, then, given }) => {
    givenHomePageNavigation(given);
    when('Je remplis des champs du filtres', async () => {
      await selectAllItems('Statut de la règle');
      const textField = screen.getByLabelText("Nom d'intermédiaire");
      await userEvent.type(textField, 'content');
      expect(textField).toHaveValue('content');
    });
    and('je click sur le bouton de Réinitialisation des champs', async () => {
      const resetBtn = screen.getByText(/Réinitialiser les filtres/i);
      await userEvent.click(resetBtn);
    });
    then('Les champs du formulaire sont vides', async () => {
      const textField = screen.getByLabelText("Nom d'intermédiaire");
      expect(textField).toHaveValue('');
      expect(screen.queryByText(/Nom d'intermédiaire \/ Code portefeuille \(/i)).not.toBeInTheDocument();
    });
  });

  test('La saisie dans le champs "collaborateur" retourne plus de 10 résultats', ({ given, when, then, and }) => {
    givenIRenderFiltersWithCollaboratorsSearch(given);
    whenISearchCollaborators(when);
    thenISeeCollaboratorResults(then);
    thenTheSearchFunctionIsCalled(and);
  });

  test('La saisie dans le champs "collaborateur" ne retourne aucun resultat', ({ given, when, then, and }) => {
    givenIRenderFiltersWithCollaboratorsSearch(given);

    whenISearchCollaborators(when);

    then(/^Le texte "(.*)" s'affiche$/, async (value: string) => {
      const msg = await waitFor(() => screen.getByText(value));
      expect(msg).toBeInTheDocument();
    });

    thenTheSearchFunctionIsCalled(and);
  });

  test('La saisie dans les champs "collaborateur" commence par des espaces', ({ given, when, then }) => {
    givenIRenderFiltersWithCollaboratorsSearch(given);
    whenISearchCollaborators(when);
    thenTheSearchFunctionIsNotCalled(then);
  });

  test('La saisie de "<input>" met "<expected>" dans code syndic', ({ given, when, then }) => {
    givenHomePageNavigation(given);
    whenIWritteTextInField(when);
    thenTheInputContainsThisText(then);
  });

  test('Je saisis moins de 5 caractères dans code syndic', ({ given, when, then }) => {
    givenHomePageNavigation(given);
    whenIWritteTextInField(when);
    thenTheMessageIsVisible(then);
  });

  test('La saisie de "<input>" met "<expected>" dans code NAF', ({ given, when, then }) => {
    givenHomePageNavigation(given);
    whenIWritteTextInField(when);
    thenTheInputContainsThisText(then);
  });

  test('Je saisis moins de 7 caractères dans code NAF', ({ given, when, then }) => {
    givenHomePageNavigation(given);
    whenIWritteTextInField(when);
    thenTheMessageIsVisible(then);
  });

  test('La saisie de "<input>" dans code NAF ne declancle pas de message d\'erreur', ({ given, when, then }) => {
    givenHomePageNavigation(given);
    whenIWritteTextInField(when);
    then(/Le message '.*' n'est pas visible/i, async () => {
      const message = await waitFor(() =>
        screen.queryByText('Le format à respecter est : " PRXMATCH ("/\\b\\d{3}[A-Z012]\\d{3}\\b/')
      );
      expect(message).not.toBeInTheDocument();
    });
  });

  test('La saisie de "<input>" dans code NAF declancle un message d\'erreur', ({ given, when, then }) => {
    givenHomePageNavigation(given);
    whenIWritteTextInField(when);
    then(/Le message '.*' est visible/i, async () => {
      const message = await waitFor(() =>
        screen.queryByText('Le format à respecter est : " PRXMATCH ("/\\b\\d{3}[A-Z012]\\d{3}\\b/')
      );
      expect(message).toBeInTheDocument();
    });
  });

  test('La saisie de "<input>" met "<expected>" dans N° client AXAPAC', ({ given, when, then }) => {
    givenHomePageNavigation(given);
    whenIWritteTextInField(when);
    thenTheInputContainsThisText(then);
  });

  test('La saisie de "<input>" met "<expected>" dans Chargée de clientèle', ({ given, when, then }) => {
    givenHomePageNavigation(given);
    whenIWritteTextInField(when);
    thenTheInputContainsThisText(then);
  });

  test('La saisie de "<input>" dans Chargée de clientèle affiche une erreure', ({ given, when, then }) => {
    givenHomePageNavigation(given);
    whenIWritteTextInField(when);
    thenTheMessageIsVisible(then);
  });

  test('La saisie de "<input>" dans Chargée de clientèle n\'affiche pas une erreure', ({ given, when, then }) => {
    givenHomePageNavigation(given);
    whenIWritteTextInField(when);
    thenTheMessageIsNotVisible(then);
  });

  test('La saisie de "<input>" met "<expected>" dans Code UV Produit', ({ given, when, then }) => {
    givenHomePageNavigation(given);
    whenIWritteTextInField(when);
    thenTheInputContainsThisText(then);
  });

  test('La saisie de "<input>" met "<expected>" dans clause', ({ given, when, then }) => {
    givenHomePageNavigation(given);
    whenIWritteTextInField(when);
    thenTheInputContainsThisText(then);
  });

  test('La saisie de "<input>" dans Clause affiche une erreure', ({ given, when, then }) => {
    givenHomePageNavigation(given);
    whenIWritteTextInField(when);
    thenTheMessageIsVisible(then);
  });

  test('La saisie de "<input>" met "<expected>" dans N° contrat', ({ given, when, then }) => {
    givenHomePageNavigation(given);
    whenIWritteTextInField(when);
    thenTheInputContainsThisText(then);
  });

  test('La saisie de "<input>" dans Code portefeuille affiche une erreure', ({ given, when, then }) => {
    givenHomePageNavigation(given);
    whenIWritteTextInField(when);
    thenTheMessageIsVisible(then);
  });

  test('La saisie de "<input>" met "<expected>" dans Code portefeuille', ({ given, when, then }) => {
    givenHomePageNavigation(given);
    whenIWritteTextInField(when);
    thenTheInputContainsThisText(then);
  });

  test("Le Code portefeuille saisie n'existe pas", ({ given, when, then }) => {
    const search = vi.fn().mockReturnValue(Promise.resolve({ data: [] }));
    given(/^La recherche du code portefeuille ne retourne aucun resultat$/i, async () => {
      await waitFor(() =>
        render(
          <RuleFilters
            criterias={fields}
            filterCollaboratorsAsync={promiseOptions}
            searchCriteria={search}
            onSubmit={() => {}}
          />
        )
      );
    });
    whenIWritteTextInField(when);
    then(/^Le message ".*" est visible$/i, async () => {
      expect(search).toHaveBeenCalledWith('PORTFOLIO_CODE', '1234567890');
    });
  });

  test('Le Code portefeuille saisie existe', ({ given, when, then }) => {
    given(/^La recherche du code portefeuille retourne une valeur$/i, async () => {
      const search = vi.fn().mockReturnValue(Promise.resolve({ data: [{}] }));
      await waitFor(() =>
        render(
          <RuleFilters
            criterias={fields}
            filterCollaboratorsAsync={promiseOptions}
            searchCriteria={search}
            onSubmit={() => {}}
          />
        )
      );
    });
    whenIWritteTextInField(when);
    thenTheMessageIsNotVisible(then);
  });
});
