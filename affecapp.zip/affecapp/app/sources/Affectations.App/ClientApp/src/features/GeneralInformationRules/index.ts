import GeneralInformationRules from './GeneralInformationRules';

export { GeneralInformationRules };
