Feature: Consultation règle - Modalités de la règle - IARDENT-55629

  Rule: Consultation des modalités de la règle

    Scenario: Affichage des dmodalités de la règle
      Given Je recupère les données d'une règle provenant de mon bff
      When je constate que je reçois une reponse de success du bff
      Then je dois voir afficher les données suivantes
        | critere                  | conditions   | valeur                              |
        | segmentation             | est parmi    | MB                                  |
        | Région distributeur      | est parmi    | 64                                  |
        | Reseau                   | est parmi    | Courtier                            |
        | Branche                  | est parmi    | Transport autre                     |
        | COPHT (€)                | égal à       | 999 999 999,99                      |
        | Département distributeur | est parmi    | 01                                  |
        | Catégorie du contrat QP  | est parmi    | Ceci est un exemple pour easyq      |
        | Code UV produit          | est parmi    | 1A234                               |
        | Nom intermédiaire        | commence par | Alain&Nicole 123 - Boutique/Magasin |
        | Code portefeuille        | est parmi    | 0000012345                          |
        | Clause                   | est parmi    | 012345                              |
        | Code Syndic              | est parmi    | 01234                               |
        | Code NAF                 | est parmi    | 12345ABCDE                          |
        | N° client AXAPAC         | est parmi    | 000E012345                          |
        | Chargé de clientèle      | est parmi    | 000E012                             |
        | N° contrat               | est parmi    | 000E012345678912                    |
