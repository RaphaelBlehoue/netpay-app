import { clsx } from 'clsx';

import { rowRulesType } from '@affectations/features/commonTypes';

const FIRST_RULES = 'infos-1';

const RowHeaderInformation = ({ label, content, id }: rowRulesType) => {
  const isFirst = id === FIRST_RULES;
  return (
    <section className="headerInformations-rules__content" id={id}>
      <div className="list-group">
        <span className={clsx('list-label', isFirst && 'input-required')}>{label}</span>
      </div>
      <div className="list-group">
        <strong>{content}</strong>
      </div>
    </section>
  );
};

export { RowHeaderInformation };
