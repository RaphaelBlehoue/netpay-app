import { useCallback, useEffect, useMemo, useState } from 'react';
import clsx from 'clsx';
import { Control, useFieldArray, UseFormGetValues, UseFormReset, UseFormSetValue, UseFormWatch } from 'react-hook-form';

import { Button } from '@affectations/components';
import { ButtonClassModifiers } from '@affectations/components/ui/Button/types';
import { TableContainer } from '@affectations/components/ui/Table/TableContainer';
import { ReactComponent as IcReset } from '@affectations/assets/reset-icon.svg';
import { ReactComponent as IcPlusSign } from '@affectations/assets/sign-plus.svg';
import { IRuleCategory } from '@affectations/api/rulesCriteria/useGetRulesCriteria';

import { DynamicTermsOfTheFormFieldRules } from './components/AddForm/DynamicTermsOfTheFormFieldRules';
import {
  DEFAULT_MODALITIES,
  HEADER_TABLE,
  INIT_MODALITIES,
  REMOVE_IDS_LIST,
  removeEmptyObject,
  STATIC_FILTER_CRITERIA,
} from './utils';

import './TermsOfTheWizardRules.scss';

import { IAffectationFormInputs } from '@affectations/types';

const SECTION_TITLE = 'Modalités de la règle';

interface ITermsOfTheWizardRules {
  control: Control<IAffectationFormInputs>;
  reset: UseFormReset<IAffectationFormInputs>;
  watch: UseFormWatch<IAffectationFormInputs>;
  setValue?: UseFormSetValue<IAffectationFormInputs>;
  getValues?: UseFormGetValues<IAffectationFormInputs>;
  maxline: number;
  AllCriteriaOptions?: Record<string, IRuleCategory>;
}

const AddTermsOfTheWizardRules = ({
  maxline,
  AllCriteriaOptions,
  control,
  reset,
  watch,
  setValue,
  getValues,
}: ITermsOfTheWizardRules) => {
  const [currentList, setCurrentList] = useState<Record<string, string>>({});
  const { fields, append, remove } = useFieldArray({
    control,
    name: 'modalities',
  });

  const watchModalities = watch('modalities');
  const availabeOptions = useMemo(() => {
    return STATIC_FILTER_CRITERIA.filter((item, _index) => !Object.values(currentList).includes(item.value));
  }, [currentList]);

  const handleSelectChange = useCallback((e: Record<number, string>) => {
    setCurrentList(prev => {
      return {
        ...removeEmptyObject(prev),
        ...e,
      };
    });
  }, []);

  const addModalities = () => {
    append(DEFAULT_MODALITIES);
  };

  const insertClassModifiers = [
    ...(fields.length >= maxline ? [ButtonClassModifiers.Disabled] : []),
    ButtonClassModifiers.Reverse,
  ];

  const removeModalities = (id: number, dataId: string) => {
    setCurrentList(prev => {
      return {
        ...removeEmptyObject(prev, dataId),
      };
    });
    fields.length && remove(id);
  };

  const resetAll = useCallback(() => {
    remove(REMOVE_IDS_LIST);
    reset(INIT_MODALITIES);
    setCurrentList({});
  }, [remove, reset]);

  useEffect(() => {
    resetAll();
  }, [resetAll]);

  const haveDynamicField = fields.length > 0;

  return (
    <>
      <h2 className="af-title">{SECTION_TITLE}</h2>
      <div className="af-terms-of-the-wizard-rules">
        <div className="af-terms-of-the-wizard-rules__list">
          <TableContainer title="Modalites-de-la-regle" headerColumns={HEADER_TABLE.columns}>
            {fields.map((item, index) => (
              <DynamicTermsOfTheFormFieldRules
                key={item.id}
                dataId={item.id}
                control={control}
                index={index}
                getValues={getValues}
                setValue={setValue}
                onSelectUpdate={handleSelectChange}
                valued={watchModalities[index]}
                optionsCriteria={availabeOptions}
                optionsCondition={[]}
                currentMuliSelectOptions={AllCriteriaOptions}
                labelIcon="remove rule"
                onRemove={() => removeModalities(index, item.id)}
              />
            ))}
          </TableContainer>
        </div>
        <div className="af-terms-of-the-wizard-rules--add-btn">
          <Button
            title="Ajouter un critère"
            wrapperClassName="af-terms-of-the-wizard-rules"
            classModifiers={insertClassModifiers}
            classNames={clsx(haveDynamicField && 'add-modalities--btn', !haveDynamicField && 'not-reset-all')}
            icon={<IcPlusSign className="af-terms-of-the-wizard-rules--icon" title="icon-plus" aria-label="iconplus" />}
            type="button"
            onClick={addModalities}
            isDisabled={fields.length >= maxline}
          />
          <Button
            title="Réinitialiser les critères"
            wrapperClassName="af-terms-of-the-wizard-rules"
            classNames="reset-all-modalities--btn"
            className={clsx('btn-remove')}
            icon={<IcReset className="af-terms-of-the-wizard-rules--icon" aria-label="reinitialiser critere" />}
            aria-label="Réinitialiser les critères"
            type="button"
            onClick={() => resetAll()}
          />
        </div>
      </div>
    </>
  );
};

export { AddTermsOfTheWizardRules };
