### here's how we'd like this folder to be organized with indications and roles in brackets

```
|   README.md
|
+---affectations (feature)
    |   affectation.feature
    |   affectation-edit.feature
    |   index.ts
    |
    +---components
    |       Component1.tsx
    |       Component2.tsx
    |       (Feature*)ViewModelServices.ts
    |
    +---routes
    |       AffectationList.tsx
    |       AffectationEdit.tsx
    |       index.ts
    |
    \---__tests__
\---authentification
    |   login.feature
    |   recover-password.feature
    |   index.ts
    |
    +---components
    |       FormLogin.tsx
    |       FormRecoverPassword.tsx
    |       authViewModelServices.ts
    |
    +---routes
    |       Login.tsx
    |       RecoverPassword.tsx
    |       index.ts
    |
    \---__tests__
```
