Feature:  Création d'une règle - Configuration critères/conditions - Liste déroulante IARDENT-56364

  Rule: Possibilité de sélectionner une/plusieurs/toutes valeurs d'une liste

    Scenario: Affichage d'une valeur sélectionnée dans le champs de saisie autre que tous/toutes
      Given j'ai une liste deroulante ouverte avec des valeurs
      When je coche une ou plusieurs valeurs autre que Tous/toutes
      Then je dois avoir la ou les valeurs cochées affichées dans la liste

    Scenario: Affichage de plusieurs valeurs sélectionnées dans le champs de saisie autre que tous/toutes
      Given j'ai une liste deroulante ouverte avec des valeurs
      When je coche une ou plusieurs valeurs autre que Tous/toutes
      Then je dois avoir la ou les valeurs cochées affichées dans la liste

    Scenario: Affichage de la valeur "tous/toutes" dans le champs de saisie quand toute est coché
      Given j'ai une liste deroulante ouverte avec des valeurs
      When je coche la valeur Tous / toutes
      Then je dois avoir la valeurs Tous / toutes affichée et toutes les valeurs cochées dans la liste

    Scenario: Affichage de la valeur "tous/toutes" dans le champs de saisie quand toutes les valeurs sont cochées
      Given j'ai une liste deroulante ouverte avec des valeurs
      When je coche toute les valeurs de la liste deroulante
      Then je dois avoir la valeurs Tous / toutes affichée et toutes les valeurs cochées dans la liste
