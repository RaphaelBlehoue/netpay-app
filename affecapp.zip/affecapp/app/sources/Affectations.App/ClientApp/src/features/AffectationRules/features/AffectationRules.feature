Feature:  Création d’une règle – Affectation & Enregistrement-Validation IARDENT-55106

  Rule: Affichage des règles de validation des champs inputs

    Scenario: Affichage de l'erreur de règle de valeur obligatoire
      Given je vois la section Affectation du formulaire
      When je clique sur le bouton submit
      Then je dois voir "1" erreur(s) de validation avec le text "Ce champs est obligatoire"

    Scenario: Affichage du nom de la valeur de region
      Given je vois la section Affectation du formulaire
      When je selectionne "ES_AUTO_NE" comme valeur de team
      Then je dois voir "Nord Est" comme nom de region afficher

    Scenario: Affichage du message d'erreur de l'autocomplétion
      Given je vois la section Affectation du formulaire
      When je saisie une donnée "qazi" qui n'existe pas
      Then je dois voir "1" erreur(s) de validation avec le text "Aucun resultat"
      And le champs doit avoir la donnée "qazi"
