import { BadgeClassModifiers } from '@affectations/components/ui/Badge/types';

export type rowRulesType = {
  label: string;
  content?: string;
  id?: string;
};

export type rowHeaderType = {
  createDate?: Date | string;
  title?: string;
  status?: string;
  badgeStatus?: BadgeClassModifiers;
  createContent?: string;
  updateContent?: string;
};

export type TDataInput = { name: string; value: string; id: string };
