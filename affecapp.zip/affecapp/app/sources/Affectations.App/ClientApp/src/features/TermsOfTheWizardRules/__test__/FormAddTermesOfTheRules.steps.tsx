import { act, screen, waitFor } from '@testing-library/react';
import { UserEvent } from '@testing-library/user-event';
import { defineFeature, DefineStepFunction, loadFeature } from 'jest-cucumber';
import { useForm } from 'react-hook-form';

import { Button } from '@affectations/components';
import { useModelAffectationRules } from '@affectations/pages/affectations/useViewModelAffectationRules';
import { BUTTON_TITLE } from '@affectations/pages/affectations/utils';
import { AppContextProvider } from '@affectations/contexts/AppContextProvider';
import { CONSULTATION_RULE_ID_DETAIL } from '@affectations/routes/configRoute';
import { renderMemoryRouter } from '@affectations/test-utils';
import { IAffectationFormInputs } from '@affectations/types';

import { AddTermsOfTheWizardRules } from '../AddTermsOfTheWizardRules';

const feature = loadFeature('../features/FormAddTermesOfTheRules.feature');

const FormSectionTermsOfTheRules = ({ max, ...props }: { max: number }) => {
  const { reset, watch, control, handleSubmit } = useForm<IAffectationFormInputs>({ mode: 'all' });
  const { multiSelectionOptions } = useModelAffectationRules();
  const onFormSubmit = async (data: IAffectationFormInputs) => {
    return data;
  };

  return (
    <form>
      <AddTermsOfTheWizardRules
        AllCriteriaOptions={multiSelectionOptions}
        control={control}
        watch={watch}
        reset={reset}
        maxline={max}
        {...props}
      />
      <Button title={BUTTON_TITLE.active} type="submit" onClick={handleSubmit(onFormSubmit)} />
    </form>
  );
};

defineFeature(feature, test => {
  let userSetup: UserEvent;
  let button: HTMLButtonElement;
  let selectCriteria: HTMLSelectElement;
  let selectCondition: HTMLSelectElement;
  let inputField: HTMLInputElement;
  let selectField: HTMLSelectElement;

  const shouldseeFormModalityComponent = (given: DefineStepFunction) => {
    given('je vois la section modalities du formulaire', () => {
      const initialEntries: string[] = [CONSULTATION_RULE_ID_DETAIL];
      const { user } = renderMemoryRouter(
        <AppContextProvider>
          <FormSectionTermsOfTheRules max={16} />
        </AppContextProvider>,
        { initialEntries }
      );
      userSetup = user;
    });
  };

  const whenSendFormAffectation = (when: DefineStepFunction) => {
    when('je clique sur le bouton submit', async () => {
      await act(() => userSetup.click(screen.getByRole('button', { name: BUTTON_TITLE.active })));
    });
  };

  const whenAdddnewFormLine = (and: DefineStepFunction) => {
    and(/^j'ajoute une nouvelle ligne de formulaire$/, async () => {
      button = screen.getByRole('button', { name: /Ajouter un critère/i });
      expect(button).toBeInTheDocument();
      await userSetup.click(button);
    });
  };

  const whenSelectCriteriaField = (when: DefineStepFunction) => {
    when(/^je selectionne "(.*)" comme critères$/, async (labelSelected: string) => {
      waitFor(() => {
        selectCriteria = screen.getByRole('combobox', { name: /modalities.3.criteria/i });
      });
      await act(() => userSetup.selectOptions(selectCriteria, labelSelected));
    });
  };

  const whenSelectConditionField = (when: DefineStepFunction) => {
    when(/^je selectionne "(.*)" comme condition$/, async (labelSelected: string) => {
      waitFor(() => {
        selectCondition = screen.getByRole('combobox', { name: /modalities.3.condition/i });
      });
      await act(() => userSetup.selectOptions(selectCondition, labelSelected));
    });
  };

  const addInputFieldValue = (and: DefineStepFunction) => {
    and(/^je saisie la valeur "(.*)" dans mon input$/, async (input: string) => {
      waitFor(() => {
        inputField = screen.getByRole('textbox', { name: /modalities.3.rules/i });
      });
      await act(() => userSetup.type(inputField, input));
    });
  };

  const shouldseeFormErrors = (then: DefineStepFunction) => {
    then(
      /^je dois voir "(.*)" erreur\(s\) de validation avec le text "(.*)"$/,
      async (countRules: number, errorAlert: string) => {
        const expected = new RegExp(`^${errorAlert}$`, 'i');
        const rulesElt = await screen.findAllByText(expected);
        expect(rulesElt).toHaveLength(countRules);
      }
    );
  };

  test("Affichage  d'erreur de règle de valeur obligatoire", ({ given, when, then }) => {
    shouldseeFormModalityComponent(given);
    whenSendFormAffectation(when);
    shouldseeFormErrors(then);
  });

  test("Affichage d'erreur de règle de condition obligatoire", ({ given, and, when, then }) => {
    shouldseeFormModalityComponent(given);
    whenAdddnewFormLine(and);
    whenSendFormAffectation(when);
    shouldseeFormErrors(then);
    shouldseeFormErrors(and);
  });

  test("Affichage d'erreur de valeur obligatoire Code Syndic", ({ given, and, when, then }) => {
    shouldseeFormModalityComponent(given);
    whenAdddnewFormLine(and);
    whenSelectCriteriaField(and);
    and(/^je vois "(.*)" afficher comme condition$/, async (condtionName: string) => {
      await waitFor(async () => {
        const expected = new RegExp(`${condtionName}`, 'i');
        const condtionElt = await screen.findAllByText(expected);
        expect(condtionElt).toHaveLength(4);
      });
    });
    whenSendFormAffectation(when);
    shouldseeFormErrors(then);
  });

  test("Affichage d'erreur de valeur obligatoire Code Syndic Format maximum", ({ given, and, when, then }) => {
    shouldseeFormModalityComponent(given);
    whenAdddnewFormLine(and);
    whenSelectCriteriaField(and);
    and(/^je vois "(.*)" afficher comme condition$/, async (condtionName: string) => {
      await waitFor(async () => {
        const expected = new RegExp(`${condtionName}`, 'i');
        const condtionElt = await screen.findAllByText(expected);
        expect(condtionElt).toHaveLength(4);
      });
    });
    addInputFieldValue(and);
    whenSendFormAffectation(when);
    shouldseeFormErrors(then);
    shouldseeFormErrors(and);
  });

  test("Affichage d'erreur de valeur obligatoire Code Naf Format maximum", ({ given, and, when, then }) => {
    shouldseeFormModalityComponent(given);
    whenAdddnewFormLine(and);
    whenSelectCriteriaField(and);
    whenSelectConditionField(and);
    addInputFieldValue(and);
    whenSendFormAffectation(when);
    shouldseeFormErrors(then);
    shouldseeFormErrors(and);
  });

  test("Affichage d'erreur de valeur obligatoire Code Naf Format regex", ({ given, and, when, then }) => {
    shouldseeFormModalityComponent(given);
    whenAdddnewFormLine(and);
    whenSelectCriteriaField(and);
    whenSelectConditionField(and);
    addInputFieldValue(and);
    whenSendFormAffectation(when);
    shouldseeFormErrors(then);
    shouldseeFormErrors(and);
  });

  test("Affichage d'erreur de valeur obligatoire Code Portefeuille", ({ given, and, when, then }) => {
    shouldseeFormModalityComponent(given);
    whenAdddnewFormLine(and);
    whenSelectCriteriaField(and);
    and(/^je vois "(.*)" afficher comme condition$/, async (condtionName: string) => {
      waitFor(async () => {
        const expected = new RegExp(`${condtionName}`, 'i');
        const condtionElt = await screen.findAllByText(expected);
        expect(condtionElt).toHaveLength(4);
      });
    });
    whenSendFormAffectation(when);
    shouldseeFormErrors(then);
  });

  test("Affichage d'erreur de valeur obligatoire Nom intermediaire condition et valeur", ({
    given,
    and,
    when,
    then,
  }) => {
    shouldseeFormModalityComponent(given);
    whenAdddnewFormLine(and);
    whenSelectCriteriaField(when);
    whenSendFormAffectation(and);
    shouldseeFormErrors(then);
    shouldseeFormErrors(and);
  });

  test("Affichage d'erreur de valeur obligatoire Nom intermediaire valeur", ({ given, and, when, then }) => {
    shouldseeFormModalityComponent(given);
    whenAdddnewFormLine(and);
    whenSelectCriteriaField(and);
    and('je vois une nouvelle liste de selection', async () => {
      selectField = await screen.findByRole('combobox', { name: /modalities.3.condition/i });
      expect(selectField).toBeInTheDocument();
    });
    whenSelectConditionField(and);
    whenSendFormAffectation(when);
    shouldseeFormErrors(then);
  });
});
