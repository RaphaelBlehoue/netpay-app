import { IRuleDto } from '@affectations/api/bff-clients.generated';

const AFFECTATATION_DATE = '2024-01-17T16:58:06.548Z';
const INTERMEDIAIRY_NAME = 'Alain&Nicole 123 - Boutique/Magasin';
const CONTRACT_CATEGORY = 'Ceci est un exemple pour easyq';
const INTERMEDIAIRY_CONDITION = 'commence par';
const BRANCH = 'Transport autre';

export const expectResponseInput = {
  id: 5,
  ruleDetailsDto: {
    ruleName: 'Remplacement de Mélanie',
    statut: 'Brouillon',
    startDate: '2024-01-01T23:00:00',
    endDate: null,
    comment: '27/02/023 - Rajout par numcnt (ancienne QP)',
    creationDate: '2023-01-01T09:05:12',
    createdBy: 'Olivier SAILLY',
    creatorId: 'S123456',
    updateDate: '2024-03-01T10:55:02',
    updatorId: 'S123456',
    updatedBy: 'Jérôme CAGNONCLE',
  },
  critereDto: {
    segmentation: 'MB',
    distributorRegion: '64',
    network: 'Courtier',
    branch: BRANCH,
    copht: 999999999.99,
    distributorDepartment: '01',
    contractCategory: CONTRACT_CATEGORY,
    uvCode: '1A234',
    intermediateName: INTERMEDIAIRY_NAME,
    portfolioCode: '0000012345',
    clause: '012345',
    syndicCode: '01234',
    nafCode: '12345ABCDE',
    clientNumber: '000E012345',
    accountManager: '000E012',
    contractNumber: '000E012345678912',
  },
  affectationDto: {
    affectedTeam: 'ES_AUTO_NE',
    affectedRegion: 'Auvergne-Rhône-Alpes',
    affectedEmployee: 'BONTEMS Patrick',
    affectedEmployeeId: 'S123456',
    affectationDate: AFFECTATATION_DATE,
    affectationDemandDate: AFFECTATATION_DATE,
  },
  conditionsDto: {
    contractNumberCondition: 'est parmi',
    accountManagerCondition: 'est parmi',
    clientNumberCondition: 'est parmi',
    nafCodeCondition: 'contient',
    syndicCodeCondition: 'est parmi',
    clauseCondition: 'est parmi',
    portfolioCondition: 'est parmi',
    intermediateNameCondition: INTERMEDIAIRY_CONDITION,
    productCondition: 'est parmi',
    cophtCondition: 'égal à',
    departmentCondition: 'est parmi',
    networkCondition: 'est parmi',
    regionCondition: 'est parmi',
    branchCondition: 'est parmi',
    segmentationCondition: 'est parmi',
    turnoverCondition: null,
    contractCategoryCondition: 'est parmi',
  },
} as unknown as IRuleDto;

export const expectResponseOutput = [
  {
    criteres: 'segmentation',
    conditions: 'est parmi',
    valeur: 'MB',
  },
  {
    criteres: 'Région distributeur',
    conditions: 'est parmi',
    valeur: '64',
  },
  {
    criteres: 'Reseau',
    conditions: 'est parmi',
    valeur: 'Courtier',
  },
  {
    criteres: 'Branche',
    conditions: 'est parmi',
    valeur: BRANCH,
  },
  {
    criteres: 'COPHT (€)',
    conditions: 'égal à',
    valeur: '999 999 999,99',
  },
  {
    criteres: 'Département distributeur',
    conditions: 'est parmi',
    valeur: '01',
  },
  {
    criteres: 'Catégorie du contrat QP',
    conditions: 'est parmi',
    valeur: CONTRACT_CATEGORY,
  },
  {
    criteres: 'Code UV produit',
    conditions: 'est parmi',
    valeur: '1A234',
  },
  {
    criteres: 'Nom intermédiaire',
    conditions: INTERMEDIAIRY_CONDITION,
    valeur: INTERMEDIAIRY_NAME,
  },
  {
    criteres: 'Code portefeuille',
    conditions: 'est parmi',
    valeur: '0000012345',
  },
  {
    criteres: 'Clause',
    conditions: 'est parmi',
    valeur: '012345',
  },
  {
    criteres: 'Code Syndic',
    conditions: 'est parmi',
    valeur: '01234',
  },
  {
    criteres: 'Code NAF',
    conditions: 'contient',
    valeur: '12345ABCDE',
  },
  {
    criteres: 'N° client AXAPAC',
    conditions: 'est parmi',
    valeur: '000E012345',
  },
  {
    criteres: 'Chargé de clientèle',
    conditions: 'est parmi',
    valeur: '000E012',
  },
  {
    criteres: 'N° contrat',
    conditions: 'est parmi',
    valeur: '000E012345678912',
  },
];

export const expectResponseInputPartial = {
  id: 5,
  ruleDetailsDto: {
    ruleName: 'Remplacement de Mélanie',
    statut: 'Brouillon',
    startDate: '2024-01-01T22:00:00.000Z',
    comment: '27/02/023 - Rajout par numcnt (ancienne QP)',
    creationDate: '2023-01-01T08:05:12.000Z',
    createdBy: 'Olivier SAILLY',
    creatorId: 'S123456',
    updateDate: '2024-03-01T09:55:02.000Z',
    updatedBy: 'Jérôme CAGNONCLE',
    updatorId: 'S123456',
  },
  critereDto: {
    segmentation: 'MB',
    distributorRegion: '',
    network: '',
    branch: BRANCH,
    copht: 999999999.99,
    distributorDepartment: '01',
    contractCategory: CONTRACT_CATEGORY,
    uvCode: '1A234',
    intermediateName: INTERMEDIAIRY_NAME,
    portfolioCode: '',
    clause: '012345',
    syndicCode: '01234',
    nafCode: '',
    clientNumber: '000E012345',
    accountManager: '000E012',
    contractNumber: '',
  },
  affectationDto: {
    affectedTeam: 'ES_AUTO_NE',
    affectedRegion: 'Auvergne-Rhône-Alpes',
    affectedEmployee: 'BONTEMS Patrick',
    affectedEmployeeId: 'S123456',
    affectationDate: AFFECTATATION_DATE,
    affectationDemandDate: AFFECTATATION_DATE,
  },
  conditionsDto: {
    contractNumberCondition: 'est parmi',
    accountManagerCondition: 'est parmi',
    clientNumberCondition: 'est parmi',
    nafCodeCondition: 'contient',
    syndicCodeCondition: 'est parmi',
    clauseCondition: 'est parmi',
    portfolioCondition: 'est parmi',
    intermediateNameCondition: INTERMEDIAIRY_CONDITION,
    productCondition: 'est parmi',
    cophtCondition: 'égal à',
    departmentCondition: 'est parmi',
    networkCondition: 'est parmi',
    regionCondition: 'est parmi',
    branchCondition: 'est parmi',
    segmentationCondition: 'est parmi',
    turnoverCondition: null,
    contractCategoryCondition: 'est parmi',
  },
} as unknown as IRuleDto;

export const expectResponseOutputPartial = [
  {
    criteres: 'segmentation',
    conditions: 'est parmi',
    valeur: 'MB',
  },
  {
    criteres: 'Branche',
    conditions: 'est parmi',
    valeur: BRANCH,
  },
  {
    criteres: 'COPHT (€)',
    conditions: 'égal à',
    valeur: '999 999 999,99',
  },
  {
    criteres: 'Département distributeur',
    conditions: 'est parmi',
    valeur: '01',
  },
  {
    criteres: 'Catégorie du contrat QP',
    conditions: 'est parmi',
    valeur: CONTRACT_CATEGORY,
  },
  {
    criteres: 'Code UV produit',
    conditions: 'est parmi',
    valeur: '1A234',
  },
  {
    criteres: 'Nom intermédiaire',
    conditions: INTERMEDIAIRY_CONDITION,
    valeur: INTERMEDIAIRY_NAME,
  },
  {
    criteres: 'Clause',
    conditions: 'est parmi',
    valeur: '012345',
  },
  {
    criteres: 'Code Syndic',
    conditions: 'est parmi',
    valeur: '01234',
  },
  {
    criteres: 'N° client AXAPAC',
    conditions: 'est parmi',
    valeur: '000E012345',
  },
  {
    criteres: 'Chargé de clientèle',
    conditions: 'est parmi',
    valeur: '000E012',
  },
];
