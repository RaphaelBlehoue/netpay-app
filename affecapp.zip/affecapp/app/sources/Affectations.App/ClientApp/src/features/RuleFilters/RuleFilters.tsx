import { FC, FocusEventHandler, useCallback, useRef } from 'react';
import Button from '@axa-fr/react-toolkit-button';
import { zodResolver } from '@hookform/resolvers/zod';
import clsx from 'clsx';
import { SubmitHandler, useForm } from 'react-hook-form';

import { AsyncAutoComplete, SearchInput, TOption } from '@affectations/components';
import SelectMultiple, { SelectMultipleItems } from '@affectations/components/ui/SelectMultiple/SelectMultiple';
import { convertTableToString, schema } from '@affectations/utils/rules';
import {
  AffectationDto,
  CriteresDto,
  IAffectationDto,
  ICriteresDto,
  IRuleDetailsDto,
  IRuleDto,
  PagedDataOfRuleCriterion,
  RuleDetailsDto,
} from '@affectations/api/bff-clients.generated';
import { CriteriaName, searchCriteriaByName } from '@affectations/api/citeria';

import refresh from '../../assets/icons/refresh.svg';
import style from './style.module.scss';

const MAX_SEARCH_COLLABORATORS_COUNT = 10;
const SEARCH_START_CARACTERE_LENGTH = 3;

export type FilterFields = {
  affectationRegions?: SelectMultipleItems;
  affectationTeams?: SelectMultipleItems;
  collaborator?: TOption;
  segmentations?: SelectMultipleItems;
  branches?: SelectMultipleItems;
  networks?: SelectMultipleItems;
  regionDistributions?: SelectMultipleItems;
  departmentDistributions?: SelectMultipleItems;
  ruleStatus?: SelectMultipleItems;
  contractNumber?: string;
  portfolioCode?: string;
  clientNumber?: string;
  accountManager?: string;
  uvCodeProduct?: string;
  clause?: string;
  syndicCode?: string;
  codeNAF?: string;
  intermediaryName?: string;
};

const isNotInputValid = (value: string) =>
  value.length < SEARCH_START_CARACTERE_LENGTH || value.trim().length !== value.length;

type Props = {
  criterias: Partial<FilterFields>;
  filterCollaboratorsAsync: (inputValue: string) => Promise<TOption[]>;
  onSubmit: (data: IRuleDto) => void;
  searchCriteria?: (criteria: CriteriaName, inputValue: string) => Promise<PagedDataOfRuleCriterion>;
};

const RuleFilters: FC<Props> = ({
  criterias,
  filterCollaboratorsAsync,
  searchCriteria = searchCriteriaByName,
  onSubmit,
}) => {
  const form = useRef<HTMLFormElement>(null);
  const {
    control,
    setValue,
    watch,
    getValues,
    handleSubmit,
    setError,
    reset,
    formState: { errors },
  } = useForm<FilterFields>({
    defaultValues: criterias,
    mode: 'onBlur',
    resolver: zodResolver(schema),
  });

  const submit = useCallback<SubmitHandler<FilterFields>>(
    data => {
      const critereDto: ICriteresDto = {
        segmentation: convertTableToString(data.segmentations),
        distributorDepartment: convertTableToString(data.departmentDistributions),
        distributorRegion: convertTableToString(data.regionDistributions),
        network: convertTableToString(data.networks),
        branch: convertTableToString(data.branches),
        portfolioCode: data.portfolioCode,
        clause: data.clause,
        nafCode: data.codeNAF,
        clientNumber: data.clientNumber,
        accountManager: data.accountManager,
        contractNumber: data.contractNumber,
        syndicCode: data.syndicCode,
        uvCode: data.uvCodeProduct,
        intermediateName: data.intermediaryName,
      };

      const affectationRegions: IAffectationDto = {
        affectedRegion: convertTableToString(data.affectationRegions),
        affectedTeam: convertTableToString(data.affectationTeams),
        affectedEmployee: data.collaborator?.value,
      };

      const ruleDetailsDto: IRuleDetailsDto = {
        statut: convertTableToString(data.ruleStatus),
      };
      const formData: IRuleDto = {
        critereDto: new CriteresDto(critereDto),
        affectationDto: new AffectationDto(affectationRegions),
        ruleDetailsDto: new RuleDetailsDto(ruleDetailsDto),
      };

      onSubmit(formData);
    },
    [onSubmit]
  );

  const handleCollaboratorChange = useCallback(
    async (inputValue: string) => {
      if (isNotInputValid(inputValue)) {
        return [];
      }
      const data = (await filterCollaboratorsAsync(inputValue)) ?? [];
      return data.slice(0, MAX_SEARCH_COLLABORATORS_COUNT);
    },
    [filterCollaboratorsAsync]
  );

  const handleOnCodePortfolioBlur = useCallback<FocusEventHandler<HTMLInputElement>>(
    async e => {
      const value = e.target.value.trim();
      if (value.length === MAX_SEARCH_COLLABORATORS_COUNT) {
        const result = await searchCriteria('PORTFOLIO_CODE', value);

        if (!result.data?.length) {
          setError('portfolioCode', { type: 'manual', message: 'Aucun résultat.' });
        }
      }
    },
    [searchCriteria, setError]
  );

  return (
    <form ref={form} className={clsx('af-form', style.form)} name="myform" onSubmit={handleSubmit(submit)}>
      <h1>Filtres et recherche spécifique</h1>
      <div className={style.inputs}>
        <SelectMultiple
          control={control}
          label="Région d'affectation"
          name="affectationRegions"
          setValue={setValue}
          watch={watch}
          getValues={getValues}
          form={form.current}
        />
        <SelectMultiple
          control={control}
          label="Equipe d'affectation"
          name="affectationTeams"
          setValue={setValue}
          watch={watch}
          getValues={getValues}
          form={form.current}
        />

        <div className={style['auto-complete']}>
          <label htmlFor="collaborator-field">Collaborateur</label>
          <AsyncAutoComplete
            control={control}
            name="collaborator"
            inputId="collaborator-field"
            loadOptions={handleCollaboratorChange}
            noOptionsMessage={data => (!isNotInputValid(data.inputValue) ? 'Aucun résultat' : null)}
            cacheOptions
            placeholder="Rechercher..."
            defaultOptions
          />
        </div>
        <SelectMultiple
          control={control}
          label="Segmentation"
          name="segmentations"
          setValue={setValue}
          watch={watch}
          getValues={getValues}
          form={form.current}
          small
        />
        <SelectMultiple
          control={control}
          label="Branche"
          name="branches"
          setValue={setValue}
          watch={watch}
          getValues={getValues}
          form={form.current}
        />
        <SelectMultiple
          control={control}
          label="Réseaux"
          name="networks"
          setValue={setValue}
          watch={watch}
          getValues={getValues}
          form={form.current}
          small
        />
        <SelectMultiple
          control={control}
          label="Région distributeur"
          name="regionDistributions"
          setValue={setValue}
          watch={watch}
          getValues={getValues}
          form={form.current}
        />
        <SelectMultiple
          control={control}
          label="Département distributeur"
          name="departmentDistributions"
          setValue={setValue}
          watch={watch}
          getValues={getValues}
          form={form.current}
        />
        <SelectMultiple
          control={control}
          label="Statut de la règle"
          name="ruleStatus"
          setValue={setValue}
          watch={watch}
          getValues={getValues}
          form={form.current}
        />
        <SearchInput
          control={control}
          name="contractNumber"
          label="N° Contrat"
          helpMessage="Ex: 00000012345678910"
          maxLength={16}
          isPad
          isAlphaNumeric
          padCount={16}
        />
        <SearchInput control={control} name="intermediaryName" label="Nom d'intermédiaire" maxLength={100} />
        <SearchInput
          control={control}
          name="portfolioCode"
          label="Code portefeuille"
          type="number"
          maxLength={10}
          message={errors.portfolioCode?.message}
          onBlur={handleOnCodePortfolioBlur}
        />
        <SearchInput
          control={control}
          small
          name="clientNumber"
          label="N° Client AXAPAC"
          maxLength={10}
          isPad
          padCount={10}
          type="number"
        />
        <SearchInput
          control={control}
          small
          name="accountManager"
          label="Chargée de clientèle"
          maxLength={7}
          message={errors.accountManager?.message}
        />
        <SearchInput control={control} small name="uvCodeProduct" label="Code UV produit" maxLength={5} type="number" />
        <SearchInput
          control={control}
          small
          name="clause"
          label="Clause"
          type="number"
          maxLength={6}
          message={errors.clause?.message}
        />
        <SearchInput
          control={control}
          small
          name="syndicCode"
          label="Code syndic"
          maxLength={5}
          type="number"
          message={errors.syndicCode?.message}
        />
        <SearchInput
          control={control}
          small
          name="codeNAF"
          label="Code NAF"
          maxLength={7}
          message={errors.codeNAF?.message}
        />
      </div>
      <div className={style.actions}>
        <Button type="submit">Filtrer le tableau</Button>
        <button type="reset" className={style['reset-btn']} onClick={() => reset()}>
          <img src={refresh} alt="Refresh" />
          Réinitialiser les filtres
        </button>
      </div>
    </form>
  );
};

export default RuleFilters;
