import { screen } from '@testing-library/react';
import { defineFeature, loadFeature } from 'jest-cucumber';

import { renderSetup } from '@affectations/test-utils';

import { AssignmentRule, IAssigmentRules } from '../AssignmentRule';

const feature = loadFeature('../features/RowAssignmentRules.feature');

defineFeature(feature, test => {
  let assigmentRules: IAssigmentRules;
  test("Affichage des données provenant de l'api", ({ given, when, then }) => {
    given(/^Je recupère les données d'une règle provenant de mon bff$/, async () => {
      const rowData = [
        {
          label: "Affecter à l'équipe",
          content: 'ES_AUTO_NE',
        },
        {
          label: 'Affecter au collaborateur',
          content: 'BONTEMS PATRICK (S123456)',
        },
        {
          label: "Région d'affectation",
          content: `NE`,
        },
        {
          label: 'Commentaire',
          content: '27/02/023 - Rajout par numcnt (ancienne QP)',
        },
      ];

      assigmentRules = {
        assigmentRulesMapping: rowData,
        isLoading: false,
        isSuccess: true,
        sectionTitle: 'Affectation',
      };
    });

    when(/^je constate que je reçois une reponse de success du bff$/, async _isPartial => {
      renderSetup(<AssignmentRule {...assigmentRules} />);
    });

    then(/^je dois voir afficher sur ma page les données suivantes$/, async ruleData => {
      const expectedData = ruleData.map((data: Record<string, string>) => Object.values(data));
      for (const [label, value] of expectedData) {
        const currentElementLabels = await screen.findByText(label);
        expect(currentElementLabels).toBeInTheDocument();
        const currentElementValues = await screen.findByText(value);
        expect(currentElementValues).toBeInTheDocument();
      }
    });
  });
});
