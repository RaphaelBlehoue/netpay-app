import '@axa-fr/react-toolkit-form-input-checkbox/dist/af-checkbox.css';

import { ChangeEventHandler, FC, useCallback, useMemo, useState } from 'react';
import Title from '@axa-fr/react-toolkit-title';

import '@axa-fr/react-toolkit-title/dist/af-title.css';

import Button from '@axa-fr/react-toolkit-button';
import { Pager } from '@axa-fr/react-toolkit-table';
import { UseMutateFunction } from '@tanstack/react-query';
import clsx from 'clsx';

import { useRuleColumns } from '@affectations/hooks/rules/useRuleColumns';
import { Modal } from '@affectations/components';
import { DataTable } from '@affectations/components/ui/DataTable';
import {
  AffectationDto,
  ConditionsDto,
  CriteresDto,
  FileResponse,
  FilterRuleDto,
  RuleDetailsDto,
  RuleDto,
} from '@affectations/api/bff-clients.generated';
import { TError } from '@affectations/api/types';
import { CONSULTATION_RULE_ID_DETAIL } from '@affectations/routes/configRoute';

import style from './style.module.scss';
import { Rules } from './type';
import { getFileNumberToExport } from './utils';

const DEFAULT_PAGE_SIZE = 25;
const FIFTY = 50;
const SEVENTY_FIVE = 75;
const HUNDRED = 100;
const HUNDRED_AND_FIFTY = 150;
const TWO_HUNDRED = 200;

type Props = {
  data: Rules;
  isLoading: boolean;
  currentPage: number;
  itemsPerPage?: number;
  count?: number;
  currentFilterState?: RuleDto;
  numberPages: number;
  onPageChange?: (page: number) => void;
  onPageSizeChange?: (size: number) => void;
  mutationExportFn?: UseMutateFunction<FileResponse, TError, FilterRuleDto>;
};

const pageSizes = [DEFAULT_PAGE_SIZE, FIFTY, SEVENTY_FIVE, HUNDRED, HUNDRED_AND_FIFTY, TWO_HUNDRED];

const RuleDataTable: FC<Props> = ({
  data,
  isLoading,
  currentPage,
  itemsPerPage = DEFAULT_PAGE_SIZE,
  numberPages,
  count,
  currentFilterState,
  onPageChange = () => {},
  onPageSizeChange = () => {},
  mutationExportFn = () => {},
}) => {
  const [selectedRows, setSelectedRows] = useState<Record<string, boolean>>({});
  const [isOpen, setIsOpen] = useState<{ isToggleOn: boolean }>({ isToggleOn: false });
  const selectRowCount = useMemo(() => Object.keys(selectedRows).length, [selectedRows]);
  const columns = useRuleColumns();

  const handlePageChange = useCallback(
    (e: { value: number }) => {
      onPageChange(e.value);
    },
    [onPageChange]
  );

  const handlePageSizeChange = useCallback<ChangeEventHandler<HTMLSelectElement>>(
    e => {
      const converted = parseInt(e.target.value);
      if (!isNaN(converted)) {
        onPageSizeChange(converted);
      }
    },
    [onPageSizeChange]
  );

  const getInfoExport: {
    isAll: boolean;
    selectRowCount: number;
  } = useMemo(() => {
    const isAllPageSelected: boolean = data.length === itemsPerPage;
    const isAllDataSelected: boolean = selectRowCount === data.length;
    return {
      isAll: isAllPageSelected && isAllDataSelected,
      selectRowCount,
    };
  }, [data.length, itemsPerPage, selectRowCount]);

  const countContent = useMemo(() => {
    const rulesCountSelected = getInfoExport.isAll ? count : getInfoExport.selectRowCount;
    return getFileNumberToExport(rulesCountSelected);
  }, [count, getInfoExport]);

  const handleToggleModal = () => {
    setIsOpen(prevState => ({
      isToggleOn: !prevState.isToggleOn,
    }));
  };

  const handleRuleExport = () => {
    const keyIds: number[] = Object.keys(selectedRows).map(keyID => parseInt(keyID));
    const exportFilter = new FilterRuleDto({
      ...(!getInfoExport.isAll
        ? {
            ids: keyIds,
            ruleDetailsDto: new RuleDetailsDto(),
            affectationDto: new AffectationDto(),
            conditionsDto: new ConditionsDto(),
            critereDto: new CriteresDto(),
          }
        : { ids: [], ...currentFilterState }),
    });
    mutationExportFn && mutationExportFn(exportFilter);
    handleToggleModal();
  };

  return (
    <div className={style['rule-data-table']}>
      <div className={style['title-action']}>
        <Title>
          {!!count && (
            <>
              {count} règle{data.length > 1 && 's'} d'affectation
            </>
          )}
          {!data.length && !isLoading && <>Aucune règle d'affectation correspond à votre recherche.</>}
        </Title>
        <div className={style['ctf']}>
          <Button
            classModifier={clsx({ disabled: !selectRowCount })}
            aria-disabled={!selectRowCount}
            disabled={!selectRowCount}
          >
            Modifier
          </Button>
          <Button
            classModifier={clsx('reverse', { disabled: !selectRowCount })}
            aria-disabled={!selectRowCount}
            disabled={!selectRowCount}
            onClick={handleToggleModal}
          >
            Exporter
          </Button>
          {selectRowCount > 0 && (
            <Modal
              title="Exporter"
              isOpen={isOpen.isToggleOn}
              content={countContent}
              buttonLabel="Confirmer"
              onClose={handleToggleModal}
              onSubmit={handleRuleExport}
            />
          )}
        </div>
      </div>
      {!!data.length && (
        <>
          <DataTable
            columns={columns}
            data={data}
            rowSelection={selectedRows}
            setRowSelection={setSelectedRows}
            href={CONSULTATION_RULE_ID_DETAIL}
            sticky
          />
          <section className={style.pagination} role="navigation" aria-label="pagination">
            <div className={style.pages}>
              <label htmlFor="page-sizes">Afficher</label>
              <select id="page-sizes" onChange={handlePageSizeChange}>
                {pageSizes.map(x => (
                  <option key={x} value={x} selected={x === itemsPerPage}>
                    {x}
                  </option>
                ))}
              </select>
              <span>résultats par page</span>
            </div>
            <Pager currentPage={currentPage} numberPages={numberPages} onChange={handlePageChange} />
          </section>
        </>
      )}
    </div>
  );
};

export default RuleDataTable;
