import { act, render, screen, waitFor } from '@testing-library/react';
import { defineFeature, DefineStepFunction, loadFeature } from 'jest-cucumber';
import { http, HttpResponse } from 'msw';
import { createMemoryRouter } from 'react-router-dom';

import { HTTP_STATUS } from '@affectations/components/ui/ErrorMessage/constants';
import { Claim } from '@affectations/api/duende-bff-clients.generated';
import { AuthenticationProvider } from '@affectations/contexts';
import { server } from '@affectations/mocks/server';
import { Router } from '@affectations/Router';
import { configRoutes } from '@affectations/routes';

const feature = loadFeature('../features/Authentication.feature');

const mockRequest = (path: string, body: object | undefined, status: number) => {
  server.use(http.get(path, () => HttpResponse.json(body, { status })));
};

const whenIAccessTheHomepage = (when: DefineStepFunction) => {
  when("J'accede à la page d'accueil de l'application", async () => {
    global.window.location.href = '/';
    await act(async () => {
      render(<Router router={createMemoryRouter(configRoutes)} />, { wrapper: AuthenticationProvider });
    });
  });
};

const thenIAmRedirectedToTheLoginPage = (then: DefineStepFunction) => {
  then(/^Je suis redirigé vers la page de connexion$/, async () => {
    waitFor(() => {
      expect(global.window.location.assign).toHaveBeenCalled();
    });
  });
};
const thenIAmRedirectedToTheForbidden = (then: DefineStepFunction) => {
  then(/^Je suis redirigé vers la page forbidden$/, () => {
    waitFor(() => {
      expect(global.window.location.pathname?.trim().toLocaleLowerCase()).toBe('/forbidden');
    });
  });
};

const givenTheServerReturnsSuccessResponse = (given: DefineStepFunction) => {
  given("le serveur d'authentification retourne un message de succes avec les claims", (claims: Claim[]) => {
    mockRequest('/bff/user', claims, HTTP_STATUS.OK);
  });
};

const givenTheAuthenticationServerResturnsTheStatus = (given: DefineStepFunction) => {
  given(
    /^le serveur d'authentification retourne un status (.*) pour la requête sur (.*)$/,
    (statusCode: string, path: string) => {
      mockRequest(path, {}, parseInt(statusCode));
    }
  );
};

const thenThisMsgIsVisible = (then: DefineStepFunction) => {
  then(/Je vois le message "(.*)"/i, async (msg: string) => {
    const msgElt = await screen.findByText(msg);
    expect(msgElt).toBeInTheDocument();
  });
};

const thenThisCTAIsVisible = (then: DefineStepFunction) => {
  then(/Le CTA "(.*)" est visible/i, async (name: string) => {
    const cta = await screen.findByRole('button', { name });
    expect(cta).toBeInTheDocument();
  });
};

defineFeature(feature, test => {
  test("L'utilisateur n'est pas authentifié", ({ given, when, then }) => {
    global.window = Object.create(window);

    const locationReplace = vi.fn();
    Object.defineProperty(global.window, 'location', {
      configurable: true,
      value: { assign: locationReplace },
    });

    givenTheAuthenticationServerResturnsTheStatus(given);
    whenIAccessTheHomepage(when);
    thenIAmRedirectedToTheLoginPage(then);
  });

  test("L'utilisateur n'est pas habilité", ({ given, when, then, and }) => {
    givenTheAuthenticationServerResturnsTheStatus(given);
    whenIAccessTheHomepage(when);
    thenThisMsgIsVisible(then);
    thenThisMsgIsVisible(and);
    thenThisCTAIsVisible(and);
  });

  test("L'utilisateur authentifie et sans role", ({ given, when, then }) => {
    givenTheServerReturnsSuccessResponse(given);
    whenIAccessTheHomepage(when);
    thenIAmRedirectedToTheForbidden(then);
  });

  test("L'utilisateur authentifie", ({ given, when, then }) => {
    givenTheServerReturnsSuccessResponse(given);
    whenIAccessTheHomepage(when);
    then('Je ne suis pas redirigé', () => {
      waitFor(() => expect(global.window.location.pathname.trim().toLocaleLowerCase()).toBe('/'));
    });
  });
});
