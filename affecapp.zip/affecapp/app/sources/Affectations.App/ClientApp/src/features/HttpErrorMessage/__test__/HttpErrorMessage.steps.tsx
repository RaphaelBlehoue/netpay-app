import { FC } from 'react';
import Button from '@axa-fr/react-toolkit-button';
import { useMutation } from '@tanstack/react-query';
import { act, render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { defineFeature, DefineStepFunction, loadFeature } from 'jest-cucumber';
import { http, HttpResponse } from 'msw';

import { ErrorMessage } from '@affectations/components';
import { ApiException } from '@affectations/api/bff-clients.generated';
import { ErrorProvider, QueryProvider } from '@affectations/contexts';
import { wait } from '@affectations/hooks';
import { server } from '@affectations/mocks/server';

const ErrorMessageTestComponent: FC = () => {
  const mutationFn = async () => {
    const response = await fetch(`${window.location.origin}/api/error`);
    if (!response.ok)
      throw new ApiException('Something went wrong !', response.status, await response.text(), {}, null);
    return response;
  };

  const mutation = useMutation({
    mutationFn,
  });

  return (
    <>
      <ErrorMessage />
      <Button onClick={() => mutation.mutate()}>throw</Button>
    </>
  );
};

const mockErrors = (body: object | undefined, status: number) => {
  server.use(http.get('/api/error', () => HttpResponse.json(body, { status })));
};

const feature = loadFeature('../features/HttpErrorMessage.feature');

const thenNoErrorMessageDisplayed = (then: DefineStepFunction) => {
  then("Aucun message d'erreur n'est affiché", async () => {
    const alert = screen.queryByRole('alert');
    expect(alert).toBeNull();
  });
};
const givenErrorRequestIsMocked = (given: DefineStepFunction) => {
  given(
    /^la requête sur la route (.*) retourne une erreur (\d+) avec la référence "(.*)"$/,
    (apiUrl: string, status: string, reference?: string) => {
      const body = reference
        ? {
            'correlation-id': reference,
          }
        : {};
      mockErrors(body, parseInt(status));
    }
  );
};
const whenButtonClickToMakeRequest = (when: DefineStepFunction) => {
  when('je click sur le bouton pour émettre la requête', async () => {
    const button = screen.getByText(/^throw$/);
    await act(() => userEvent.click(button));
  });
};
const thenErrorMessageIsDisplayed = (then: DefineStepFunction) => {
  then(/^le message: (.*) s'affiche sur la page$/, async (message: string) => {
    await wait(1000);
    const errorMsg = await waitFor(() => screen.getByText(message));
    expect(errorMsg).toBeInTheDocument();
  });
};
const thenTheErrorMessageIsNotDisplayed = (then: DefineStepFunction) => {
  then(/^le message "(.*)" n'est pas visisible$/, (message: string) => {
    const errorMsg = screen.queryByText(message);
    expect(errorMsg).toBeNull();
  });
};

defineFeature(feature, test => {
  beforeEach(async () => {
    await waitFor(() =>
      render(
        <ErrorProvider>
          <QueryProvider>
            <ErrorMessageTestComponent />
          </QueryProvider>
        </ErrorProvider>
      )
    );
  });
  test('Une erreur HTTP est declanche avec une référence', ({ given, when, then }) => {
    givenErrorRequestIsMocked(given);

    whenButtonClickToMakeRequest(when);

    thenErrorMessageIsDisplayed(then);
  });
  test('Une erreur 500 est déclenchée', ({ given, when, then }) => {
    givenErrorRequestIsMocked(given);

    whenButtonClickToMakeRequest(when);

    thenErrorMessageIsDisplayed(then);
  });
  test('Une erreur 401 est déclenchée', ({ given, when, then }) => {
    givenErrorRequestIsMocked(given);

    whenButtonClickToMakeRequest(when);

    thenErrorMessageIsDisplayed(then);
  });
  test("Un message d'erreur 401 est remplacé par un message d'erreur 500", ({ given, when, then }) => {
    givenErrorRequestIsMocked(given);

    whenButtonClickToMakeRequest(when);

    thenErrorMessageIsDisplayed(then);

    givenErrorRequestIsMocked(given);
    whenButtonClickToMakeRequest(when);
    thenErrorMessageIsDisplayed(given);
    thenTheErrorMessageIsNotDisplayed(then);
  });
  test("Aucune message d'erreur n'est initialement visible", ({ then }) => {
    thenNoErrorMessageDisplayed(then);
  });
});
