Feature: Creation du composant Tableau modalités de la régle - IARDENT-56441

  Rule: Affichage des 3 lignes par défaut du formulaire des modalités de la règle

    Scenario: Affichage du formulaire de modalités de la règle
      Given je vois le composant table afficher
      When je dois voir le titre du formulaire afficher
      Then je dois voir le texte du titre "Modalités de la règle"

    Scenario: Verification de la présence des trois lignes par defaut
      Given je vois le composant table afficher
      When les lignes par defaut du formulaire son afficher
      Then je dois voir "3" lignes par default afficher dans le Tableau

  Rule: Ajouter de nouvelles lignes au formulaire des modalités de la règle
    Scenario: Le button "Ajouter un critère" est présent sur la page
      Given je vois le composant table afficher
      When les lignes par defaut du formulaire son afficher
      Then je dois le button avec le titre Ajouter un critère et une icon

    Scenario: Le button "Ajouter un critère" ne doit pas être désactivé
      Given je vois le composant table afficher
      And le button avec le titre Ajouter un critère
      When le quota maximun de "16" lignes n'est pas atteint
      Then le button Ajouter critère ne devrai pas être desactivé

    Scenario: Le formulaire des modalites de la règle doit avoir 4 lignes afficher après un premier ajout
      Given je vois le composant table afficher
      And  je dois voir "3" lignes par default afficher dans le Tableau
      And le button avec le titre Ajouter un critère
      When Je clique sur le button Ajouter critère
      Then Je devrais voir "4" lignes afficher dans le formulaire

  Rule: Vérification de l'atteinte de la limite du quota d'ajout de lignes dans le formulaire
    Scenario: Le button "Ajouter un critère" doit est désactivé
      Given je vois le composant table afficher
      And  je dois voir "3" lignes par default afficher dans le Tableau
      And le button avec le titre Ajouter un critère
      And le quota maximun de "4" lignes n'est pas atteint
      When Je clique sur le button Ajouter critère
      Then Je devrais voir "4" lignes afficher dans le formulaire
      And le button avec le titre Ajouter un critère doit être desactivé

  Rule: Suppression des lignes sur le formulaire de modalités de la règle

    Scenario: Le button "icon remove" est présent sur la ligne ajoutée
      Given je vois le composant table afficher
      And  je dois voir "3" lignes par default afficher dans le Tableau
      And le button avec le titre Ajouter un critère
      When Je clique sur le button Ajouter critère
      Then Je devrais voir "4" lignes afficher dans le formulaire
      And Je devrais voir le button icon remove "remove rule3"

    Scenario: Le formulaire possede 5 lignes, après suppression nous devrions avoir 4 lignes
      Given je vois le composant table afficher
      And je dois voir "3" lignes par default afficher dans le Tableau
      And le button avec le titre Ajouter un critère
      And j'ajoute 2 ligne à mon formulaire Tableau
      And Je devrais voir "5" lignes afficher dans le formulaire
      And Je devrais voir "2" button icons remove afficher
      When Je clique sur le button icon remove "remove rule3"
      Then Je devrais voir "4" lignes afficher dans le formulaire

    Scenario: Le formulaire possede 5 lignes, après suppression total nous devrions les 3 lignes par defaut
      Given je vois le composant table afficher
      And je dois voir "3" lignes par default afficher dans le Tableau
      And le button avec le titre Ajouter un critère
      And j'ajoute 2 ligne à mon formulaire Tableau
      And Je devrais voir "5" lignes afficher dans le formulaire
      And Je devrais voir "2" button icons remove afficher
      When Je clique sur le button icon remove "remove all"
      Then Je devrais voir "3" lignes afficher dans le formulaire
