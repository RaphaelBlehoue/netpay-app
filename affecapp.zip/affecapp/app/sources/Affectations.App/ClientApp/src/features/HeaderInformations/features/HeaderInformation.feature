Feature: Consultation regle - Header + infos générales IARDENT-53693

  Rule: Consultation Detail

    Scenario: Affichage de la règle sans l'information de mise a jour
      Given je recupère les données provenant du bff
      And la date de début de la règle est "2024-01-01T23:00:00"
      And la date de fin de la règle est "2024-01-31T23:00:00"
      When la date du jour est "2024-02-01T23:00:00"
      And la règle n'a jamais été mise a jour
      Then je dois voir afficher les informations suivantes
        | startDate  | endDate    | ruleName                | status  | createContent                                  | updateContent |
        | 01/01/2024 | 31/01/2024 | REMPLACEMENT DE MÉLANIE | Expirée | Crée par Olivier SAILLY, le 01/01/2023 à 09h05 |               |

    Scenario: Règle expirée
      Given je recupère les données provenant du bff
      And la date de début de la règle est "2024-01-01T23:00:00"
      And la date de fin de la règle est "2024-01-31T23:00:00"
      When la date du jour est "2024-02-01T23:00:00"
      And la date de mise a jour est "2023-03-01T10:55:02"
      Then je dois voir afficher les informations suivantes
        | startDate  | endDate    | ruleName                | status  | createContent                                  | updateContent                                           |
        | 01/01/2024 | 31/01/2024 | REMPLACEMENT DE MÉLANIE | Expirée | Crée par Olivier SAILLY, le 01/01/2023 à 09h05 | Mise à jour par Jérôme CAGNONCLE, le 01/03/2023 à 10h55 |


    Scenario: Règle active
      Given je recupère les données provenant du bff
      And la date de début de la règle est "2024-01-01T23:00:00"
      And la date de fin de la règle est "2024-01-31T23:00:00"
      When la date du jour est "2024-01-31T23:00:00"
      And la règle est "Active"
      And la date de mise a jour est "2023-03-01T10:55:02"
      Then je dois voir afficher les informations suivantes
        | startDate  | endDate    | ruleName                | status | createContent                                  | updateContent                                           |
        | 01/01/2024 | 31/01/2024 | REMPLACEMENT DE MÉLANIE | Active | Crée par Olivier SAILLY, le 01/01/2023 à 09h05 | Mise à jour par Jérôme CAGNONCLE, le 01/03/2023 à 10h55 |


    Scenario: Règle en brouillon
      Given je recupère les données provenant du bff
      And la date de début de la règle est "2024-01-01T23:00:00"
      And la date de fin de la règle est "2024-01-31T23:00:00"
      When la date du jour est "2024-01-31T23:00:00"
      And la règle est "Brouillon"
      And la date de mise a jour est "2023-03-01T10:55:02"
      Then je dois voir afficher les informations suivantes
        | startDate  | endDate    | ruleName                | status    | createContent                                  | updateContent                                           |
        | 01/01/2024 | 31/01/2024 | REMPLACEMENT DE MÉLANIE | Brouillon | Crée par Olivier SAILLY, le 01/01/2023 à 09h05 | Mise à jour par Jérôme CAGNONCLE, le 01/03/2023 à 10h55 |

    Scenario: Règle active sans date de fin
      Given je recupère les données provenant du bff
      And la date de début de la règle est "2024-01-01T23:00:00"
      And la date de fin de la règle est n'est pas definie
      When la date du jour est "2024-01-31T23:00:00"
      And la règle est "Active"
      And la date de mise a jour est "2023-03-01T10:55:02"
      Then je dois voir afficher les informations suivantes
        | startDate  | endDate | ruleName                | status | createContent                                  | updateContent                                           |
        | 01/01/2024 |         | REMPLACEMENT DE MÉLANIE | Active | Crée par Olivier SAILLY, le 01/01/2023 à 09h05 | Mise à jour par Jérôme CAGNONCLE, le 01/03/2023 à 10h55 |

    Scenario: Règle en brouillon sans date de fin
      Given je recupère les données provenant du bff
      And la date de début de la règle est "2024-01-01T23:00:00"
      And la date de fin de la règle est n'est pas definie
      When la date du jour est "2024-01-31T23:00:00"
      And la règle est "Brouillon"
      And la date de mise a jour est "2023-03-01T10:55:02"
      Then je dois voir afficher les informations suivantes
        | startDate  | endDate | ruleName                | status    | createContent                                  | updateContent                                           |
        | 01/01/2024 |         | REMPLACEMENT DE MÉLANIE | Brouillon | Crée par Olivier SAILLY, le 01/01/2023 à 09h05 | Mise à jour par Jérôme CAGNONCLE, le 01/03/2023 à 10h55 |
