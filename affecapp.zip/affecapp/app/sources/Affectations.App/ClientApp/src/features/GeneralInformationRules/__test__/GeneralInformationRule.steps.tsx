import { act, render, screen, waitFor } from '@testing-library/react';
import userEvent, { UserEvent } from '@testing-library/user-event';
import { defineFeature, DefineStepFunction, loadFeature } from 'jest-cucumber';
import { useForm } from 'react-hook-form';

import { IAffectationFormInputs } from '@affectations/types';

import GeneralInformationRules from '../GeneralInformationRules';

const feature = loadFeature('../features/GeneralInformationRules.feature');

const dateNow = new Date();
const nowInput = dateNow.toISOString().split('T')[0];

const dateTomorrow = new Date();
dateTomorrow.setDate(dateTomorrow.getDate() + 1);
const tomorrow = dateTomorrow.toISOString().split('T')[0];

const dateYesterday = new Date();
dateYesterday.setDate(dateYesterday.getDate() - 2);
const yesterday = dateYesterday.toISOString().split('T')[0];

const Form = () => {
  const { control, watch, trigger } = useForm<IAffectationFormInputs>({ mode: 'all' });
  return <GeneralInformationRules control={control} watch={watch} trigger={trigger} />;
};

const givenIRenderTheForm = (given: DefineStepFunction) =>
  given('Je rends le formulaire', async () => await waitFor(() => render(<Form />)));

const thenTheMessageIsDisplayed = (then: DefineStepFunction) =>
  then(/Le message "(.*)" s'affiche/, async (message: string) => {
    const errorMsg = await waitFor(() => screen.getByText(message));
    expect(errorMsg).toBeInTheDocument();
  });

const whenIEnterTodayInStartDate = (when: DefineStepFunction) =>
  when("Je saisie une date d'aujourd'hui dans le champs date de début", async () => {
    const startDate = screen.getByLabelText('Date de début');
    await act(() => user.type(startDate, nowInput!));
  });

const whenIEnterTomorowInEndDate = (when: DefineStepFunction) =>
  when('Je saisie la date de demain dans le champ date de fin', async () => {
    const startDate = screen.getByLabelText('Date de début');
    await act(() => user.type(startDate, tomorrow ?? ''));
  });

let user: UserEvent;

defineFeature(feature, test => {
  beforeEach(() => {
    user = userEvent.setup();
  });
  test('Saisie dans le champ nom de la règle', ({ given, when, then, and }) => {
    givenIRenderTheForm(given);
    when(/Le texte "(.*)" est saisi dans le champ nom de la règle/, async (input: string) => {
      const nameInput = screen.getByRole('textbox', {
        name: "Nom de la règle d'affectation",
      });
      if (input) await act(() => user.type(nameInput, input));
    });
    then(/Le champs nom de la règle a pour valeur "(.*)"/, (current: string) => {
      const nameInput = screen.getByRole('textbox', {
        name: "Nom de la règle d'affectation",
      });
      expect(nameInput).toHaveValue(current);
    });
    and(/Le compteur de caractères affiche "(.*)"/, (counter: string) => {
      const counterText = screen.getByText(counter);
      expect(counterText).toBeInTheDocument();
    });
  });

  test("La date de début est inférieure à celle d'aujourd'hui", ({ given, when, then }) => {
    givenIRenderTheForm(given);
    when("Je saisit une date d'hier dans le champ date de début", async () => {
      const startDate = screen.getByLabelText('Date de début');
      await act(() => user.type(startDate, yesterday!));
      await act(() => user.tab());
    });
    thenTheMessageIsDisplayed(then);
  });

  test("La date de début n'est pas renseignée", ({ given, when, then, and }) => {
    givenIRenderTheForm(given);
    when('Je click sur le champ de date de début', async () => {
      const startDate = screen.getByLabelText('Date de début');

      await act(() => user.click(startDate));
    });
    and('Je click sur un autre champ dans le formulaire', async () => {
      const nameInput = screen.getByLabelText("Nom de la règle d'affectation");
      await act(() => user.click(nameInput));
    });
    thenTheMessageIsDisplayed(then);
  });

  test("La date minimum du champs date de début est celle d'aujourd'hui", ({ given, then }) => {
    givenIRenderTheForm(given);
    then("le champ date de début a pour valeur minimum la date d'aujourd'hui", () => {
      const startDate = screen.getByLabelText('Date de début');
      expect(startDate).toHaveAttribute('min', nowInput);
    });
  });

  test("L'utilisateur saisit une date valide", ({ given, when, then }) => {
    givenIRenderTheForm(given);
    whenIEnterTodayInStartDate(when);
    then("la valeur du champs date de début est est celle d'aujourd'hui", () => {
      const startDate = screen.getByLabelText('Date de début');
      expect(startDate).toHaveValue(nowInput);
    });
  });

  test("La date minimum du champ date de fin est celle d'aujourd'hui", ({ given, then }) => {
    givenIRenderTheForm(given);
    then("le champ date de fin a pour valeur minimum la date d'aujourd'hui", () => {
      const endDate = screen.getByLabelText('Date de fin');
      expect(endDate).toHaveAttribute('min', nowInput);
    });
  });

  test('La date de début est renseignée', ({ given, when, then }) => {
    givenIRenderTheForm(given);
    whenIEnterTomorowInEndDate(when);
    then('le champ date de fin a pour valeur minimum la date de demain', async () => {
      const endDate = await waitFor(() => screen.getByLabelText('Date de fin'));
      expect(endDate).toHaveAttribute('min', tomorrow);
    });
  });

  test('La date de début est supérieure à celle de fin', ({ given, when, then, and }) => {
    givenIRenderTheForm(given);
    whenIEnterTodayInStartDate(when);
    and("Je saisie la date d'hier dans le champs date de fin", async () => {
      const endDate = screen.getByLabelText('Date de fin');
      await act(() => user.type(endDate, yesterday!));
      await act(() => user.tab());
    });
    thenTheMessageIsDisplayed(then);
  });

  test('La date de début est modifiée alors que celle de fin a une valeur inférieure', ({ given, when, then, and }) => {
    givenIRenderTheForm(given);
    whenIEnterTodayInStartDate(when);
    and("Je saisie une date d'aujourd'hui dans le champs date de fin", async () => {
      const endDate = screen.getByLabelText('Date de fin');
      await act(() => user.type(endDate, nowInput!));
      await act(() => user.tab());
    });
    and('Je saisie une date demain dans le champs date de début', async () => {
      const startDate = screen.getByLabelText('Date de début');
      await act(() => user.clear(startDate));
      await act(() => user.type(startDate, tomorrow!));
      await act(() => user.tab());
    });
    thenTheMessageIsDisplayed(then);
  });

  test("La date de fin est renseignée mais la date de début ne l'est pas", ({ given, when, then }) => {
    givenIRenderTheForm(given);
    when('Je saisie la date de demain dans le champ date de fin', async () => {
      const endDate = screen.getByLabelText('Date de fin');
      await act(() => user.type(endDate, tomorrow!));
      await act(() => user.tab());
    });
    thenTheMessageIsDisplayed(then);
  });
});
