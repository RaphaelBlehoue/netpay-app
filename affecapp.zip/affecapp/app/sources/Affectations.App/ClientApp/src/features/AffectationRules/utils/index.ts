import { Team } from '@affectations/api/bff-clients.generated';

const SEARCH_START_CARACTERE_LENGTH = 3;
export type regionType = {
  affectationRegion?: string;
  affectationCode?: string;
};

export const regionList: { [key: string]: string } = {
  '13': 'DOM TOM',
  '64': 'Ile de France',
  '65': 'Nord Est',
  '66': 'Ouest',
  '67': 'Sud Est',
  '68': 'Sud Ouest',
};

export const isNotInputValid = (value: string) =>
  value.length < SEARCH_START_CARACTERE_LENGTH || value.trim().length !== value.length;

export const getRegionValueByCode = (code: string, listTeams: Team[]): string | regionType => {
  const region = listTeams.find(current => current.code === code);
  if (region === undefined) {
    return '';
  }
  const currentCode = region?.regionCode;
  if (currentCode === undefined) {
    return '';
  }
  return { affectationRegion: regionList[currentCode], affectationCode: region.regionCode };
};
