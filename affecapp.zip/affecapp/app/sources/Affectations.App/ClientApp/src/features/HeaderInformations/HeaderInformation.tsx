import './HeaderInformation.scss';

import { useState } from 'react';
import { UseMutateFunction } from '@tanstack/react-query';

import { Button, Loader, Modal } from '@affectations/components';
import { BadgeStatusName } from '@affectations/components/ui/Badge/types';
import { ButtonClassModifiers } from '@affectations/components/ui/Button/types';
import { FileResponse, FilterRuleDto } from '@affectations/api/bff-clients.generated';
import { TRulesQueryParams } from '@affectations/api/rules/types';
import { TError } from '@affectations/api/types';

import { rowHeaderType, rowRulesType } from '../commonTypes';
import { RowHeader } from './componennts/RowHeader';
import { RowHeaderInformation } from './componennts/RowHeaderInformations';

export interface IHeaderInfoRulesMapping {
  rowHeaderMapping: rowHeaderType;
  rowRulesMapping?: rowRulesType[];
  isLoading?: boolean;
  isSuccess?: boolean;
  sectionTitle?: string;
  ruleId?: TRulesQueryParams;
  mutationExportFn?: UseMutateFunction<FileResponse, TError, FilterRuleDto>;
  handleRuleExport?: (
    ruleId: TRulesQueryParams,
    FnMutation: UseMutateFunction<FileResponse, TError, FilterRuleDto>
  ) => void;
}
const CONTENT_WORDING = `Êtes-vous sûr de vouloir exporter cette règle ?`;

const showActiveCTAButton = (status: string | undefined) => {
  return ![BadgeStatusName.Error, BadgeStatusName.Sucess].includes(status as BadgeStatusName);
};
const HeaderInformation = ({
  rowHeaderMapping,
  rowRulesMapping,
  isLoading,
  isSuccess,
  sectionTitle,
  ruleId,
  mutationExportFn = () => {},
  handleRuleExport = () => {},
}: IHeaderInfoRulesMapping) => {
  const hasActiveRulesButton = showActiveCTAButton(rowHeaderMapping?.status);
  const [isOpen, setIsOpen] = useState<{ isToggleOn: boolean }>({ isToggleOn: false });

  const handleToggleModal = () => {
    setIsOpen(prevState => ({
      isToggleOn: !prevState.isToggleOn,
    }));
  };

  const handleExport = () => {
    ruleId && handleRuleExport(ruleId, mutationExportFn);
    handleToggleModal();
  };

  return (
    <section className="headerInformations-rules" aria-label="header infos rules">
      <Loader isLoading={isLoading}>
        {isSuccess && (
          <>
            <div className="container-head">
              <div className="container-head__item">
                <RowHeader {...rowHeaderMapping} />
              </div>
              <div className="container-head__item">
                {hasActiveRulesButton && (
                  <Button
                    title="Activer la règle"
                    classModifiers={[ButtonClassModifiers.Sucess, ButtonClassModifiers.resetWidth]}
                  />
                )}
                <Button
                  title="Modifier"
                  classModifiers={[ButtonClassModifiers.Info, ButtonClassModifiers.resetWidth]}
                />
                <Button
                  title="Exporter"
                  classModifiers={[ButtonClassModifiers.Reverse]}
                  onClick={handleToggleModal}
                  role="dialog"
                  aria-label="Exporter règle"
                />
              </div>
            </div>
            <h2 className="af-title">{sectionTitle}</h2>
            {rowRulesMapping?.map(({ label, content }, index) => (
              <RowHeaderInformation id={`infos-${index + 1}`} key={`block-${label}`} label={label} content={content} />
            ))}
            <Modal
              title="Exporter"
              isOpen={isOpen.isToggleOn}
              content={CONTENT_WORDING}
              buttonLabel="Confirmer"
              onClose={handleToggleModal}
              onSubmit={handleExport}
            />
          </>
        )}
      </Loader>
    </section>
  );
};
export { HeaderInformation };
