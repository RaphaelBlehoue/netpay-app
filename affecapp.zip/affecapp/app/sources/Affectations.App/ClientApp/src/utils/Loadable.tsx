import { Suspense } from 'react';

import { Loader } from '@affectations/components';

const Loadable = (Component: React.ComponentType) => (props: React.JSX.IntrinsicAttributes) => (
  <Suspense fallback={<Loader />}>
    <Component {...props} />
  </Suspense>
);

export { Loadable };
