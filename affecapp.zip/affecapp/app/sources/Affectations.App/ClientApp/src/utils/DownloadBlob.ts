const TIME_OUT = 100;

export const downloadFile = (
  file: Blob, fileName?: string,
): void => {
  // msSaveOrOpenBlob is a method provided by Microsoft's Internet Explorer and Edge browsers
  //for saving or opening a Blob object
  const navigator = window.navigator as Navigator & { msSaveOrOpenBlob?: (blob: Blob, defaultName?: string) => void };
  if (navigator && navigator.msSaveOrOpenBlob) {
    return navigator.msSaveOrOpenBlob(file);
  }

  // For other browsers:
  // Create a link pointing to the ObjectURL containing the blob.
  const fileUrlDownload = window.URL.createObjectURL(file);
  const anchorElement = document.createElement('a');
  anchorElement.href = fileUrlDownload;
  anchorElement.download = fileName ?? '';

  anchorElement.dispatchEvent(
    new MouseEvent('click', {
      bubbles: true,
      cancelable: true,
      view: window
    })
  );


  setTimeout(() => {
    window.URL.revokeObjectURL(fileUrlDownload);
    anchorElement.remove();
  }, TIME_OUT);
};
