import { getStatusConsultation, TStatus } from '@affectations/pages/Consultation/utils';
import { RuleDto } from '@affectations/api/bff-clients.generated';
import { Rule } from '@affectations/features/RuleDataTable/type';

const dataOrEmptyString = (value?: string) => value ?? '';
const formatDate = (date?: string | Date) => (date ? new Date(date).toLocaleDateString('fr-FR') : '');

export const toTableRules = (data?: RuleDto[]): Rule[] =>
  data?.map(x => {
    const currentStatus: TStatus = getStatusConsultation(
      x.ruleDetailsDto?.startDate,
      x.ruleDetailsDto?.endDate,
      x.ruleDetailsDto?.statut
    );
    return {
      status: dataOrEmptyString(currentStatus.statusLabel),
      id: dataOrEmptyString(x.id?.toString()),
      region: dataOrEmptyString(x.affectationDto?.affectedRegion),
      branche: dataOrEmptyString(x.critereDto?.branch),
      segmentation: dataOrEmptyString(x.critereDto?.segmentation),
      department: dataOrEmptyString(x.critereDto?.distributorDepartment),
      intermediate: dataOrEmptyString(x.critereDto?.intermediateName),
      walletCode: dataOrEmptyString(x.critereDto?.portfolioCode),
      network: dataOrEmptyString(x.critereDto?.network),
      contractNumber: dataOrEmptyString(x.critereDto?.contractNumber),
      team: dataOrEmptyString(x.affectationDto?.affectedTeam),
      collaborator: dataOrEmptyString(x.affectationDto?.affectedEmployee),
      accountManager: dataOrEmptyString(x.critereDto?.accountManager),
      clientNumber: dataOrEmptyString(x.critereDto?.clientNumber),
      uvProductCode: dataOrEmptyString(x.critereDto?.uvCode),
      clause: dataOrEmptyString(x.conditionsDto?.clauseCondition),
      syndicCode: dataOrEmptyString(x.critereDto?.syndicCode),
      nafCode: dataOrEmptyString(x.critereDto?.nafCode),
      copth: x.critereDto?.copht,
      contractCategory: dataOrEmptyString(x.critereDto?.contractCategory) ?? '',
      priorisation: dataOrEmptyString(x.ruleDetailsDto?.priority),
      ruleName: dataOrEmptyString(x.ruleDetailsDto?.ruleName),
      comment: dataOrEmptyString(x.ruleDetailsDto?.comment),
      startDate: formatDate(x.ruleDetailsDto?.startDate),
      endtDate: formatDate(x.ruleDetailsDto?.endDate),
      userMaj: dataOrEmptyString(x.ruleDetailsDto?.updatedBy),
      updateDate: formatDate(x.ruleDetailsDto?.updateDate),
    };
  }) ?? [];
