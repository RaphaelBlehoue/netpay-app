import { format } from 'date-fns';

export enum DateFormats {
  DATE = 'dd/MM/yyyy',
  DATE_TIME = "dd/MM/yyyy à HH'h'mm",
  DATE_TIME_FR = "dd/MM/yyyy à HH':'mm",
  DATE_BD = 'yyyy-MM-dd'
}

export enum NoProdEnv {
  MOCKENV = 'mock',
  DEVENV = 'development'
}

export const formatDate: (date?: Date, formatOption?: DateFormats) => string = (
  date,
  formatOption = DateFormats.DATE
) => (date ? format(date, formatOption) : '');

export const formatColorState: (state: string) => string = state => (state ? `bg-${state}` : '');

/**
 * Format siret
 * @param siret format 14 characters 12345678999999
 * @returns formatted siret 123456789 99999
 */
export const formatSiret = (siret?: string) => (siret ? `${siret.substring(0, 9)} ${siret.substring(9)}` : '');

export const isDevEnv = process.env.NODE_ENV === NoProdEnv.MOCKENV || process.env.NODE_ENV === NoProdEnv.DEVENV;

export const capitalize = (text?: string) => text && `${text.charAt(0).toUpperCase()}${text.slice(1)}`;

const SUCCESS_MESSAGE = `Les règles ont bien été exportées. Vous pouvez retrouver le fichier dans vos dossiers.`;
const SINGLE_SUCCESS_MESSAGE = `La règle a bien été exportée. Vous pouvez retrouver le fichier dans vos dossiers.`;
const ERROR_MESSAGE = `Il semblerait y avoir une erreur, veuillez réessayer ultérieurement.`;
const ICON_NAME_SUCCESS = 'glyphicon glyphicon-ok';
const ICON_NAME_ERROR = 'glyphicon glyphicon-exclamation-sign';

export { SUCCESS_MESSAGE, ERROR_MESSAGE, ICON_NAME_ERROR, ICON_NAME_SUCCESS, SINGLE_SUCCESS_MESSAGE };
