import { User, UserClaimType } from '@affectations/types/user';
import { IClaim } from '@affectations/api/duende-bff-clients.generated';

export const LOGIN_PATH = '/bff/login';
export const FORBIDDEN_PATH = '/forbidden';

export const resolveUser = (identity: IClaim[]): User | undefined => {
  if (identity.length === 0) {
    return undefined;
  }
  const rawClaims = identity.reduce<IClaim>((acc, current) => {
    const { type, value } = current;
    if (acc[type]) {
      acc[type] = typeof acc[type] === 'string' ? [acc[type], value] : [...acc[type], value];
    } else {
      acc[type] = value;
    }
    return acc;
  }, {} as IClaim);
  return {
    sid: rawClaims[UserClaimType.Sid],
    axaType: rawClaims[UserClaimType.AxaType],
    racf: rawClaims[UserClaimType.Racf],
    roles:
      typeof rawClaims[UserClaimType.Roles] === 'string'
        ? [rawClaims[UserClaimType.Roles]]
        : rawClaims[UserClaimType.Roles],
    givenName: rawClaims[UserClaimType.GivenName],
    surname: rawClaims[UserClaimType.Surname],
    name: rawClaims[UserClaimType.Name],
    rawClaims,
    get hasRole() {
      return Number(this.roles?.length ?? 0) > 0;
    },
  };
};
