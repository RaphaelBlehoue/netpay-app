import { User, UserClaimType } from '@affectations/types/user';

import { resolveUser } from '../authentication';

const testCases: {
  label: string;
  claims: { type: string; value: string | number }[];
  expectedUser: User | undefined;
}[] = [
  {
    label: 'Empty list of claim',
    claims: [],
    expectedUser: undefined,
  },
  {
    label: 'Claims with one role',
    claims: [
      {
        type: UserClaimType.Sid,
        value: '606fb974-6dcb-451f-b18b-587ed53c5528',
      },
      {
        type: UserClaimType.Roles,
        value: 'ROLE_1',
      },
    ],
    expectedUser: {
      sid: '606fb974-6dcb-451f-b18b-587ed53c5528',
      roles: ['ROLE_1'],
      rawClaims: {
        [UserClaimType.Roles]: 'ROLE_1',
        [UserClaimType.Sid]: '606fb974-6dcb-451f-b18b-587ed53c5528',
      } as never,
      hasRole: true,
    },
  },
  {
    label: 'Claims with multiple role',
    claims: [
      {
        type: UserClaimType.Sid,
        value: '606fb974-6dcb-451f-b18b-587ed53c5528',
      },
      {
        type: UserClaimType.Roles,
        value: 'ROLE_1',
      },
      {
        type: UserClaimType.Roles,
        value: 'ROLE_2',
      },
      {
        type: UserClaimType.Roles,
        value: 'ROLE_3',
      },
    ],
    expectedUser: {
      sid: '606fb974-6dcb-451f-b18b-587ed53c5528',
      roles: ['ROLE_1', 'ROLE_2', 'ROLE_3'],
      rawClaims: {
        [UserClaimType.Roles]: ['ROLE_1', 'ROLE_2', 'ROLE_3'],
        [UserClaimType.Sid]: '606fb974-6dcb-451f-b18b-587ed53c5528',
      } as never,
      hasRole: true,
    },
  },
  {
    label: 'Claims with any role',
    claims: [
      {
        type: UserClaimType.GivenName,
        value: 'John',
      },
      {
        type: UserClaimType.Sid,
        value: '606fb974-6dcb-451f-b18b-587ed53c5528',
      },
      {
        type: UserClaimType.Name,
        value: 'John Doe',
      },
      {
        type: UserClaimType.AxaType,
        value: '2',
      },
      {
        type: UserClaimType.Racf,
        value: 'S870973',
      },
    ],
    expectedUser: {
      sid: '606fb974-6dcb-451f-b18b-587ed53c5528',
      axaType: '2',
      racf: 'S870973',
      roles: undefined,
      givenName: 'John',
      name: 'John Doe',
      rawClaims: {
        sid: '606fb974-6dcb-451f-b18b-587ed53c5528',
        axa_type: '2',
        axa_uid_racf: 'S870973',
        name: 'John Doe',
        'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname': 'John',
      } as never,
      hasRole: false,
    },
  },
  {
    label: 'Claims with more iformations',
    claims: [
      {
        type: 'axa_cab_rdu',
        value: '',
      },
      {
        type: 'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier',
        value: 'BAeZx81NBvFnzwrh3GGyg/FfLkFN9tzhtDm3JRZS888=',
      },
      {
        type: 'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/gender',
        value: 'unknown',
      },
      {
        type: 'axa_quality',
        value: '',
      },
      {
        type: 'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname',
        value: 'John',
      },
      {
        type: 'sid',
        value: '606fb974-6dcb-451f-b18b-587ed53c5528',
      },
      {
        type: 'updated_at',
        value: '1707732722',
      },
      {
        type: 'auth_time',
        value: '1707738214',
      },
      {
        type: 'name',
        value: 'John Doe',
      },
      {
        type: 'axa_uid_rdu',
        value: '',
      },
      {
        type: 'realm',
        value: 'WAC_Recette_intranet',
      },
      {
        type: 'axa_type',
        value: '2',
      },
      {
        type: 'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/surname',
        value: 'John',
      },
      {
        type: 'axa_uid_racf',
        value: 'S870973',
      },
      {
        type: 'bff:logout_url',
        value: '/bff/logout?sid=606fb974-6dcb-451f-b18b-587ed53c5528',
      },
      {
        type: 'bff:session_expires_in',
        value: 1157,
      },
    ],
    expectedUser: {
      sid: '606fb974-6dcb-451f-b18b-587ed53c5528',
      axaType: '2',
      racf: 'S870973',
      roles: undefined,
      givenName: 'John',
      surname: 'John',
      name: 'John Doe',
      rawClaims: {
        axa_cab_rdu: '',
        'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier':
          'BAeZx81NBvFnzwrh3GGyg/FfLkFN9tzhtDm3JRZS888=',
        'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/gender': 'unknown',
        axa_quality: '',
        'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname': 'John',
        sid: '606fb974-6dcb-451f-b18b-587ed53c5528',
        updated_at: '1707732722',
        auth_time: '1707738214',
        name: 'John Doe',
        axa_uid_rdu: '',
        realm: 'WAC_Recette_intranet',
        axa_type: '2',
        'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/surname': 'John',
        axa_uid_racf: 'S870973',
        'bff:logout_url': '/bff/logout?sid=606fb974-6dcb-451f-b18b-587ed53c5528',
        'bff:session_expires_in': 1157,
      } as never,
      hasRole: false,
    },
  },
];

describe('authentication', () => {
  it.each(testCases)('$label should return expected user', ({ claims, expectedUser }) => {
    const result = resolveUser(claims as never);
    expect(result ?? {}).toMatchObject(expectedUser ?? {});
  });
});
