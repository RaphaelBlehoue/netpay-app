import { downloadFile } from '../DownloadBlob';



const navigator = window.navigator as Navigator & { msSaveOrOpenBlob?: (blob: Blob, defaultName?: string) => void };


describe('downloadFile', () => {
  it('should use msSaveOrOpenBlob on IE, Edge and other', () => {
    const blob = new Blob(['test content'], { type: 'text/plain' });
    const msSaveOrOpenBlob = vi.fn();
    navigator.msSaveOrOpenBlob = msSaveOrOpenBlob;
    downloadFile(blob, 'export.txt');

    expect(msSaveOrOpenBlob).toHaveBeenCalledWith(blob);
    delete (navigator.msSaveOrOpenBlob);
  });

});
