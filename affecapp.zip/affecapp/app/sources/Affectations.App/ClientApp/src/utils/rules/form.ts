import { z } from 'zod';

import { type SelectMultipleItems } from '@affectations/components/ui/SelectMultiple/SelectMultiple';

const MAX_TEN = 10;
const MAX_FIVE = 5;
const MAX_SIX = 6;
const MAX_SEVEN = 7;

export const schema = z.object({
  affectationRegions: z.any().optional(),
  affectationTeams: z.any().optional(),
  segmentations: z.any().optional(),
  branches: z.any().optional(),
  networks: z.any().optional(),
  regionDistributions: z.any().optional(),
  departmentDistributions: z.any().optional(),
  ruleStatus: z.any().optional(),
  collaborator: z.any().optional(),
  contractNumber: z.any().optional(),
  clientNumber: z.any().optional(),
  intermediaryName: z.any().optional(),
  uvCodeProduct: z.any().optional(),
  portfolioCode: z
    .string()
    .optional()
    .refine(value => !value || value?.toString().length === MAX_TEN, {
      message: 'Veuillez respecter le format de 10 caractères obligatoires.',
    }),
  clause: z
    .string()
    .optional()
    .refine(value => !value || value?.toString().length === MAX_SIX, {
      message: 'Respecter le format de 6 chiffres.',
    }),
  syndicCode: z
    .string()
    .optional()
    .refine(value => !value || value?.toString().length === MAX_FIVE, {
      message: 'Veuillez respecter le format : 5 caractères.',
    }),
  accountManager: z
    .string()
    .optional()
    .refine(value => !value || value?.toString().match(/^S\d{6}$/), {
      message: 'Veuillez respecter le format : 7 caractères maximum.',
    }),
  codeNAF: z
    .string()
    .optional()
    .refine(value => !value || value.toString().length === MAX_SEVEN, {
      message: 'Veuillez respecter le format : 7 caractères.',
    })
    .refine(value => !value || value?.toString().match(/\b\d{3}[A-Z012]\d{3}\b/), {
      message: 'Le format à respecter est : " PRXMATCH ("/\\b\\d{3}[A-Z012]\\d{3}\\b/',
    }),
});

export const convertTableToString = (value?: SelectMultipleItems) =>
  value
    ?.filter(x => x.isSelected)
    .map(x => x.value)
    .join('; ');
