import { createBrowserRouter, RouterProvider, RouterProviderProps } from 'react-router-dom';

import { configRoutes } from '@affectations/routes';

const browserRouter = createBrowserRouter(configRoutes);

const Router = (props: Partial<RouterProviderProps> = {}) => <RouterProvider router={browserRouter} {...props} />;

export { Router };
