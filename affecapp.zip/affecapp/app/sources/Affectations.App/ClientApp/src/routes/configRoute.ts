export const ROOT_BASE_URL = '/';
export const HOME_BASE_URL = '/';
export const AFFECTATION_BASE_URL = '/add-affectation-regle';
export const CONSULTATION_RULE_ID_DETAIL = '/consultation/:rulesId/detail';
