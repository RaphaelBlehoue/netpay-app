import { RouteObject } from 'react-router-dom';

import { configPrivateRoutes } from './privatesRoutes';


export const configRoutes: RouteObject[] = [
  ...configPrivateRoutes
];
