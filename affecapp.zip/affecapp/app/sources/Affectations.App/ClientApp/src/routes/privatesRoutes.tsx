import { RouteObject } from 'react-router-dom';

import { AppLayout } from '@affectations/components/layouts/Layout/AppLayout';
import Affectation from '@affectations/pages/affectations';
import ConsultationDetail from '@affectations/pages/Consultation/ConsultationDetail';
import Home from '@affectations/pages/home';
import NotFound from '@affectations/pages/not-found/NotFound';

import { AFFECTATION_BASE_URL, CONSULTATION_RULE_ID_DETAIL, HOME_BASE_URL, ROOT_BASE_URL } from './configRoute';

export const configPrivateRoutes: RouteObject[] = [
  {
    path: ROOT_BASE_URL,
    element: <AppLayout />,
    children: [
      { path: HOME_BASE_URL, element: <Home /> },
      { path: AFFECTATION_BASE_URL, element: <Affectation /> },
      { path: CONSULTATION_RULE_ID_DETAIL, element: <ConsultationDetail /> },
      { path: '*', element: <NotFound /> },
    ],
  },
];
