import { HttpHandler } from 'msw';

import { getUserMock } from '@affectations/__apiMocks__/seeds/authentication/authentication.mock';
import { searchCollaborators } from '@affectations/__apiMocks__/seeds/employees/employees.mocks';
import {
  getRulesCriteriaMock,
  postCriteriaSearch,
  searchRulesCriteriaMock,
} from '@affectations/__apiMocks__/seeds/rulesCriteria/rulesCriteria.mocks';
import {
  createRules,
  getRulesByIdConsultationMock,
  searchRule,
} from '@affectations/__apiMocks__/seeds/rules/rules.mocks';
import { getTeamsMock } from './../__apiMocks__/seeds/teams/teams.mock';
import { exportRules } from '@affectations/__apiMocks__/seeds/exportRules/exportRules.mocks';

const AuthentificationHandlerArray: Array<HttpHandler> = [getUserMock()];
const ConsultationHandlerArray: Array<HttpHandler> = [
  getRulesByIdConsultationMock(),
  getRulesCriteriaMock(),
  postCriteriaSearch(),
  searchRulesCriteriaMock(),
  searchRule(),
  searchCollaborators(),
  getTeamsMock(),
  createRules(),
  exportRules()
];

export const handlers: ReadonlyArray<HttpHandler> = [...ConsultationHandlerArray, ...AuthentificationHandlerArray];
