export const getUrl = (path: string) => `${window.location.origin}/api/v1/${path}`;
