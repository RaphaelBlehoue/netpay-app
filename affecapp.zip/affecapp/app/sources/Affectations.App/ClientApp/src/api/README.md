### here's how we'd like this folder to be organized with indications and roles in brackets

```
| README.md
|
+---affectations
| queryKeys.ts
| useGetAffectation.ts
| useGetAffectionCancel.ts
| usePostAffection.ts
|
+---consultations
  queryKeys.ts
  useGetConsulation.ts
  useGetConsulationStatus.ts
  usePostConsulation.ts
```
