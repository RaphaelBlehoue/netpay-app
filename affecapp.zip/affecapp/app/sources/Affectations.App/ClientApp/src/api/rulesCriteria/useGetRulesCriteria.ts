import { useFetch } from '@affectations/lib/fetch-api';
import { useQuery } from '@tanstack/react-query';
import {
  IRuleCriterionCategory,
  RuleCriteriaClient
} from '../bff-clients.generated';
import { DEFAULT_STALE_TIME, TError, UseQueryGenericType, } from '../types';
import { QUERY_KEYS } from './queryKeys';


export type IRuleCriterion = {
  code?: string;
  label?: string;
};

export type IRuleCategory = {
  code?: string;
  label?: string;
  ruleCriteria?: IRuleCriterion[];
};

const BuildGetRulesCriteriaAdaptorFactory = () => {
  const rulesClient = new RuleCriteriaClient('', { fetch: useFetch() });
  return rulesClient.getRuleCriteria();
};

export const useGetRulesCriteria = (): UseQueryGenericType<Record<string, IRuleCriterionCategory>, TError> => {
  const {
    data,
    error,
    isError,
    isLoading,
    isSuccess,
    status,
    isStale,
    isFetched
  } = useQuery<Record<string, IRuleCriterionCategory>, TError>({
    queryKey: [QUERY_KEYS.RULES_CRITERIA],
    queryFn: () => BuildGetRulesCriteriaAdaptorFactory(),
    staleTime: DEFAULT_STALE_TIME
  });
  return { data, error, isLoading, status, isError, isSuccess, isStale, isFetched };
};
