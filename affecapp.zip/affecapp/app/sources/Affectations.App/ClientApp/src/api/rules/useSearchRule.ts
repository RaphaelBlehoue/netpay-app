import { useQuery } from '@tanstack/react-query';

import { PagedDataOfRuleDto, RuleDto, RulesClient } from '@affectations/api/bff-clients.generated';
import { useFetch } from '@affectations/lib/fetch-api';

import { DEFAULT_STALE_TIME, QUERY_KEYS } from './queryKeys';
import { TError, UseQueryGenericType } from '../types';

const BuildSearchRulesAdaptorFactory = (page: number, size: number, ruleDto: RuleDto) => {
  const rulesClientApiProvider = new RulesClient('', { fetch: useFetch() });
  return rulesClientApiProvider.search(page, size, ruleDto);
};

export const useSearchRule = (
  page: number,
  size: number,
  ruleDto: RuleDto
): UseQueryGenericType<PagedDataOfRuleDto, TError> =>
  useQuery({
    queryKey: [QUERY_KEYS.RULES_SEARCH_AFFECTATION, page, size, JSON.stringify(ruleDto)],
    queryFn: () => BuildSearchRulesAdaptorFactory(page, size, ruleDto),
    staleTime: DEFAULT_STALE_TIME,
  });
