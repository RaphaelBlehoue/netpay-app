import { useFetch } from '@affectations/lib/fetch-api';
import { ApiException, IProblemDetails, IRuleDto, RulesClient } from '../bff-clients.generated';
import { TRulesQueryParams } from './types';
import { useQuery } from '@tanstack/react-query';
import { DEFAULT_STALE_TIME, UseQueryGenericType, } from '../types';
import { QUERY_KEYS } from './queryKeys';


type TError = IProblemDetails | ApiException;

const BuildGetRulesByIdAdaptorFactory = (ruleId: number) => {
  const rulesClient = new RulesClient('', { fetch: useFetch() });
  return rulesClient.getRuleById(ruleId);
};

export const useGetRulesById = (params: TRulesQueryParams): UseQueryGenericType<IRuleDto, TError> => {
  const { rulesId } = params;
  const { data, error, isError, isLoading, isSuccess, status, isStale, isFetched } = useQuery<IRuleDto, TError>({
    queryKey: [QUERY_KEYS.RULES_ID_AFFECTATION, rulesId],
    queryFn: () => BuildGetRulesByIdAdaptorFactory(rulesId),
    staleTime: DEFAULT_STALE_TIME
  });
  return { data, error, isLoading, status, isError, isSuccess, isStale, isFetched };
};
