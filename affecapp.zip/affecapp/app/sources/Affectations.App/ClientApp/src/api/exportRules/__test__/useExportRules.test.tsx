import { PropsWithChildren } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { renderHook, waitFor } from '@testing-library/react';
import { MemoryRouter as Router } from 'react-router-dom';

import { downloadFile } from '@affectations/utils/DownloadBlob';
import { StatusCodes } from '@affectations/utils/http';
import { exportRules } from '@affectations/__apiMocks__/seeds/exportRules/exportRules.mocks';
import {
  AffectationDto,
  ConditionsDto,
  CriteresDto,
  FilterRuleDto,
  RuleDetailsDto,
} from '@affectations/api/bff-clients.generated';
import { server } from '@affectations/mocks/server';

import { TFilterRuleDto, useExportRules } from '../useExportRules';

vi.mock('@affectations/utils/DownloadBlob', () => ({
  downloadFile: vi.fn(),
}));

const currentFilterStateMock = new FilterRuleDto({
  ruleDetailsDto: new RuleDetailsDto(),
  affectationDto: new AffectationDto(),
  conditionsDto: new ConditionsDto(),
  critereDto: new CriteresDto(),
}) as TFilterRuleDto;

const inputExportFileMock = (isMulti: boolean = false) =>
  new FilterRuleDto({
    ...(isMulti
      ? {
          ids: [1, 3, 4],
          ruleDetailsDto: new RuleDetailsDto(),
          affectationDto: new AffectationDto(),
          conditionsDto: new ConditionsDto(),
          critereDto: new CriteresDto(),
        }
      : {
          ids: [],
          ...currentFilterStateMock,
        }),
  });

const mockExportRules = (status: number = StatusCodes.OK) => {
  server.use(exportRules(status));
};

const createWrapper = () => {
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: {
        retry: false,
      },
    },
  });
  return ({ children }: PropsWithChildren) => (
    <Router>
      <QueryClientProvider client={queryClient}> {children} </QueryClientProvider>
    </Router>
  );
};

const setupHook = () => {
  return renderHook(() => useExportRules(), {
    wrapper: createWrapper(),
  });
};

describe('useExportRules', () => {
  it('should retrieve the assignment rule(s) successfully with All', async () => {
    mockExportRules();
    const { result } = setupHook();
    const AllExport = inputExportFileMock();
    await waitFor(() => result.current.mutate(AllExport));
    await waitFor(() => expect(result.current.isSuccess).toBe(true));
    expect(downloadFile).toHaveBeenCalledWith(result.current.data?.data, result.current.data?.fileName);
    expect(downloadFile).toHaveBeenCalledTimes(1);
  });

  it('should retrieve the assignment rule(s) successfully with ids', async () => {
    mockExportRules();
    const { result } = setupHook();
    const IdsExport = inputExportFileMock(false);
    await waitFor(() => result.current.mutate(IdsExport));
    await waitFor(() => expect(result.current.isSuccess).toBe(true));
    expect(downloadFile).toHaveBeenCalledWith(result.current.data?.data, result.current.data?.fileName);
    expect(downloadFile).toHaveBeenCalledTimes(1);
  });

  it('should not retrieve the assignment rule(s) when unauthorized error', async () => {
    mockExportRules(StatusCodes.UNAUTHORIZED);
    const { result } = setupHook();
    const AllExport = inputExportFileMock();
    await waitFor(() => result.current.mutate(AllExport));
    await waitFor(() => expect(result.current.isSuccess).toBe(false));
    expect(downloadFile).not.toHaveBeenCalledWith(result.current.data?.data, result.current.data?.fileName);
  });

  it('should not retrieve the assignment rule(s) when internal error', async () => {
    mockExportRules(StatusCodes.INTERNAL);
    const { result } = setupHook();
    const AllExport = inputExportFileMock();
    await waitFor(() => result.current.mutate(AllExport));
    await waitFor(() => expect(result.current.isSuccess).toBe(false));
    expect(downloadFile).not.toHaveBeenCalledWith(result.current.data?.data, result.current.data?.fileName);
  });
});
