import { useFetch } from '@affectations/lib/fetch-api';
import { useMutation } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import {
  ApiException,
  IProblemDetails,
  RuleCreationDto,
  RuleDto,
  RulesClient
} from '../bff-clients.generated';
import { UseMutationType, } from '../types';
import { AffectationCreationOrUpdateState } from '@affectations/types';

type TError = IProblemDetails | ApiException;


const BuildCreateRulesAdaptorFactory = (data: RuleCreationDto) => {
  const rulesClient = new RulesClient('', { fetch: useFetch() });
  return rulesClient.addRule(data);
};

export const useCreateRules = (): UseMutationType<unknown, TError, RuleDto> => {
  const navigate = useNavigate();
  const { mutate, isError, error, isSuccess } = useMutation<RuleDto, TError, RuleDto>({
    mutationFn: async (inputFormData: RuleCreationDto) => BuildCreateRulesAdaptorFactory(inputFormData),
    onSuccess: async (data, _rulesData) => {
      navigate(`/consultation/${data.id}/detail`, {
        state: { isCreatedOrUpdatedContract: AffectationCreationOrUpdateState.Created }
      });
    }
  });
  return { mutate, isError, error, isSuccess };
};
