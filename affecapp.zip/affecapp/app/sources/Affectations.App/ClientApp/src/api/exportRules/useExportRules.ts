import { useMutation } from '@tanstack/react-query';

import { downloadFile } from '@affectations/utils/DownloadBlob';
import { useFetch } from '@affectations/lib/fetch-api';

import {
  ApiException,
  FileResponse,
  FilterRuleDto,
  IFilterRuleDto,
  IProblemDetails,
  RulesClient,
} from '../bff-clients.generated';
import { UseMutationTypeWithData } from '../types';

type TError = IProblemDetails | ApiException;
export type TFilterRuleDto = IFilterRuleDto & Omit<IFilterRuleDto, 'ids'>;

const BuildExportRuleAdaptorFactory = (ExportData: FilterRuleDto) => {
  const rulesClient = new RulesClient('', { fetch: useFetch() });
  return rulesClient.export(ExportData);
};

export const useExportRules = (): UseMutationTypeWithData<FileResponse, TError, FilterRuleDto> => {
  const { mutate, isError, error, isSuccess, data } = useMutation<FileResponse, TError, FilterRuleDto>({
    mutationFn: async (inputExportFile: FilterRuleDto) => BuildExportRuleAdaptorFactory(inputExportFile),
    onSuccess: async (file: FileResponse) => {
      const { data: dataFile, fileName } = file;
      downloadFile(dataFile, fileName);
    },
  });
  return { mutate, isError, error, isSuccess, data };
};
