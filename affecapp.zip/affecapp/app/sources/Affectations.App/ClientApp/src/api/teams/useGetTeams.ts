import { useQuery } from '@tanstack/react-query';

import { useFetch } from '@affectations/lib/fetch-api';

import { TeamsClient } from '../bff-clients.generated';
import { QUERY_KEYS } from './queryKey';

const BuilGetCollaboratorsFactory = () => {
  const client = new TeamsClient('', { fetch: useFetch() });
  return client.getTeams();
};

export const useGetTeams = () =>
  useQuery({
    queryKey: [QUERY_KEYS.ALL_TEAMS],
    queryFn: BuilGetCollaboratorsFactory,
  });
