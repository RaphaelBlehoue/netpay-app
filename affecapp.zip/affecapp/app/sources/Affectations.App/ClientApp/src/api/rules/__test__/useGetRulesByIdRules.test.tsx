import { renderHook, waitFor } from '@testing-library/react';
import { http, HttpResponse } from 'msw';

import { StatusCodes } from '@affectations/utils/http';
import getRulesdActiveJson from '@affectations/__apiMocks__/seeds/rules/mocks/get-rules-by-id-200-active-and-now.json';
import getRulesByIdMockJson from '@affectations/__apiMocks__/seeds/rules/mocks/get-rules-by-id-200.json';
import { RuleDto } from '@affectations/api/bff-clients.generated';
import { server } from '@affectations/mocks/server';
import { renderWrapperWithReactQuery } from '@affectations/test-utils';

import { TRulesQueryParams } from '../types';
import { useGetRulesById } from '../useGetRulesByIdRules';

const mockGetRuleById = (id: number, rule: Record<string, unknown>) => {
  server.use(
    http.get(`/rules/${id}`, () => {
      return HttpResponse.json(rule, { status: StatusCodes.OK });
    })
  );
};

const setupHook = (params: TRulesQueryParams) => {
  return renderHook(() => useGetRulesById(params), {
    wrapper: renderWrapperWithReactQuery(),
  });
};

describe('useGetRulesByIdRules', () => {
  it('should successfully retrieve all data from the rules consultation', async () => {
    const getRuleByIdParams: TRulesQueryParams = { rulesId: 1 };
    mockGetRuleById(1, getRulesByIdMockJson);
    const expectedData = RuleDto.fromJS(getRulesByIdMockJson);

    const { result } = setupHook(getRuleByIdParams);

    expect(result.current.isLoading).toBe(true);
    await waitFor(() => expect(result.current.isFetched).toBe(true));
    await waitFor(() => expect(result.current.isSuccess).toBe(true));
    expect(result.current.isLoading).toBe(false);
    expect(result.current.data).toEqual(expectedData);
  });

  it('should successfully retrieve partial data from the rules consultation', async () => {
    const getRuleByIdParams: TRulesQueryParams = { rulesId: 2 };
    mockGetRuleById(2, getRulesdActiveJson);
    const expectedData = RuleDto.fromJS(getRulesdActiveJson);

    const { result } = setupHook(getRuleByIdParams);

    expect(result.current.isLoading).toBe(true);
    await waitFor(() => expect(result.current.isFetched).toBe(true));
    await waitFor(() => expect(result.current.isSuccess).toBe(true));
    expect(result.current.isLoading).toBe(false);
    expect(result.current.data).toEqual(expectedData);
  });
});
