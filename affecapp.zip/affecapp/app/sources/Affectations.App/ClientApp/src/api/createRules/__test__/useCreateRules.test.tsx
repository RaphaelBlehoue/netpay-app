import { PropsWithChildren } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { renderHook, waitFor } from '@testing-library/react';
import { http, HttpResponse } from 'msw';
import { MemoryRouter as Router } from 'react-router-dom';

import { StatusCodes } from '@affectations/utils/http';
import postRulesAffectation from '@affectations/__apiMocks__/seeds/rules/mocks/post-rules-201.json';
import { RuleCreationDto } from '@affectations/api/bff-clients.generated';
import { server } from '@affectations/mocks/server';
import { getUrl } from '@affectations/mocks/url';

import { useCreateRules } from '../useCreateRules';

const mockPostRules = () => {
  server.use(
    http.post(getUrl('rules'), async ({ request }) => {
      return HttpResponse.json(postRulesAffectation, { status: StatusCodes.CREATED });
    })
  );
};

const input = {
  ruleDetailsDto: {
    ruleName: '',
    statut: 'active',
    startDate: '2024-05-24T00:00:00.000Z',
    comment: 'axa connect',
  },
  affectationDto: {
    affectedTeam: 'ES_AUTO_SE',
    affectedRegion: 'Sud Est',
    affectedEmployee: 'S009795',
  },
  rules: {
    Branche: {
      condition: 'est parmi',
      values: ['Auto'],
    },
    'Région distributeur': {
      condition: 'est parmi',
      values: ['65'],
    },
    Segmentation: {
      condition: 'est parmi',
      values: ['EN'],
    },
  },
} as unknown as RuleCreationDto;
const createWrapper = () => {
  const queryClient = new QueryClient({
    defaultOptions: {
      queries: {
        retry: false,
      },
    },
  });
  return ({ children }: PropsWithChildren) => (
    <Router>
      <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>
    </Router>
  );
};
const setupHook = () => {
  return renderHook(() => useCreateRules(), {
    wrapper: createWrapper(),
  });
};

describe('useCreate', () => {
  it('should create affectation successfully', async () => {
    mockPostRules();
    const { result } = setupHook();
    await waitFor(() => {
      result.current.mutate(input);
      expect(result.current.isSuccess).toBe(true);
      expect(result.current.isError).toBe(false);
      expect(result.current.error).toBeNull();
    });
  });
});
