export const QUERY_KEYS = {
  RULES_ID_AFFECTATION: 'rules_id_Affectation',
  RULES_SEARCH_AFFECTATION: 'rules_search_Affectation',
};
export const DEFAULT_STALE_TIME = 3_600_000;
