export type TRulesQueryParams = {
  rulesId: number
};
