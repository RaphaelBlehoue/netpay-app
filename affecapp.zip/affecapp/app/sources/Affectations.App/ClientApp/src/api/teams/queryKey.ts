export const QUERY_KEYS = {
  ALL_TEAMS: 'ALL_TEAMS',
};
