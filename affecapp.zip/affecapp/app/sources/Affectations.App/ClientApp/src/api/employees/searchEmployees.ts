import { EmployeesClient, EmployeeSearchDto } from '../bff-clients.generated';
import { TOption } from '@affectations/components';
import { useFetch as httpAct } from '@affectations/lib/fetch-api';

export const searchEmployees = async (searchInput: string) => {
  const client = new EmployeesClient('', { fetch: httpAct() });
  const dto = new EmployeeSearchDto({
    pageNumber: 1,
    pageSize: 10,
  });
  dto.lastNameStartsWithFilter = searchInput;
  const result = await client.search(dto);
  return (
    result.data?.map<TOption>(x => ({
      label: `${x.lastName} ${x.firstName} - ${x.id}`,
      value: x.id?.toString() ?? '',
    })) ?? []
  );
};
