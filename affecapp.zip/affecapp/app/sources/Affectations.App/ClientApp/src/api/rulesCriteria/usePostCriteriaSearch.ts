import { useState } from 'react';

import { TOption } from '@affectations/components';
import { STATIC_ALL_VALUE_CRITERIA } from '@affectations/features/TermsOfTheWizardRules/utils';

import { ApiException, IProblemDetails, RuleCriterion } from '../bff-clients.generated';
import { CriteriaName, searchCriteriaByName } from '../citeria';

type TError = IProblemDetails | ApiException;

export const usePostCriteriaSearch = ({
  criteria = STATIC_ALL_VALUE_CRITERIA.INTERMEDIARY_NAME,
}: {
  criteria?: CriteriaName;
}) => {
  const [error, setError] = useState<TError>();
  const searchCriteriaPost = async (searchInput: string): Promise<TOption[]> => {
    try {
      const response = await searchCriteriaByName(criteria, searchInput);
      return (
        response.data
          ?.map<TOption>((x: RuleCriterion) => ({
            label: x.label?.toString() ?? '',
            value: x.code?.toString() ?? '',
          }))
          .filter(({ label, value }: TOption): boolean => label !== '' && value !== '') ?? []
      );
    } catch (err) {
      setError(err as TError);
      throw error;
    }
  };

  return {
    searchCriteriaPost,
    error,
  };
};
