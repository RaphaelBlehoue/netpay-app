import { UseQueryResult, UseMutationResult } from '@tanstack/react-query';
import { ApiException, IProblemDetails } from './bff-clients.generated';

type QueryKeysType = 'data' | 'error' | 'isLoading' | 'isError' | 'isSuccess' | 'status' | 'isStale' | 'isFetched';
type TErrorType = null | unknown;

export type TError = IProblemDetails | ApiException;

export const DEFAULT_STALE_TIME = 3_600_000;

type UseMutationResultKeys = 'mutate' | 'isError' | 'error' | 'isSuccess';

export type UseQueryGenericType<TData = unknown, Error = TErrorType> = Pick<UseQueryResult<
  TData, Error>, QueryKeysType>;

export type UseMutationType<TData = unknown, TErrors = unknown, TVariables = void> = Pick<
  UseMutationResult<TData, TErrors, TVariables>,
  UseMutationResultKeys
>;
export type UseMutationTypeWithData<TData = unknown, TErrors = unknown, TVariables = void> = Pick<
  UseMutationResult<TData, TErrors, TVariables>,
  UseMutationResultKeys | 'data'
>;
export type UseMutationTypeWithMutateAsync<TData = unknown, TErrors = unknown, TVariables = void> = Pick<
  UseMutationResult<TData, TErrors, TVariables>,
  UseMutationResultKeys | 'mutateAsync'
>;
