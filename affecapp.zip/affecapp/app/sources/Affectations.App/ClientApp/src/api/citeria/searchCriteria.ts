import { useFetch as httpAct } from '@affectations/lib/fetch-api';

import { RuleCriteriaClient, RuleCriterionSearchDto } from '../bff-clients.generated';

export type CriteriaName =
  | 'BRANCH'
  | 'CLAUSE'
  | 'DISTRIBUTION_DEPARTMENT'
  | 'DISTRIBUTION_REGION'
  | 'ASSIGNMENT_REGION'
  | 'INTERMEDIARY_NAME'
  | 'NETWORKS'
  | 'QP_CONTRACT_CATEGORY'
  | 'SEGMENTATION'
  | 'PORTFOLIO_CODE'
  | 'UVCODE';

export const searchCriteriaByName = async (criteria: CriteriaName, searchTerm: string) => {
  const client = new RuleCriteriaClient('', { fetch: httpAct() });

  const dto = new RuleCriterionSearchDto({
    categoryCode: criteria,
    labelStartsWithFilter: searchTerm,
    pageNumber: 1,
    pageSize: 10,
  });

  return client.search(dto);
};
