export const QUERY_KEYS = {
  RULES_CRITERIA: 'rules_All_Criteria'
};
