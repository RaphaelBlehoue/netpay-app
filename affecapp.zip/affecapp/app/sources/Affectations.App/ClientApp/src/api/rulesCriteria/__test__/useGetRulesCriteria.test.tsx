import { renderHook, waitFor } from '@testing-library/react';
import { http, HttpResponse } from 'msw';

import { StatusCodes } from '@affectations/utils/http';
import getRulesCriteria from '@affectations/__apiMocks__/seeds/rulesCriteria/mocks/get-rules-criteria.json';
import { server } from '@affectations/mocks/server';
import { renderWrapperWithReactQuery } from '@affectations/test-utils';

import { useGetRulesCriteria } from '../useGetRulesCriteria';

const mockGetRuleCriteria = (rulesCriteria: Record<string, unknown>) => {
  server.use(
    http.get(`/api/v1/rule-criteria`, () => {
      return HttpResponse.json(rulesCriteria, { status: StatusCodes.OK });
    })
  );
};

const setupHook = () => {
  return renderHook(() => useGetRulesCriteria(), {
    wrapper: renderWrapperWithReactQuery(),
  });
};

describe('useGetRulesByIdRules', () => {
  it('should successfully retrieve all data from the rules consultation', async () => {
    mockGetRuleCriteria(getRulesCriteria);
    const expectedData = JSON.parse(JSON.stringify(getRulesCriteria));

    const { result } = setupHook();

    expect(result.current.isLoading).toBe(true);
    await waitFor(() => expect(result.current.isFetched).toBe(true));
    await waitFor(() => expect(result.current.isSuccess).toBe(true));
    expect(result.current.isLoading).toBe(false);
    expect(result.current.data).toEqual(expectedData);
  });
});
