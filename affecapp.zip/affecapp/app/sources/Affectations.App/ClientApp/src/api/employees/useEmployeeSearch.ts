import { TOption } from '@affectations/components';
import { useState } from 'react';
import {
  ApiException,
  IProblemDetails
} from '../bff-clients.generated';
import { searchEmployees } from './searchEmployees';

type TError = IProblemDetails | ApiException;

export const useEmployeeSearch = () => {
  const [error, setError] = useState<TError>();
  const findEmployees = async (searchInput: string): Promise<TOption[]> => {
    try {
      return await searchEmployees(searchInput);
    } catch (err) {
      setError(err as TError);
      throw error;
    }
  };

  return {
    findEmployees,
    error,
  };
};
