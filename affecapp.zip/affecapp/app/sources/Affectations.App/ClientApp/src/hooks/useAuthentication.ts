import { useContext } from 'react';

import { AuthenticationContext } from '@affectations/contexts';

export const useAuthentication = () => {
  return useContext(AuthenticationContext);
};
