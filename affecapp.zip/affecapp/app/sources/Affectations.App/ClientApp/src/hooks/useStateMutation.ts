import { useIsMutating } from '@tanstack/react-query';

const useStateMutation = () => {
  const isMutatingState = 0;
  const mutationState = useIsMutating();
  const isMutating = mutationState > isMutatingState;
  return {
    isMutating,
  };
};

export { useStateMutation };
