import { FC, PropsWithChildren } from 'react';
import { act, renderHook } from '@testing-library/react';
import { http, HttpResponse } from 'msw';

import { HTTP_STATUS } from '@affectations/components/ui/ErrorMessage/constants';
import { AuthenticationProvider } from '@affectations/contexts';
import { server } from '@affectations/mocks/server';

import { useAuthentication } from '../useAuthentication';
import { wait } from '../useError';

const claims = [
  {
    type: 'axa_cab_rdu',
    value: '',
  },
  {
    type: 'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier',
    value: 'BAeZx81NBvFnzwrh3GGyg/FfLkFN9tzhtDm3JRZS888=',
  },
  {
    type: 'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/gender',
    value: 'unknown',
  },
  {
    type: 'axa_quality',
    value: '',
  },
  {
    type: 'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname',
    value: 'John',
  },
  {
    type: 'sid',
    value: '606fb974-6dcb-451f-b18b-587ed53c5528',
  },
  {
    type: 'updated_at',
    value: '1707732722',
  },
  {
    type: 'auth_time',
    value: '1707738214',
  },
  {
    type: 'name',
    value: 'John Doe',
  },
  {
    type: 'axa_uid_rdu',
    value: '',
  },
  {
    type: 'realm',
    value: 'WAC_Recette_intranet',
  },
  {
    type: 'axa_type',
    value: '2',
  },
  {
    type: 'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/surname',
    value: 'John',
  },
  {
    type: 'axa_uid_racf',
    value: 'S870973',
  },
  {
    type: 'bff:logout_url',
    value: '/bff/logout?sid=606fb974-6dcb-451f-b18b-587ed53c5528',
  },
  {
    type: 'bff:session_expires_in',
    value: 1157,
  },
];

const mockRequest = (body: object | undefined, status: number) => {
  server.use(
    http.get('/bff/user', () => {
      return HttpResponse.json(body, { status });
    })
  );
};

describe('useAuthetication', () => {
  const Wrapper: FC<PropsWithChildren> = ({ children }) => <AuthenticationProvider>{children}</AuthenticationProvider>;
  it('Should load while data are fetched', () => {
    const { result } = renderHook(() => useAuthentication(), { wrapper: Wrapper });
    server.use(
      http.get('/bff/user', () => {
        wait(300);
        return HttpResponse.json(claims, { status: HTTP_STATUS.OK });
      })
    );

    expect(result.current.isLoading).toBeTruthy();
    expect(result.current.error).toBeUndefined();
    expect(result.current.user).toBeUndefined();
  });

  it('Should return user after fetch', async () => {
    mockRequest(claims, HTTP_STATUS.OK);
    const { result } = renderHook(() => useAuthentication(), { wrapper: Wrapper });
    const expected = {
      sid: '606fb974-6dcb-451f-b18b-587ed53c5528',
      axaType: '2',
      racf: 'S870973',
      roles: undefined,
      givenName: 'John',
      surname: 'John',
      name: 'John Doe',
      rawClaims: {
        axa_cab_rdu: '',
        'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier':
          'BAeZx81NBvFnzwrh3GGyg/FfLkFN9tzhtDm3JRZS888=',
        'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/gender': 'unknown',
        axa_quality: '',
        'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname': 'John',
        sid: '606fb974-6dcb-451f-b18b-587ed53c5528',
        updated_at: '1707732722',
        auth_time: '1707738214',
        name: 'John Doe',
        axa_uid_rdu: '',
        realm: 'WAC_Recette_intranet',
        axa_type: '2',
        'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/surname': 'John',
        axa_uid_racf: 'S870973',
        'bff:logout_url': '/bff/logout?sid=606fb974-6dcb-451f-b18b-587ed53c5528',
        'bff:session_expires_in': 1157,
      },
      hasRole: false,
    };

    await act(async () => result.current.fetchUser());

    expect(result.current.user).toMatchObject(expected);
    expect(result.current.isLoading).toBeFalsy();
    expect(result.current.error).toBeUndefined();
  });
  it('Should return error when fetch failed', async () => {
    const { result } = renderHook(() => useAuthentication(), { wrapper: Wrapper });
    mockRequest({}, HTTP_STATUS.UNAUTHORIZED);
    await act(async () => result.current.fetchUser());

    expect(result.current.user).toBeUndefined();
    expect(result.current.isLoading).toBeFalsy();
    expect(result.current.error).toBeDefined();
  });
});
