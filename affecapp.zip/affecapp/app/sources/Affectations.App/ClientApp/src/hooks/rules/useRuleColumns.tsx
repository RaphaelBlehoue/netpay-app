import { useMemo } from 'react';
import Badge from '@axa-fr/react-toolkit-badge';
import { CheckboxItem } from '@axa-fr/react-toolkit-form-input-checkbox';
import { ColumnDef } from '@tanstack/react-table';
import clsx from 'clsx';

import { Rule } from '@affectations/features/RuleDataTable/type';

const ellipsisArray = (input?: string): string => {
  if (!input) {
    return '';
  }
  const splitted = input.split(';');
  if (splitted.length === 1) {
    return input;
  }

  return splitted[0]?.trim() + ';...';
};

export const useRuleColumns = () =>
  useMemo<ColumnDef<Rule>[]>(
    () => [
      {
        id: 'select',
        header: ({ table }) => (
          <CheckboxItem isChecked={table.getIsAllRowsSelected()} onClick={table.getToggleAllRowsSelectedHandler()} />
        ),
        cell: ({ row }) => (
          <CheckboxItem
            isChecked={row.getIsSelected()}
            disabled={!row.getCanSelect()}
            onChange={row.getToggleSelectedHandler()}
          />
        ),
        enableSorting: false,
      },
      {
        id: 'status',
        header: 'Statut',
        accessorKey: 'status',
        cell: info => {
          const status = info.getValue()?.toString();
          if (!status) {
            return null;
          }
          return (
            <Badge
              classModifier={clsx({
                success: status.toLocaleLowerCase() === 'Active'.toLocaleLowerCase(),
                danger: status.toLocaleLowerCase() === 'Brouillon'.toLocaleLowerCase(),
                error: status.toLocaleLowerCase() === 'Expirée'.toLocaleLowerCase(),
              })}
            >
              {status}
            </Badge>
          );
        },
      },
      {
        id: 'region',
        header: "Région d'affectation",
        accessorKey: 'region',
        cell: info => info.getValue(),
      },
      {
        id: 'branche',
        header: 'Branche',
        accessorKey: 'branche',
        cell: info => info.getValue(),
      },
      {
        id: 'segmentation',
        header: 'Segmentation',
        accessorKey: 'segmentation',
        cell: info => info.getValue(),
      },
      {
        id: 'department',
        header: 'Département',
        accessorKey: 'department',
        cell: info => info.getValue(),
      },
      {
        id: 'intermediate',
        header: "Nom d'intermédiaire",
        accessorKey: 'intermediate',
        cell: info => ellipsisArray(info.getValue<string>()),
      },
      {
        id: 'walletCode',
        header: 'Code portefeuille',
        accessorKey: 'walletCode',
        cell: info => ellipsisArray(info.getValue<string>()),
      },
      {
        id: 'network',
        header: 'Réseau',
        accessorKey: 'network',
        cell: info => info.getValue(),
      },
      {
        id: 'contractNumber',
        header: 'N° contrat',
        accessorKey: 'contractNumber',
        cell: info => ellipsisArray(info.getValue<string>()),
      },
      {
        id: 'team',
        header: "Equipe d'affectation",
        accessorKey: 'team',
        cell: info => info.getValue(),
      },
      {
        id: 'collaborator',
        header: 'Affectation collaborateur',
        accessorKey: 'collaborator',
        cell: info => info.getValue(),
      },
      {
        id: 'accountManager',
        header: 'Chargé de clientèle',
        accessorKey: 'accountManager',
        cell: info => info.getValue(),
      },
      {
        id: 'clientNumber',
        header: 'N° client',
        accessorKey: 'clientNumber',
        cell: info => ellipsisArray(info.getValue<string>()),
      },
      {
        id: 'uvProductCode',
        header: 'Code UV Produit',
        accessorKey: 'uvProductCode',
        cell: info => ellipsisArray(info.getValue<string>()),
      },
      {
        id: 'clause',
        header: 'Clause',
        accessorKey: 'clause',
        cell: info => ellipsisArray(info.getValue<string>()),
      },
      {
        id: 'syndicCode',
        header: 'Code syndic',
        accessorKey: 'syndicCode',
        cell: info => ellipsisArray(info.getValue<string>()),
      },
      {
        id: 'nafCode',
        header: 'Code NAF',
        accessorKey: 'nafCode',
        cell: info => ellipsisArray(info.getValue<string>()),
      },
      {
        id: 'copth',
        header: 'COPHT (€)',
        accessorKey: 'copth',
        cell: info => info.getValue(),
      },
      {
        id: 'contractCategory',
        header: 'Catégorie du contrat QP',
        accessorKey: 'contractCategory',
        cell: info => info.getValue(),
      },
      {
        id: 'priorisation',
        header: 'Priorisation',
        accessorKey: 'priorisation',
        cell: info => info.getValue(),
      },
      {
        id: 'ruleName',
        header: 'Nom de la règle',
        accessorKey: 'ruleName',
        cell: info => info.getValue(),
      },
      {
        id: 'comment',
        header: 'Commentaire',
        accessorKey: 'comment',
        cell: info => info.getValue(),
      },
      {
        id: 'startDate',
        header: 'Date de début',
        accessorKey: 'startDate',
        cell: info => info.getValue(),
      },
      {
        id: 'endtDate',
        header: 'Date de fin',
        accessorKey: 'endtDate',
        cell: info => info.getValue(),
      },
      {
        id: 'userMaj',
        header: 'Mise à jour par',
        accessorKey: 'userMaj',
        cell: info => info.getValue(),
      },
      {
        id: 'updateDate',
        header: 'Date de modification',
        accessorKey: 'updateDate',
        cell: info => info.getValue(),
      },
      {
        id: 'id',
        header: 'ID règle',
        accessorKey: 'id',
        cell: info => info.getValue(),
      },
    ],
    []
  );
