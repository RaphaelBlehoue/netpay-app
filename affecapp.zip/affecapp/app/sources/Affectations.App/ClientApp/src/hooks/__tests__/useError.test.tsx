import { FC, PropsWithChildren } from 'react';

import { IProblemDetails } from '@affectations/api/bff-clients.generated';
import { ErrorProvider } from '@affectations/contexts';

import { useError } from '../useError';
import { act, renderHook } from '@testing-library/react';

describe('useError', () => {
  const wrapper: FC<PropsWithChildren> = ({ children }) => <ErrorProvider>{children}</ErrorProvider>;
  it('should clear up errors', () => {
    const { result } = renderHook(() => useError(), { wrapper });
    const { error, clearError } = result.current;

    clearError();

    expect(error).toBeUndefined();
  });
  it('should define an error', async () => {
    const { result } = renderHook(() => useError(), { wrapper });
    const apiError: IProblemDetails = {
      status: 500,
    };

    await act(async () => {
      await result.current.displayError(apiError);
    });

    expect(result.current.error).toEqual(apiError);
  });
  it('should replace existing error', async () => {
    const { result } = renderHook(() => useError(), { wrapper });
    const apiError1: IProblemDetails = {
      status: 500,
    };
    await act(async () => {
      await result.current.displayError(apiError1);
    });
    expect(result.current.error).toEqual(apiError1);

    const apiError2: IProblemDetails = {
      status: 401,
    };

    await act(async () => {
      await result.current.displayError(apiError2);
    });

    expect(result.current.error).toEqual(apiError2);
  });
});
