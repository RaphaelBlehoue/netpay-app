import { useCallback, useContext } from 'react';

import { Error, ErrorContext } from '@affectations/contexts';

const DISPLAY_ERROR_DELAY = 300;

export const wait = (time: number): Promise<void> => new Promise(resolve => setTimeout(resolve, time));

export const useError = () => {
  const { error, setError } = useContext(ErrorContext);

  const displayError = useCallback(
    async (httpError: Error) => {
      if (httpError) {
        setError(undefined);
        await wait(DISPLAY_ERROR_DELAY);
      }

      setError(httpError);
    },
    [setError]
  );

  const clearError = useCallback(() => {
    setError(undefined);
  }, [setError]);

  return { error, displayError, clearError };
};
