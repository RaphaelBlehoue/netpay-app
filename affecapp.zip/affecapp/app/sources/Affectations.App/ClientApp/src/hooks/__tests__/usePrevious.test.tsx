import { renderHook } from '@testing-library/react';

import { usePrevious } from '../usePrevious';

describe('usePrevious hook', () => {
  it('should return the previous value', () => {
    const { result, rerender } = renderHook(() => usePrevious(10));
    expect(result.current).toBe(undefined);

    const newValue = 20;
    rerender(() => usePrevious(newValue));

    expect(result.current).toBe(10);
  });
});
