import ToolkitBadge from '@axa-fr/react-toolkit-badge';

import '@axa-fr/react-toolkit-badge/dist/badge.scss';

import { ComponentProps } from 'react';

import { BadgeClassModifiers } from './types';

type BadgeToolkitProps = ComponentProps<typeof ToolkitBadge>;

type TPropsBadge = {
  classModifiers?: BadgeClassModifiers;
  status: string;
} & BadgeToolkitProps;

const Badge = ({ status, classModifiers }: TPropsBadge) => (
  <ToolkitBadge classModifier={classModifiers}>{status}</ToolkitBadge>
);

export { Badge };
