import { screen, waitFor } from '@testing-library/react';

import { FORBIDDEN_PATH } from '@affectations/utils/authentication';
import { ApiException } from '@affectations/api/duende-bff-clients.generated';

import { HTTP_STATUS } from '../../ErrorMessage/constants';

const actual = await vi.importActual('react-router-dom');
vi.mock('react-router-dom', () => ({
  ...(actual as object),
  Navigate: vi.fn(({ to }) => (
    <div data-testid="redirect" data-to={to}>
      Redirect....
    </div>
  )),
}));

const renderMemoryRouter = (await import('@affectations/test-utils')).renderMemoryRouter;
const AuthenticationError = (await import('../AuthenticationError')).default;

describe('AuthenticationError', () => {
  it('should redirect if error status is unauthorized', () => {
    const error: ApiException = new ApiException('UNAUTORISE', HTTP_STATUS.UNAUTHORIZED, '', {}, {});
    const mockRedirect = vi.fn();
    renderMemoryRouter(<AuthenticationError error={error} redirect={mockRedirect} />);

    expect(mockRedirect).toHaveBeenCalled();
  });
  it('should navigate if error status is different to unauthorized', async () => {
    const error: ApiException = new ApiException('UNAUTORISE', HTTP_STATUS.OK, '', {}, {});
    const mockRedirect = vi.fn();
    renderMemoryRouter(<AuthenticationError error={error} redirect={mockRedirect} />);

    const redirect = await waitFor(() => screen.getByTestId('redirect'));

    expect(mockRedirect).not.toHaveBeenCalled();
    expect(redirect).toHaveAttribute('data-to', `${FORBIDDEN_PATH}`);
  });
});
