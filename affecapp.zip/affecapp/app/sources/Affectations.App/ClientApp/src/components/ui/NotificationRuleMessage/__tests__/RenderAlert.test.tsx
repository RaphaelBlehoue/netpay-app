import { render, screen } from '@testing-library/react';

import { RenderAlert } from '../RenderAlert';

describe('RenderAlert', () => {
  it('should be rendered without error', () => {
    render(<RenderAlert message="Success" details="details" />);
  });

  it.each`
    message
    ${'Rule activated'}
    ${'Rule saved'}
    ${'Rule saved with errors'}
  `('the text "$message" is displayed', ({ message }) => {
    render(<RenderAlert message={message} details="details" />);
    const msg = screen.getByText(message);

    expect(msg).toBeInTheDocument();
  });
});
