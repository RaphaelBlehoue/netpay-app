import { useRef } from 'react';
import { act, render, screen, waitFor } from '@testing-library/react';
import { axe } from 'jest-axe';
import { useForm } from 'react-hook-form';

import { renderSetup } from '@affectations/test-utils';

import SelectMultiple from '../SelectMultiple';

const SelectMultipleTest = () => {
  const form = useRef<HTMLFormElement>(null);
  const { control, setValue, watch, getValues } = useForm({
    defaultValues: {
      testList: [
        { label: 'Option 1', value: '1' },
        { label: 'Option 2', value: '2' },
        { label: 'Option 3', value: '3' },
      ],
      secondTestList: [
        { label: 'Line 1', value: '1' },
        { label: 'Line 2', value: '2' },
        { label: 'Line 3', value: '3' },
        { label: 'Line 4', value: '4' },
      ],
    },
  });

  return (
    <form
      ref={form}
    >
      <SelectMultiple
        control={control}
        label="Test list"
        name="testList"
        setValue={setValue}
        watch={watch}
        getValues={getValues}
        form={form.current}
      />
      <SelectMultiple
        control={control}
        label="Second test list"
        name="secondTestList"
        setValue={setValue}
        watch={watch}
        getValues={getValues}
        form={form.current}
      />
      <button type="reset">Reset</button>
    </form>
  );
};

describe('SelectMultiple', () => {
  it('Should render the component without errors', async () => {
    const { container } = render(<SelectMultipleTest />);
    const results = await axe(container);

    const select = screen.getByLabelText('Test list select');
    expect(select).toBeInTheDocument();
    expect(select).not.toHaveClass('visible');
    expect(results).toHaveNoViolations();
  });

  it('Should display options when you click on select', async () => {
    const { user } = await waitFor(() => renderSetup(<SelectMultipleTest />));
    const selectButton = screen.getByLabelText('Test list button');
    const select = screen.getByLabelText('Test list select');
    await act(() => user.click(selectButton));
    expect(select).toBeInTheDocument();
    expect(select).toHaveClass('visible');
  });

  it('Shoud display label and number of selected item', async () => {
    const { user } = await waitFor(() => renderSetup(<SelectMultipleTest />));
    const selectButton = screen.getByLabelText('Test list button');
    expect(screen.queryByText('Test list (1)')).not.toBeInTheDocument();
    expect(screen.queryByText('Test list (2)')).not.toBeInTheDocument();
    await act(() => user.click(selectButton));
    const option = screen.getByText(/option 1/i);
    await act(() => user.click(option));
    expect(screen.getByText('Test list (1)')).toBeInTheDocument();
    const option2 = screen.getByText(/option 2/i);
    await act(() => user.click(option2));
  });

  it('Shoud display label and count item when all checkbox is checked', async () => {
    const { user } = await waitFor(() => renderSetup(<SelectMultipleTest />));
    const selectButton = screen.getByLabelText('Test list button');
    await act(() => user.click(selectButton));
    const option = screen.getByText(/toutes \(3\)/i);
    await act(() => user.click(option));
    expect(screen.getByText('Test list (3)')).toBeInTheDocument();
  });

  it('Shoud hidden label and count item when all checkbox is unchecked', async () => {
    const { user } = await waitFor(() => renderSetup(<SelectMultipleTest />));
    const selectButton = screen.getByLabelText('Test list button');
    await act(() => user.click(selectButton));
    const option = screen.getByText(/toutes \(3\)/i);
    await act(() => user.click(option));
    expect(screen.getByText('Test list (3)')).toBeInTheDocument();
    await act(() => user.click(option));
    expect(screen.queryByText('Test list (3)')).not.toBeInTheDocument();
  });

  it('Shoud close current select when another one is opened', async () => {
    const { user } = await waitFor(() => renderSetup(<SelectMultipleTest />));
    const selectButton = screen.getByLabelText('Test list button');
    await act(() => user.click(selectButton));
    const select = screen.getByLabelText('Test list select');
    expect(select).toHaveClass('visible');
    const otherButton = screen.getByLabelText('Second test list button');
    await act(() => user.click(otherButton));
    expect(select).not.toHaveClass('visible');
  });

  it('Shoud close current select when lose focus', async () => {
    const { user, container } = await waitFor(() => renderSetup(<SelectMultipleTest />));
    const selectButton = screen.getByLabelText('Test list button');
    await act(() => user.click(selectButton));
    const select = screen.getByLabelText('Test list select');
    expect(select).toHaveClass('visible');
    await act(() => user.click(container));
    expect(select).not.toHaveClass('visible');
  });

  it('Shoud reset field when form is reseted', async () => {
    const { user } = await waitFor(() => renderSetup(<SelectMultipleTest />));
    const selectButton = screen.getByLabelText('Test list button');
    await act(() => user.click(selectButton));
    const option = screen.getByText(/toutes \(3\)/i);
    await act(() => user.click(option));
    expect(screen.getByText('Test list (3)')).toBeInTheDocument();
    const resetBtn = screen.getByText(/reset/i);
    await act(() => user.click(resetBtn));
    expect(screen.queryByText('Test list (3)')).not.toBeInTheDocument();
  });

  it('Shoud selection work', async () => {
    const { user } = await waitFor(() => renderSetup(<SelectMultipleTest />));
    const selectButton = screen.getByLabelText('Test list button');
    await act(() => user.click(selectButton));
    const option = screen.getByText(/toutes \(3\)/i);
    await act(() => user.click(option));
    expect(screen.getByText('Test list (3)')).toBeInTheDocument();
    const option1 = screen.getByText('Option 1');
    await act(() => user.click(option1));
    expect(screen.queryByText('Test list (3)')).not.toBeInTheDocument();
    await act(() => user.click(option));
    expect(screen.getByText('Test list (3)')).toBeInTheDocument();
  });
});
