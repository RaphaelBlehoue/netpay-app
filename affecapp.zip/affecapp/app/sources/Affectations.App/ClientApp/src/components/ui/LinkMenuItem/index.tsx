import { forwardRef } from 'react';
import { NavLink, useLocation } from 'react-router-dom';

type TRoute = {
  label: string;
  to: string;
};
const LinkMenuItem = forwardRef<HTMLLIElement, TRoute>(({ label, to }, _ref) => {
  const location = useLocation();
  const getLinkForActiveClass = (path: string) => {
    const isActive: boolean = path === location.pathname;
    return `af-nav__item af-nav__item${isActive ? '--active' : ''}`;
  };

  return (
    <li className={getLinkForActiveClass(to)} key={to}>
      <NavLink className={`af-nav__link`} to={to}>
        {label}
      </NavLink>
    </li>
  );
});

export { LinkMenuItem };
