export enum BadgeClassModifiers {
  Sucess = 'success',
  Info = 'info',
  Danger = 'danger',
  Error = 'error',
}

export enum BadgeStatusName {
  Sucess = 'Active',
  Danger = 'Brouillon',
  Error = 'Expirée',
}
