export { default } from './SimpleInput';
