import { DateFormats, formatDate, formatSiret } from '@affectations/utils';

export interface Column<DataType> {
  key: keyof DataType;
  title: string;
  type?: CellTypes;
  format?: CellFormats;
  path?: string;
}

enum CellFormats {
  DATE = 'siret',
  SIRET = 'date',
}

export enum CellTypes {
  LINK = 'link',
}

export const formatText = <DataType>(text: DataType[keyof DataType], format?: string) => {
  switch (format) {
    case CellFormats.SIRET:
      return formatSiret(text as string);
    case CellFormats.DATE:
      return formatDate(text as Date, DateFormats.DATE);
    default:
      return text as string;
  }
};
