import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';

import Unauthorized from '../Unauthorized';

const user = userEvent.setup();

describe('Unauthorized', () => {
  it("L'utlisateur clique sur Recharger la page.", async () => {
    const reload = vi.fn();
    render(<Unauthorized reload={reload} />);
    const cta = await screen.findByRole('button', { name: /Recharger la page/i });
    await user.click(cta);
    expect(reload).toHaveBeenCalled();
  });
});
