export enum CONFIRMATION_TYPE {
  ACTIVE = 'Active',
  DRAFT = 'Brouillon',
  DRAFT_ERROR = 'draft_error',
}
