import { render, screen } from '@testing-library/react';

import ConfirmationMessage from '../ConfirmationMessage';
import { CONFIRMATION_TYPE } from '../constants';

describe('CreatingMessage', () => {
  it('should display active message', () => {
    const dateCreation = new Date('2024-03-12T10:00:00');
    const statut = CONFIRMATION_TYPE.ACTIVE;

    render(<ConfirmationMessage status={statut} creationDate={dateCreation} />);

    const activeMessagePart1 = screen.getByText('La règle a bien été activée le 12/03/2024 à 10:00.');
    const activeMessagePart2 = screen.getByText("L'affectation sera effective dès demain.");

    expect(activeMessagePart1).toBeInTheDocument();
    expect(activeMessagePart2).toBeInTheDocument();
  });

  it('should display active message when date creation typeof string', () => {
    const dateCreation = '2024-03-12T10:00:00';
    const statut = CONFIRMATION_TYPE.ACTIVE;

    render(<ConfirmationMessage status={statut} creationDate={dateCreation} />);

    const activeMessagePart1 = screen.getByText('La règle a bien été activée le 12/03/2024 à 10:00.');
    const activeMessagePart2 = screen.getByText("L'affectation sera effective dès demain.");

    expect(activeMessagePart1).toBeInTheDocument();
    expect(activeMessagePart2).toBeInTheDocument();
  });

  it('should display brouillon message', () => {
    const dateCreation = new Date('2024-03-12T10:00:00');
    const statut = CONFIRMATION_TYPE.DRAFT;

    render(<ConfirmationMessage status={statut} creationDate={dateCreation} />);

    const brouillonMessagePart1 = screen.getByText(
      'La règle a bien été enregistrée en brouillon le 12/03/2024 à 10:00.'
    );
    const brouillonMessagePart2 = screen.getByText(
      "N'oubliez pas d'activer la règle afin que l'affectation soit effective."
    );

    expect(brouillonMessagePart1).toBeInTheDocument();
    expect(brouillonMessagePart2).toBeInTheDocument();
  });

  it('should display brouillon message when date creation typeof string', () => {
    const dateCreation = '2024-03-12T10:00:00';
    const statut = CONFIRMATION_TYPE.DRAFT;

    render(<ConfirmationMessage status={statut} creationDate={dateCreation} />);

    const brouillonMessagePart1 = screen.getByText(
      'La règle a bien été enregistrée en brouillon le 12/03/2024 à 10:00.'
    );
    const brouillonMessagePart2 = screen.getByText(
      "N'oubliez pas d'activer la règle afin que l'affectation soit effective."
    );

    expect(brouillonMessagePart1).toBeInTheDocument();
    expect(brouillonMessagePart2).toBeInTheDocument();
  });

  it('should display brouillon with error message', () => {
    const dateCreation = new Date('2024-03-12T10:00:00');
    const statut = CONFIRMATION_TYPE.DRAFT_ERROR;

    render(<ConfirmationMessage status={statut} creationDate={dateCreation} />);

    const brouillonWithErrorMsgPart1 = screen.getByText(
      'La règle a bien été enregistrée en brouillon malgré' +
        " la présence d'erreurs sur certains champs le 12/03/2024 à 10:00."
    );
    const brouillonWithErrorMsgPart2 = screen.getByText(
      "N'oubliez pas de corriger ou de remplir les champs en erreur" +
        " ainsi que d'activer la règle afin que l'affectation soit effective."
    );

    expect(brouillonWithErrorMsgPart1).toBeInTheDocument();
    expect(brouillonWithErrorMsgPart2).toBeInTheDocument();
  });

  it('should display brouillon with error message when date creation typeof string', () => {
    const dateCreation = '2024-03-12T10:00:00';
    const statut = CONFIRMATION_TYPE.DRAFT_ERROR;

    render(<ConfirmationMessage status={statut} creationDate={dateCreation} />);

    const brouillonWithErrorMsgPart1 = screen.getByText(
      'La règle a bien été enregistrée en brouillon malgré' +
        " la présence d'erreurs sur certains champs le 12/03/2024 à 10:00."
    );
    const brouillonWithErrorMsgPart2 = screen.getByText(
      "N'oubliez pas de corriger ou de remplir les champs en erreur" +
        " ainsi que d'activer la règle afin que l'affectation soit effective."
    );

    expect(brouillonWithErrorMsgPart1).toBeInTheDocument();
    expect(brouillonWithErrorMsgPart2).toBeInTheDocument();
  });
});
