import { ComponentProps, forwardRef } from 'react';
import { Select as ToolkitSelect } from '@axa-fr/react-toolkit-form-input-select';

import '@axa-fr/react-toolkit-form-input-select/dist/af-select.css';

type ToolkitSelectProps = ComponentProps<typeof ToolkitSelect>;
type TPropsSelect = {
  onSelectChange?: (value: string) => void;
} & ToolkitSelectProps;

const Select = forwardRef<HTMLSelectElement, TPropsSelect>(({ options, onChange, value, ...props }, ref) => {
  return (
    <div className="af-form__select">
      <ToolkitSelect ref={ref} options={options} onChange={onChange} value={value} {...props} />
    </div>
  );
});

export { Select };
