import { render, screen } from '@testing-library/react';

import { Loader } from '@affectations/components/ui/Loader';

describe('Loader', () => {
  it('should render Spinner component', async () => {
    render(<Loader isLoading />);
    expect(await screen.findByText(/Chargement.../)).toBeInTheDocument();
  });
});
