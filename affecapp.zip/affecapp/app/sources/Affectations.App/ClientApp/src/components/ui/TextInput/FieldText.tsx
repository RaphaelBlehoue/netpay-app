import { forwardRef, FunctionComponent, InputHTMLAttributes } from 'react';
import clsx from 'clsx';

import './TextInput.scss';

interface IFieldTextProps extends InputHTMLAttributes<HTMLInputElement> {
  name: string;
  label?: string;
  isDisabled?: boolean;
  FieldContainerClassName?: string;
  inputContainerClassName?: string;
  inputLabelClassName?: string;
  inputFieldClassName?: string;
  inputType?: string;
  hasRequiredContent?: boolean;
}

// https://react-hook-form.com/get-started#Integratinganexistingform

const FieldText: FunctionComponent<IFieldTextProps> = forwardRef<HTMLInputElement, IFieldTextProps>(
  (
    {
      name,
      label,
      FieldContainerClassName,
      inputContainerClassName,
      inputLabelClassName,
      inputFieldClassName,
      inputType,
      isDisabled,
      hasRequiredContent = false,
      ...otherProps
    },
    ref
  ) => (
    <div className={clsx(FieldContainerClassName)}>
      {label && (
        <div className={clsx(inputLabelClassName)}>
          <label htmlFor={name} className={clsx(inputLabelClassName, hasRequiredContent && 'input-required')}>
            {label}
          </label>
        </div>
      )}
      <div className={clsx(inputContainerClassName)}>
        <input
          name={name}
          className={clsx(['text-input', inputFieldClassName])}
          type={inputType ?? 'text'}
          ref={ref}
          id={name}
          disabled={isDisabled}
          {...otherProps}
        />
      </div>
    </div>
  )
);
export { FieldText };
