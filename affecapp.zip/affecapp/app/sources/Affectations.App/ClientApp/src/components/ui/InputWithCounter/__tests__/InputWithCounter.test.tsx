import { FC } from 'react';
import { act, render, screen, waitFor } from '@testing-library/react';
import { useForm } from 'react-hook-form';

import { renderSetup } from '@affectations/test-utils';

import InputWithCounter from '../InputWithCounter';

const INPUT = 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.';

type TestComponent = {
  maxLength?: number;
  helpMessage?: string;
};

const TestComponent: FC<TestComponent> = ({ maxLength = 100, helpMessage }) => {
  const { control } = useForm();
  return (
    <InputWithCounter
      label="Test input"
      maxLength={maxLength}
      helpMessage={helpMessage}
      name="testField"
      control={control}
    />
  );
};

describe('InputWithCounter', () => {
  it('should display helpMessage instead of counter', async () => {
    await waitFor(() => render(<TestComponent helpMessage="help message" />));
    const helpMessage = screen.getByText('help message');
    const counter = screen.queryByTitle('0/100');
    expect(helpMessage).toBeInTheDocument();
    expect(counter).not.toBeInTheDocument();
  });

  it('should correctly display character initial counter', async () => {
    await waitFor(() => render(<TestComponent />));
    const counter = screen.getByText('0/100');
    expect(counter).toBeInTheDocument();
  });

  it('should correctly display character count upon typing in the field', async () => {
    const { user } = await waitFor(() => renderSetup(<TestComponent />));
    const textbox = screen.getByRole('textbox');
    await act(() => user.type(textbox, INPUT));
    const counter = screen.getByText(`${INPUT.length}/100`);
    expect(counter).toBeInTheDocument();
  });

  it.each`
    input    | maxlength    | value
    ${INPUT} | ${10}        | ${'Lorem ipsu'}
    ${INPUT} | ${25}        | ${'Lorem ipsum dolor sit ame'}
    ${INPUT} | ${0}         | ${''}
    ${INPUT} | ${undefined} | ${INPUT}
  `(
    'Should verify that text field limits entry $input to $value for $maxlength max characters.',
    async ({ input, maxlength, value }) => {
      const { user } = await waitFor(() => renderSetup(<TestComponent maxLength={maxlength} />));
      const textbox = screen.getByRole('textbox');
      await act(() => user.type(textbox, input));
      expect(textbox).toHaveValue(value);
    }
  );
});
