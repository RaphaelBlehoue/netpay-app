import { TOption } from './MultiCheckBoxSelectOption';

export const predicateUserWantToSelectAll = (isAllCheck: boolean, currentValueProvider: TOption[]): TOption[] => {
  let internalSate: TOption[];
  if (isAllCheck) {
    internalSate = currentValueProvider.filter((item: TOption) => item.value === '*');
  } else {
    internalSate = currentValueProvider.filter((item: TOption) => item.value !== '*');
  }
  return internalSate;
};

export const predicateAllDeselect = (optionsProvider: TOption[], currentValueProvider: TOption[]) => {
  const currentArray = currentValueProvider.map(el => el.value);
  return optionsProvider.filter((item: TOption) => !currentArray.includes(item.value));
};
