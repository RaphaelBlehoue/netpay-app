import '@axa-fr/react-toolkit-loader/dist/af-spinner.css';

import { PropsWithChildren } from 'react';

type LoaderType = PropsWithChildren<{ isLoading?: boolean }>;
const Loader = ({ children, isLoading }: LoaderType) => {
  return (
    <>
      {isLoading ? (
        <div className="af-spinner af-spinner--active">
          <div className="af-spinner__animation"></div>
          <div className="af-spinner__caption">
            <span>Chargement...</span>
          </div>
        </div>
      ) : (
        children
      )}
    </>
  );
};

export { Loader };
