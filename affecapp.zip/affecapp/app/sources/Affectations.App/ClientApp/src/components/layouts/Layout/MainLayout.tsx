import { PropsWithChildren, useEffect } from 'react';

import { useAuthentication } from '@affectations/hooks/useAuthentication';
import {
  AuthenticationError,
  Footer,
  Header,
  Loader,
  Navigation,
  TNavigationItem,
  Unauthorized,
} from '@affectations/components';
import { HTTP_STATUS } from '@affectations/components/ui/ErrorMessage/constants';

const navigationMaps: TNavigationItem[] = [
  { label: 'Accueil', to: '/' },
  { label: "Créer une règle d'affectation", to: '/add-affectation-regle' },
];

const MainLayout = ({ children }: PropsWithChildren) => {
  const { user, isLoading, fetchUser, error } = useAuthentication();

  useEffect(() => {
    fetchUser();
  }, [fetchUser]);

  if (isLoading) {
    return <Loader isLoading={isLoading} />;
  }

  if (error?.status === HTTP_STATUS.UNAUTHORIZED) {
    return <AuthenticationError error={error} />;
  }
  return (
    <>
      <Header name={user?.name} />
      <Navigation items={navigationMaps} />
      {error ? <Unauthorized /> : <main>{children}</main>}
      <Footer />
    </>
  );
};

export { MainLayout };
