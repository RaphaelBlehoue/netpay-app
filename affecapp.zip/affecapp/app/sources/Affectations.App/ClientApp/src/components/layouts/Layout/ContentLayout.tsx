import { PropsWithChildren } from 'react';
import clsx from 'clsx';

import { ErrorMessage, TitleBar } from '@affectations/components/ui';

type ContentLayoutProps = PropsWithChildren<{ titleHead: string; className?: string }>;
const ContentLayout = ({ titleHead, className, children }: ContentLayoutProps) => {
  return (
    <>
      <TitleBar title={titleHead} />
      <div className={clsx('page-container', className)}>
        <ErrorMessage />
        {children}
      </div>
    </>
  );
};

export { ContentLayout };
