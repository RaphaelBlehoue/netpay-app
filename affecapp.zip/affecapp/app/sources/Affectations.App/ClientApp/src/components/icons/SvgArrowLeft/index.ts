import SvgArrowLeft from './SvgArrowLeft';

export { SvgArrowLeft };
