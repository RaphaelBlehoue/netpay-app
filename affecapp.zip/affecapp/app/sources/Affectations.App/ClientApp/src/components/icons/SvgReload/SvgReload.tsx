import { FC, SVGAttributes } from 'react';
import clsx from 'clsx';

import style from './style.module.scss';

const d =
  'm15.99 0-2.35 2.35A7.96 7.96 0 0 0 7.99 0C3.57 0 0 3.58' +
  ' 0 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08a5.99 5.99 0 0 1-5.65 4c-3.31 0-6-2.69-6-6s2.69-6' +
  ' 6-6c1.66 0 3.14.69 4.22 1.78L8.99 7h7z';

const SvgReload: FC<SVGAttributes<HTMLOrSVGElement>> = props => (
  <svg xmlns="http://www.w3.org/2000/svg" className={clsx(style.reload, props.className)} {...props}>
    <path fill="#3032c1" d={d} />
  </svg>
);
export default SvgReload;
