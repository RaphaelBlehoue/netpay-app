import { ComponentPropsWithRef } from 'react';

import './TextInput.scss';

import { Control, Controller, FieldValues, Path } from 'react-hook-form';

import { FieldText } from './FieldText';

type TProps = ComponentPropsWithRef<typeof FieldText>;

type ITextInputController<TFieldValuesPath extends FieldValues> = {
  placeholder?: string;
  name: Path<TFieldValuesPath>;
  control: Control<TFieldValuesPath>;
} & TProps;

const TextInputController = ({ name, control, ...otherProps }: ITextInputController<FieldValues>) => {
  return (
    <div className="af-container-input-content">
      <Controller
        name={name}
        control={control}
        render={({ field }) => (
          <FieldText {...field} onChange={e => field.onChange(e)} value={field.value} {...otherProps} />
        )}
      />
    </div>
  );
};

export { TextInputController };
