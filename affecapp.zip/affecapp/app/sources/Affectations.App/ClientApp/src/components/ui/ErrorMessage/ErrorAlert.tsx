import { FC } from 'react';

import { Alert, AlertClassModifiers } from '../Alert';
import style from './style.module.scss';

type Props = {
  errorMessage: string;
};

export const ErrorAlert: FC<Props> = ({ errorMessage }) => (
  <div className={style.errorComponent}>
    <Alert mode={AlertClassModifiers.Error} title={errorMessage} />
  </div>
);
