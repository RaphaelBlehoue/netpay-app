import { ComponentProps } from 'react';
import AsyncSelect from 'react-select/async';

type TAsyncSelectProps = ComponentProps<typeof AsyncSelect>;

type TAutoComplete = {
  className?: string;
  classNamePrefix?: string;
  value?: unknown;
} & TAsyncSelectProps;
const AutoComplete = ({ className, classNamePrefix, ...OthersProps }: TAutoComplete) => {
  return (
    <AsyncSelect
      {...OthersProps}
      className={className}
      classNamePrefix={classNamePrefix}
      styles={{
        control: base => ({
          ...base,
          height: 48,
          width: 200,
          border: '0.063rem solid #999999',
          borderRadius: 0,
        }),
        dropdownIndicator: base => ({ ...base, color: '#000' }),
      }}
      components={{
        IndicatorSeparator: () => null,
        DropdownIndicator: () => null,
      }}
    />
  );
};
export { AutoComplete };
