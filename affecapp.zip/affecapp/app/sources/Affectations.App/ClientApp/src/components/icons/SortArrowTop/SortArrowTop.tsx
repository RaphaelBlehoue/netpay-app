import { FC, SVGAttributes } from 'react';
import clsx from 'clsx';

import style from './style.module.scss';

const SvgSortArrowTop: FC<SVGAttributes<SVGElement>> = props => (
  <svg {...props} xmlns="http://www.w3.org/2000/svg" className={clsx(props.className, style['sort-arrow-top'])}>
    <path fill="#fff" d="m0 6 5-6 5 6z" />
  </svg>
);
export default SvgSortArrowTop;
