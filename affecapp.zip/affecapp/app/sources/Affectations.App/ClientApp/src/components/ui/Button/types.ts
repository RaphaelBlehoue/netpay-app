export enum ButtonClassModifiers {
  Sucess = 'success',
  Info = 'info',
  Danger = 'danger',
  Error = 'error',
  Reverse = 'reverse',
  Disabled = 'disabled',
  Small = 'small',
  HasIconLeft = 'hasIconLeft',
  HasIconRight = 'hasIconRight',
  resetWidth = 'resetWidth',
}
