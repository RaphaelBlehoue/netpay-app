type FieldErrorProps = {
  error: string;
  isErrorDateInput: boolean;
};

const FieldError = ({ error, isErrorDateInput = false }: FieldErrorProps) => {
  const iconClassName = isErrorDateInput ? 'glyphicon-exclamation-sign' : 'glyphicon glyphicon-exclamation-sign';
  const errorTextClassName = isErrorDateInput ? undefined : 'af-form__error-text';

  return (
    <small className="af-form__message af-form__message--error">
      <i className={iconClassName} />
      <span className={errorTextClassName}>{error}</span>
    </small>
  );
};

export { FieldError };
