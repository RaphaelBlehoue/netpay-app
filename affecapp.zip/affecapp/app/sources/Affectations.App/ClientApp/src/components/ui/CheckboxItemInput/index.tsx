import { CheckboxItem as ToolkitCheckbox } from '@axa-fr/react-toolkit-form-input-checkbox';

import '@axa-fr/react-toolkit-form-input-checkbox/dist/af-checkbox.css';

import { ComponentProps } from 'react';

type TCheckBox = ComponentProps<typeof ToolkitCheckbox>;

const CheckboxItemInput = ({ id, label, value, name, isChecked, className, ...props }: TCheckBox) => (
  <ToolkitCheckbox
    id={id}
    name={name}
    label={label}
    value={value}
    isChecked={isChecked}
    className={className}
    {...props}
  />
);
export { CheckboxItemInput };
