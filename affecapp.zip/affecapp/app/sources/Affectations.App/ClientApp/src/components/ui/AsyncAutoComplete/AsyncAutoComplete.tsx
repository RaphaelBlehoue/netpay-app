import { ComponentProps, ReactNode } from 'react';
import { Control, Controller, FieldValues, Path } from 'react-hook-form';
import { GroupBase, OptionsOrGroups } from 'react-select';
import AsyncSelect from 'react-select/async';

import { TOption } from '../Select';

type Props<T extends FieldValues> = ComponentProps<typeof AsyncSelect> & {
  control: Control<T>;
  name: Path<T>;
  loadOptions: (
    inputValue: string,
    callback: (options: OptionsOrGroups<T, GroupBase<T>>) => void
  ) => Promise<TOption[]> | void;
  noOptionsMessage: (obj: { inputValue: string }) => ReactNode;
};

export const AsyncAutoComplete = <T extends FieldValues>({
  control,
  name,
  loadOptions,
  noOptionsMessage,
  ...other
}: Props<T>) => (
  <Controller
    control={control}
    name={name}
    render={({ field }) => (
      <AsyncSelect
        {...other}
        {...field}
        value={field.value ?? null}
        styles={{
          control: base => ({
            ...base,
            height: 48,
            width: 200,
            border: '0.063rem solid #999999',
            borderRadius: 0,
          }),
          dropdownIndicator: base => ({ ...base, color: '#000' }),
        }}
        components={{
          IndicatorSeparator: () => null,
          DropdownIndicator: () => null,
        }}
        loadOptions={loadOptions}
        noOptionsMessage={noOptionsMessage}
      />
    )}
  />
);
