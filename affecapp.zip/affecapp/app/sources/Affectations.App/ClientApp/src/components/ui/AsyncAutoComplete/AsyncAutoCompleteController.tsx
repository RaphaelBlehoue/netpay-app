import { ComponentProps, ReactNode, useEffect, useMemo, useState } from 'react';
import { FieldError } from '@axa-fr/react-toolkit-form-core';
import clsx from 'clsx';
import { Control, Controller, FieldValues, Path, useForm } from 'react-hook-form';
import { GroupBase, InputActionMeta, OptionsOrGroups } from 'react-select';

import { setFormValueValidation } from '@affectations/pages/affectations/utils';
import { MessageTypes, TCriteria, TFieldArray } from '@affectations/types';

import { TOption } from '../Select';
import { AutoComplete } from './AutoComplete';

import './AsyncAutoComplete.scss';

const excludeNameInputInRule = 'collaborater';

type Props<T extends FieldValues> = ComponentProps<typeof AutoComplete> & {
  control: Control<T>;
  className?: string;
  classNamePrefix?: string;
  currentValueCriteria?: TFieldArray;
  messageType?: MessageTypes;
  errors?: string;
  name: Path<T>;
  loadOptions: (
    inputValue: string,
    callback: (options: OptionsOrGroups<T, GroupBase<T>>) => void
  ) => Promise<TOption[]> | void;
  noOptionsMessage?: (obj: { inputValue: string }) => ReactNode;
  onkeydownHandler?: (evt: React.KeyboardEvent) => void;
};

export const AsyncAutoCompleteController = <T extends FieldValues>({
  control,
  name,
  className,
  classNamePrefix,
  currentValueCriteria,
  errors,
  messageType,
  loadOptions,
  noOptionsMessage,
  onkeydownHandler,
  ...other
}: Props<T>) => {
  const [inputValue, setInputValue] = useState<string>('');
  const { clearErrors } = useForm();
  const handleInputChange = (newValue: string, action: InputActionMeta) => {
    if (action.action !== 'input-blur' && action.action !== 'menu-close') {
      setInputValue(newValue);
    }
  };

  const handleBlur = () => {
    setInputValue(inputValue);
  };

  const rules = useMemo(() => {
    return setFormValueValidation(currentValueCriteria?.criteria as TCriteria);
  }, [currentValueCriteria?.criteria]);

  useEffect(() => {
    if (name === excludeNameInputInRule) {
      clearErrors(name);
    }
  }, [clearErrors, name]);

  return (
    <Controller
      control={control}
      name={name}
      rules={rules.validatedRules}
      render={({ field, fieldState }) => {
        const errorMessage = fieldState.error?.message;
        const setErrorMessage = errorMessage ?? errors;
        return (
          <>
            <AutoComplete
              {...other}
              {...field}
              className={clsx(className, { 'af-form__multi--error error-autocomplete': !!errorMessage })}
              classNamePrefix={classNamePrefix}
              aria-label={name}
              value={field.value ?? null}
              loadOptions={loadOptions}
              noOptionsMessage={noOptionsMessage}
              onKeyDown={onkeydownHandler}
              inputValue={inputValue}
              onInputChange={handleInputChange}
              onBlur={handleBlur}
            />
            {setErrorMessage?.length && <FieldError message={errorMessage} messageType={messageType} />}
          </>
        );
      }}
    />
  );
};
