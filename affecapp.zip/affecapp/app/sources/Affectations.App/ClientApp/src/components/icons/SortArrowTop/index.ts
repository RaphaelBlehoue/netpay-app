import SvgSortArrowTop from './SortArrowTop';

export { SvgSortArrowTop };
