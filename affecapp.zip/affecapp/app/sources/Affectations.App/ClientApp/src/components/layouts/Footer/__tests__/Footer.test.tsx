import { render, screen, within } from '@testing-library/react';
import { axe } from 'jest-axe';

import { Footer } from '@affectations/components';

describe('<Footer />', () => {
  it('Render <Footer/>', async () => {
    const { container } = render(<Footer />);
    const footer = screen.getByRole('contentinfo');
    expect(footer).toBeDefined();

    const footerScope = within(footer);
    expect(footerScope.getByText(/AXA Tous droits réservés/i)).toBeInTheDocument();
    expect(footerScope.getByAltText(/Logo Axa/)).toBeInTheDocument();

    const link = footerScope.getByRole('link');
    expect(link).toHaveAttribute('href', 'https://www.axa.fr/');
    expect(await axe(container)).toHaveNoViolations();
  });
});
