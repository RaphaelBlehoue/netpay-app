import { ComponentProps, forwardRef } from 'react';
import { SelectInput } from '@axa-fr/react-toolkit-form-input-select';
import clsx from 'clsx';
import { Control, Controller, FieldValues, Path } from 'react-hook-form';

import '@axa-fr/react-toolkit-form-input-select/dist/af-select.css';
import './Select.scss';

type TSelectControllerProps<TFieldValuesPath extends FieldValues> = {
  placeholder?: string;
  selectAdditionnalClassName?: string;
  label?: string;
  name: Path<TFieldValuesPath>;
  control: Control<TFieldValuesPath>;
  rules?: object;
  onSelectChange?: (value?: string) => void;
  onSelectUpdateOption?: (value?: string) => void;
} & Omit<ComponentProps<typeof SelectInput>, 'label'>;
const SelectController = forwardRef<HTMLSelectElement, TSelectControllerProps<FieldValues>>(
  (
    {
      name,
      control,
      options,
      label = '',
      placeholder,
      rules = {},
      selectAdditionnalClassName,
      onSelectChange,
      onSelectUpdateOption,
      ...otherProps
    },
    ref
  ) => {
    return (
      <div className="af-container__select-content af-form__select">
        <Controller
          name={name}
          control={control}
          rules={rules}
          render={({ field, fieldState }) => {
            const handleChange = (e: { value: string }) => {
              field.onChange(e.value);
              onSelectChange?.(e.value);
              onSelectUpdateOption?.(e.value);
            };
            const error = fieldState?.error?.message;
            return (
              <SelectInput
                {...field}
                ref={ref}
                label={label}
                options={options}
                placeholder={placeholder ?? '- Sélectionner -'}
                className={clsx(['select-input', selectAdditionnalClassName])}
                onChange={handleChange}
                value={field.value || ''}
                forceDisplayMessage
                message={error}
                {...otherProps}
              />
            );
          }}
        />
      </div>
    );
  }
);

export { SelectController };
