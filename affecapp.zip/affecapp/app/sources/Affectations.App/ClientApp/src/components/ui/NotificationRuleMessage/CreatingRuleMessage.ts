import { CONFIRMATION_TYPE } from './constants';
import { DateFormats, formatDate } from '@affectations/utils';

const returnFormatDate = (date: Date) => formatDate(date, DateFormats.DATE_TIME_FR);
const getBrouillonMsg = (dateCreation: Date) => {
  return {
    message: `La règle a bien été enregistrée en brouillon le ${returnFormatDate(dateCreation)}.`,
    details: "N'oubliez pas d'activer la règle afin que l'affectation soit effective.",
  };
};

const getBrouillonWithErrorsMsg = (dateCreation: Date) => {
  return {
    message:
      `La règle a bien été enregistrée en brouillon malgré la présence d'erreurs sur certains champs ` +
      `le ${returnFormatDate(dateCreation)}.`,
    details:
      "N'oubliez pas de corriger ou de remplir les champs en erreur ainsi que d'activer " +
      "la règle afin que l'affectation soit effective.",
  };
};

const getActiveMsg = (dateCreation: Date) => {
  return {
    message: `La règle a bien été activée le ${returnFormatDate(dateCreation)}.`,
    details: "L'affectation sera effective dès demain.",
  };
};

const CreatingMessage = (statut: string, dateCreation: Date) => {
  switch (statut) {
    case CONFIRMATION_TYPE.ACTIVE:
      return getActiveMsg(dateCreation);
    case CONFIRMATION_TYPE.DRAFT:
      return getBrouillonMsg(dateCreation);
    case CONFIRMATION_TYPE.DRAFT_ERROR:
      return getBrouillonWithErrorsMsg(dateCreation);
    default:
      return getActiveMsg(dateCreation);
  }
};
export default CreatingMessage;
