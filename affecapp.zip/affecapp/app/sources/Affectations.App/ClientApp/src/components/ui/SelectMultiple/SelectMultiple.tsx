import { FocusEvent, MouseEventHandler, useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { CheckboxItem } from '@axa-fr/react-toolkit-form-input-checkbox';

import '@axa-fr/react-toolkit-form-input-checkbox/dist/af-checkbox.css';

import clsx from 'clsx';
import {
  ArrayPath,
  Control,
  Controller,
  FieldValues,
  useFieldArray,
  UseFormGetValues,
  UseFormSetValue,
  UseFormWatch,
} from 'react-hook-form';

import { SvgArrowLeft } from '@affectations/components';

import style from './style.module.scss';

export type SelectMultipleItem = {
  label: string;
  value: string;
  isSelected: boolean;
};

export type SelectMultipleItems = SelectMultipleItem[];

type Props<T extends FieldValues = FieldValues> = {
  name: ArrayPath<T>;
  label: string;
  canAll?: boolean;
  isReset?: boolean;
  control: Control<T>;
  form?: HTMLFormElement | null;
  setValue: UseFormSetValue<T>;
  watch: UseFormWatch<T>;
  getValues: UseFormGetValues<T>;
  small?: boolean;
};

const SelectMultiple = <T extends FieldValues = FieldValues>({
  name,
  label,
  canAll = true,
  control,
  form,
  setValue,
  watch,
  getValues,
  small = false,
}: Props<T>) => {
  const [isVisible, setIsVisible] = useState(false);
  const [currentFieldsState, setCurrentFieldsState] = useState<SelectMultipleItems>([]);
  const [isAllChecked] = useState(false);

  const selectRef = useRef<HTMLDivElement>(null);

  const selectedFields = useMemo(() => currentFieldsState.filter(x => x.isSelected), [currentFieldsState]);
  const currentFields = useMemo(() => control._formValues[name], [control._formValues, name]);

  const { fields } = useFieldArray<T>({
    control,
    name,
  });
  const currentState = watch(name as never);

  const handleSelectAll = useCallback(
    (state: boolean) => {
      currentFields.forEach((_: never, index: number) => {
        setValue(`${name}[${index}].isSelected` as never, state as never);
      });

      setCurrentFieldsState([...getValues(name as never)]);
    },
    [currentFields, getValues, name, setValue]
  );

  useEffect(() => {
    handleSelectAll(isAllChecked);
  }, [handleSelectAll, isAllChecked]);

  useEffect(() => {
    const resetField = () => {
      handleSelectAll(false);
    };
    form?.addEventListener('reset', resetField);

    return () => {
      form?.removeEventListener('reset', resetField);
    };
  }, [form, handleSelectAll, name]);

  const toggleVisibility = useCallback(() => {
    setIsVisible(visibility => !visibility);
  }, []);

  const handleClick = useCallback<MouseEventHandler<HTMLDivElement>>(
    e => {
      e.stopPropagation();
      e.preventDefault();
      toggleVisibility();
    },
    [toggleVisibility]
  );
  const stopPropagation = useCallback<MouseEventHandler<HTMLDivElement>>(e => {
    e.stopPropagation();
  }, []);
  const handleIsAllChange = useCallback(() => {
    handleSelectAll(selectedFields.length < currentState.length);
  }, [currentState.length, handleSelectAll, selectedFields.length]);
  const handleBlur = useCallback((event: FocusEvent<HTMLDivElement>) => {
    const select = selectRef.current;
    if (!select?.contains(event.relatedTarget)) {
      setIsVisible(false);
    }
  }, []);

  return (
    <>
      <div className={clsx(style['select-multiple'], 'select-multiple', { small })} onBlur={handleBlur} ref={selectRef}>
        <label htmlFor={name}>{label}</label>
        <div
          className={style.input}
          onClick={handleClick}
          role={'button'}
          onKeyDown={toggleVisibility}
          id={name}
          tabIndex={0}
          aria-label={label + ' button'}
        >
          <span>
            {!!selectedFields.length && (
              <>
                {label} ({selectedFields.length})
              </>
            )}
          </span>
          <SvgArrowLeft />
        </div>
        <div
          className={clsx(style.values, { [style.visible ?? '']: isVisible })}
          onClick={stopPropagation}
          onKeyDown={() => {}}
          role="listbox"
          aria-label={label + ' select'}
          tabIndex={0}
        >
          {canAll && (
            <>
              <CheckboxItem
                label={`Toutes (${currentFields.length})`}
                name={name}
                value={'all'}
                id={`all-${name}`}
                isChecked={selectedFields.length === currentState.length}
                onChange={handleIsAllChange}
                onClick={stopPropagation}
                role="option"
              />{' '}
              <div className={style.line}></div>
            </>
          )}
          {fields.map((item, index) => {
            const line = item as never as SelectMultipleItem;
            return (
              <Controller
                key={item.id}
                name={`${name}[${index}].isSelected` as never}
                control={control}
                render={({ field }) => (
                  <CheckboxItem
                    {...field}
                    key={line.value}
                    label={line.label}
                    value={line.value}
                    id={`${name}-${index}-${field.value}`}
                    isChecked={field.value}
                    onChange={() => {
                      field.onChange(!field.value);
                      setCurrentFieldsState([...getValues(name as never)]);
                    }}
                    role="option"
                  />
                )}
              />
            );
          })}
        </div>
      </div>
    </>
  );
};

export default SelectMultiple;
