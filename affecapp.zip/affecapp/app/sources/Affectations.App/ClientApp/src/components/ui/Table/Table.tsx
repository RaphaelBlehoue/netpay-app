import ToolkitTable from '@axa-fr/react-toolkit-table';

import { TableHeader } from './TableHeader';
import { TableRows } from './TableRows';
import type { Column } from './utils';

import '@axa-fr/react-toolkit-table/dist/af-table.css';

interface IPropsTable<DataType> {
  title: string;
  columns: Column<DataType>[];
  data: DataType[];
}

const Table = <DataType extends object>({ columns, data, title }: IPropsTable<DataType>) => {
  return (
    <ToolkitTable classModifier="uaxa" className="af-table" aria-label={title}>
      <TableHeader columns={columns} />
      <TableRows columns={columns} data={data} />
    </ToolkitTable>
  );
};

export { Table };
