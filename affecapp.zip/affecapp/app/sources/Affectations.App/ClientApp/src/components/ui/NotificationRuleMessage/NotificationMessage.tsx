import { AlertClassModifiers } from '../Alert';
import { RenderAlert } from './RenderAlert';

type Props = {
  message: string;
  status?: AlertClassModifiers;
  details?: string;
  iconName?: string;
};
const NotificationMessage = ({ status, message, details, iconName }: Props) => {
  return (
    <div>
      <RenderAlert message={message} alertType={status} details={details} iconName={iconName} />
    </div>
  );
};
export { NotificationMessage };
