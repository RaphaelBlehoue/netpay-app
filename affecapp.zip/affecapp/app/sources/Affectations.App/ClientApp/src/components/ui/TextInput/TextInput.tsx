import { ComponentProps, forwardRef, useEffect, useMemo } from 'react';
import { TextInput as ToolkitInput } from '@axa-fr/react-toolkit-form-input-text';

import './TextInput.scss';

import { Control, Controller, FieldValues, Path, useForm } from 'react-hook-form';

import { setFormValueValidation } from '@affectations/pages/affectations/utils/validationFormAndDataFormatter';
import { TCriteria, TFieldArray } from '@affectations/types';

import { addLeadingZeros, blockAdditionalCharInput, TFieldOnInput } from './utils';

type TProps<IFormValuesPath extends FieldValues> = {
  control: Control<IFormValuesPath>;
  label?: string;
  name: Path<IFormValuesPath>;
  currentValueCriteria?: TFieldArray;
  messageError?: string;
  rules?: object;
} & Omit<ComponentProps<typeof ToolkitInput>, 'value' | 'label'>;

const CONTRACT_NUMBER = 'CONTRACT_NUMBER';

const TextInput = forwardRef<HTMLInputElement, TProps<FieldValues>>(
  ({ control, currentValueCriteria, placeholder, name, label, ...props }, ref) => {
    const { clearErrors } = useForm();
    const rules = useMemo(() => {
      return setFormValueValidation(currentValueCriteria?.criteria as TCriteria);
    }, [currentValueCriteria?.criteria]);

    useEffect(() => {
      clearErrors(name);
    }, [clearErrors, name]);
    return (
      <div className="af-container-input-text">
        <Controller
          control={control}
          name={name}
          rules={rules.validatedRules}
          render={({ field, fieldState }) => {
            const error = fieldState.error?.message;
            const handleChange = (e: { value: string }) => {
              const value = e.value;
              const options: TFieldOnInput = {
                currentValue: value,
                maxChar: rules.maxChar,
                field,
              };
              blockAdditionalCharInput(options);
            };
            const handldeOnInputBlur = () => {
              if (currentValueCriteria?.criteria === CONTRACT_NUMBER) {
                const input = field.value;
                if (input.length >= 1) {
                  field.onChange(addLeadingZeros(field.value));
                }
              }
            };

            return (
              <ToolkitInput
                className="text-input"
                placeholder={placeholder}
                label={label}
                {...field}
                {...props}
                ref={ref}
                aria-label={name}
                onChange={handleChange}
                onBlur={handldeOnInputBlur}
                message={error}
                forceDisplayMessage={true}
              />
            );
          }}
        />
      </div>
    );
  }
);

export { TextInput };
