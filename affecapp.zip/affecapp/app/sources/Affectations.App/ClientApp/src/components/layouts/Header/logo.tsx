import { Link } from '@affectations/components/ui';
import logo from '@affectations/public/logo-axa.svg';

export const Logo = () => {
  return (
    <div className="af-header__name">
      <div className="af-logo">
        <Link to={'/'} title="AXA France - Affectations" target="_blank">
          <img className="af-logo__brand" src={logo} alt="Axa Logo" />
        </Link>
      </div>
      <h2 className="af-header__title">Easy Affectation</h2>
    </div>
  );
};
