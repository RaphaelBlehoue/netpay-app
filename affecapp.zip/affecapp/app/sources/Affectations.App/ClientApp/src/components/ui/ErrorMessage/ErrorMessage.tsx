import { useCallback, useMemo } from 'react';

import { type Error } from '@affectations/contexts';
import { useError } from '@affectations/hooks';

import { ERRORS } from './constants';
import { ErrorAlert } from './ErrorAlert';

const CORRELATION_ID_PROP_NAME = 'correlation-id';

const getTechnicalErrorMsg = (refCode: string) => {
  return `Une erreur technique est survenue, merci de contacter l'équipe IT avec la référence suivante "${refCode}".`;
};

const ErrorMessage = () => {
  const { error } = useError();

  const getErrorWithReference = useCallback((httpError?: Error) => {
    if (!httpError?.response) {
      return undefined;
    }
    const responseText = httpError.response;
    try {
      const data = JSON.parse(responseText) as { [CORRELATION_ID_PROP_NAME]?: string } | undefined;
      if (!data?.[CORRELATION_ID_PROP_NAME]) {
        return undefined;
      }
      return getTechnicalErrorMsg(data[CORRELATION_ID_PROP_NAME]);
    } catch {
      return undefined;
    }
  }, []);
  const errorMessage = useMemo<undefined | string>(() => {
    if (!error?.status) {
      return undefined;
    }
    const errorWithReference = getErrorWithReference(error);
    return errorWithReference ?? ERRORS[error?.status];
  }, [error, getErrorWithReference]);

  if (errorMessage) {
    return <ErrorAlert errorMessage={errorMessage} />;
  }
  return null;
};

export default ErrorMessage;
