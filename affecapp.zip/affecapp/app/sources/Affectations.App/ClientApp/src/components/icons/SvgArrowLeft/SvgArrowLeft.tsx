import { FC, SVGAttributes } from 'react';
import clsx from 'clsx';

import style from './style.module.scss';

const SvgArrowLeft: FC<SVGAttributes<HTMLOrSVGElement>> = props => (
  <svg className={clsx(style.arrow, props.className)} xmlns="http://www.w3.org/2000/svg" {...props}>
    <path d="M3.12 6 7.7 1.41 6.29 0l-6 6 6 6 1.41-1.41z" />
  </svg>
);
export default SvgArrowLeft;
