import { NavBar } from '@axa-fr/react-toolkit-layout-header';

import { LinkMenuItem } from '../LinkMenuItem';

import './Navigation.scss';

export type TNavigationItem = {
  label: string;
  to: string;
};

interface IPropsNavigation {
  items?: TNavigationItem[];
}

const Navigation = ({ items }: IPropsNavigation) => {
  return (
    <NavBar className="af-nav" isVisible onClick={() => null} id="menuid">
      {items?.map(item => <LinkMenuItem key={item.to} label={item.label} to={item.to} />)}
    </NavBar>
  );
};

export { Navigation };
