import { Paging } from '@axa-fr/react-toolkit-table';

import './Pagination.scss';

interface IPropsPagination {
  currentPage: number;
  itemsPerPage: 5 | 10 | 25 | 50 | 100;
  totalItems: number;
  onChange: (e: { numberItems: number; page: number }) => void;
}

const Pagination = ({ currentPage, itemsPerPage, totalItems, onChange }: IPropsPagination) => {
  const totalPages = Math.ceil(totalItems / itemsPerPage);

  return (
    <Paging
      className="paging"
      currentPage={currentPage}
      numberItems={itemsPerPage}
      numberPages={totalPages}
      onChange={onChange}
    />
  );
};

export { Pagination };
