import CreatingMessage from './CreatingRuleMessage';
import { RenderAlert } from './RenderAlert';

type Props = {
  status: string;
  creationDate: Date | string;
};
const ConfirmationMessage = ({ status, creationDate }: Props) => {
  const currentDate: Date = typeof creationDate === 'string' ? new Date(creationDate) : creationDate;
  const { message, details } = CreatingMessage(status, currentDate) ?? {};
  return (
    <div>
      <RenderAlert message={message} details={details} />
    </div>
  );
};
export default ConfirmationMessage;
