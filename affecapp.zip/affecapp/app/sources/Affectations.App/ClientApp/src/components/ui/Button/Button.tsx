import { ComponentPropsWithRef } from 'react';
import ToolkitButton from '@axa-fr/react-toolkit-button';
import clsx from 'clsx';

import { ButtonClassModifiers } from './types';

import '@axa-fr/react-toolkit-button/dist/button.scss';

type ButtonToolkitProps = ComponentPropsWithRef<typeof ToolkitButton>;

type TPropsButton = {
  classModifiers?: ButtonClassModifiers[];
  icon?: React.ReactElement;
  typeButton?: string;
  wrapperClassName?: string;
  isDisabled?: boolean;
  classNames?: string;
} & ButtonToolkitProps;

const Button = ({
  classModifiers,
  title,
  icon,
  wrapperClassName,
  classNames,
  isDisabled = false,
  onClick,
  ...props
}: TPropsButton) => {
  return (
    <ToolkitButton
      classModifier={clsx(classModifiers, classNames)}
      name={title}
      onClick={onClick}
      disabled={isDisabled}
      {...props}
    >
      <span className="item-title">{title}</span>
      <span className={`${wrapperClassName}--wrapper-icon item-icon item-icon` ?? 'item-icon'}>{icon}</span>
    </ToolkitButton>
  );
};

export { Button };
