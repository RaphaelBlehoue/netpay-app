import { Dispatch, SetStateAction, useCallback, useState } from 'react';
import Table from '@axa-fr/react-toolkit-table';
import {
  ColumnDef,
  flexRender,
  getCoreRowModel,
  getFilteredRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  SortingState,
  useReactTable,
} from '@tanstack/react-table';
import clsx from 'clsx';
import { useNavigate } from 'react-router-dom';

import { SvgSortArrowTop } from '@affectations/components/icons';

import '@axa-fr/react-toolkit-table/dist/af-table.css';

import style from './style.module.scss';

type Props<T extends { id: string }> = {
  columns: ColumnDef<T>[];
  data: T[];
  rowSelection?: Record<string, boolean>;
  setRowSelection?: Dispatch<SetStateAction<Record<string, boolean>>>;
  href?: string;
  sticky?: boolean;
};

const DataTable = <T extends { id: string }>({
  columns,
  data,
  rowSelection = {},
  setRowSelection = () => {},
  href,
  sticky = false,
}: Props<T>) => {
  const navigate = useNavigate();
  const [sorting, setSorting] = useState<SortingState>([]);
  const table = useReactTable({
    data,
    columns,
    state: {
      rowSelection,
      sorting,
    },
    enableRowSelection: true,
    onRowSelectionChange: setRowSelection,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    getSortedRowModel: getSortedRowModel(),
    onSortingChange: setSorting,
    manualPagination: true,
    rowCount: data.length,
    getRowId: row => row.id,
  });

  const handleTableCellSelected = (e: React.MouseEvent<HTMLElement>, cellId: string) => {
    if (cellId.endsWith('select')) {
      e.stopPropagation();
    }
  };

  const jumpToPage = useCallback(
    (key: string) => {
      const url = href?.replace(':rulesId', key);
      if (url) {
        navigate(url);
      }
    },
    [href, navigate]
  );

  return (
    <div className={clsx(style['data-table'], 'table-container')}>
      <Table>
        <Table.Header className={clsx({ [style.sticky ?? '']: sticky })}>
          <Table.Tr>
            {table.getFlatHeaders().map(header => {
              const { getIsSorted, getCanSort, clearSorting, toggleSorting, columnDef } = header.column;
              const isSorted = getIsSorted() === 'asc';
              return (
                <Table.Th
                  key={header.id}
                  classModifier={clsx({ ['sort-asc']: isSorted })}
                  data-sortable={getCanSort()}
                  data-th={header.id}
                  role="columnheader"
                >
                  <div className={style['content']}>
                    {flexRender(columnDef.header, header.getContext())}
                    {getCanSort() && (
                      <button
                        onClick={() => {
                          if (getCanSort()) {
                            isSorted ? clearSorting() : toggleSorting(false);
                          }
                        }}
                        type="button"
                        title="trie du tableau"
                        className={style['arrows']}
                      >
                        <SvgSortArrowTop />
                        <SvgSortArrowTop />
                      </button>
                    )}
                  </div>
                </Table.Th>
              );
            })}
          </Table.Tr>
        </Table.Header>
        <Table.Body>
          {table.getRowModel().rows.map(row => (
            <Table.Tr
              key={row.id}
              classModifier={clsx({ selected: row.getIsSelected() })}
              onClick={() => jumpToPage(row.original.id)}
            >
              {row.getVisibleCells().map(cell => (
                <Table.Td
                  key={cell.id}
                  data-td={cell.id.replace(`${row.index}_`, '')}
                  onClick={e => {
                    handleTableCellSelected(e, cell.id);
                  }}
                >
                  {flexRender(cell.column.columnDef.cell, cell.getContext())}
                </Table.Td>
              ))}
            </Table.Tr>
          ))}
        </Table.Body>
      </Table>
    </div>
  );
};

export default DataTable;
