import '@axa-fr/react-toolkit-form-input-text/dist/af-inputtext.css';
import '@axa-fr/react-toolkit-form-core/dist/af-form.css';

import { ComponentProps, FC, useCallback } from 'react';
import { TextInput } from '@axa-fr/react-toolkit-form-input-text';
import clsx from 'clsx';
import { Control, Controller, ControllerRenderProps, FieldValues } from 'react-hook-form';

import { SvgSearch } from '@affectations/components/icons';

import style from './style.module.scss';

const MAX_TEN = 10;

const toNumber = (value: string) => {
  const match = value.match(/^\d+/);
  return match ? match[0] : '';
};

const toAlphaNumber = (value: string) => {
  const match = value.match(/[a-zA-Z0-9]*/);
  return match ? match[0] : '';
};

function padString(input: string, length: number, padChar = '0'): string {
  if (padChar.length !== 1) {
    throw new Error('padChar doit être un seul caractère.');
  }

  const regex = new RegExp(`^${padChar}+`);
  const cleanedInput = input.replace(regex, '');
  if (!cleanedInput.length) {
    return '';
  }
  const padding = padChar.repeat(Math.max(0, length - cleanedInput.length));

  return padding + cleanedInput;
}

type Props = {
  control: Control;
  name: string;
  small?: boolean;
  searchIcon?: boolean;
  isPad?: boolean;
  isAlphaNumeric?: boolean;
  padCharacter?: string;
  padCount?: number;
  onChange?: (value: string) => string;
} & Omit<ComponentProps<typeof TextInput>, 'onChange'>;
const SearchInput: FC<Props> = ({
  control,
  name,
  small = false,
  searchIcon = false,
  isPad = false,
  isAlphaNumeric = false,
  padCharacter = '0',
  padCount = MAX_TEN,
  type,
  maxLength,
  ...others
}) => {
  const handleChange = useCallback(
    (data: { value: string }, field: ControllerRenderProps<FieldValues, string>) => {
      let newValue = type === 'number' ? toNumber(data.value) : data.value;
      newValue = isAlphaNumeric ? toAlphaNumber(newValue) : newValue;
      if (others.onChange) {
        newValue = others.onChange(data.value);
      }
      if (maxLength) {
        newValue = newValue.toString().substring(0, maxLength);
      }
      field.onChange(newValue);
    },
    [isAlphaNumeric, maxLength, others, type]
  );
  const handleBlur = useCallback(
    (e: React.FocusEvent<HTMLInputElement>, field: ControllerRenderProps<FieldValues, string>) => {
      if (isPad) {
        const value = padString(e.target.value.toString(), padCount, padCharacter);
        field.onChange(value);
      }
      field.onBlur();
      others.onBlur?.(e);
    },
    [isPad, others, padCharacter, padCount]
  );

  return (
    <Controller
      control={control}
      name={name}
      render={({ field }) => (
        <TextInput
          {...field}
          {...others}
          type="number"
          className={clsx(style['search-input'], {
            [style['icon-search'] ?? '']: searchIcon,
            [style.small ?? '']: small,
          })}
          onChange={data => handleChange(data, field)}
          onBlur={e => handleBlur(e, field)}
        >
          {searchIcon && (
            <div className={style.icon}>
              <SvgSearch />
            </div>
          )}
        </TextInput>
      )}
    />
  );
};

export default SearchInput;
