import { useId } from 'react';
import { components, OptionProps } from 'react-select';

import { CheckboxItemInput } from '../CheckboxItemInput';

export type TOption = {
  value: string;
  label: string;
};

const MultiCheckBoxSelectOption = ({ ...props }: OptionProps) => {
  const uniqueId = useId();
  const { label, isSelected, getValue } = props;
  const nbValues = getValue().length;
  const allOptions = props.options.length - 1;
  const currentValue = getValue() as TOption[];
  const isSelect = currentValue.some(item => item.value === '*') && currentValue.length === 1;
  const isAllSelected = allOptions === nbValues || currentValue.some(item => item.value === '*') || isSelect;

  return (
    <components.Option {...props}>
      <CheckboxItemInput id={uniqueId} isChecked={isSelected || isAllSelected} label={label} readOnly />
    </components.Option>
  );
};

export { MultiCheckBoxSelectOption };
