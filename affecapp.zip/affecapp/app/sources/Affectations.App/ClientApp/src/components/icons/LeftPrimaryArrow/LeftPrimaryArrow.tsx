import { FC } from 'react';

import style from './style.module.scss';

const SvgRightArrow: FC<React.SVGAttributes<SVGElement>> = props => (
  <svg xmlns="http://www.w3.org/2000/svg" className={style['left-primary-arrow']} {...props}>
    <path fill="#3032c1" d="M14 7 7 0 5.766 1.234l4.883 4.891H0v1.75h10.649l-4.883 4.891L7 14z" />
  </svg>
);
export default SvgRightArrow;
