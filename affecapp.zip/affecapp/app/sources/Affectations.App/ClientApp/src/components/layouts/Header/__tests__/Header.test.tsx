import { screen, within } from '@testing-library/react';
import { axe } from 'jest-axe';
import { MemoryRouter } from 'react-router-dom';

import { Header } from '@affectations/components';
import { renderWrapperWithContext } from '@affectations/test-utils';

describe('Header', () => {
  it('Render Header', async () => {
    const user = 'brique Thierry';
    const { container } = renderWrapperWithContext(
      <MemoryRouter>
        <Header name={user} />
      </MemoryRouter>
    );
    const header = screen.getByRole('banner');
    expect(header).toBeDefined();

    const headerScope = within(header);
    expect(headerScope.getByText(/brique Thierry/i)).toBeInTheDocument();

    const logoAxa = headerScope.getByRole('img', { name: /axa logo/i });
    expect(logoAxa).toHaveAttribute('alt', 'Axa Logo');
    expect(await axe(container)).toHaveNoViolations();
  });
});
