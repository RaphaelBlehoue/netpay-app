import './TextInput.scss';

import { ComponentProps } from 'react';
import { FieldValues, Path, UseFormRegister } from 'react-hook-form';

import { FieldText } from './FieldText';

type TProps = ComponentProps<typeof FieldText>;

interface IinputFieldProps<IFormValuesPath extends FieldValues> extends TProps {
  register: UseFormRegister<IFormValuesPath>;
  name: Path<IFormValuesPath>;
  label?: string;
}
const TextInputField = <IFormValuesPath extends FieldValues>({
  register,
  name,
  ...otherProps
}: IinputFieldProps<IFormValuesPath>) => {
  return (
    <div className="af-container-input-content">
      <FieldText {...register(name)} {...otherProps} />
    </div>
  );
};

export { TextInputField };
