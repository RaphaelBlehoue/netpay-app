import { FC, SVGAttributes } from 'react';
import clsx from 'clsx';

import style from './style.module.scss';

const d =
  'M12.266 12.266q1.58-1.581 1.58-3.804 0-2.224-1.58-3.805t-3.804-1.58-3.805' +
  ' 1.58-1.58 3.805 1.58 3.804 3.805 1.58 3.804-1.58m7.29 5.114q.444.444.444 1.082 ' +
  '0 .625-.457 1.081a1.48 1.48 0 0 1-1.081.457q-.65 0-1.082-.457l-4.123-4.11q-2.151 ' +
  '1.49-4.795 1.49a8.3 8.3 0 0 1-3.288-.667 8.5 8.5 0 0 1-2.704-1.803A8.5 8.5 0 0 1 .667 ' +
  '11.75 8.3 8.3 0 0 1 0 8.462q0-1.719.667-3.288A8.5 8.5 0 0 1 2.47 2.47 8.5 8.5 0 0 1 ' +
  '5.174.667 8.3 8.3 0 0 1 8.462 0q1.718 0 3.287.667a8.5 8.5 0 0 1 2.704 1.803 8.5 8.5 0 ' +
  '0 1 1.803 2.704 8.3 8.3 0 0 1 .667 3.288q0 2.643-1.49 4.795z';

const SvgSearch: FC<SVGAttributes<HTMLOrSVGElement>> = props => {
  return (
    <svg className={clsx(style.search, props.className)} xmlns="http://www.w3.org/2000/svg" {...props}>
      <path fill="#999" d={d} />
    </svg>
  );
};
export default SvgSearch;
