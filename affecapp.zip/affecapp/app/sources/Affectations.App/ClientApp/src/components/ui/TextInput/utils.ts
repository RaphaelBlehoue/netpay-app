import { FieldValues } from 'react-hook-form';

const MAX_NUMBER_OF_CHARACTERS = 16;
export type TFieldOnInput = {
  currentValue: string;
  maxChar?: number;
  field: FieldValues;
};

export const addLeadingZeros = (currentValue: string) => {
  return currentValue.padStart(MAX_NUMBER_OF_CHARACTERS, '0');
};

export const blockAdditionalCharInput = ({ currentValue, maxChar = Number.MAX_VALUE, field }: TFieldOnInput) => {
  const inputValue = currentValue;
  if (inputValue.length <= maxChar) {
    field.onChange(currentValue);
  }
};
