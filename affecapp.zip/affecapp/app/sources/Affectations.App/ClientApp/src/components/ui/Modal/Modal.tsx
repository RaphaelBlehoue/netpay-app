import { ReactNode } from 'react';
import Modal from '@axa-fr/react-toolkit-modal-default';

import '@axa-fr/react-toolkit-modal-default/dist/af-modal.css';
import '@axa-fr/react-toolkit-button/dist/af-button.css';

import { Button } from '../Button';
import { ButtonClassModifiers } from '../Button/types';

import './Modal.scss';

type TModal = {
  title: string;
  subTitle?: string;
  content: string | ReactNode;
  buttonLabel: string;
  isOpen: boolean;
  onClose: () => void;
  onSubmit: () => void;
};

const ModalToolkit = ({ title, isOpen, content, buttonLabel, onClose, onSubmit }: TModal) => {
  return (
    <Modal isOpen={isOpen} onOutsideTap={onClose}>
      <Modal.Header title={title} onCancel={onClose} />
      <Modal.Body>{content}</Modal.Body>
      <Modal.Footer>
        <Button
          title="Annuler"
          classModifiers={[ButtonClassModifiers.Reverse]}
          onClick={onClose}
          aria-label="Fermer la modal"
        />
        <Button
          title={buttonLabel}
          classModifiers={[ButtonClassModifiers.Sucess]}
          type="submit"
          onClick={onSubmit}
          aria-label="Confirmer une action"
        />
      </Modal.Footer>
    </Modal>
  );
};

export { ModalToolkit as Modal };
