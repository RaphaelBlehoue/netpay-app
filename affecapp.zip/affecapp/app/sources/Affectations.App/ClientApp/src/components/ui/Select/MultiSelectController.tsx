import { ComponentProps, useEffect, useState } from 'react';
import { Control, Controller, FieldValues, Path, UseFormGetValues, UseFormSetValue } from 'react-hook-form';
import Select from 'react-select';

import { MultiCheckBoxSelectOption as CheckBoxSelectOption, TOption } from './MultiCheckBoxSelectOption';

import '@axa-fr/react-toolkit-form-input-select/dist/af-select.css';
import './MultiSelect.scss';

import { FieldError } from '@axa-fr/react-toolkit-form-core';
import clsx from 'clsx';

import { affectationValueFormSchema } from '@affectations/pages/affectations/utils/validationFormAndDataFormatter';
import { MessageTypes } from '@affectations/types';

import { predicateAllDeselect, predicateUserWantToSelectAll } from './utils';

type TProps = ComponentProps<typeof Select>;

interface IMultiSelectControllerProps<TFieldValuesPath extends FieldValues> extends TProps {
  name: Path<TFieldValuesPath>;
  control?: Control<TFieldValuesPath>;
  placeholder?: string;
  classNamePrefix?: string;
  messageType?: MessageTypes;
  options: TOption[];
  className?: string;
  isMulti?: boolean;
  isDisplayValueInSelect?: boolean;
  setValue?: UseFormSetValue<TFieldValuesPath>;
  getValues?: UseFormGetValues<TFieldValuesPath>;
  onSelectChange?: (valueOption?: TOption | unknown) => void;
}

const NB_CURRENT_VALUE = 2;

const MultiSelectController = <TFieldValuesPath extends FieldValues>({
  name,
  control,
  options,
  setValue,
  classNamePrefix,
  messageType = MessageTypes.error,
  isMulti = true,
  placeholder = '- Sélectionner -',
  className,
  isDisplayValueInSelect = true,
  onSelectChange,
  ...otherProps
}: IMultiSelectControllerProps<TFieldValuesPath>) => {
  const [selectedItems, setSelectedItems] = useState<TOption[]>([]);

  const onSelectUpdateChange = (valueOption: TOption | unknown) => {
    const currentValue = valueOption as TOption[];
    const nbValues = currentValue.length;
    const isAllSelect = options.length - 1 === nbValues;
    const isAllChecked = currentValue?.some((current: TOption, _index: number) => current.value === '*');
    let newValueField: TOption[];

    if (isAllChecked && nbValues === NB_CURRENT_VALUE) {
      newValueField = predicateAllDeselect(options, currentValue);
      return setSelectedItems(newValueField);
    }

    if (isAllSelect) {
      newValueField = options.filter((item: TOption) => item.value === '*');
      return setSelectedItems(newValueField);
    }

    newValueField = predicateUserWantToSelectAll(isAllChecked, currentValue);
    return setSelectedItems(newValueField);
  };

  useEffect(() => {
    setValue && setValue(name, selectedItems as never);
  }, [name, selectedItems, setValue]);
  return (
    <Controller
      name={name}
      control={control}
      rules={affectationValueFormSchema.DEFAULT}
      render={({ field, fieldState: { error } }) => {
        const handleChange = (valueOption: TOption | unknown) => {
          field.onChange?.(valueOption);
          onSelectChange?.(valueOption);
          onSelectUpdateChange(valueOption);
        };
        const errorMessage = error?.message;
        return (
          <div className="content-multi">
            <Select
              {...field}
              classNamePrefix={classNamePrefix}
              className={clsx(className, { 'af-form__multi--error': !!errorMessage })}
              options={options}
              components={{
                Option: CheckBoxSelectOption,
              }}
              isMulti={isMulti}
              value={selectedItems || null}
              onChange={handleChange}
              placeholder={placeholder}
              hideSelectedOptions={false}
              blurInputOnSelect={false}
              closeMenuOnSelect={false}
              isClearable={false}
              controlShouldRenderValue={isDisplayValueInSelect}
              aria-label={name}
              {...otherProps}
            />
            <FieldError message={errorMessage} messageType={messageType} />
          </div>
        );
      }}
    />
  );
};

export { MultiSelectController };
