import { AlertCore } from '@axa-fr/react-toolkit-alert';

import { AlertClassModifiers } from '../Alert';

import '@axa-fr/react-toolkit-alert/dist/af-alert.css';

import style from './style.module.scss';

type Props = {
  message: string;
  details?: string;
  iconName?: string;
  alertType?: AlertClassModifiers;
};

export const RenderAlert = ({
  message,
  details,
  iconName = 'glyphicon glyphicon-ok',
  alertType = AlertClassModifiers.Success,
}: Props) => (
  <div>
    <AlertCore classModifier={alertType} title={message} iconClassName={iconName}>
      {details && (
        <ul className={style.unstyledList}>
          <li>{details}</li>
        </ul>
      )}
    </AlertCore>
  </div>
);
