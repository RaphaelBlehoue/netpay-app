export { default } from './LeftPrimaryArrow';
