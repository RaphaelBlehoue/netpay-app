export const HTTP_STATUS = {
  BAD_REQUEST: 400,
  UNAUTHORIZED: 401,
  FORBIDDEN: 403,
  NOT_FOUND: 404,
  SERVER_ERROR: 500,
  OK: 200,
};

export const ERRORS = {
  [HTTP_STATUS.UNAUTHORIZED]:
    'Vous avez été déconnecté ' +
    "de l'application Easy Affectation car vous êtes resté inactif pendant 20 min. Veuillez rafraîchir la page.",
  [HTTP_STATUS.SERVER_ERROR]:
    'Une erreur est survenue, Easy Affectation est momentanément indisponible. Veuillez réessayer ultérieurement.',
};
