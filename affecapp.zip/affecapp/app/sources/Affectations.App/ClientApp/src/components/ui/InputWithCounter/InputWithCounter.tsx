import { ComponentProps, forwardRef } from 'react';
import { TextInput } from '@axa-fr/react-toolkit-form-input-text';

import './style.scss';

import { Control, Controller } from 'react-hook-form';

const DEFAUL_MAX_INPUT_LENGTH = 255;

type Props = {
  maxLength?: number;
  control: Control;
  name: string;
} & Omit<ComponentProps<typeof TextInput>, 'value'>;

const InputWithCounter = forwardRef<HTMLInputElement, Props>(
  ({ maxLength = DEFAUL_MAX_INPUT_LENGTH, control, name, helpMessage, ...props }, ref) => {
    return (
      <Controller
        control={control}
        name={name}
        rules={{ required: false, maxLength }}
        defaultValue={''}
        render={({ field }) => (
          <TextInput
            {...props}
            {...field}
            ref={ref}
            onChange={e => field.onChange(e.value)}
            helpMessage={helpMessage ?? `${field.value?.length ?? 0}/${maxLength}`}
            maxLength={maxLength}
          />
        )}
      />
    );
  }
);

export default InputWithCounter;
