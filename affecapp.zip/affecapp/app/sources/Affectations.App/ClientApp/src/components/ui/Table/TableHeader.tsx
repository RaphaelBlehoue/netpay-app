import Table from '@axa-fr/react-toolkit-table';

import type { Column } from './utils';

import './TableHeader.scss';

const { Tr, Th, Header } = Table;

interface IPropsTableHeader<DataType> {
  columns: Column<DataType>[];
}

const TableHeader = <DataType extends object>({ columns }: IPropsTableHeader<DataType>) => {
  return (
    <Header>
      <Tr>
        {columns.map((element, index) => (
          <Th key={index} className="af-table__th">
            <span className="af-table-th-content">{element.title}</span>
          </Th>
        ))}
      </Tr>
    </Header>
  );
};

export { TableHeader };
