import { AppContextProvider } from '@affectations/contexts/AppContextProvider';

import './App.scss';

import { Router } from '@affectations/Router';

const App = () => {
  return (
    <AppContextProvider>
      <Router />
    </AppContextProvider>
  );
};

export { App };
