import { Outlet, ScrollRestoration } from 'react-router-dom';

import { MainLayout } from './MainLayout';

const AppLayout = () => {
  return (
    <MainLayout>
      <ScrollRestoration />
      <Outlet />
    </MainLayout>
  );
};

export { AppLayout };
