export { default } from './SvgReload';
