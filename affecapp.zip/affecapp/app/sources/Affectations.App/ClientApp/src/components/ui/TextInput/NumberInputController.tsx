import { ComponentProps, useState } from 'react';
import { TextInput as ToolkitInput } from '@axa-fr/react-toolkit-form-input-text';
import { Control, Controller, FieldValues, Path } from 'react-hook-form';

import './TextInput.scss';

import { affectationValueFormSchema } from '@affectations/pages/affectations/utils/validationFormAndDataFormatter';
import { TDataInput } from '@affectations/features/commonTypes';

type TProps = ComponentProps<typeof ToolkitInput>;

type INumberInputController<IFormValuesPath extends FieldValues> = {
  placeholder?: string;
  name: Path<IFormValuesPath>;
  label?: string;
  control?: Control<IFormValuesPath>;
} & Omit<TProps, 'label'>;

const addSpace = (input: number | string) => input.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
const removeSpace = (input: string) => input.replace(/\s/g, '');
const removeInputNotNumeric = (input: string | number) => input.toString().replace(/\D/g, '');

const NumberInputController = <IFormValuesPath extends FieldValues>({
  name,
  control,
  label,
  placeholder,
  ...otherProps
}: INumberInputController<IFormValuesPath>) => {
  const [stateValue, setStateValue] = useState<string>('');
  return (
    <div className="af-container-input-content">
      <Controller
        name={name}
        control={control}
        rules={affectationValueFormSchema.DEFAULT}
        render={({ field }) => {
          const handleChange = (event: TDataInput) => {
            setStateValue(addSpace(removeInputNotNumeric(event.value)));
            field.onChange(removeSpace(event.value));
          };
          return (
            <div className="af-container-input-text">
              <ToolkitInput
                {...field}
                className="number__input"
                placeholder={placeholder}
                label={label}
                {...field}
                {...otherProps}
                ref={field.ref}
                onChange={handleChange}
                value={stateValue}
                {...otherProps}
              />
            </div>
          );
        }}
      />
    </div>
  );
};

export { NumberInputController };
