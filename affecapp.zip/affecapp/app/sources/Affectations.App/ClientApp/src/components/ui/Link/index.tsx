import { ComponentProps } from 'react';
import { Link as LinkReactRouterDom } from 'react-router-dom';

import './Link.scss';

type LinkProps = ComponentProps<typeof LinkReactRouterDom>;

const Link = ({ children, ...props }: LinkProps) => {
  return (
    <LinkReactRouterDom className="af-link-react-router-dom" {...props}>
      {children}
    </LinkReactRouterDom>
  );
};

export { Link };
