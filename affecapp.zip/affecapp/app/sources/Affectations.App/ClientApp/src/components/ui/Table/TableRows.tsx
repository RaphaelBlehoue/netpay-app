import Table from '@axa-fr/react-toolkit-table';
import { generatePath } from 'react-router-dom';

import { Link } from '../Link';
import { CellTypes, formatText, type Column } from './utils';

const { Tr, Td, Body } = Table;

interface IPropsTableRows<DataType> {
  columns: Column<DataType>[];
  data: DataType[];
}

const TableRows = <DataType extends object>({ columns, data }: IPropsTableRows<DataType>) => {
  return (
    <Body>
      {data.map((row, rIndex) => (
        <Tr key={rIndex}>
          {columns.map((column, cIndex) => (
            <Td key={cIndex}>
              {column.type === CellTypes.LINK ? (
                <Link
                  to={generatePath(column.path as string, row[column.key] as string)}
                  className="af-link"
                  aria-label={`Lien avec redirection ${column.title} ${row[column.key]}`}
                >
                  <span className="af-link__text">{formatText(row[column.key], column?.format)}</span>
                </Link>
              ) : (
                <span className="af-table-body-content">{formatText(row[column.key], column?.format)}</span>
              )}
            </Td>
          ))}
        </Tr>
      ))}
    </Body>
  );
};

export { TableRows };
