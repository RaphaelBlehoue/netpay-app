import { Header as HeaderToolkit } from '@axa-fr/react-toolkit-layout-header';

import '@axa-fr/react-toolkit-layout-header/dist/Header/af-header.css';
import '@axa-fr/react-toolkit-layout-header/dist/Logo/af-logo.css';
import '@axa-fr/react-toolkit-layout-header/dist/Name/af-name.css';
import '@axa-fr/react-toolkit-layout-header/dist/User/af-user.css';
import './Header.scss';

import { Logo } from './logo';

interface IHeader {
  name: string;
}

const Header = ({ name }: Partial<IHeader>) => {
  return (
    <section className="container-header">
      <HeaderToolkit>
        <Logo />
        <div className="af-info-user">
          <span className="af-info-user__name">{name ?? 'invite'}</span>
        </div>
      </HeaderToolkit>
    </section>
  );
};

export { Header };
