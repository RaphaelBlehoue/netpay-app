import { FC } from 'react';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';

import { IProblemDetails } from '@affectations/api/bff-clients.generated';
import { ErrorProvider } from '@affectations/contexts';
import { useError } from '@affectations/hooks';

import { ERRORS, HTTP_STATUS } from '../constants';
import ErrorMessage from '../ErrorMessage';

const Wrapper: FC<{ error?: IProblemDetails }> = ({ error }) => {
  const { displayError } = useError();
  return (
    <>
      <ErrorMessage />
      <button type="button" onClick={() => displayError(error)}>
        display
      </button>
    </>
  );
};

describe('ErrorMessage', () => {
  it('should not display error initialy', async () => {
    render(
      <ErrorProvider>
        <Wrapper />
      </ErrorProvider>
    );
    const alert = screen.queryByRole('alert');
    expect(alert).toBeNull();
  });
  it.each([
    { status: HTTP_STATUS.UNAUTHORIZED, message: ERRORS[HTTP_STATUS.UNAUTHORIZED] },
    { status: HTTP_STATUS.SERVER_ERROR, message: ERRORS[HTTP_STATUS.SERVER_ERROR] },
  ])('should display "$message" for "$status" code', async ({ status, message }) => {
    const error: IProblemDetails = {
      status,
    };
    render(
      <ErrorProvider>
        <Wrapper error={error} />
      </ErrorProvider>
    );
    const button = screen.getByRole('button', {
      name: 'display',
    });

    await waitFor(async () => await userEvent.click(button));
    const alert = await screen.findByText(message ?? '');

    expect(alert).toBeInTheDocument();
  });
});
