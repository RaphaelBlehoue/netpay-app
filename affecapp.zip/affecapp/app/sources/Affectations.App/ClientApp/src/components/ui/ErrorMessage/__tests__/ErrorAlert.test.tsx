import { render, screen } from '@testing-library/react';

import { ErrorAlert } from '../ErrorAlert';

describe('ErrorAlert', () => {
  it('should be rendered without error', () => {
    render(<ErrorAlert errorMessage="Error" />);
  });
  it.each`
    error
    ${'Something went wrong !'}
    ${'Your are unauthorized to do this action'}
    ${'Try again'}
  `('the text "%s" is displayed', ({ error }) => {
    render(<ErrorAlert errorMessage={error} />);
    const msg = screen.getByText(error);

    expect(msg).toBeInTheDocument();
  });
});
