import { TextareaInput as ToolkitTextarea } from '@axa-fr/react-toolkit-form-input-textarea';

import './TextareaInput.scss';

import { ComponentProps } from 'react';

type TProps = ComponentProps<typeof ToolkitTextarea>;

interface TPropsTextareaInput extends Omit<TProps, 'label'> {
  label?: string;
  helpMessage?: string;
}

const TextareaInput = ({ name, placeholder, helpMessage, label, ...props }: TPropsTextareaInput) => {
  return (
    <ToolkitTextarea
      label={label}
      aria-label={name}
      className="textarea-input"
      placeholder={placeholder}
      helpMessage={helpMessage}
      rows={4}
      cols={40}
      {...props}
    />
  );
};

export { TextareaInput };
