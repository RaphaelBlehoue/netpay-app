import Table from '@axa-fr/react-toolkit-table';
import clsx from 'clsx';

import { TableHeader } from './TableHeader';
import { TableRows } from './TableRows';
import type { Column } from './utils';

import '@axa-fr/react-toolkit-table/dist/af-table.css';

const { Body } = Table;

interface IPropsTable<DataType> {
  title: string;
  headerColumns: Column<DataType>[];
  children?: React.ReactNode;
  dataRows?: DataType[];
}

const TableContainer = <DataType extends object>({
  children,
  headerColumns,
  title,
  dataRows,
}: IPropsTable<DataType>) => {
  return (
    <Table classModifier={clsx('uaxa', 'modalities')} className="af-table" aria-label={title}>
      <TableHeader columns={headerColumns} />
      {dataRows?.length ? <TableRows columns={headerColumns} data={dataRows} /> : <Body>{children}</Body>}
    </Table>
  );
};

export { TableContainer };
