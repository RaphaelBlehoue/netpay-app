import { ComponentProps } from 'react';

import './TextareaInput.scss';

import { Control, Controller, FieldValues, Path } from 'react-hook-form';

import { blockAdditionalCharInput, TFieldOnInput } from '../TextInput/utils';
import { TextareaInput } from './TextareaInput';

type TProps = ComponentProps<typeof TextareaInput>;
interface ITextareaInputController<IFormValuesPath extends FieldValues> extends TProps {
  placeholder?: string;
  name: Path<IFormValuesPath>;
  maxLength?: number;
  control?: Control<IFormValuesPath>;
}
const TextareaInputController = <IFormValuesPath extends FieldValues>({
  name,
  control,
  maxLength,
  ...otherProps
}: ITextareaInputController<IFormValuesPath>) => (
  <div className="af-container__textarea-content">
    <Controller
      name={name}
      control={control}
      render={({ field }) => {
        const handleChange = (e: { value: string }) => {
          const value = e.value;
          const options: TFieldOnInput = {
            currentValue: value,
            maxChar: maxLength,
            field,
          };
          blockAdditionalCharInput(options);
        };
        return (
          <TextareaInput
            {...field}
            onChange={handleChange}
            helpMessage={maxLength ? `${field.value?.length ?? 0}/${maxLength}` : ''}
            {...otherProps}
          />
        );
      }}
    />
  </div>
);

export { TextareaInputController };
