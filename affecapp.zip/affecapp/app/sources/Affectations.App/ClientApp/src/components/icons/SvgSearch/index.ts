import SvgSearch from './SvgSearch';

export { SvgSearch };
