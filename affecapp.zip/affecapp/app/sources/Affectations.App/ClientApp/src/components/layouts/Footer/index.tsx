import { Footer as FooterToolkit } from '@axa-fr/react-toolkit-layout-footer';

import '@axa-fr/react-toolkit-layout-footer/dist/af-footer.css';
import './Footer.scss';

const Footer = () => {
  const customCopyRight = `© ${new Date().getFullYear()} AXA Tous droits réservés - Version ${APP_VERSION}`;
  return <FooterToolkit copyright={customCopyRight} />;
};

export { Footer };
