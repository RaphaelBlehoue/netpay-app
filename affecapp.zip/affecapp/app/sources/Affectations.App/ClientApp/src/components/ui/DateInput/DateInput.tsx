import { BaseSyntheticEvent, ComponentProps, FC, forwardRef } from 'react';
import { DateInput as AxaDateInput } from '@axa-fr/react-toolkit-form-input-date';

type Props = { onClear?: () => void } & ComponentProps<typeof AxaDateInput>;

const DateInput: FC<Props> = forwardRef<HTMLInputElement, Props>(({ onClear = () => {}, ...others }, _ref) => (
  <AxaDateInput
    {...others}
    onChangeCapture={(e: BaseSyntheticEvent) => {
      if (!e.target.value) {
        onClear();
      }
    }}
  />
));

export default DateInput;
