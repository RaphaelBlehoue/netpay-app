import { FC } from 'react';
import { Navigate } from 'react-router-dom';

import { FORBIDDEN_PATH, LOGIN_PATH } from '@affectations/utils/authentication';
import { ApiException } from '@affectations/api/duende-bff-clients.generated';

import { HTTP_STATUS } from '../ErrorMessage/constants';

type Props = {
  error?: ApiException;
  redirect?: (path: string) => void;
};

const AuthenticationError: FC<Props> = ({ error, redirect = location.assign.bind(location) }) => {
  if (error?.status === HTTP_STATUS.UNAUTHORIZED) {

    redirect(`${LOGIN_PATH}?returnUrl=${location.pathname}`);
    return null;
  }
  return <Navigate to={`${FORBIDDEN_PATH}`} />;
};

export default AuthenticationError;
