import ToolkitAlert from '@axa-fr/react-toolkit-alert';

import './Alert.scss';

export enum AlertClassModifiers {
  Success = 'success',
  Info = 'info',
  Danger = 'danger',
  Error = 'error',
}

interface IPropsAlert {
  title: string;
  mode?: AlertClassModifiers;
}

const iconMap = {
  success: 'ok',
  info: 'info-sign',
  danger: 'warning-sign',
  error: 'minus-sign',
};

const Alert = ({ mode = AlertClassModifiers.Danger, title }: IPropsAlert) => {
  const icon = iconMap[mode];

  return <ToolkitAlert classModifier={mode} icon={`glyphicon glyphicon-${icon}`} title={title} />;
};

export { Alert };
