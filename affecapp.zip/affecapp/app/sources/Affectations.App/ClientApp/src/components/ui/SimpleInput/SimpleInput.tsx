import { ComponentProps, FC } from 'react';
import { Control, Controller } from 'react-hook-form';

type Props = {
  control: Control;
  name: string;
} & ComponentProps<'input'>;

const SimpleInput: FC<Props> = ({ control, name, ...others }) => (
  <Controller
    control={control}
    name={name}
    render={({ field }) => <input {...others} {...field} onChange={e => field.onChange(e.target.value)} />}
  />
);

export default SimpleInput;
