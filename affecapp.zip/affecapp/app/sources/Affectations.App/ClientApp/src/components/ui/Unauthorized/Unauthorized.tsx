import { useCallback } from 'react';
import Alert from '@axa-fr/react-toolkit-alert';
import Button from '@axa-fr/react-toolkit-button';

import SvgReload from '@affectations/components/icons/SvgReload';
import { ContentLayout } from '@affectations/components/layouts/Layout/ContentLayout';

import style from './style.module.scss';

const TITLE_BAR = 'Accès Refusé';

type Props = {
  reload?: () => void;
};

const Unauthorized = ({ reload = location.reload.bind(location) }: Props) => {
  const handleReload = useCallback(() => {
    reload();
  }, [reload]);

  return (
    <ContentLayout titleHead={TITLE_BAR} className={style['unauthorized']}>
      <Alert
        classModifier="error"
        title="Erreur : La page n'a pas pu être chargée, car nous ne parvenons pas à vous authentifier."
      >
        <p className={style['second-title']}>
          Merci de contacter le support IT pour demander une habilitation à l'outil EASY Affectation.
        </p>
      </Alert>
      <div className={style.box}>
        <Button classModifier="reverse" onClick={handleReload}>
          <SvgReload />
          <span>Recharger la page</span>
        </Button>
      </div>
    </ContentLayout>
  );
};

export default Unauthorized;
