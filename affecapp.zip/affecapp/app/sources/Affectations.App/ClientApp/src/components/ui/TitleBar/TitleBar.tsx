import { Title } from '@axa-fr/react-toolkit-layout-header';

import './TitleBar.scss';

interface IPropsTitleBar {
  title: string;
}

const TitleBar = ({ title }: IPropsTitleBar) => {
  return <Title title={title} />;
};

export { TitleBar };
