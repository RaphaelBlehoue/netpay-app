import React, { PropsWithChildren } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { render, RenderOptions } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { MemoryRouter } from 'react-router-dom';

import { HOME_BASE_URL } from '@affectations/routes/configRoute';

interface TRenderOptions extends RenderOptions {
  initialEntries?: string[];
  queryClient?: QueryClient;
}
const renderMemoryRouter = (ui: React.ReactElement, options?: Omit<TRenderOptions, 'wrapper'>) => {
  const WrapperTest = ({ children }: PropsWithChildren) => {
    return (
      <MemoryRouter initialEntries={options?.initialEntries ?? [HOME_BASE_URL]}>
        {options?.queryClient ? (
          <QueryClientProvider client={options?.queryClient}>{children}</QueryClientProvider>
        ) : (
          children
        )}
      </MemoryRouter>
    );
  };

  return {
    user: userEvent.setup(),
    ...render(ui, { wrapper: WrapperTest, ...options }),
  };
};

export { renderMemoryRouter };
