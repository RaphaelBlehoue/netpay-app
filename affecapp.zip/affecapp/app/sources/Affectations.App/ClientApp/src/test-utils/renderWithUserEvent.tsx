import { render } from '@testing-library/react';
import userEvent from '@testing-library/user-event';

import { AppContextProvider } from '@affectations/contexts/AppContextProvider';

function renderSetup(jsxElement: React.ReactElement) {
  return {
    user: userEvent.setup(),
    ...render(<AppContextProvider>{jsxElement}</AppContextProvider>),
  };
}

export { renderSetup };
