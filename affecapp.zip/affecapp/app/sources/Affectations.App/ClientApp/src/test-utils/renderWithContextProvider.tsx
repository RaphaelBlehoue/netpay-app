import { PropsWithChildren } from 'react';
import { render } from '@testing-library/react';

import { AppContextProvider } from '@affectations/contexts/AppContextProvider';

const renderWrapperWithContext = (ui: React.ReactElement, options?: object) => {
  const WrapperTest = ({ children }: PropsWithChildren) => {
    return <AppContextProvider>{children}</AppContextProvider>;
  };

  return render(ui, { wrapper: WrapperTest, ...options });
};

export { renderWrapperWithContext };
