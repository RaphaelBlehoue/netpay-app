import { ISVGElement } from '@affectations/types/icon';

const IcInfoSign = ({ size, ...props }: ISVGElement) => (
  <svg xmlns="http://www.w3.org/2000/svg" width={size ?? '24'} height={size ?? '24'} {...props}>
    <path
      fill="#3032c1"
      d="M20 10c0-5.52-4.48-10-10-10S0 4.48 0 10s4.48 10 10 10 10-4.48 10-10Zm-9-1v6H9V9h2Zm0-4v2H9V5h2Z"
    />
  </svg>
);

export {IcInfoSign};
