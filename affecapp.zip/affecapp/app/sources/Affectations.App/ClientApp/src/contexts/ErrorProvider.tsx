import { createContext, Dispatch, FC, PropsWithChildren, SetStateAction, useState } from 'react';

import { ApiException, IProblemDetails } from '@affectations/api/bff-clients.generated';

export type Error = undefined | IProblemDetails | ApiException;

export type ErrorState = {
  error: Error;
  setError: Dispatch<SetStateAction<Error>>;
};

export const ErrorContext = createContext<ErrorState>({
  error: undefined,
  setError: () => null,
});

export const ErrorProvider: FC<PropsWithChildren> = ({ children }) => {
  const [error, setError] = useState<Error>(undefined);
  return <ErrorContext.Provider value={{ error, setError }}>{children}</ErrorContext.Provider>;
};
