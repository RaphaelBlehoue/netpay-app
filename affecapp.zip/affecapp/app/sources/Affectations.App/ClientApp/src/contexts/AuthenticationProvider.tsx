import { createContext, FC, PropsWithChildren, useCallback, useMemo, useState } from 'react';

import { User } from '@affectations/types/user';
import { FORBIDDEN_PATH, resolveUser } from '@affectations/utils/authentication';
import { ApiException, BffClient } from '@affectations/api/duende-bff-clients.generated';
import { useFetch as httpClient } from '@affectations/lib/fetch-api';

export type AuthenticationState = {
  user?: User;
  isLoading: boolean;
  error?: ApiException;
  fetchUser: () => void;
};
export const AuthenticationContext = createContext<AuthenticationState>({
  user: undefined,
  isLoading: false,
  error: undefined,
  fetchUser: () => {},
});

export const AuthenticationProvider: FC<PropsWithChildren> = ({ children }) => {
  const [user, setUser] = useState<User | undefined>(undefined);
  const [error, setError] = useState<ApiException | undefined>(undefined);
  const [isLoading, setIsLoading] = useState(true);

  const fetchUser = useCallback(async () => {
    const bffClient = new BffClient('', {
      fetch: httpClient(),
    });
    if (location.pathname === FORBIDDEN_PATH) {
      return;
    }
    try {
      const identity = await bffClient.getUserIdentity();
      const resolvedUser = resolveUser(identity);
      setUser(resolvedUser);
    } catch (cachedError) {
      setError(cachedError as ApiException);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const value = useMemo<AuthenticationState>(
    () => ({
      user,
      isLoading,
      error,
      fetchUser,
    }),
    [error, fetchUser, isLoading, user]
  );

  return <AuthenticationContext.Provider value={value}>{children}</AuthenticationContext.Provider>;
};
