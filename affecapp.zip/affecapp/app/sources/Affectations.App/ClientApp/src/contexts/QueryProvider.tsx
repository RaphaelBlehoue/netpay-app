import { FC, PropsWithChildren, useCallback, useMemo } from 'react';
import { MutationCache, QueryCache, QueryClient, QueryClientProvider } from '@tanstack/react-query';

import { useError } from '@affectations/hooks';

const GCTIME_MULTIPLE = 10;
const MINUTE_MULTIPLE = 60;
const MILLISC = 1000;
const MINUTE: number = MILLISC * MINUTE_MULTIPLE;
const PRODUCTION = 'production';

const QueryProvider: FC<PropsWithChildren> = ({ children }) => {
  const isProd: boolean = process.env.NODE_ENV === PRODUCTION;
  const { displayError } = useError();

  const handleErrors = useCallback(
    (error: Error) => {
      displayError(error);
    },
    [displayError]
  );
  const queryClient = useMemo(
    () =>
      new QueryClient({
        queryCache: new QueryCache({
          onError: handleErrors
        }),
        mutationCache: new MutationCache({
          onError: handleErrors
        }),
        defaultOptions: {
          queries: {
            throwOnError: false,
            ...(isProd
              ? {
                  refetchOnWindowFocus: false,
                  gcTime: GCTIME_MULTIPLE * MINUTE,
                  retry: false,
                }
              : {}),
          },
        },
      }),
    [isProd, handleErrors]
  );
  return <QueryClientProvider client={queryClient}>{children}</QueryClientProvider>;
};

export default QueryProvider;
