import { PropsWithChildren, Suspense } from 'react';
import { ReactQueryDevtools } from '@tanstack/react-query-devtools';

import { isDevEnv } from '@affectations/utils';

import { AuthenticationProvider } from './AuthenticationProvider';
import { ErrorProvider } from './ErrorProvider';
import QueryProvider from './QueryProvider';

const AppContextProvider = ({ children }: PropsWithChildren) => {
  return (
    <AuthenticationProvider>
      <ErrorProvider>
        <QueryProvider>
          {children}
          {isDevEnv && (
            <Suspense fallback={null}>
              <ReactQueryDevtools initialIsOpen={false} />
            </Suspense>
          )}
        </QueryProvider>
      </ErrorProvider>
    </AuthenticationProvider>
  );
};

export { AppContextProvider };
