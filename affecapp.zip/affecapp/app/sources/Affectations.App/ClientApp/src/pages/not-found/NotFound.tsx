import Alert from '@axa-fr/react-toolkit-alert';
import { Link } from 'react-router-dom';

import { LeftPrimaryArrow } from '@affectations/components';
import { ContentLayout } from '@affectations/components/layouts/Layout/ContentLayout';

import style from './style.module.scss';

const TITLE_BAR = 'Page Introuvable.';

const NotFound = () => {
  return (
    <ContentLayout titleHead={TITLE_BAR} className={style['not-found-page']}>
      <Alert classModifier="error" title="Erreur : La page que vous recherchez n'existe pas.">
        <p className={style['second-title']}>Vous pouvez retourner à la page d'accueil.</p>
      </Alert>
      <Link to={'/'} className={style.link}>
        <LeftPrimaryArrow />
        <span>Retourner à la page d'accueil.</span>
      </Link>
    </ContentLayout>
  );
};

export default NotFound;
