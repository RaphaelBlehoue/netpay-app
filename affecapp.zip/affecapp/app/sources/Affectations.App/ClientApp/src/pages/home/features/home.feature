Feature: Home Page

  Rule: Footer in Home page

    Scenario: should see in Footer copyright and the default app version
      Given the home page is created
      When I get to the home page
      Then I should see copyright "AXA Tous droits réservés - Version 0.1.0"

    Scenario: should see in Footer copyright and a custom app version
      Given a custom version has been set up to "0.1.0-alpha.27"
      And the home page is created
      When I get to the home page
      Then I should see copyright "Version 0.1.0-alpha.27"

  Rule: Navigation between home page to other page

    Scenario: should see tabs in Page Navigation
      Given the home page is created
      When I get to the home page
      Then I should see tabs Accueil and créer une régle d'affectation

    Scenario: Navigation between Accueil page to créer régle d'affectation page
      Given the home page is created
      When I get to the home page
      Then  I should see the home page display

    Scenario: Navigation between créer régle d'affectation page to  Accueil page
      Given the home page is created
      When I click on tab "creér une régle d'affectation"
      Then I should see the assignment rules creation page displayed
