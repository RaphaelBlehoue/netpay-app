import { renderHook, waitFor } from '@testing-library/react';

import { TRulesQueryParams } from '@affectations/api/rules/types';
import { renderWrapperWithReactQuery } from '@affectations/test-utils';

import { useViewModelConsultationDetail } from '../useViewModelConsultationDetail';
import {
  expectedAssignmentRulesData,
  expectedAssignmentRulesDataOuest,
  expectedAssignmentRulesEmployer,
  expectedAssignmentRulesWithoutRegion,
  expectedRowInfoRulesData,
  expectedWithoutEmployer,
  expectedWithoutUpdateBy,
} from './data.mock';

const setupHook = (params: TRulesQueryParams) => {
  return renderHook(() => useViewModelConsultationDetail(params), {
    wrapper: renderWrapperWithReactQuery(),
  });
};

describe('useViewModelConsultationDetail', () => {
  it('should successfully retrieve all data from the rules consultation', async () => {
    const getRuleByIdParams: TRulesQueryParams = { rulesId: 1 };
    const { result } = setupHook(getRuleByIdParams);

    expect(result.current.isLoading).toBe(true);
    await waitFor(() => expect(result.current.isFetched).toBe(true));
    await waitFor(() => expect(result.current.isSuccess).toBe(true));
    expect(result.current.isLoading).toBe(false);
    expect(result.current.assignmentRulesData()).toEqual(expectedAssignmentRulesDataOuest);
    expect(result.current.rowInfoRulesData()).toStrictEqual(expectedRowInfoRulesData);
  });

  it('should successfully retrieve rules consultation without updateBy', async () => {
    const getRuleByIdParams: TRulesQueryParams = { rulesId: 6 };
    const { result } = setupHook(getRuleByIdParams);

    expect(result.current.isLoading).toBe(true);
    await waitFor(() => expect(result.current.isFetched).toBe(true));
    await waitFor(() => expect(result.current.isSuccess).toBe(true));
    expect(result.current.isLoading).toBe(false);
    expect(result.current.assignmentRulesData()).toEqual(expectedAssignmentRulesData);
    expect(result.current.rowInfoRulesData()).toStrictEqual(expectedWithoutUpdateBy);
  });

  it('should successfully retrieve rules consultation without Employer', async () => {
    const getRuleByIdParams: TRulesQueryParams = { rulesId: 7 };
    const { result } = setupHook(getRuleByIdParams);

    expect(result.current.isLoading).toBe(true);
    await waitFor(() => expect(result.current.isFetched).toBe(true));
    await waitFor(() => expect(result.current.isSuccess).toBe(true));
    expect(result.current.isLoading).toBe(false);
    expect(result.current.assignmentRulesData()).toEqual(expectedAssignmentRulesEmployer);
    expect(result.current.rowInfoRulesData()).toStrictEqual(expectedWithoutEmployer);
  });

  it('should successfully retrieve rules consultation without Region', async () => {
    const getRuleByIdParams: TRulesQueryParams = { rulesId: 8 };
    const { result } = setupHook(getRuleByIdParams);

    expect(result.current.isLoading).toBe(true);
    await waitFor(() => expect(result.current.isFetched).toBe(true));
    await waitFor(() => expect(result.current.isSuccess).toBe(true));
    expect(result.current.isLoading).toBe(false);
    expect(result.current.assignmentRulesData()).toEqual(expectedAssignmentRulesWithoutRegion);
  });
});
