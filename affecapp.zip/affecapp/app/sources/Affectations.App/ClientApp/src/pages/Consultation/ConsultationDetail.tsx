import { useLocation, useParams } from 'react-router-dom';

import { ContentLayout } from '@affectations/components/layouts/Layout/ContentLayout';
import { AlertClassModifiers } from '@affectations/components/ui/Alert';
import { NotificationMessage } from '@affectations/components/ui/NotificationRuleMessage';
import ConfirmationMessage from '@affectations/components/ui/NotificationRuleMessage/ConfirmationMessage';
import { useExportRules } from '@affectations/api/exportRules/useExportRules';
import { TRulesQueryParams } from '@affectations/api/rules/types';
import { AssignmentRule } from '@affectations/features/ConsultationOfTheRules';
import { HeaderInformation } from '@affectations/features/HeaderInformations/HeaderInformation';
import { TermsOfTheWizardRules } from '@affectations/features/TermsOfTheWizardRules';
import { AffectationCreationOrUpdateState } from '@affectations/types';
import { ERROR_MESSAGE, ICON_NAME_ERROR, ICON_NAME_SUCCESS, SINGLE_SUCCESS_MESSAGE } from '@affectations/utils';

import { useViewModelConsultationDetail } from './useViewModelConsultationDetail';
import { handleExportOneRule } from './utils';

const TITLE_BAR = 'Consultation';

const formatParams = (id: string | undefined): TRulesQueryParams => ({
  rulesId: parseInt(id ?? '1'),
});

type TaffectionLocationState = {
  isCreatedOrUpdatedContract: AffectationCreationOrUpdateState;
};

const ConsultationDetail = () => {
  const { rulesId } = useParams();
  const params: TRulesQueryParams = formatParams(rulesId);
  const { termsOfRulesData, assignmentRulesData, rowInfoRulesData, isSuccess, isLoading } =
    useViewModelConsultationDetail(params);
  const { mutate: exportMutation, isSuccess: isExportSucess, isError } = useExportRules();

  const termsOfTheWizardRules = termsOfRulesData();
  const assigmentRules = assignmentRulesData();
  const headerInfos = rowInfoRulesData();
  const location = useLocation();
  const locationState = location.state as TaffectionLocationState | null;
  const currentDate = headerInfos.rowHeaderData.createDate ?? '';
  const currentStatus = headerInfos.rowHeaderData.status ?? '';
  return (
    <ContentLayout titleHead={TITLE_BAR}>
      <article className="content-wrap" aria-label="consultation detail page">
        {isSuccess && (
          <>
            {locationState?.isCreatedOrUpdatedContract && (
              <ConfirmationMessage status={currentStatus} creationDate={currentDate} />
            )}
            {isExportSucess && <NotificationMessage message={SINGLE_SUCCESS_MESSAGE} iconName={ICON_NAME_SUCCESS} />}
            {isError && (
              <NotificationMessage
                message={ERROR_MESSAGE}
                status={AlertClassModifiers.Error}
                iconName={ICON_NAME_ERROR}
              />
            )}
            <HeaderInformation
              rowHeaderMapping={headerInfos.rowHeaderData}
              rowRulesMapping={headerInfos.rowRulesData}
              isLoading={isLoading}
              isSuccess={isSuccess}
              sectionTitle="Informations générales"
              ruleId={params}
              mutationExportFn={exportMutation}
              handleRuleExport={handleExportOneRule}
            />
            <TermsOfTheWizardRules
              rulesMapping={termsOfTheWizardRules}
              isLoading={isLoading}
              isSuccess={isSuccess}
              sectionTitle="Modalités de la règle"
            />
            <AssignmentRule
              assigmentRulesMapping={assigmentRules}
              isLoading={isLoading}
              isSuccess={isSuccess}
              sectionTitle="Affectation"
            />
          </>
        )}
      </article>
    </ContentLayout>
  );
};

export default ConsultationDetail;
