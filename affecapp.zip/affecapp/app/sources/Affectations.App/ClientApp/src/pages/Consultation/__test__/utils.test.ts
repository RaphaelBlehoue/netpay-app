import { getStatusConsultation } from '../utils';

describe('getStatusConsultation', () => {
  it.each`
    startDate                | endDate                  | status         | expected
    ${`2024-01-01T23:00:00`} | ${`2024-04-01T23:00:00`} | ${`Active`}    | ${`Expirée`}
    ${`2024-01-01T23:00:00`} | ${`2024-05-01T22:00:00`} | ${`Active`}    | ${`Active`}
    ${`2024-01-01T23:00:00`} | ${`2024-05-01T22:00:00`} | ${`Active`}    | ${`Active`}
    ${`2024-01-01T23:00:00`} | ${`2024-05-01T20:00:00`} | ${`brouillon`} | ${`Brouillon`}
    ${`2024-01-01T23:00:00`} | ${`2024-04-01T21:00:00`} | ${`Brouillon`} | ${`Expirée`}
    ${`2024-01-01T23:00:00`} | ${`2024-07-01T23:00:00`} | ${`active`}    | ${`Active`}
    ${`2024-08-01T23:00:00`} | ${`2024-09-01T23:00:00`} | ${`active`}    | ${`Active`}
    ${`2024-02-01T23:00:00`} | ${null}                  | ${`active`}    | ${`Active`}
    ${`2024-01-01T23:00:00`} | ${null}                  | ${`Active`}    | ${`Active`}
    ${`2024-08-01T23:00:00`} | ${null}                  | ${`active`}    | ${`Active`}
    ${`2024-08-02T23:00:00`} | ${null}                  | ${`Active`}    | ${`Active`}
    ${`2024-01-01T23:00:00`} | ${null}                  | ${`Brouillon`} | ${`Brouillon`}
    ${`2024-01-02T23:00:00`} | ${null}                  | ${`brouillon`} | ${`Brouillon`}
    ${`2024-07-02T23:00:00`} | ${null}                  | ${`Brouillon`} | ${`Brouillon`}
    ${`2024-08-04T23:00:00`} | ${null}                  | ${`brouillon`} | ${`Brouillon`}
  `('returns $expected when $startDate, $endDate with the $status', ({ startDate, endDate, status, expected }) => {
    const today = new Date('2024-05-01T23:00:00');
    vi.useFakeTimers();
    vi.setSystemTime(today);
    const inputExpected = getStatusConsultation(startDate, endDate, status);
    expect(inputExpected.statusLabel).toBe(expected);
  });

  afterEach(() => {
    vi.clearAllTimers();
  });
});
