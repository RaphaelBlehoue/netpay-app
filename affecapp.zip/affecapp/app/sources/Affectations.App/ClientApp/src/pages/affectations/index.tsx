export { default } from './affectations';
