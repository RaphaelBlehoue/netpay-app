Feature: consultation Page

  Rule: Navigation to consultation page

    Scenario: Navigation vers la page consultation
      Given je demande a voir la page de consultation
      When la page a bien chargé les données
      Then  je dois voir afficher le titre de la page "consultation"

