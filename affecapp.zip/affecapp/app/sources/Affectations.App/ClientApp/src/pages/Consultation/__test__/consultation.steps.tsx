import { screen, waitFor } from '@testing-library/react';
import { defineFeature, loadFeature } from 'jest-cucumber';

import { MainLayout } from '@affectations/components/layouts/Layout/MainLayout';
import { AppContextProvider } from '@affectations/contexts/AppContextProvider';
import { CONSULTATION_RULE_ID_DETAIL } from '@affectations/routes/configRoute';
import { renderMemoryRouter } from '@affectations/test-utils';

import ConsultationDetail from '../ConsultationDetail';

const feature = loadFeature('../features/consultation.feature');

defineFeature(feature, test => {
  test('Navigation vers la page consultation', ({ given, when, then }) => {
    const initialEntries: string[] = [CONSULTATION_RULE_ID_DETAIL];
    given(/^je demande a voir la page de consultation$/, () => {
      renderMemoryRouter(
        <AppContextProvider>
          <MainLayout>
            <ConsultationDetail />
          </MainLayout>
        </AppContextProvider>,
        { initialEntries }
      );
    });

    when(/^la page a bien chargé les données$/, async () => {
      await waitFor(() => screen.getByRole('article', { name: /consultation detail page/i }));
    });

    then(/^je dois voir afficher le titre de la page "(.*)"$/, async (_title: string) => {
      const consultationPageTitle = screen.getByRole('heading', { level: 1, name: /Consultation/i });
      expect(consultationPageTitle).toBeInTheDocument();
    });
  });
});
