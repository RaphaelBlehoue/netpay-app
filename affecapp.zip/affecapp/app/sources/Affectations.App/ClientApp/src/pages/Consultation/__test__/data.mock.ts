const CREATE_CONTENT = 'Crée par Olivier SAILLY, le 01/01/2023 à 09h05';
const CREATE_DATE = new Date('2023-01-01T09:05:12.000Z').toISOString();
const LABEL_EQUIPE = 'Affecter à l\'équipe';
const LABEL_COLLABORATEUR = 'Affecter au collaborateur';
const LABEL_REGION = 'Région d\'affectation';
const CONTENT_COMMENT = '27/02/023 - Rajout par numcnt (ancienne QP)';
const DATE_DEBUT = 'Date de début';
const DATE_FIN = 'Date de fin';

const expectedAssignmentRulesDataOuest = [
  {
    content: 'ES_AUTO_NE',
    label: LABEL_EQUIPE,
  },
  {
    content: 'BONTEMS PATRICK (S123456)',
    label: LABEL_COLLABORATEUR,
  },
  {
    content: 'OUEST',
    label: LABEL_REGION,
  },
  {
    content: CONTENT_COMMENT,
    label: 'Commentaire',
  },
];

const expectedAssignmentRulesData = [
  {
    content: 'ES_AUTO_NE',
    label: LABEL_EQUIPE,
  },
  {
    content: 'BONTEMS PATRICK (S123456)',
    label: LABEL_COLLABORATEUR,
  },
  {
    content: 'NORD EST',
    label: LABEL_REGION,
  },
  {
    content: CONTENT_COMMENT,
    label: 'Commentaire',
  },
];

const expectedAssignmentRulesEmployer = [
  {
    content: 'ES_AUTO_NE',
    label: LABEL_EQUIPE,
  },
  {
    content: '',
    label: LABEL_COLLABORATEUR,
  },
  {
    content: 'SUD EST',
    label: LABEL_REGION,
  },
  {
    content: CONTENT_COMMENT,
    label: 'Commentaire',
  },
];


const expectedAssignmentRulesWithoutRegion = [
  {
    content: 'ES_AUTO_NE',
    label: LABEL_EQUIPE,
  },
  {
    content: '',
    label: LABEL_COLLABORATEUR,
  },
  {
    content: 'NE',
    label: LABEL_REGION,
  },
  {
    content: CONTENT_COMMENT,
    label: 'Commentaire',
  },
];

const expectedRowInfoRulesData = {
  rowHeaderData: {
    badgeStatus: 'error',
    createContent: CREATE_CONTENT,
    createDate: CREATE_DATE,
    status: 'Expirée',
    title: 'Remplacement de Mélanie',
    updateContent: 'Mise à jour par Jérôme CAGNONCLE, le 01/03/2023 à 10h55',
  },
  rowRulesData: [
    {
      content: '01/01/2024',
      label: DATE_DEBUT,
    },
    {
      content: '11/02/2024',
      label: DATE_FIN,
    },
  ],
};

const expectedWithoutUpdateBy = {
  rowHeaderData: {
    badgeStatus: 'danger',
    createContent: CREATE_CONTENT,
    createDate: CREATE_DATE,
    status: 'Brouillon',
    title: null,
    updateContent: '',
  },
  rowRulesData: [
    {
      content: '',
      label: DATE_DEBUT,
    },
    {
      content: '',
      label: DATE_FIN,
    },
  ],
};

const expectedWithoutEmployer = {
  rowHeaderData: {
    badgeStatus: 'danger',
    createContent: CREATE_CONTENT,
    createDate: CREATE_DATE,
    status: 'Brouillon',
    title: null,
    updateContent: '',
  },
  rowRulesData: [
    {
      content: '',
      label: DATE_DEBUT,
    },
    {
      content: '',
      label: DATE_FIN,
    },
  ],
};

export {
  expectedAssignmentRulesData,
  expectedAssignmentRulesEmployer,
  expectedWithoutEmployer,
  expectedRowInfoRulesData,
  expectedWithoutUpdateBy,
  expectedAssignmentRulesWithoutRegion,
  expectedAssignmentRulesDataOuest
};
