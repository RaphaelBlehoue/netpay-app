import { act, render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { defineFeature, DefineStepFunction, loadFeature } from 'jest-cucumber';
import { createMemoryRouter } from 'react-router-dom';

import { AppContextProvider } from '@affectations/contexts/AppContextProvider';
import { Router } from '@affectations/Router';
import { configRoutes } from '@affectations/routes';

let user = userEvent.setup();

const feature = loadFeature('../features/NotFound.feature');

const givenIOpenThisPage = (given: DefineStepFunction) =>
  given("J'accède à une page inexistante", async () => {
    global.window.location.href = '/not-found';
    await act(async () => {
      render(<Router router={createMemoryRouter(configRoutes, { initialEntries: ['/not-found'] })} />, {
        wrapper: AppContextProvider,
      });
    });
  });

const thenThisMsgIsVisible = (then: DefineStepFunction) => {
  then(/Je vois le message "(.*)"/i, async (msg: string) => {
    const msgElt = await screen.findByText(msg);
    expect(msgElt).toBeInTheDocument();
  });
};

const thenThisCTAIsVisible = (then: DefineStepFunction) => {
  then(/Le CTA "(.*)" est visible/i, async (name: string) => {
    const cta = await screen.findByRole('link', { name });
    expect(cta).toBeInTheDocument();
  });
};

const WhenIClickOnCTA = (then: DefineStepFunction) => {
  then(/Je clique sur le CTA "(.*)"/i, async (name: string) => {
    const cta = await screen.findByRole('link', { name });
    await user.click(cta);
  });
};

defineFeature(feature, test => {
  beforeEach(() => {
    user = userEvent.setup();
  });
  test('Erreur 404', ({ given, then, and }) => {
    givenIOpenThisPage(given);
    thenThisMsgIsVisible(then);
    thenThisCTAIsVisible(and);
  });
  test("L'utlisateur clique sur Retourner à la page d'accueil", ({ given, when, then }) => {
    givenIOpenThisPage(given);
    WhenIClickOnCTA(when);
    then("Je suis redirigé sur la page d'accueil", () => {
      const title = screen.getByRole('heading', { level: 1, name: /Accueil/i });
      expect(title).toBeInTheDocument();
    });
  });
});
