import { IRuleCriterionCategory } from '@affectations/api/bff-clients.generated';
import { useCreateRules } from '@affectations/api/createRules/useCreateRules';
import { useEmployeeSearch } from '@affectations/api/employees';
import { useGetRulesCriteria } from '@affectations/api/rulesCriteria/useGetRulesCriteria';
import { useGetTeams } from '@affectations/api/teams/useGetTeams';
import { MULTI_SELECT_VALUE_CRITERIA } from '@affectations/features/TermsOfTheWizardRules/utils';
import { useMemo } from 'react';

const useModelAffectationRules = () => {
  const { data: criterias, isError, error, isLoading: isCriteriaLoading, isFetched, isSuccess } = useGetRulesCriteria();
  const { data: teams, isLoading: isTeamsLoading } = useGetTeams();
  const { mutate: createRules } = useCreateRules();
  const { findEmployees: searchEmployees, error: EmployeeError } = useEmployeeSearch();


  const isLoading = isCriteriaLoading && isTeamsLoading;

  const multiSelectionOptions = MULTI_SELECT_VALUE_CRITERIA.reduce<Record<string, IRuleCriterionCategory>>(
    (acc, current: string) => {
      const currentCriteria = criterias?.[current] || {};
      acc[current] = currentCriteria;
      return acc;
    }, {} as Record<string, IRuleCriterionCategory>);

  const teamsOption = useMemo(() => {
    if (!teams) {
      return [];
    }
    return teams.map(current => ({
      label: current.code ?? '',
      value: current.name ?? ''
    }));
  }, [teams]);
  return {
    criterias,
    multiSelectionOptions,
    teamsOption,
    teams,
    createRules,
    searchEmployees,
    EmployeeError,
    isError,
    isLoading,
    isSuccess,
    error,
    isFetched
  };
};

export { useModelAffectationRules };

