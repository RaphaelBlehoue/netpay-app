import { CriterionDto, IAffectationDto } from '@affectations/api/bff-clients.generated';
import { STATIC_CRITERIA } from '@affectations/features/TermsOfTheWizardRules/utils';
import {
  IAffectationFormInputs,
  IRuleCreationDto,
  IRuleDetailsCreationDto,
  TCriteria,
  TFieldArray,
  TRulesValue,
} from '@affectations/types';
import { parseISO } from 'date-fns';
import { FormEvent } from 'react';


const REQUIRED_FIELD_VALUE_MESSAGE = 'Veuillez renseigner une valeur.';
export const REQUIRED_FIELD_CONDITION_MESSAGE = 'Veuillez renseigner une condition.';
const REQUIRED_FIELD_AFF_TEAM = 'Ce champs est obligatoire';
const REQUIRED_FIELD_AFF_COL = 'Aucun résultat.';
const REQUIRED_FIELD_AFF_COL_KO = 'Le référentiel n\'est pas disponible actuellement.';
const FORMAT_FIELD_MESSAGE = 'Le format a respecter est : "xxxxxxx"';
const FORMAT_ACCOUNT_FIELD_MESSAGE = 'Veuillez respecter le format de 7 caractères maximum commençant par "S"';
const NUMBER_16 = 16;
const NUMBER_10 = 10;
const NUMBER_7 = 7;
const NUMBER_6 = 6;
const NUMBER_5 = 5;

const PLACEHOLDER_CONDITION = 'Selectionner';


export const BUTTON_TITLE = {
  active: 'Activer la règle',
  brouillon: 'Enregistrer en brouillon'
};

export const stopPropagate = (callback: (event: FormEvent<HTMLFormElement>) => void) => {
  return (e: FormEvent<HTMLFormElement>) => {
    e.stopPropagation();
    callback(e);
  };
};

export const getKeyByValue = (obj: Record<string, string>, value: string) => {
  for (const [key, val] of Object.entries(obj)) {
    if (val === value) {
      return key;
    }
  }
  return Object.keys(BUTTON_TITLE)[0];
};

const getLabel = (currentValue: string) => {
  const current = STATIC_CRITERIA.find((item, _index) => item.value === currentValue);
  return current && current.label;
};

const rulesDetail = (input: IAffectationFormInputs): IRuleDetailsCreationDto => {
  const startDate = parseISO(input.startDate.toISOString());
  const inputEndDate = input.endDate;
  const endDate = inputEndDate ? parseISO(inputEndDate.toISOString()) : undefined;
  return {
    ruleName: input.name ?? undefined,
    statut: input.status ?? Object.keys(BUTTON_TITLE)[0],
    ...(input.endDate ? { endDate } : undefined),
    ...(input.startDate ? { startDate } : undefined),
    comment: input.comment ?? '',
  };
};

const affectation = (input: IAffectationFormInputs): IAffectationDto => {
  let collaboratorName: string | undefined;
  if (input.collaborater) {
    const tempCollaborator = input.collaborater.label.split('-');
    collaboratorName = tempCollaborator[0]?.trim();
  }
  return {
    ...(collaboratorName ? { affectedEmployee: collaboratorName } : undefined),
    affectedTeam: input.teams,
    affectedRegion: input.regions,
    affectedEmployeeId: input.collaborater?.value,
  };
};

const rulesData = (input: IAffectationFormInputs): TRulesValue => {
  return input.modalities.reduce((acc: TRulesValue, modality: TFieldArray) => {
    const condition = modality.condition;
    const criteria = getLabel(modality.criteria) ?? modality.criteria;
    let inValues: Array<string> = [];
    if (Array.isArray(modality.rules)) {
      inValues = modality.rules.map(rule => rule.value);
    } else if (typeof modality.rules === 'string') {
      inValues.push(modality.rules);
    } else {
      inValues.push(modality.rules.value);
    }
    acc[criteria] = {
      condition,
      values: inValues
    } as CriterionDto;
    return acc;
  }, {});
};

export const transformDataInputToOutput = (input: IAffectationFormInputs): IRuleCreationDto => {
  const ruleDetailsDto: IRuleDetailsCreationDto = rulesDetail(input);
  const affectationDto: IAffectationDto = affectation(input);
  const rules: TRulesValue = rulesData(input);

  return {
    ruleDetailsDto,
    affectationDto,
    rules
  };
};


const renderMessageFormat = (numberFormat: number) => ({
  value: numberFormat,
  message: `Le format a respecter est : ${numberFormat} caractères maximum`
});

const isEqualNumber = (value: string) => {
  const numberRegex = /^\d+$/;
  return numberRegex.test(value) || 'Seuls les caractères numériques sont acceptés.';
};

const isEqualNaf = (value: string) => {
  const nafRegex = /\b\d{3}[A-Z012]\d{3}\b/;
  return nafRegex.test(value) || FORMAT_FIELD_MESSAGE;
};

const isEqualFormatClient = (value: string) => {
  const clientRegex = new RegExp(/^S\d{6}$/);
  return clientRegex.test(value) || FORMAT_ACCOUNT_FIELD_MESSAGE;
};

const hasNotSelectedValue = (value: string) => {
  return value !== PLACEHOLDER_CONDITION || REQUIRED_FIELD_CONDITION_MESSAGE;
};

export const affectationFormSchema = {
  'TEAM': {
    required: REQUIRED_FIELD_AFF_TEAM
  },
  'COLLABORATEUR': {
    required: REQUIRED_FIELD_AFF_COL
  },
  'COLLABORATEUR_KO': {
    required: REQUIRED_FIELD_AFF_COL_KO
  },
};

export const affectationConditionFormSchema = {
  'DEFAULT': {
    required: REQUIRED_FIELD_CONDITION_MESSAGE,
    validate: hasNotSelectedValue
  }
};

export const affectationValueFormSchema = {
  'DEFAULT': {
    required: REQUIRED_FIELD_VALUE_MESSAGE
  },
  'CODE_NAF': {
    required: REQUIRED_FIELD_VALUE_MESSAGE,
    minLength: renderMessageFormat(NUMBER_7),
    validate: isEqualNaf
  },
  'CODE_SYNDIC': {
    required: REQUIRED_FIELD_VALUE_MESSAGE,
    minLength: renderMessageFormat(NUMBER_5)
  },
  'AXAPAC': {
    required: REQUIRED_FIELD_VALUE_MESSAGE,
    minLength: renderMessageFormat(NUMBER_10),
    validate: isEqualNumber
  },
  'ACCOUNT_MANAGER': {
    required: REQUIRED_FIELD_VALUE_MESSAGE,
    minLength: renderMessageFormat(NUMBER_7),
    validate: isEqualFormatClient
  },
  'CONTRACT_NUMBER': {
    required: REQUIRED_FIELD_VALUE_MESSAGE,
    minLength: renderMessageFormat(NUMBER_16),
  },
  'CODE_PORTEFEUILLE': {
    required: REQUIRED_FIELD_VALUE_MESSAGE,
  },
  'UVCODE': {
    required: REQUIRED_FIELD_VALUE_MESSAGE,
    minLength: renderMessageFormat(NUMBER_5),
    validate: isEqualNumber
  },
  'CLAUSE': {
    required: REQUIRED_FIELD_VALUE_MESSAGE,
    minLength: renderMessageFormat(NUMBER_6),
  },
  'INTERMEDIARY_NAME': {
    required: REQUIRED_FIELD_VALUE_MESSAGE
  }
};

export const setFormValueValidation = (currenState: TCriteria | undefined) => {
  switch (currenState) {
    case 'CODE_NAF':
      return {
        validatedRules: affectationValueFormSchema.CODE_NAF,
        maxChar: NUMBER_7
      };
    case 'AXAPAC':
      return {
        validatedRules: affectationValueFormSchema.AXAPAC,
        maxChar: NUMBER_10
      };
    case 'CODE_SYNDIC':
      return {
        validatedRules: affectationValueFormSchema.CODE_SYNDIC,
        maxChar: NUMBER_5
      };
    case 'ACCOUNT_MANAGER':
      return {
        validatedRules: affectationValueFormSchema.ACCOUNT_MANAGER,
        maxChar: NUMBER_7
      };
    case 'CONTRACT_NUMBER':
      return {
        validatedRules: affectationValueFormSchema.CONTRACT_NUMBER,
        maxChar: NUMBER_16
      };
    case 'CODE_PORTEFEUILLE':
      return {
        validatedRules: affectationValueFormSchema.CODE_PORTEFEUILLE,
        maxChar: NUMBER_10
      };
    case 'UVCODE':
      return {
        validatedRules: affectationValueFormSchema.UVCODE,
        maxChar: NUMBER_5
      };
    case 'CLAUSE':
      return {
        validatedRules: affectationValueFormSchema.CLAUSE,
        maxChar: NUMBER_6
      };
    case 'INTERMEDIARY_NAME':
      return {
        validatedRules: affectationValueFormSchema.INTERMEDIARY_NAME,
        maxChar: 0
      };
    default:
      return {};
  }
};
