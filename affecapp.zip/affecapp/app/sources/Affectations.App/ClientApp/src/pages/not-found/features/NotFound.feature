Feature: Page introuvable

    Scenario: Erreur 404
        Given J'accède à une page inexistante
        Then Je vois le message "Erreur : La page que vous recherchez n'existe pas."
        And Le CTA "Retourner à la page d'accueil." est visible

    Scenario: L'utlisateur clique sur Retourner à la page d'accueil
        Given J'accède à une page inexistante
        When Je clique sur le CTA "Retourner à la page d'accueil."
        Then Je suis redirigé sur la page d'accueil