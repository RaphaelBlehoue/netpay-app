export { default } from './ConsultationDetail';
