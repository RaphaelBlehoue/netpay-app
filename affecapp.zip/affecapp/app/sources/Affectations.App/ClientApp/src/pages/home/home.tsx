import { ContentLayout } from '@affectations/components/layouts/Layout/ContentLayout';
import RuleFilters from '@affectations/features/RuleFilters';

import './home.scss';

import { useCallback, useLayoutEffect, useMemo, useState } from 'react';

import { AlertClassModifiers } from '@affectations/components/ui/Alert';
import { NotificationMessage } from '@affectations/components/ui/NotificationRuleMessage';
import { toTableRules } from '@affectations/utils/rules';
import {
  AffectationDto,
  ConditionsDto,
  CriteresDto,
  IRuleDto,
  RuleDetailsDto,
  RuleDto,
} from '@affectations/api/bff-clients.generated';
import { searchEmployees } from '@affectations/api/employees';
import { useExportRules } from '@affectations/api/exportRules/useExportRules';
import { useSearchRule } from '@affectations/api/rules/useSearchRule';
import { useGetRulesCriteria } from '@affectations/api/rulesCriteria/useGetRulesCriteria';
import { useGetTeams } from '@affectations/api/teams/useGetTeams';
import { RuleDataTable, Rules } from '@affectations/features/RuleDataTable';
import { FilterFields } from '@affectations/features/RuleFilters/RuleFilters';
import { ERROR_MESSAGE, ICON_NAME_ERROR, ICON_NAME_SUCCESS, SUCCESS_MESSAGE } from '@affectations/utils';

const TITLE_BAR = 'Accueil';
const DEFAULT_PAGE_SIZE = 25;

const defaultCriteria = new RuleDto({
  ruleDetailsDto: new RuleDetailsDto(),
  affectationDto: new AffectationDto(),
  conditionsDto: new ConditionsDto(),
  critereDto: new CriteresDto(),
});

const Home = () => {
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [itemsPerPage, setItemsPerPage] = useState(DEFAULT_PAGE_SIZE);
  const [globalFilterCriteria, setGlobalFilterCriteria] = useState<RuleDto>(defaultCriteria);

  const { isLoading, data } = useSearchRule(currentPage, itemsPerPage, globalFilterCriteria);
  const rules = useMemo<Rules>(() => toTableRules(data?.data), [data]);
  const { data: rulesCriterias, isLoading: isRulesCriteriaLoading } = useGetRulesCriteria();
  const { data: teams, isLoading: isTeamsLoading } = useGetTeams();
  const { mutate: exportMutation, isSuccess, isError } = useExportRules();

  const handleSubmit = useCallback((formData: IRuleDto) => {
    setCurrentPage(1);
    setGlobalFilterCriteria(new RuleDto(formData));
  }, []);

  const criteriaToFormFields = useCallback(
    (name: string) => {
      if (!rulesCriterias) {
        return [];
      }
      return rulesCriterias[name]?.ruleCriteria?.map(x => ({
        label: x.label ?? '',
        value: x.code ?? '',
        isSelected: false,
      }));
    },
    [rulesCriterias]
  );
  const filterFields = useMemo<FilterFields | undefined>(() => {
    if (!rulesCriterias || isRulesCriteriaLoading || !teams || isTeamsLoading) {
      return undefined;
    }
    return {
      affectationRegions: criteriaToFormFields('ASSIGNMENT_REGION'),
      affectationTeams: teams.map(x => ({ label: x.name ?? '', value: x.code ?? '', isSelected: false })),
      segmentations: criteriaToFormFields('SEGMENTATION'),
      branches: criteriaToFormFields('BRANCH'),
      networks: criteriaToFormFields('NETWORKS'),
      regionDistributions: criteriaToFormFields('DISTRIBUTION_REGION'),
      departmentDistributions: criteriaToFormFields('DISTRIBUTION_DEPARTMENT'),
      ruleStatus: [
        { label: 'Active', value: 'active', isSelected: false },
        { label: 'Brouillon', value: 'brouillon', isSelected: false },
        { label: 'Expirée', value: 'expirée', isSelected: false },
      ],
    };
  }, [criteriaToFormFields, isRulesCriteriaLoading, isTeamsLoading, rulesCriterias, teams]);

  const handlePageChange = useCallback((size: number) => {
    setCurrentPage(1);
    setItemsPerPage(size);
  }, []);

  useLayoutEffect(() => {
    const scrollToTop = () => {
      if (document.documentElement.scrollTo) {
        document.documentElement.scrollTo({ top: 0, left: 0, behavior: 'instant' });
      } else {
        window.scrollTo(0, 0);
      }
    };
    scrollToTop();
  }, [isSuccess, isError]);

  return (
    <ContentLayout titleHead={TITLE_BAR}>
      <article className="content-wrap" aria-label="home page">
        {isSuccess && <NotificationMessage message={SUCCESS_MESSAGE} iconName={ICON_NAME_SUCCESS} />}
        {isError && (
          <NotificationMessage message={ERROR_MESSAGE} status={AlertClassModifiers.Error} iconName={ICON_NAME_ERROR} />
        )}
        {filterFields && (
          <RuleFilters onSubmit={handleSubmit} criterias={filterFields} filterCollaboratorsAsync={searchEmployees} />
        )}
        <RuleDataTable
          currentPage={currentPage}
          numberPages={data?.totalPages ?? 0}
          itemsPerPage={itemsPerPage}
          data={rules}
          count={data?.totalData}
          isLoading={isLoading}
          onPageSizeChange={handlePageChange}
          onPageChange={setCurrentPage}
          currentFilterState={globalFilterCriteria}
          mutationExportFn={exportMutation}
        />
      </article>
    </ContentLayout>
  );
};
export default Home;
