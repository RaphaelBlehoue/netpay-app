import { SubmitHandler, useForm } from 'react-hook-form';

import { useStateMutation } from '@affectations/hooks/useStateMutation';
import { Button, Loader } from '@affectations/components';
import { ContentLayout } from '@affectations/components/layouts/Layout/ContentLayout';
import { ButtonClassModifiers } from '@affectations/components/ui/Button/types';
import { useModelAffectationRules } from '@affectations/pages/affectations/useViewModelAffectationRules';
import { RuleCreationDto } from '@affectations/api/bff-clients.generated';
import { AffectionRules } from '@affectations/features/AffectationRules';
import { GeneralInformationRules } from '@affectations/features/GeneralInformationRules';
import { AddTermsOfTheWizardRules } from '@affectations/features/TermsOfTheWizardRules';
import { INIT_MODALITIES } from '@affectations/features/TermsOfTheWizardRules/utils';
import { IAffectationFormInputs } from '@affectations/types';

import { BUTTON_TITLE, transformDataInputToOutput } from './utils';

import './affectation.scss';

import { useState } from 'react';

const TITLE_BAR = "Créer une règle d'affectation";
const BROUILLON_BUTTON_ID = 'brouillon';
const ACTIVE_BUTTON_ID = 'active';

const Affectation = () => {
  const {
    control,
    setValue,
    getValues,
    reset,
    watch,
    trigger,
    handleSubmit,
    setError,
    clearErrors,
    resetField,
    formState: { errors, isValid },
  } = useForm<IAffectationFormInputs>({
    defaultValues: INIT_MODALITIES,
    shouldUseNativeValidation: false,
    mode: 'all',
  });
  const { multiSelectionOptions, isLoading, isSuccess, teamsOption, teams, createRules, searchEmployees } =
    useModelAffectationRules();
  const [isSaveButton, setIsSaveButton] = useState<boolean>(false);
  const [isDraftButton, setIsDraftButton] = useState<boolean>(false);
  const { isMutating } = useStateMutation();

  const isNotError = Object.keys(errors).length === 0;

  const onSubmitForm: SubmitHandler<IAffectationFormInputs> = data => {
    if (isNotError && isValid) {
      const dataForm = transformDataInputToOutput(data) as RuleCreationDto;
      createRules(dataForm);
    } else {
      setError && setError('collaborater', { type: 'noMatch', message: 'Aucun resultat' });
    }
  };

  const onSaveAsDraft: SubmitHandler<IAffectationFormInputs> = data => {
    const newData: IAffectationFormInputs = {
      status: Object.keys(BUTTON_TITLE)[1],
      ...data,
    };
    onSubmitForm(newData);
  };

  const saveDraftOnSubmit = async () => {
    setIsDraftButton(true);
    await handleSubmit(onSaveAsDraft)();
  };

  const saveActiveOnSubmit = async () => {
    setIsSaveButton(true);
    await handleSubmit(onSubmitForm)();
  };

  return (
    <ContentLayout titleHead={TITLE_BAR} className="content-wrap">
      <Loader isLoading={isLoading}>
        {isSuccess && (
          <form noValidate>
            <article className="content-wrap" aria-label="Créer une règle d'affectation">
              <GeneralInformationRules control={control} watch={watch} trigger={trigger} />
              <AddTermsOfTheWizardRules
                control={control}
                reset={reset}
                watch={watch}
                setValue={setValue}
                getValues={getValues}
                maxline={16}
                AllCriteriaOptions={multiSelectionOptions}
              />
              <AffectionRules
                control={control}
                filterEmployeeAsync={searchEmployees}
                teamsOptions={teamsOption}
                teams={teams || []}
                watch={watch}
                setValue={setValue}
                errors={errors}
                setError={setError}
                clearErrors={clearErrors}
                resetField={resetField}
              />
            </article>
            <div className="button-container">
              <Button
                title={isMutating && isDraftButton ? 'Chargement...' : BUTTON_TITLE.brouillon}
                name="brouillon"
                classModifiers={[ButtonClassModifiers.Reverse]}
                type="submit"
                id={BROUILLON_BUTTON_ID}
                onClick={saveDraftOnSubmit}
                disabled={isMutating}
              />
              <Button
                title={isMutating && isSaveButton ? 'Chargement...' : BUTTON_TITLE.active}
                type="submit"
                name="active"
                id={ACTIVE_BUTTON_ID}
                onClick={saveActiveOnSubmit}
                classModifiers={[ButtonClassModifiers.Sucess]}
                disabled={isMutating}
              />
            </div>
          </form>
        )}
      </Loader>
    </ContentLayout>
  );
};

export default Affectation;
