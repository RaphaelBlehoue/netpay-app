import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { defineFeature, loadFeature } from 'jest-cucumber';
import { act } from 'react-dom/test-utils';
import { createMemoryRouter } from 'react-router-dom';

import { MainLayout } from '@affectations/components/layouts/Layout/MainLayout';
import Affectation from '@affectations/pages/affectations';
import Home from '@affectations/pages/home';
import { AppContextProvider } from '@affectations/contexts/AppContextProvider';
import { Router } from '@affectations/Router';
import { configRoutes } from '@affectations/routes';
import { AFFECTATION_BASE_URL, HOME_BASE_URL, ROOT_BASE_URL } from '@affectations/routes/configRoute';
import { renderMemoryRouter } from '@affectations/test-utils';

const feature = loadFeature('../features/home.feature');

defineFeature(feature, test => {
  test('should see in Footer copyright and the default app version', ({ given, when, then }) => {
    given('the home page is created', () => {});

    when('I get to the home page', () => {
      const initialEntries: string[] = [ROOT_BASE_URL];
      render(<Router router={createMemoryRouter(configRoutes, { initialEntries })} />, {
        wrapper: AppContextProvider,
      });
    });

    then(/^I should see copyright "(.*)"$/, async _copyright => {
      const customCopyRight = await waitFor(() => screen.getByText(/axa tous droits réservés/i));
      expect(customCopyRight).toBeInTheDocument();
      expect(customCopyRight).toHaveTextContent(_copyright);
    });
  });

  test('should see in Footer copyright and a custom app version', ({ given, when, then }) => {
    given(/^a custom version has been set up to "(.*)"$/, (version: string) => {
      vi.stubGlobal('APP_VERSION', version);
    });

    given('the home page is created', () => {});

    when('I get to the home page', () => {
      const initialEntries: string[] = [ROOT_BASE_URL];
      render(<Router router={createMemoryRouter(configRoutes, { initialEntries })} />, {
        wrapper: AppContextProvider,
      });
    });

    then(/^I should see copyright "(.*)"$/, async _copyright => {
      const customCopyRight = await waitFor(() => screen.getByText(/axa tous droits réservés/i));
      expect(customCopyRight).toBeInTheDocument();
      expect(customCopyRight).toHaveTextContent(_copyright);
    });
  });

  test('should see tabs in Page Navigation', ({ given, when, then }) => {
    const initialEntries: string[] = [HOME_BASE_URL];
    given('the home page is created', () => {
      renderMemoryRouter(
        <AppContextProvider>
          <MainLayout>
            <Home />
          </MainLayout>
        </AppContextProvider>,
        { initialEntries }
      );
    });

    when('I get to the home page', async () => {
      const title = await waitFor(() => screen.getByRole('heading', { level: 1, name: /Accueil/i }));
      expect(title).toBeInTheDocument();
    });

    then(/^I should see tabs Accueil and créer une régle d'affectation$/, (_tabAccueil, _tabAffectation) => {
      expect(screen.getByRole('link', { name: /accueil/i })).toBeInTheDocument();
      expect(
        screen.getByRole('link', {
          name: /créer une règle d'affectation/i,
        })
      ).toBeInTheDocument();
    });
  });

  test("Navigation between Accueil page to créer régle d'affectation page", ({ given, when, then }) => {
    const initialEntries: string[] = [HOME_BASE_URL];
    given('the home page is created', () => {
      renderMemoryRouter(
        <AppContextProvider>
          <MainLayout>
            <Home />
          </MainLayout>
        </AppContextProvider>,
        { initialEntries }
      );
    });

    when(/^I get to the home page$/, async () => {
      await waitFor(() => screen.getByRole('heading', { level: 1, name: /Accueil/i }));
    });

    then(/^I should see the home page display$/, async () => {
      const homePageContentElem = screen.getByRole('article', { name: /home page/i });
      expect(homePageContentElem).toBeInTheDocument();
    });
  });

  test("Navigation between créer régle d'affectation page to  Accueil page", ({ given, when, then }) => {
    const initialEntries: string[] = [HOME_BASE_URL, AFFECTATION_BASE_URL];
    given('the home page is created', () => {
      renderMemoryRouter(
        <AppContextProvider>
          <MainLayout>
            <Affectation />
          </MainLayout>
        </AppContextProvider>,
        { initialEntries }
      );
    });

    when(/^I click on tab "(.*)"$/, async _tabAffectation => {
      const link = await waitFor(() =>
        screen.getByRole('link', {
          name: /créer une règle d'affectation/i,
        })
      );
      act(() => fireEvent.click(link));
    });

    then(/^I should see the assignment rules creation page displayed$/, async () => {
      const affectionPageContentElem = await waitFor(() =>
        screen.getByRole('article', { name: /Créer une règle d'affectation/ })
      );
      expect(affectionPageContentElem).toBeInTheDocument();
    });
  });
});
