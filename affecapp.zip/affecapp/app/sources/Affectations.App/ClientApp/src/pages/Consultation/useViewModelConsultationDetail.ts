import { BadgeClassModifiers, BadgeStatusName } from '@affectations/components/ui/Badge/types';
import { Column } from '@affectations/components/ui/Table/utils';
import { TRulesQueryParams } from '@affectations/api/rules/types';
import { useGetRulesById } from '@affectations/api/rules/useGetRulesByIdRules';
import { rowHeaderType, rowRulesType } from '@affectations/features/commonTypes';
import {
  formatterModality,
  HeaderDataType,
  TtermsOfRulesData,
} from '@affectations/features/TermsOfTheWizardRules/utils';
import { capitalize, DateFormats, formatDate } from '@affectations/utils';

import { getStatusConsultation } from './utils';
import { regionList } from '@affectations/features/AffectationRules/utils';

export const headerColums: Column<HeaderDataType>[] = [
  { title: 'Critères', key: 'criteres' },
  { title: 'Conditions', key: 'conditions' },
  { title: 'Valeur(s)', key: 'valeur' },
];

//const TIME_ZONE_DEFAULT_HOURS;

interface IRowInfoRulesData {
  rowHeaderData: rowHeaderType;
  rowRulesData: rowRulesType[];
}

type TStatus = {
  status: BadgeClassModifiers;
  statusLabel: BadgeStatusName;
};

const useViewModelConsultationDetail = (params: TRulesQueryParams) => {
  const { data: rules, isSuccess, isLoading, isError, error, isFetched } = useGetRulesById(params);

  const termsOfRulesData = (): TtermsOfRulesData => {
    const rowsData = formatterModality(rules);

    return {
      columns: headerColums,
      modalityData: rowsData,
    };
  };

  const assignmentRulesData = (): rowRulesType[] => {
    const employeName = rules?.affectationDto?.affectedEmployee?.toUpperCase() ?? '';
    const employeId = rules?.affectationDto?.affectedEmployeeId ?? '';
    const affectedEmployee = employeName !== '' ? `${employeName} (${employeId})` : '';
    const region = rules?.affectationDto?.affectedRegion;
    const currentRegion = region ? regionList[region] : 'NE';
    const affectedRegion = currentRegion?.toUpperCase();
    const teams = rules?.affectationDto?.affectedTeam ?? '';

    return [
      {
        label: "Affecter à l'équipe",
        content: teams,
      },
      {
        label: 'Affecter au collaborateur',
        content: affectedEmployee,
      },
      {
        label: "Région d'affectation",
        content: affectedRegion,
      },
      {
        label: 'Commentaire',
        content: rules?.ruleDetailsDto?.comment,
      },
    ];
  };

  const rowInfoRulesData = (): IRowInfoRulesData => {
    const setEndDate: Date | undefined = rules?.ruleDetailsDto?.endDate;
    const setStartDate: Date | undefined = rules?.ruleDetailsDto?.startDate;
    const setUpdateDate: Date | undefined = rules?.ruleDetailsDto?.updateDate;
    const setStatus: string | undefined = rules?.ruleDetailsDto?.statut;

    const status: TStatus = getStatusConsultation(setStartDate, setEndDate, setStatus);

    const createDate = formatDate(rules?.ruleDetailsDto?.creationDate, DateFormats.DATE_TIME);
    const tempDate = rules?.ruleDetailsDto?.creationDate;
    tempDate?.setHours(tempDate.getHours());
    const date = tempDate?.toISOString();
    const updateDate = setUpdateDate !== undefined ? formatDate(setUpdateDate, DateFormats.DATE_TIME) : '';
    const updateBy = rules?.ruleDetailsDto?.updatedBy;
    const createBy = rules?.ruleDetailsDto?.createdBy;
    const createByContent =
      createBy !== undefined ? `Crée par ${rules?.ruleDetailsDto?.createdBy}, le ${createDate}` : '';
    const updadeByContent =
      updateDate.toString().length && !!updateBy ? `Mise à jour par ${updateBy}, le ${updateDate}` : '';
    const startDate = formatDate(setStartDate, DateFormats.DATE);
    const endDate = setEndDate ? formatDate(setEndDate, DateFormats.DATE) : '';

    const rowHeaderData: rowHeaderType = {
      title: rules?.ruleDetailsDto?.ruleName,
      createContent: createByContent,
      updateContent: updadeByContent,
      badgeStatus: status.status,
      status: capitalize(status.statusLabel) as BadgeStatusName,
      createDate: date,
    };

    const rowRulesData: rowRulesType[] = [
      {
        label: 'Date de début',
        content: startDate,
      },
      {
        label: 'Date de fin',
        content: endDate,
      },
    ];

    return {
      rowHeaderData,
      rowRulesData,
    };
  };

  return {
    isLoading,
    isSuccess,
    isError,
    isFetched,
    error,
    termsOfRulesData,
    assignmentRulesData,
    rowInfoRulesData,
  };
};

export { useViewModelConsultationDetail };
