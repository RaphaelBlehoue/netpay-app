import { IAffectationFormInputs, IRuleCreationDto } from '@affectations/types';
const DATE_START = new Date('2024-05-08T00:00:00.000Z');
const DATE_END = new Date('2024-05-22T00:00:00.000Z');
export const inputWithAffectation: IAffectationFormInputs = {
  modalities: [
    {
      criteria: 'BRANCH',
      condition: 'est parmi',
      rules: [
        {
          label: 'Auto',
          value: 'Auto',
        },
      ],
    },
    {
      criteria: 'DISTRIBUTION_REGION',
      condition: 'est parmi',
      rules: [
        {
          label: 'DOM TOM',
          value: '13',
        },
        {
          label: 'Ile de France',
          value: '64',
        },
      ],
    },
    {
      criteria: 'SEGMENTATION',
      condition: 'est parmi',
      rules: [
        {
          label: 'ES',
          value: 'ES',
        },
      ],
    },
  ],
  name: '',
  startDate: DATE_START,
  endDate: DATE_END,
  teams: 'ES_IDL',
  collaborater: {
    label: 'AXA',
    value: 'AXA FR',
  },
  regions: '',
  comment: '',
  status: 'active',
};
export const inputMissingAffectation: IAffectationFormInputs = {
  modalities: [
    {
      criteria: 'BRANCH',
      condition: 'est parmi',
      rules: [
        {
          label: 'Auto',
          value: 'Auto',
        },
      ],
    },
    {
      criteria: 'DISTRIBUTION_REGION',
      condition: 'est parmi',
      rules: [
        {
          label: 'DOM TOM',
          value: '13',
        },
        {
          label: 'Ile de France',
          value: '64',
        },
      ],
    },
    {
      criteria: 'SEGMENTATION',
      condition: 'est parmi',
      rules: [
        {
          label: 'ES',
          value: 'ES',
        },
      ],
    },
  ],
  name: '',
  startDate: DATE_START,
  endDate: DATE_END,
};
export const expectedOutpout: IRuleCreationDto = {
  ruleDetailsDto: {
    ruleName: '',
    statut: 'active',
    startDate: DATE_START,
    endDate: DATE_END,
    comment: '',
  },
  affectationDto: {
    affectedTeam: 'ES_IDL',
    affectedRegion: '',
    affectedEmployee: 'AXA',
    affectedEmployeeId: 'AXA FR'
  },
  rules: {
    Branche: {
      condition: 'est parmi',
      values: ['Auto'],
    },
    'Région distributeur': {
      condition: 'est parmi',
      values: ['13', '64'],
    },
    Segmentation: {
      condition: 'est parmi',
      values: ['ES'],
    },
  },
};
export const expectedMissingOutpout: IRuleCreationDto = {
  ruleDetailsDto: {
    ruleName: '',
    statut: 'active',
    startDate: DATE_START,
    endDate: DATE_END,
    comment: '',
  },
  affectationDto: {
    affectedEmployeeId: undefined,
    affectedRegion: undefined,
    affectedTeam: undefined,
  },
  rules: {
    Branche: {
      condition: 'est parmi',
      values: ['Auto'],
    },
    'Région distributeur': {
      condition: 'est parmi',
      values: ['13', '64'],
    },
    Segmentation: {
      condition: 'est parmi',
      values: ['ES'],
    },
  },
};
