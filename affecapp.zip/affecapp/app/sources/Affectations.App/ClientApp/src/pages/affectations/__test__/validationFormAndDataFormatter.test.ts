import { transformDataInputToOutput } from '../utils/validationFormAndDataFormatter';
import { IAffectationFormInputs, IRuleCreationDto } from '@affectations/types';
import { expectedMissingOutpout, expectedOutpout, inputMissingAffectation, inputWithAffectation } from './data.mock';
describe('validationFormAndDataFormatter', () => {
  it('should return completed output with all formdata', async () => {
    const expectInput: IAffectationFormInputs = inputWithAffectation;
    const expectedOutput: IRuleCreationDto = expectedOutpout;
    expect(transformDataInputToOutput(expectInput)).toEqual(expectedOutput);
  });
  it('should return output with missign affectation section formdata', async () => {
    const expectInput: IAffectationFormInputs = inputMissingAffectation;
    const expectedOutput: IRuleCreationDto = expectedMissingOutpout;
    expect(transformDataInputToOutput(expectInput)).toEqual(expectedOutput);
  });
});
