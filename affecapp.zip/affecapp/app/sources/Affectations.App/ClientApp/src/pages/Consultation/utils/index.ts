import { UseMutateFunction } from '@tanstack/react-query';
import { isAfter, isBefore, isSameDay } from 'date-fns';

import {
  AffectationDto,
  ConditionsDto,
  CriteresDto,
  FileResponse,
  FilterRuleDto,
  RuleDetailsDto,
} from '@affectations/api/bff-clients.generated';
import { TRulesQueryParams } from '@affectations/api/rules/types';
import { TError } from '@affectations/api/types';

import { BadgeClassModifiers, BadgeStatusName } from '@affectations/components/ui/Badge/types';
import { DateFormats, capitalize, formatDate } from '@affectations/utils';

export type TStatus = {
  status: BadgeClassModifiers;
  statusLabel: BadgeStatusName;
};

type TStatusComposition = {
  ACTIVE: TStatus;
  DRAFT: TStatus;
  EXPIRED: TStatus;
};

export const statusComposition: TStatusComposition = {
  ACTIVE: {
    status: BadgeClassModifiers.Sucess,
    statusLabel: BadgeStatusName.Sucess,
  },
  DRAFT: {
    status: BadgeClassModifiers.Danger,
    statusLabel: BadgeStatusName.Danger,
  },
  EXPIRED: {
    status: BadgeClassModifiers.Error,
    statusLabel: BadgeStatusName.Error,
  },
};

const getRenderStatus = (inputStatus?: string): TStatus => {
  let defaultStatus: string | undefined = inputStatus ?? BadgeStatusName.Danger;
  defaultStatus = capitalize(defaultStatus.toLowerCase());
  if (defaultStatus !== BadgeStatusName.Danger) {
    return statusComposition.ACTIVE;
  }
  return statusComposition.DRAFT;
};

const formatDateForStatus = (date: Date | undefined): Date | null => {
  const temp = date ? formatDate(date, DateFormats.DATE_BD) : null;
  return temp ? new Date(temp) : null;
};

const getDateFormatted = (
  inputStartDate: Date | undefined,
  inputEndDate?: Date | undefined,
): {
  startDate: Date | null;
  endDate: Date | null;
} => {
  const tempStartDate = inputStartDate ? new Date(inputStartDate) : null;
  const tempEndDate = inputEndDate ? new Date(inputEndDate) : null;
  return {
    startDate: tempStartDate ? formatDateForStatus(tempStartDate) : null,
    endDate: tempEndDate ? formatDateForStatus(tempEndDate) : null
  };
};

const getStatusConsultation = (
  inputStartDate: Date | undefined,
  inputEndDate?: Date | undefined,
  inputStatus?: string
): TStatus => {
  const currentStatus = getRenderStatus(inputStatus);
  const { startDate, endDate } = getDateFormatted(inputStartDate, inputEndDate);
  const tempCurrentDate = formatDate(new Date(), DateFormats.DATE_BD);
  const currentDate = new Date(tempCurrentDate);

  if (endDate && isAfter(currentDate, endDate)) {
    return statusComposition.EXPIRED;
  }

  if (endDate && isSameDay(currentDate, endDate)) {
    return currentStatus;
  }

  if (
    startDate &&
    (isSameDay(currentDate, startDate) || isAfter(currentDate, startDate) || isBefore(currentDate, startDate))
  ) {
    return currentStatus;
  }

  return statusComposition.DRAFT;
};

export { getStatusConsultation };

export const handleExportOneRule = (
  rule: TRulesQueryParams,
  mutationExportFn: UseMutateFunction<FileResponse, TError, FilterRuleDto>
): void => {
  const filterParams = new FilterRuleDto({
    ids: [rule.rulesId],
    affectationDto: new AffectationDto(),
    conditionsDto: new ConditionsDto(),
    critereDto: new CriteresDto(),
    ruleDetailsDto: new RuleDetailsDto(),
  });
  mutationExportFn(filterParams);
};

