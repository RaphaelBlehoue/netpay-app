import React from 'react';
import ReactDOM from 'react-dom/client';

import { App } from '@affectations/components/layouts/App';
import { initializeApp } from '@affectations/lib/initializeApp';

if (process.env.NODE_ENV !== 'production') {
  const { default: axe } = await import('@axe-core/react');
  axe(React, ReactDOM, 1000);
}

async function init() {
  await initializeApp();
  ReactDOM.createRoot(document.getElementById('root')!).render(
    <React.StrictMode>
      <App />
    </React.StrictMode>
  );
}

init();
