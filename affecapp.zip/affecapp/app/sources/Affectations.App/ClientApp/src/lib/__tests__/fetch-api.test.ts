import { server } from '@affectations/mocks/server';
import { Methods, StatusCodes } from '@affectations/utils/http';
import { HttpResponse, Path, http } from 'msw';
import { setGlobalOrigin } from 'undici';
import { useFetch } from '../fetch-api';


describe('useFetch should', () => {
  const anyPath = `/api/any`;
  const featureHeaderName = 'axa-feature';
  const correlationHeaderName = 'axa-correlation-id';
  const csrfHeaderName = 'x-csrf';

  let wrappedFetch: ReturnType<typeof useFetch>;
  let actualRequest: Request;

  const mockApiCall = (path: Path, method: keyof typeof http = 'all') => {
    server.use(
      http[method](path, ({ request }) => {
        actualRequest = request;
        return HttpResponse.json({}, { status: StatusCodes.OK });
      }),
    );
  };

  beforeEach(() => {
    setGlobalOrigin(window.location.origin);
    wrappedFetch = useFetch();
    mockApiCall(anyPath);
  });

  afterEach(() => {
    setGlobalOrigin(undefined);
  });

  it('append a "x-csrf" header to generate a request for cross-origin calls', async () => {
    const expectedValue = '1';

    await wrappedFetch(anyPath, { method: Methods.GET });

    expect(actualRequest.headers.get(csrfHeaderName)).toStrictEqual(expectedValue);
  });

  it('append a "axa-correlation-id" header to enhance observability', async () => {
    const guidRegex = /^[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}$/i;

    await wrappedFetch(anyPath, { method: Methods.GET });

    expect(actualRequest.headers.get(correlationHeaderName)).toMatch(guidRegex);
  });

  it('append a "axa-feature" header to enhance observability', async () => {
    const featureValueRegex = /^id=[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12},name=[\w:-]+$/i;

    await wrappedFetch(anyPath, { method: Methods.GET });
    expect(actualRequest.headers.get(featureHeaderName)).toMatch(featureValueRegex);
  });

  it('have extensible headers', async () => {
    const anyOtherHeaderName = 'any-other';
    const anyOtherHeaderValue = 'any other value';

    await wrappedFetch(anyPath, { method: Methods.GET, headers: { [anyOtherHeaderName]: anyOtherHeaderValue } });

    expect(actualRequest.headers.get(anyOtherHeaderName)).toStrictEqual(anyOtherHeaderValue);
  });

  it('persist the current session id accross calls', async () => {
    const anotherPath = `${anyPath}/2`;
    const featureValueRegex = /^id=(?<sessionId>[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}),name=[\w-]+$/i;
    mockApiCall(anotherPath);

    await wrappedFetch(anyPath, { method: Methods.GET });
    const initialId = featureValueRegex.exec(actualRequest.headers.get(featureHeaderName) as string)?.groups?.sessionId;
    await wrappedFetch(anotherPath, { method: Methods.POST });
    const lastId = featureValueRegex.exec(actualRequest.headers.get(featureHeaderName) as string)?.groups?.sessionId;

    expect(initialId).toStrictEqual(lastId);
  });

  it.each`
    input
    ${anyPath}
    ${new URL(`http://localhost:3000${anyPath}`)}
    ${new Request(new URL(`http://localhost:3000${anyPath}`))}
  `('generate a feature name regardless of the provided object', async ({ input }) => {
    const featureValueRegex = /^id=[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12},name=get-api-any$/i;

    await wrappedFetch(input, { method: Methods.GET });

    expect(actualRequest.headers.get(featureHeaderName)).toMatch(featureValueRegex);
  });

  it.each`
    method                          | path                        | expectedFeature
    ${Methods.GET.toLowerCase()}    | ${`/super/api/call/one`}    | ${`get-super-api-call-one`}
    ${Methods.POST.toLowerCase()}   | ${`/super/api/call/two`}    | ${`post-super-api-call-two`}
    ${Methods.PUT.toLowerCase()}    | ${`/super/api/call/three/`} | ${`put-super-api-call-three`}
    ${Methods.PATCH.toLowerCase()}  | ${`/super/api/call/four`}   | ${`patch-super-api-call-four`}
    ${Methods.DELETE.toLowerCase()} | ${`/super/api/call/five`}   | ${`delete-super-api-call-five`}
  `(
    'generate a feature name using the pathname and the method ($method $path should generate $expectedFeature)',
    async ({ method, path, expectedFeature }) => {
      const featureValueRegex = new RegExp(
        `^id=[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12},name=${expectedFeature}$`,
        'i',
      );
      mockApiCall(path, method);

      await wrappedFetch(path, {
        method,
      });
      expect(actualRequest.headers.get(featureHeaderName)).toMatch(featureValueRegex);
    },
  );
});
