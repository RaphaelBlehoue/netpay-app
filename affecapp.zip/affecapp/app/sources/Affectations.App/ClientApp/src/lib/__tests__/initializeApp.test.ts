import { initializeApp } from '@affectations/lib/initializeApp';
import { NoProdEnv } from '@affectations/utils';

const startMock = vi.fn();
vi.mock('@affectations/mocks/browser', () => ({
  worker: {
    start: startMock,
  },
}));

describe('initializeApp', () => {
  afterEach(() => {
    vi.resetAllMocks();
    vi.unstubAllEnvs();
  });

  it('should start with mockserver in mock env', async () => {
    vi.stubEnv('NODE_ENV', NoProdEnv.MOCKENV);
    await initializeApp();
    expect(startMock).toHaveBeenCalled();
  });

  it('should not start mockserver in development env', async () => {
    vi.stubEnv('NODE_ENV', NoProdEnv.DEVENV);
    await initializeApp();
    expect(startMock).toHaveBeenCalled();
  });

  it('should not start mockserver in production env', async () => {
    vi.stubEnv('NODE_ENV', 'production');

    const response = await initializeApp();

    expect(response).toBeFalsy();
    expect(startMock).not.toHaveBeenCalled();
  });
});
