import { vi } from 'vitest';

describe('should return queryClient configuration', () => {
  afterEach(() => {
    vi.unstubAllEnvs();
  });

  it('production env', async () => {
    // Arrange
    vi.stubEnv('NODE_ENV', 'production');
    const { getQueryClient } = await import('../react-query');
    const config = {
      gcTime: 600000,
      refetchOnWindowFocus: false,
      retry: false,
      throwOnError: true
    };

    // Act
    // Assert

    expect(getQueryClient).toBeDefined();
    expect(getQueryClient().getDefaultOptions()).toStrictEqual({
      queries: config
    });
  });

  it('testing env', async () => {
    // Arrange
    vi.stubEnv('NODE_ENV', 'test');
    const { getQueryClient } = await import('../react-query');
    const mockConfig = {
      throwOnError: true
    };
    // Act

    // Assert
    expect(getQueryClient).toBeDefined();
    expect(getQueryClient().getDefaultOptions()).toStrictEqual({
      queries: mockConfig
    });
  });

});
