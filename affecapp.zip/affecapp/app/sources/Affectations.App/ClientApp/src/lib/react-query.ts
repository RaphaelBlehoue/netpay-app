import { QueryClient, QueryClientConfig } from '@tanstack/react-query';

const GCTIME_MULTIPLE = 10;
const MINUTE_MULTIPLE = 60;
const MILLISC = 1000;
const MINUTE: number = MILLISC * MINUTE_MULTIPLE;
const PRODUCTION = 'production';
export const getQueryClient = (): QueryClient => {
  const isProd: boolean = process.env.NODE_ENV === PRODUCTION;
  const queryClient: QueryClientConfig = {
    defaultOptions: {
      queries: {
        throwOnError: true,
        ...(isProd ? {
          refetchOnWindowFocus: false,
          gcTime: GCTIME_MULTIPLE * MINUTE,
          retry: false
        } : {})
      },
    }
  };
  return new QueryClient(queryClient);
};
