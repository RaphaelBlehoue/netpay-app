import { Methods } from '@affectations/utils/http';
import { v4 } from 'uuid';

const AXA_SESSION_ID = 'axa-session-id';

type Trequest = RequestInfo | URL;


const getOrCreateSessionId = (): string => {
  let uniqueSessionId = sessionStorage.getItem(AXA_SESSION_ID) as string;
  if (!uniqueSessionId) {
    uniqueSessionId = v4();
    sessionStorage.setItem(AXA_SESSION_ID, uniqueSessionId);
  }
  return uniqueSessionId;
};

const formatAxaFeature = (sessionId: string, featureName: string) => `id=${sessionId},name=${featureName}`;

const computeFeatureName = (input: Trequest, method: string | Methods = Methods.GET) => {
  let route: string;
  if (typeof input === 'string') {
    route = input;
  } else if (input instanceof Request) {
    route = new URL(input.url).pathname;
  } else {
    route = input.pathname;
  }

  const sanitizedRoute = route
    .replace(/^\/+|\/+$/g, '')
    .replace(/\//g, '-')
    .replace(/\d+/g, 'xxx');
  return `${method}-${sanitizedRoute}`.toLowerCase();
};

//error management with react-query

export function useFetch() {
  return (input: Trequest, params: RequestInit) => {
    const correlationId = v4();
    const sessionId = getOrCreateSessionId();
    return fetch(input, {
      ...params,
      headers: {
        ...params?.headers,
        'x-csrf': '1',
        'axa-correlation-id': correlationId,
        'axa-feature': formatAxaFeature(sessionId, computeFeatureName(input, params.method)),
      },
    });
  };
}
