const MOCKENV = 'mock';
const DEV = 'development';
const ListEnv = [DEV, MOCKENV];
async function deferRender(): Promise<ServiceWorkerRegistration | undefined | boolean> {

  if (process.env.NODE_ENV && !ListEnv.includes(process.env.NODE_ENV)) {
    return false;
  }
  const { worker } = await import('@affectations/mocks/browser');
  return worker.start();
}

export async function initializeApp() {
  await deferRender();
}
