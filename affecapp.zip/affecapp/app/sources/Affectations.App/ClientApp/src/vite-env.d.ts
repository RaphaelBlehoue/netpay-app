/// <reference types="vite/client" />
/// <reference types="./types/svg.d.ts"/>
interface ImportMetaEnv {
  readonly VITE_APP_MOCKED: boolean,
  readonly MODE: 'mock' | 'development' | 'production' | 'test',
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}

declare const APP_VERSION: string;
