//https://vitejs.dev/guide/features.html#client-types

declare module '*.svg' {
  import * as React from 'react';
  const ReactComponent: React.FunctionComponent<React.ComponentProps<'svg'> & {
    title?: string
  }>;
  export default ReactComponent;
}
