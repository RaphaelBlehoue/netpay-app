import { IAffectationDto, ICriterionDto } from '@affectations/api/bff-clients.generated';

export type TRule = {
  label: string;
  value: string;
};

export type TAutoCompleteData = {
  code: string;
  label: string;
};

export enum AffectationCreationOrUpdateState {
  Created = 'Created',
  Updated = 'Updated',
}


export type TFieldArray = {
  criteria: string;
  condition: string;
  rules: TRule[] | TRule | string;
};

export interface IAffectationFormInputs {
  startDate: Date;
  endDate?: Date;
  name?: string;
  modalities: TFieldArray[];
  teams?: string;
  collaborater?: TRule;
  comment?: string;
  status?: string;
  creationDate?: string;
  updateDate?: Date;
  regions?: string;
}

export interface ILineCardContractBody {
  description: string;
  value: number;
  link?: string;
  tooltip?: string;
};

export enum MessageTypes {
  error = 'error',
  success = 'success',
  warning = 'warning',
}

export type TFormInput = {
  name?: string;
  value?: string;
  id?: string;
};

export type TCriteria =
  | 'BRANCH'
  | 'DISTRIBUTION_REGION'
  | 'SEGMENTATION'
  | 'CLAUSE'
  | 'INTERMEDIARY_NAME'
  | 'NETWORKS'
  | 'DISTRIBUTION_DEPARTMENT'
  | 'QP_CONTRACT_CATEGORY'
  | 'UVCODE'
  | 'AXAPAC'
  | 'ACCOUNT_MANAGER'
  | 'CONTRACT_NUMBER'
  | 'COPHT'
  | 'CODE_NAF'
  | 'CODE_SYNDIC'
  | 'CODE_PORTEFEUILLE';

export type IRuleDetailsCreationDto = {
  ruleName?: string | undefined;
  statut?: string | undefined;
  startDate?: Date | undefined;
  endDate?: Date | undefined;
  comment?: string | undefined;
};

export type TRulesValue = Record<string, ICriterionDto>;

export type IRuleCreationDto = {
  ruleDetailsDto?: IRuleDetailsCreationDto | undefined;
  affectationDto?: IAffectationDto | undefined;
  rules?: TRulesValue;
};
