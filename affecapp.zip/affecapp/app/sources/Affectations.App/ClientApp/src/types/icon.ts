import { SVGProps } from 'react';

export type ISVGElement = { size?: number | string } & SVGProps<SVGSVGElement>;
