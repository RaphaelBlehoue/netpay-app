import { IClaim } from '@affectations/api/duende-bff-clients.generated';

export enum UserClaimType {
  Sid = 'sid',
  AxaType = 'axa_type',
  Racf = 'axa_uid_racf',
  Roles = 'http://schemas.microsoft.com/ws/2008/06/identity/claims/role',
  GivenName = 'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/givenname',
  Surname = 'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/surname',
  Name = 'name',
}

export type User = {
  readonly sid: string;
  readonly axaType?: string;
  readonly racf?: string;
  readonly roles?: string[];
  readonly givenName?: string;
  readonly surname?: string;
  readonly name?: string;
  readonly rawClaims: IClaim;
  get hasRole(): boolean;
};
