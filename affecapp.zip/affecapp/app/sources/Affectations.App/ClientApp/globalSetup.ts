module.exports = async () => {
  process.env.TZ = 'Europe/paris';
};
