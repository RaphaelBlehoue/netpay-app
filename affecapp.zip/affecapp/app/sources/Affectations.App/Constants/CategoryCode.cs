namespace Affectations.App.Constants;

public static class CategoryCode
{
    public const string BRANCH = "BRANCH";
    public const string DISTRIBUTION_REGION = "DISTRIBUTION_REGION";
    public const string SEGMENTATION = "SEGMENTATION";
    public const string NETWORKS = "NETWORKS";
    public const string DISTRIBUTION_DEPARTMENT = "DISTRIBUTION_DEPARTMENT";
    public const string QP_CONTRACT_CATEGORY = "QP_CONTRACT_CATEGORY";
}
