namespace Affectations.App.Constants;

public static class CriteriaNames
{
    public const string ContractNumber = "N° contrat";
    public const string AccountManager = "Chargé de clientèle";
    public const string ClientNumber = "N° client AXAPAC";
    public const string NafCode = "Code NAF";
    public const string SyndicCode = "Code Syndic";
    public const string Clause = "Clause";
    public const string Portfolio = "Code portefeuille";
    public const string IntermediateName = "Nom intermédiaire";
    public const string UVCode = "Code UV";
    public const string Copht = "COPHT (€)";
    public const string Department = "Départment distributeur";
    public const string Network = "Réseaux";
    public const string Region = "Région distributeur";
    public const string Branch = "Branche";
    public const string Segmentation = "Segmentation";
    public const string ContractCategory = "Catégorie contrat QP";
}
