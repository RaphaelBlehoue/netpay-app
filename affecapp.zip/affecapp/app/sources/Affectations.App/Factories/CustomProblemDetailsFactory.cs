using AxaFrance.E2ELogging;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace Affectations.App.Factories;

public class CustomProblemDetailsFactory : ProblemDetailsFactory
{
    public override ProblemDetails CreateProblemDetails(
        HttpContext httpContext,
        int? statusCode = null,
        string? title = null,
        string? type = null,
        string? detail = null,
        string? instance = null
    )
    {
        var problemDetail = new ProblemDetails
        {
            Detail = detail,
            Instance = instance,
            Status = statusCode,
            Title = title,
            Type = type
        };

        if (httpContext != null)
        {
            var correlationContextAccessor =
                httpContext.RequestServices.GetRequiredService<ICorrelationContextAccessor>();
            problemDetail.Extensions.Add("correlation-id", correlationContextAccessor.CorrelationContext.CorrelationId);
        }

        return problemDetail;
    }

    public override ValidationProblemDetails CreateValidationProblemDetails(
        HttpContext httpContext,
        ModelStateDictionary modelStateDictionary,
        int? statusCode = null,
        string? title = null,
        string? type = null,
        string? detail = null,
        string? instance = null
    )
    {
        var validationProblemDetails = new ValidationProblemDetails(modelStateDictionary);

        if (httpContext != null)
        {
            var correlationContextAccessor =
                httpContext.RequestServices.GetRequiredService<ICorrelationContextAccessor>();
            validationProblemDetails.Extensions.Add(
                "correlation-id",
                correlationContextAccessor.CorrelationContext.CorrelationId
            );
        }
        return validationProblemDetails;
    }
}
