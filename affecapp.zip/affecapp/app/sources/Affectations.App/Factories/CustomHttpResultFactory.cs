using System.Net;
using Affectations.Domain.Exceptions;

namespace Affectations.App.Factories;

public static class CustomHttpResultFactory
{
    public static IResult CreateHttpResult(HttpContext httpContext, RuleNotFoundException ruleException)
    {
        if (ruleException?.HttpStatusCode == (int)HttpStatusCode.NotFound)
        {
            return Results.NotFound(
                new CustomProblemDetailsFactory().CreateProblemDetails(
                    httpContext,
                    ruleException?.HttpStatusCode,
                    detail: ruleException?.Message
                )
            );
        }

        return Results.BadRequest(
            new CustomProblemDetailsFactory().CreateProblemDetails(
                httpContext,
                (int)HttpStatusCode.BadRequest,
                detail: ruleException?.Message
            )
        );
    }
}
