namespace Affectations.App.Factories;

public enum RuleErrorType
{
    InvalidRuleError,
    RuleNotFoundError
}
