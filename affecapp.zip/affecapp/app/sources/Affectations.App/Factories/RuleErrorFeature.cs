namespace Affectations.App.Factories;

public class RuleErrorFeature
{
    public RuleErrorType RuleError { get; set; }
}
