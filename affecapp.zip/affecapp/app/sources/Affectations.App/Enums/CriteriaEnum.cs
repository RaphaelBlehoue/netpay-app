namespace Affectations.App.Enums;

public enum CriteriaEnum
{
    ContractNumber,
    AccountManager,
    ClientNumber,
    NafCode,
    SyndicCode,
    Clause,
    Portfolio,
    IntermediateName,
    UVCode,
    Copht,
    Department,
    Network,
    Region,
    Branch,
    Segmentation,
    ContractCategory
}
