﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Affectations.App.Tests")]
