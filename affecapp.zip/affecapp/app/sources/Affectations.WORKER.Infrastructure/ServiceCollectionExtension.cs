using Affectations.WORKER.Infrastructure.Data.Models;
using AxaFrance.E2ELogging;
using AxaFrance.ProductMonitoring;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Serilog;
using Log = Serilog.Log;

namespace Affectations.WORKER.Infrastructure;

public static class ServiceCollectionExtension
{
    public static void ConfigureInfrastructureServices(this IServiceCollection services, IConfiguration configuration)
    {
        ConfigureLogging(services, configuration);

        services.AddDbContext<AffectationsContext>(
            options =>
            {
                var connectionString = configuration.GetSection("ConnectionStrings")["affectationsdb"];
                options.UseSqlServer(connectionString);
                options.EnableDetailedErrors();
                options.UseQueryTrackingBehavior(QueryTrackingBehavior.TrackAll);
                options.LogTo(Log.Logger.Information, LogLevel.Information);
            },
            ServiceLifetime.Singleton
        );
    }

    private static void ConfigureLogging(IServiceCollection services, IConfiguration configuration)
    {
        services.AddLogging();
        services.AddE2ELogging();
        services.AddProductMonitoring(configuration.GetSection("ProductMonitoring").Bind);
        Log.Logger = new LoggerConfiguration().ReadFrom.Configuration(configuration).CreateLogger();
        services.AddSerilog(Log.Logger, true);
    }
}
