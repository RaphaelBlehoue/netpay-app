﻿using System;
using System.Collections.Generic;

namespace Affectations.WORKER.Infrastructure.Data.Models;

public partial class TTeam
{
    public string Code { get; set; } = null!;

    public string Name { get; set; } = null!;
}
