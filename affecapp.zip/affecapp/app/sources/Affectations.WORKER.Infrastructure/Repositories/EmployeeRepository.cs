using Affectations.WORKER.Core.Entities;
using Affectations.WORKER.Core.Exceptions;
using Affectations.WORKER.Core.Repositories;
using Affectations.WORKER.Infrastructure.Data.Models;
using Microsoft.Extensions.Logging;

namespace Affectations.WORKER.Infrastructure.Repositories;

public class EmployeeRepository : IEmployeeRepository
{
    private readonly AffectationsContext _affectationsContext;
    private readonly ILogger<IEmployeeRepository> _logger;

    public EmployeeRepository(AffectationsContext affectationsContext, ILogger<IEmployeeRepository> logger)
    {
        _affectationsContext = affectationsContext;
        _logger = logger;
    }

    public async Task AddEmployeeAsync(Employee employee)
    {
        await CheckEmployeeExistence(employee);

        var employeeEntity = new TEmployee
        {
            Id = employee.Id,
            LastName = employee.LastName,
            FirstName = employee.FirstName
        };
        await _affectationsContext.TEmployees.AddAsync(employeeEntity);
        await _affectationsContext.SaveChangesAsync();
    }

    private async Task CheckEmployeeExistence(Employee employee)
    {
        var existingEmployee = await _affectationsContext.TEmployees.FindAsync(employee.Id);
        if (existingEmployee != null)
        {
            throw new EmployeeExistsException("L'employé existe déjà.");
        }
    }
}
