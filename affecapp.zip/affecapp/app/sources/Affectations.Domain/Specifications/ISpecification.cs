namespace Affectations.Domain.Specifications;

public interface ISpecification { }
