namespace Affectations.Domain.Models;

public class PagedData<T>
{
    public IEnumerable<T> Data { get; set; } = Enumerable.Empty<T>();
    public int TotalPages { get; set; }
    public int Page { get; set; }
    public long Size { get; set; }
    public long TotalData { get; set; }
}
