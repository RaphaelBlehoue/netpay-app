namespace Affectations.Domain.Models;

public record CriteriaModel
{
    public string? Segmentation { get; set; }
    public string? DistributorRegion { get; set; }
    public string? Network { get; set; }
    public string? Branch { get; set; }
    public decimal? Copht { get; init; }
    public string? DistributorDepartment { get; set; }
    public string? ContractCategory { get; set; }
    public string? UVCode { get; init; }
    public string? IntermediateName { get; init; }
    public string? PortfolioCode { get; init; }
    public string? Clause { get; init; }
    public string? SyndicCode { get; init; }
    public string? NafCode { get; init; }
    public string? ClientNumber { get; init; }
    public string? AccountManager { get; init; }
    public string? ContractNumber { get; init; }
}
