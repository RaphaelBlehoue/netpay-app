using Affectations.Domain.AggregatesRoots.RuleAggregate;

namespace Affectations.Domain.Models;

public class FilterRuleModel
{
    public ICollection<long> Ids { get; private set; }
    public RuleDetails? RuleDetails { get; private set; }
    public CriteriaModel? Criteres { get; private set; }
    public Affectation? Affectation { get; private set; }
    public Conditions? Conditions { get; private set; }

    public FilterRuleModel(
        ICollection<long> ids,
        RuleDetails ruleDetails,
        CriteriaModel criteres,
        Affectation affectation,
        Conditions conditions
    )
    {
        Ids = ids;
        RuleDetails = ruleDetails;
        Criteres = criteres;
        Affectation = affectation;
        Conditions = conditions;
    }

    public FilterRuleModel() { }
}
