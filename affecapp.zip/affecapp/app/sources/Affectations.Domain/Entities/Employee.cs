namespace Affectations.Domain.Entities;

public class Employee
{
    public string Id { get; set; } = null!;
    public string? LastName { get; set; }
    public string? FirstName { get; set; }
}
