namespace Affectations.Domain.Entities;

public class RuleCriterionCategory
{
    public required string Code { get; set; }

    public string? Label { get; set; }

    public IEnumerable<RuleCriterion>? RuleCriteria { get; set; }
}
