namespace Affectations.Domain.Entities;

public class Team
{
    public required string Code { get; init; }
    public string Name { get; init; }
    public string RegionCode { get; init; }
}
