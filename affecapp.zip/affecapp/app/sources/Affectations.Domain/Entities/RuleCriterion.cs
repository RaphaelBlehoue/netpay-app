namespace Affectations.Domain.Entities;

public class RuleCriterion
{
    public string? Code { get; set; }

    public string? Label { get; set; }
}
