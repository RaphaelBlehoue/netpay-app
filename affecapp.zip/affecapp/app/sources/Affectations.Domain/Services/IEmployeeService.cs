using Affectations.Domain.Entities;
using Affectations.Domain.Models;
using Affectations.Domain.Specifications;

namespace Affectations.Domain.Services;

public interface IEmployeeService
{
    Task<PagedData<Employee>> SearchEmployeesAsync(ISpecification specification);
}
