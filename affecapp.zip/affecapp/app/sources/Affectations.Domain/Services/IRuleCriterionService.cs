using Affectations.Domain.Entities;
using Affectations.Domain.Models;
using Affectations.Domain.Specifications;

namespace Affectations.Domain.Services;

public interface IRuleCriterionService
{
    Task<PagedData<RuleCriterion>> SearchRuleCriteriaAsync(ISpecification specification);
}
