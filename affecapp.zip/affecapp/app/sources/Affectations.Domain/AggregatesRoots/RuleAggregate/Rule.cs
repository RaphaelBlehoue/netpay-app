namespace Affectations.Domain.AggregatesRoots.RuleAggregate;

public class Rule
{
    public long Id { get; private set; }
    public RuleDetails? RuleDetails { get; private set; }
    public Criteria? Criteres { get; private set; }
    public Affectation? Affectation { get; private set; }
    public Conditions? Conditions { get; private set; }

    public Rule(long id, RuleDetails ruleDetails, Criteria criteres, Affectation affectation, Conditions conditions)
    {
        Id = id;
        RuleDetails = ruleDetails;
        Criteres = criteres;
        Affectation = affectation;
        Conditions = conditions;
    }

    public Rule() { }
}
