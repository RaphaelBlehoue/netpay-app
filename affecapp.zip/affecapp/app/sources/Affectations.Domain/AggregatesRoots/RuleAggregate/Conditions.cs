namespace Affectations.Domain.AggregatesRoots.RuleAggregate;

public record Conditions
{
    public string? ContractNumberCondition { get; init; }
    public string? AccountManagerCondition { get; init; }
    public string? ClientNumberCondition { get; init; }
    public string? NafCodeCondition { get; init; }
    public string? SyndicCodeCondition { get; init; }
    public string? ClauseCondition { get; init; }
    public string? PortfolioCondition { get; init; }
    public string? IntermediateNameCondition { get; init; }
    public string? UVCodeCondition { get; init; }
    public string? CophtCondition { get; init; }
    public string? DepartmentCondition { get; init; }
    public string? NetworkCondition { get; init; }
    public string? RegionCondition { get; init; }
    public string? BranchCondition { get; init; }
    public string? SegmentationCondition { get; init; }
    public string? TurnoverCondition { get; init; }
    public string? ContractCategoryCondition { get; init; }
}
