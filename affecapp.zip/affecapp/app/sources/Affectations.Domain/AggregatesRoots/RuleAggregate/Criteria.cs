namespace Affectations.Domain.AggregatesRoots.RuleAggregate;

public class Criteria
{
    public long RuleId { get; set; }
    public ICollection<string>? Segmentation { get; set; }
    public ICollection<string>? DistributorRegion { get; set; }
    public ICollection<string>? Network { get; set; }
    public ICollection<string>? Branch { get; set; }
    public ICollection<string>? Copht { get; set; }
    public ICollection<string>? DistributorDepartment { get; set; }
    public ICollection<string>? ContractCategory { get; set; }
    public ICollection<string>? UVCode { get; set; }
    public ICollection<string>? IntermediateName { get; set; }
    public ICollection<string>? PortfolioCode { get; set; }
    public ICollection<string>? Clause { get; set; }
    public ICollection<string>? SyndicCode { get; set; }
    public ICollection<string>? NafCode { get; set; }
    public ICollection<string>? ClientNumber { get; set; }
    public ICollection<string>? AccountManager { get; set; }
    public ICollection<string>? ContractNumber { get; set; }
}
