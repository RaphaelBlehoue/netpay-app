using System.Runtime.Serialization;

namespace Affectations.Domain.Exceptions;

public class TeamException : Exception
{
    public TeamException()
        : base("La récupération de données des équipes est en erreur!") { }

    public TeamException(string message)
        : base(message) { }

    public TeamException(string message, Exception innerException)
        : base(message, innerException) { }

    protected TeamException(SerializationInfo info, StreamingContext context)
        : base(info, context) { }
}
