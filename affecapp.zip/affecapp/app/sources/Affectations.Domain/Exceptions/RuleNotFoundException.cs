using System.Runtime.Serialization;

namespace Affectations.Domain.Exceptions;

[Serializable]
public class RuleNotFoundException : Exception
{
    public int HttpStatusCode { get; set; }

    public RuleNotFoundException()
        : base("La règle est introuvable!") { }

    public RuleNotFoundException(string message)
        : base("La règle est introuvable!") { }

    public RuleNotFoundException(string message, Exception innerException)
        : base(message, innerException) { }

    protected RuleNotFoundException(SerializationInfo info, StreamingContext context)
        : base(info, context) { }

    public RuleNotFoundException(long id)
        : base($"La règle {id} est introuvable!") { }

    public RuleNotFoundException(long id, int httpStatusCode)
        : base($"La règle {id} est introuvable!")
    {
        HttpStatusCode = httpStatusCode;
    }
}
