using System.Runtime.Serialization;

namespace Affectations.Domain.Exceptions;

[Serializable]
public class EmployeeException : Exception
{
    public EmployeeException()
        : base("La récupération de données des employés est en erreur!") { }

    public EmployeeException(string message)
        : base(message) { }

    public EmployeeException(string message, Exception innerException)
        : base(message, innerException) { }

    protected EmployeeException(SerializationInfo info, StreamingContext context)
        : base(info, context) { }
}
