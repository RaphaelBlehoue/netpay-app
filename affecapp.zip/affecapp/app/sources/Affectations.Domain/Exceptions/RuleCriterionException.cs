using System.Runtime.Serialization;

namespace Affectations.Domain.Exceptions;

[Serializable]
public class RuleCriterionException : Exception
{
    public RuleCriterionException()
        : base("La récupération des référentiels est en erreur!") { }

    public RuleCriterionException(string message)
        : base(message) { }

    public RuleCriterionException(string message, Exception innerException)
        : base(message, innerException) { }

    protected RuleCriterionException(SerializationInfo info, StreamingContext context)
        : base(info, context) { }
}
