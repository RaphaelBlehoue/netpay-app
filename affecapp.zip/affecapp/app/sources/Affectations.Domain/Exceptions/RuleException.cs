using System.Runtime.Serialization;

namespace Affectations.Domain.Exceptions;

[Serializable]
public class RuleException : Exception
{
    public RuleException()
        : base("La récupération de la règle est en erreur!") { }

    public RuleException(string message)
        : base(message) { }

    public RuleException(string message, Exception innerException)
        : base(message, innerException) { }

    protected RuleException(SerializationInfo info, StreamingContext context)
        : base(info, context) { }
}
