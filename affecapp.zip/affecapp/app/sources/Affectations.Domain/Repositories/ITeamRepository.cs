using Affectations.Domain.Entities;

namespace Affectations.Domain.Repositories;

public interface ITeamRepository
{
    Task<Team[]> GetTeamsAsync();
}
