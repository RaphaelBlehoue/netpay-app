using Affectations.Domain.Entities;

namespace Affectations.Domain.Repositories;

public interface IRuleCriterionRepository
{
    Task<RuleCriterionCategory[]> GetRuleCriteriaAsync(int rowCountPerCriterion);
    Task<string[]> GetRuleCriteriaByCategorieCode(string code);
}
