using Affectations.Domain.AggregatesRoots.RuleAggregate;
using Affectations.Domain.Models;

namespace Affectations.Domain.Repositories;

public interface IRuleRepository
{
    Task<Rule> GetRuleByIdAsync(long id);
    Task<Rule> AddRuleAsync(Rule rule);
    Task<Rule> UpdateRuleAsync(Rule rule);
    Task<PagedData<Rule>> SearchRulesAsync(int page, int size, FilterRuleModel rule);
    Task<int> UpdateRulesAsync(RuleMassUpdate ruleMassUpdate);
    Task<ICollection<Rule>> ExportRules(FilterRuleModel rule);
}
