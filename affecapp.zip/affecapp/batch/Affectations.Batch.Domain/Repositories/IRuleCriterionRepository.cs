using Affectations.Batch.Domain.Models;

namespace Affectations.Batch.Domain.Repositories;

public interface IRuleCriterionRepository
{
    Task InsertManyRuleCriteriaAsync(IEnumerable<RuleCriterion> ruleCriteria, CancellationToken cancellationToken);
}
