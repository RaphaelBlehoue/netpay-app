namespace Affectations.Batch.Domain.Constants;

public static class RuleCriterionCategoryConstants
{
    public static readonly string UVCode = "UVCODE";
    public static readonly string IntermediaryName = "INTERMEDIARY_NAME";
}
