namespace Affectations.Batch.Domain.Models;

public class RuleCriterion
{
    public required string Code { get; set; }
    public string? Label { get; set; }
    public required string CategoryCode { get; set; }
}
