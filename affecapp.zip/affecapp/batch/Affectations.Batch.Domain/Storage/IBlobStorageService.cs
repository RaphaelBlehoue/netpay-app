namespace Affectations.Batch.Domain.Storage;

public interface IBlobStorageService
{
    Task<Stream> RetrieveFileAsync(string containerName);
}
