﻿# Samples

## Overview

This folder contains csv file samples for uvcode and distributor imports meant to be used in a development environment.

Warning: These samples are not intended to be used in a production environment.

## Prerequisites for Development Environment
Since the batch reads a csv file from a given blob storage, a local storage emulator needs to be used. For development purposes, Azurite is being used.

### To configure Azurite
Install Docker

Connect to Azure Container Registry (ACR)

Run the `~/docker-compose.yml` to create the Azurite container inside Docker

### To add a new sample file
Install Microsoft Azure Storage Explorer

Configure Azure Storage Explorer to map to your local storage emulator

#### Upload Uvcode sample file
Create a blob storage container named "import-codeuv"

Upload uvcode sample file into the created blob storage container

#### Upload Distributor sample file
Create a blob storage container named "import-distributor"

Upload distributor sample file into the created blob storage container

## Usage
Run the program from the IDE in debug mode using your local storage emulator to mimick Azure Storage Account locally.

Make sure your database connection string is correct.

## File Format

### Uvcode file format
CSV comma-delimited

Following 3 columns are expected in given order: codeuv, libelle and perimetre

Here is an example of a `uvcode_sample.csv` file:

```csv
codeuv;libelle;perimetre
bcd;test label 2;E
xyz;test label 3;E
```

### Distributor file format
CSV comma-delimited

Here is an example of a `distributor_sample.csv` file:

```csv
distributorCode;department;distributorScore;distributorName;distributorNetwork;distributorClassification;contractCount;potentialContributionHT;regionId
0000000111;92;3;Intermediary2;NETWORK1;CLA;5130;51.48;64
```