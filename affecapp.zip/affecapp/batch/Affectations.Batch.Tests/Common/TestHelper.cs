﻿using Affectations.Batch.Infrastructure.Data.Models;

namespace Affectations.Batch.Tests.Common;

internal static class TestHelper
{
    public static bool AreEquivalent(TRuleCriterion? expectedRuleCriterion, TRuleCriterion? actualRuleCriterion)
    {
        if (expectedRuleCriterion is null || actualRuleCriterion is null)
        {
            return expectedRuleCriterion is null && actualRuleCriterion is null;
        }

        return expectedRuleCriterion.Code == actualRuleCriterion.Code
            && expectedRuleCriterion.Label == actualRuleCriterion.Label
            && expectedRuleCriterion.RuleCriterionCategoryCode == actualRuleCriterion.RuleCriterionCategoryCode;
    }
}
