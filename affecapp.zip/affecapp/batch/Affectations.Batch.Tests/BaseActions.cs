using Affectations.Batch.Domain.Storage;
using Affectations.Batch.Infrastructure.Configuration;
using Affectations.Batch.Infrastructure.Data.Models;
using Affectations.Batch.Infrastructure.Repositories;
using Affectations.Batch.Services;
using Microsoft.Extensions.Options;
using TechTalk.SpecFlow;

namespace Affectations.Batch.Tests;

internal class BaseActions
{
    protected const string BlobUvCodeContainerName = "import-codeuv";
    protected const string BlobDistributorContainerName = "import-distributor";

    protected readonly ScenarioContext _scenarioContext;
    protected readonly AffectationsContext _affectationContext;

    protected readonly Mock<ILogger<Worker>> _workerLogger;
    protected readonly Mock<ILogger<RuleCriterionRepository>> _ruleCriterionRepositoryLogger;
    protected readonly Mock<ILogger<CsvParser>> _csvParserlogger;
    protected readonly Mock<ILogger<BatchService>> _batchServiceLogger;
    protected readonly Mock<IOptions<BlobStorageOptions>> _blobStorageOptions;
    protected readonly Mock<IBlobStorageService> _blobStorageService;

    public BaseActions(ScenarioContext scenarioContext)
    {
        _scenarioContext = scenarioContext;
        _affectationContext = InMemoryDatabase.Initialize();

        _workerLogger = new Mock<ILogger<Worker>>();
        _ruleCriterionRepositoryLogger = new Mock<ILogger<RuleCriterionRepository>>();
        _csvParserlogger = new Mock<ILogger<CsvParser>>();
        _batchServiceLogger = new Mock<ILogger<BatchService>>();
        _blobStorageService = new Mock<IBlobStorageService>();
        _blobStorageOptions = new Mock<IOptions<BlobStorageOptions>>();
        _blobStorageOptions
            .Setup(x => x.Value)
            .Returns(
                new BlobStorageOptions()
                {
                    ConnectionString =
                        "DefaultEndpointsProtocol=http;AccountName=localblobstorage;AccountKey=LaBonneClef/Tr0pS3cure==;BlobEndpoint=http://blobstorage:10000/localblobstorage",
                    ContainerNameUvcode = BlobUvCodeContainerName,
                    ContainerNameDistributor = BlobDistributorContainerName
                }
            );
    }
}
