using Affectations.Batch.Domain.Constants;
using Affectations.Batch.Domain.Models;
using Affectations.Batch.Infrastructure.Data.Models;
using Affectations.Batch.Infrastructure.Repositories;
using Microsoft.EntityFrameworkCore;

namespace Affectations.Batch.Tests.Repositories;

public class RuleCriterionRepository_InsertManyRuleCriteriaAsyncShould
{
    private readonly AffectationsContext _affectationContext;
    private readonly Mock<ILogger<RuleCriterionRepository>> _Logger;

    public RuleCriterionRepository_InsertManyRuleCriteriaAsyncShould()
    {
        _affectationContext = InMemoryDatabase.Initialize();
        _Logger = new Mock<ILogger<RuleCriterionRepository>>();
    }

    [Fact]
    public async Task InsertRuleCriteria_WhenNotExist()
    {
        var ruleCriterionRepository = new RuleCriterionRepository(_affectationContext, _Logger.Object);
        var expectedRuleCriterion1 = new RuleCriterion()
        {
            Code = "bcd",
            Label = "test label 2",
            CategoryCode = RuleCriterionCategoryConstants.UVCode
        };
        var expectedRuleCriterion2 = new RuleCriterion()
        {
            Code = "0000000002",
            Label = "Intermediary2",
            CategoryCode = RuleCriterionCategoryConstants.IntermediaryName
        };
        var uvCodes = new List<RuleCriterion>() { expectedRuleCriterion1, expectedRuleCriterion2 };
        var source = new CancellationTokenSource();
        var token = source.Token;

        var initialCount = await _affectationContext.TRuleCriteria.CountAsync();
        var expectedCount = initialCount + uvCodes.Count;
        await ruleCriterionRepository.InsertManyRuleCriteriaAsync(uvCodes, token);
        var actualCount = await _affectationContext.TRuleCriteria.CountAsync();
        var actualRuleCriterion1 = await _affectationContext.TRuleCriteria.FirstOrDefaultAsync(x =>
            x.Code == expectedRuleCriterion1.Code
        );
        var actualRuleCriterion2 = await _affectationContext.TRuleCriteria.FirstOrDefaultAsync(x =>
            x.Code == expectedRuleCriterion2.Code
        );

        Assert.Equal(expectedCount, actualCount);
        Assert.Equal(expectedRuleCriterion1.Code, actualRuleCriterion1?.Code);
        Assert.Equal(expectedRuleCriterion1.Label, actualRuleCriterion1?.Label);
        Assert.Equal(expectedRuleCriterion2.Code, actualRuleCriterion2?.Code);
        Assert.Equal(expectedRuleCriterion2.Label, actualRuleCriterion2?.Label);
    }

    [Fact]
    public async Task NotInsertRuleCriteria_WhenAlreadyExist()
    {
        var ruleCriterionRepository = new RuleCriterionRepository(_affectationContext, _Logger.Object);
        var ruleCriteria = new List<RuleCriterion>()
        {
            new()
            {
                Code = "abc",
                Label = "test label 1",
                CategoryCode = RuleCriterionCategoryConstants.UVCode
            },
            new()
            {
                Code = "0000000001",
                Label = "Intermediary1",
                CategoryCode = RuleCriterionCategoryConstants.IntermediaryName
            }
        };
        var source = new CancellationTokenSource();
        var token = source.Token;

        var expectedCount = await _affectationContext.TRuleCriteria.CountAsync();

        var ex = await Assert.ThrowsAsync<InvalidOperationException>(
            () => ruleCriterionRepository.InsertManyRuleCriteriaAsync(ruleCriteria, token)
        );
        var actualCount = await _affectationContext.TRuleCriteria.CountAsync();

        Assert.IsType<InvalidOperationException>(ex);
        Assert.Equal(expectedCount, actualCount);
    }
}
