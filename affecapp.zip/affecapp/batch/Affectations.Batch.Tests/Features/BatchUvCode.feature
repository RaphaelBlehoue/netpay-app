﻿
@integration
Feature: Ajout CodeUv

En tant qu'utilisateur, je veux exécuter le batch CodeUv afin de mettre à jour le référentiel CodeUv dans EASY Affectation

Rule: Si un codeuv associé à la catégorie "sans vie" n'existe pas dans le référentiel CodeUv, ceci va être ajouté dans le référentiel CodeUv

    Scenario: Ajout CodeUv valide associé à la catégorie "sans vie"
        Given Le blob storage codeuv contient "Samples/uvcode_sample.csv"
        When Le batch CodeUv s'exécute
        Then Le référentiel CodeUv contient les CodeUvs suivants:
        | Code | Label        | RuleCriterionCategoryCode |
        | abc  | test label 1 | UVCODE                    |
        | bcd  | test label 2 | UVCODE                    |
        | xyz  | test label 3 | UVCODE                    |

    Scenario: Ajout CodeUv invalide associé à la catégorie "vie"
        Given Le blob storage codeuv contient "Samples/uvcode_sample_vie.csv"
        When Le batch CodeUv s'exécute
        Then Le référentiel CodeUv contient les CodeUvs suivants:
        | Code | Label        | RuleCriterionCategoryCode |
        | abc  | test label 1 | UVCODE                    |
