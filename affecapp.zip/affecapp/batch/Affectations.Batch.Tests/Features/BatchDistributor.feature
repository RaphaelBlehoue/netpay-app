﻿@integration
Feature: Ajout Nom Intermédiaire

En tant qu'utilisateur, je veux exécuter le batch Nom Intermédiaire afin de mettre à jour le référentiel Nom Intermédiaire dans EASY Affectation

Rule: Si un nom intermédiaire n'existe pas dans le référentiel Nom Intermédiaire, ceci va être ajouté dans le référentiel Nom Intermédiaire

    Scenario: Ajout Nom Intermédiaire valide
        Given Le blob storage contient "Samples/distributor_sample.csv"
        When Le batch Nom Intermédiaire s'exécute
        Then Le référentiel Nom Intermédiaire contient les données suivantes:
        | Code        | Label         | RuleCriterionCategoryCode |
        | 0000000001  | Intermediary1 | INTERMEDIARY_NAME         |
        | 0000000111  | Intermediary2 | INTERMEDIARY_NAME         |
