using System.Text;
using Affectations.Batch.Domain.Constants;
using Affectations.Batch.Enums;
using Affectations.Batch.Infrastructure.Data.Models;
using Affectations.Batch.Infrastructure.Repositories;
using Affectations.Batch.Services;
using Affectations.Batch.Tests.Common;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace Affectations.Batch.Tests.Features;

[Binding]
[Scope(Feature = "Ajout Nom Intermédiaire")]
internal sealed class BatchDistributorSteps : BaseActions
{
    private const string ResultInitialCount = nameof(ResultInitialCount);
    private const string ResultNewCount = nameof(ResultNewCount);

    public BatchDistributorSteps(ScenarioContext scenarioContext)
        : base(scenarioContext) { }

    [Given(@"Le blob storage contient ""(.*)""")]
    public void GivenLeBlobStorageContient(string csvFilePath)
    {
        var csvContent = File.ReadAllText(csvFilePath);
        _blobStorageService
            .Setup(x => x.RetrieveFileAsync(BlobDistributorContainerName))
            .Returns(Task.FromResult<Stream>(new MemoryStream(Encoding.UTF8.GetBytes(csvContent))));
    }

    [When(@"Le batch Nom Intermédiaire s'exécute")]
    public async Task WhenLeBatchNomIntermediaireSexecuteAsync()
    {
        var cancellationTokenSource = new CancellationTokenSource();
        var csvParser = new CsvParser(_blobStorageService.Object, _csvParserlogger.Object, _blobStorageOptions.Object);
        var ruleCriterionRepository = new RuleCriterionRepository(
            _affectationContext,
            _ruleCriterionRepositoryLogger.Object
        );
        var batchService = new BatchService(csvParser, _batchServiceLogger.Object, ruleCriterionRepository);
        var worker = new Worker(batchService, _workerLogger.Object, BatchNameEnum.DistributorBatch);
        await worker.StartAsync(cancellationTokenSource.Token);
    }

    [Then(@"Le référentiel Nom Intermédiaire contient les données suivantes:")]
    public void ThenLeReferentielNomIntermediaireContientLesDonneesSuivantes(Table table)
    {
        var expectedRuleCriteria = table.CreateSet<TRuleCriterion>().ToArray();
        var actualRuleCriteria = _affectationContext
            .TRuleCriteria.Where(x => x.RuleCriterionCategoryCode == RuleCriterionCategoryConstants.IntermediaryName)
            .OrderBy(x => x.Code)
            .ToArray();

        Assert.Equal(expectedRuleCriteria.Length, actualRuleCriteria.Length);
        for (var i = 0; i < expectedRuleCriteria.Length; i++)
        {
            Assert.True(TestHelper.AreEquivalent(expectedRuleCriteria[i], actualRuleCriteria[i]));
        }
    }
}
