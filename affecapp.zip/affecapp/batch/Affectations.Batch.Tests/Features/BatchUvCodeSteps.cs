using System.Text;
using Affectations.Batch.Domain.Constants;
using Affectations.Batch.Enums;
using Affectations.Batch.Infrastructure.Data.Models;
using Affectations.Batch.Infrastructure.Repositories;
using Affectations.Batch.Services;
using Affectations.Batch.Tests.Common;
using TechTalk.SpecFlow;
using TechTalk.SpecFlow.Assist;

namespace Affectations.Batch.Tests.Features;

[Binding]
[Scope(Feature = "Ajout CodeUv")]
internal sealed class BatchUvCodeSteps : BaseActions
{
    private const string ResultInitialCount = nameof(ResultInitialCount);
    private const string ResultNewCount = nameof(ResultNewCount);

    public BatchUvCodeSteps(ScenarioContext scenarioContext)
        : base(scenarioContext) { }

    [Given(@"Le blob storage codeuv contient ""(.*)""")]
    public void GivenLeBlobStorageContient(string csvFilePath)
    {
        var csvContent = File.ReadAllText(csvFilePath);
        _blobStorageService
            .Setup(x => x.RetrieveFileAsync(BlobUvCodeContainerName))
            .Returns(Task.FromResult<Stream>(new MemoryStream(Encoding.UTF8.GetBytes(csvContent))));
    }

    [When(@"Le batch CodeUv s'exécute")]
    public async Task WhenLeBatchCodeUvSexecuteAsync()
    {
        var cancellationTokenSource = new CancellationTokenSource();
        var csvParser = new CsvParser(_blobStorageService.Object, _csvParserlogger.Object, _blobStorageOptions.Object);
        var ruleCriterionRepository = new RuleCriterionRepository(
            _affectationContext,
            _ruleCriterionRepositoryLogger.Object
        );
        var batchService = new BatchService(csvParser, _batchServiceLogger.Object, ruleCriterionRepository);
        var worker = new Worker(batchService, _workerLogger.Object, BatchNameEnum.UvcodeBatch);
        await worker.StartAsync(cancellationTokenSource.Token);
    }

    [Then(@"Le référentiel CodeUv contient les CodeUvs suivants:")]
    public void ThenLeReferentielCodeUvContientLesCodeUvsSuivants(Table table)
    {
        var expectedRuleCriteria = table.CreateSet<TRuleCriterion>().ToArray();
        var actualRuleCriteria = _affectationContext
            .TRuleCriteria.Where(x => x.RuleCriterionCategoryCode == RuleCriterionCategoryConstants.UVCode)
            .OrderBy(x => x.Code)
            .ToArray();

        Assert.Equal(expectedRuleCriteria.Length, actualRuleCriteria.Length);
        for (var i = 0; i < expectedRuleCriteria.Length; i++)
        {
            Assert.True(TestHelper.AreEquivalent(expectedRuleCriteria[i], actualRuleCriteria[i]));
        }
    }
}
