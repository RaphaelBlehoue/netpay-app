global using Affectations.Batch.Tests.Hooks;
global using Microsoft.Extensions.Logging;
global using Moq;
global using Xunit;
