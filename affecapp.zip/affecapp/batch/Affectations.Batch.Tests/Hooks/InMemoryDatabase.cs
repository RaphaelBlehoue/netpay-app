using Affectations.Batch.Domain.Constants;
using Affectations.Batch.Infrastructure.Data.Models;
using Microsoft.EntityFrameworkCore;

namespace Affectations.Batch.Tests.Hooks;

public static class InMemoryDatabase
{
    public static AffectationsContext Initialize()
    {
        var options = new DbContextOptionsBuilder<AffectationsContext>()
            .UseInMemoryDatabase(databaseName: $"MyInMemoryDb_{Guid.NewGuid()}")
            .Options;

        var affectationsContext = new AffectationsContext(options);

        affectationsContext.TRuleCriterionCategories.Add(
            new TRuleCriterionCategory { Code = RuleCriterionCategoryConstants.UVCode, Label = "Code UV" }
        );
        affectationsContext.TRuleCriterionCategories.Add(
            new TRuleCriterionCategory
            {
                Code = RuleCriterionCategoryConstants.IntermediaryName,
                Label = "Nom intermédiaire"
            }
        );

        affectationsContext.TRuleCriteria.Add(
            new TRuleCriterion
            {
                Code = "abc",
                Label = "test label 1",
                RuleCriterionCategoryCode = RuleCriterionCategoryConstants.UVCode
            }
        );
        affectationsContext.TRuleCriteria.Add(
            new TRuleCriterion
            {
                Code = "0000000001",
                Label = "Intermediary1",
                RuleCriterionCategoryCode = RuleCriterionCategoryConstants.IntermediaryName
            }
        );
        affectationsContext.SaveChanges();
        return affectationsContext;
    }
}
