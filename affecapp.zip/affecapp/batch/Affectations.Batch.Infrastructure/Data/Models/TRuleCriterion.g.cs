﻿using System;
using System.Collections.Generic;

namespace Affectations.Batch.Infrastructure.Data.Models;

public partial class TRuleCriterion
{
    public string Code { get; set; } = null!;

    public string? Label { get; set; }

    public string RuleCriterionCategoryCode { get; set; } = null!;

    public virtual TRuleCriterionCategory RuleCriterionCategoryCodeNavigation { get; set; } = null!;
}
