﻿using System;
using System.Collections.Generic;

namespace Affectations.Batch.Infrastructure.Data.Models;

public partial class TEmployee
{
    public string Id { get; set; } = null!;

    public string? LastName { get; set; }

    public string? FirstName { get; set; }
}
