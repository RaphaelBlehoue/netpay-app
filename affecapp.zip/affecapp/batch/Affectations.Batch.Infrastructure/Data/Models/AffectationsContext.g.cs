﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Affectations.Batch.Infrastructure.Data.Models;

public partial class AffectationsContext : DbContext
{
    public AffectationsContext(DbContextOptions<AffectationsContext> options)
        : base(options)
    {
    }

    public virtual DbSet<TEmployee> TEmployees { get; set; }

    public virtual DbSet<TRuleCriterion> TRuleCriteria { get; set; }

    public virtual DbSet<TRuleCriterionCategory> TRuleCriterionCategories { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<TEmployee>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_TEmployee");

            entity.ToTable("T_Employee", "sch_affr");

            entity.Property(e => e.Id).HasMaxLength(50);
            entity.Property(e => e.FirstName).HasMaxLength(200);
            entity.Property(e => e.LastName).HasMaxLength(200);
        });

        modelBuilder.Entity<TRuleCriterion>(entity =>
        {
            entity.HasKey(e => e.Code).HasName("PK_TRuleCriterion");

            entity.ToTable("T_RuleCriterion", "sch_affr");

            entity.Property(e => e.Code).HasMaxLength(200);
            entity.Property(e => e.Label).HasMaxLength(200);
            entity.Property(e => e.RuleCriterionCategoryCode).HasMaxLength(200);

            entity.HasOne(d => d.RuleCriterionCategoryCodeNavigation).WithMany(p => p.TRuleCriteria)
                .HasForeignKey(d => d.RuleCriterionCategoryCode)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_TRuleCriterion_TRuleCriterionCategory");
        });

        modelBuilder.Entity<TRuleCriterionCategory>(entity =>
        {
            entity.HasKey(e => e.Code).HasName("PK_TRuleCriterionCategory");

            entity.ToTable("T_RuleCriterionCategory", "sch_affr");

            entity.Property(e => e.Code).HasMaxLength(200);
            entity.Property(e => e.Label).HasMaxLength(200);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
