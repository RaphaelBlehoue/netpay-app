using Affectations.Batch.Domain.Repositories;
using Affectations.Batch.Domain.Storage;
using Affectations.Batch.Infrastructure.Configuration;
using Affectations.Batch.Infrastructure.Data.Models;
using Affectations.Batch.Infrastructure.Repositories;
using Affectations.Batch.Infrastructure.Storage;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Azure;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Affectations.Batch.Infrastructure;

public static class InfrastructureServiceCollection
{
    public static void ConfigureInfrastructureServices(this IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetSection("ConnectionStrings")["affectationsdb"];
        services.AddDbContext<AffectationsContext>(
            options =>
            {
                options.UseSqlServer(connectionString, providerOptions => providerOptions.EnableRetryOnFailure());
                options.UseQueryTrackingBehavior(QueryTrackingBehavior.TrackAll);
            },
            ServiceLifetime.Singleton
        );

        var blobStorageOptions = configuration
            .GetRequiredSection(BlobStorageOptions.ConfigurationKey)
            .Get<BlobStorageOptions>();
        services.AddAzureClients(azureClientsBuilder =>
        {
            azureClientsBuilder.AddBlobServiceClient(blobStorageOptions.ConnectionString);
        });

        services.AddTransient<IRuleCriterionRepository, RuleCriterionRepository>();
        services.AddTransient<IBlobStorageService, BlobStorageService>();
    }
}
