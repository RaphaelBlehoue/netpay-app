using Affectations.Batch.Domain.Models;
using Affectations.Batch.Domain.Repositories;
using Affectations.Batch.Infrastructure.Data.Models;
using Microsoft.Extensions.Logging;

namespace Affectations.Batch.Infrastructure.Repositories;

public class RuleCriterionRepository : IRuleCriterionRepository
{
    private readonly AffectationsContext _affectationsContext;
    private readonly ILogger<RuleCriterionRepository> _logger;

    public RuleCriterionRepository(AffectationsContext affectationsContext, ILogger<RuleCriterionRepository> logger)
    {
        _affectationsContext = affectationsContext;
        _logger = logger;
    }

    public async Task InsertManyRuleCriteriaAsync(
        IEnumerable<RuleCriterion> ruleCriteria,
        CancellationToken cancellationToken
    )
    {
        var newRuleCriterionEntities = ruleCriteria
            .Select(static x => new TRuleCriterion
            {
                Code = x.Code,
                Label = x.Label,
                RuleCriterionCategoryCode = x.CategoryCode
            })
            .ToList();

        _logger.LogInformation(
            "Importing {newRuleCriterionEntities.Count} valid record(s).",
            newRuleCriterionEntities.Count
        );

        await _affectationsContext.TRuleCriteria.AddRangeAsync(newRuleCriterionEntities, cancellationToken);
        await _affectationsContext.SaveChangesAsync(cancellationToken);

        _logger.LogInformation(
            "{newRuleCriterionEntities.Count} valid record(s) imported.",
            newRuleCriterionEntities.Count
        );
    }
}
