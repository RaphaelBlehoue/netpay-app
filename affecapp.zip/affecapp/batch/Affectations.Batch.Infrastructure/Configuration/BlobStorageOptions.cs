namespace Affectations.Batch.Infrastructure.Configuration;

public class BlobStorageOptions
{
    public const string ConfigurationKey = "Storage";

    public required string ConnectionString { get; set; }
    public required string ContainerNameUvcode { get; set; }
    public required string ContainerNameDistributor { get; set; }
}
