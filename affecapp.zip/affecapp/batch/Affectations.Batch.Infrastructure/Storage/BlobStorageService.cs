using System.Globalization;
using Affectations.Batch.Domain.Storage;
using Affectations.Batch.Infrastructure.Configuration;
using Azure.Storage.Blobs;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Affectations.Batch.Infrastructure.Storage;

public partial class BlobStorageService : IBlobStorageService
{
    private const int MaxBlobItems = 10;

    private readonly BlobServiceClient _blobServiceClient;
    private readonly BlobStorageOptions _blobStorageOptions;
    private readonly ILogger<BlobStorageService> _logger;

    public BlobStorageService(
        BlobServiceClient blobServiceClient,
        IOptions<BlobStorageOptions> blobStorageOptions,
        ILogger<BlobStorageService> logger
    )
    {
        _blobServiceClient = blobServiceClient;
        _blobStorageOptions = blobStorageOptions.Value;
        _logger = logger;
    }

    public async Task<Stream> RetrieveFileAsync(string containerName)
    {
        var containerClient = _blobServiceClient.GetBlobContainerClient(containerName);
        if (!await containerClient.ExistsAsync())
        {
            var e = new NotSupportedException($"The container '{containerName}' does not exist!");
            _logger.LogError(e.Message);
            throw e;
        }

        var blobItems = await containerClient
            .GetBlobsAsync()
            .OrderByDescending(b => b.Properties.LastModified)
            .Take(MaxBlobItems)
            .ToArrayAsync();
        LogLastExistingBlobs(blobItems.Length, string.Join(", ", blobItems.Select(b => b.Name)));

        var blobItem = blobItems.FirstOrDefault();
        if (blobItem is null)
        {
            var e = new NotSupportedException($"No blob found in the container '{containerName}'!");
            _logger.LogError(e.Message);
            throw e;
        }

        var createdOnOrModifiedOn = blobItem.Properties.LastModified ?? blobItem.Properties.CreatedOn;
        var lastModified =
            createdOnOrModifiedOn?.ToString("yyyy-MM-ddTHH:mm:ss.fffffffzzz", CultureInfo.InvariantCulture)
            ?? "unknown";
        LogUsingBlob(blobItem.Name, lastModified);

        var blobClient = containerClient.GetBlobClient(blobItem.Name);
        var blobDownloadInfo = await blobClient.DownloadAsync();
        if (blobDownloadInfo.Value.ContentLength == 0)
        {
            var e = new NotSupportedException($"The blob '{blobItem.Name}' is empty!");
            _logger.LogError(e.Message);
            throw e;
        }

        LogDownloadedBlob(blobItem.Name, blobDownloadInfo.Value.ContentLength);
        return blobDownloadInfo.Value.Content;
    }

    [LoggerMessage(
        EventId = 30,
        Level = LogLevel.Information,
        Message = "Using input file from blob: {name}\nLast modified: {lastModified}"
    )]
    public partial void LogUsingBlob(string name, string lastModified);

    [LoggerMessage(EventId = 31, Level = LogLevel.Information, Message = "Downloaded blob {name} (size: {size}o)")]
    public partial void LogDownloadedBlob(string name, long size);

    [LoggerMessage(
        EventId = 32,
        Level = LogLevel.Information,
        Message = "Last {count} existing blobs: {commaSeparatedBlobNames}"
    )]
    public partial void LogLastExistingBlobs(int count, string commaSeparatedBlobNames);
}
