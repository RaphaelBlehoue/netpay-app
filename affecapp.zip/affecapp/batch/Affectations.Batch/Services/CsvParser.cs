using System.Globalization;
using Affectations.Batch.Constants;
using Affectations.Batch.Domain.Constants;
using Affectations.Batch.Domain.Models;
using Affectations.Batch.Domain.Storage;
using Affectations.Batch.Enums;
using Affectations.Batch.Infrastructure.Configuration;
using Affectations.Batch.Models;
using CsvHelper;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Affectations.Batch.Services;

public class CsvParser : ICsvParser
{
    private static readonly CultureInfo FrenchCulture = new("fr-FR");

    private readonly IBlobStorageService _blobStorageService;
    private readonly ILogger<CsvParser> _logger;
    private readonly BlobStorageOptions _blobStorageOptions;

    public CsvParser(
        IBlobStorageService blobStorageService,
        ILogger<CsvParser> logger,
        IOptions<BlobStorageOptions> blobStorageOptions
    )
    {
        _blobStorageService = blobStorageService;
        _logger = logger;
        _blobStorageOptions = blobStorageOptions.Value;
    }

    public IEnumerable<RuleCriterion>? ParseFromFile(BatchNameEnum batchName)
    {
        try
        {
            _logger.LogInformation("Begin CSV Parsing.");

            using var file = _blobStorageService.RetrieveFileAsync(GetBlobContainerName(batchName));
            using var reader = new StreamReader(file.Result);
            using var csvReader = new CsvReader(reader, FrenchCulture);
            var ruleCriteria = GetRuleCriteriaFromFile(csvReader, batchName);

            _logger.LogInformation("End CSV Parsing.");

            return ruleCriteria;
        }
        catch (Exception e)
        {
            _logger.LogError("An error has occurred while parsing: {e.Message}.", e.Message);
            return [];
        }
    }

    private string GetBlobContainerName(BatchNameEnum batchName)
    {
        string blobContainerName = string.Empty;

        switch (batchName)
        {
            case BatchNameEnum.UvcodeBatch:
                blobContainerName = _blobStorageOptions.ContainerNameUvcode;
                break;
            case BatchNameEnum.DistributorBatch:
                blobContainerName = _blobStorageOptions.ContainerNameDistributor;
                break;
            default:
                break;
        }

        return blobContainerName;
    }

    private IEnumerable<RuleCriterion>? GetRuleCriteriaFromFile(CsvReader csvReader, BatchNameEnum batchName)
    {
        IEnumerable<RuleCriterion>? ruleCriteria = null;

        switch (batchName)
        {
            case BatchNameEnum.UvcodeBatch:
                csvReader.Context.RegisterClassMap<UvCodeMap>();
                var uvCodes = csvReader
                    .GetRecords<UvCode>()
                    .Where(static x => x?.Perimeter?.ToUpper() != UvCodeConstants.DefaultLifePerimeterCode)
                    .ToArray();

                ruleCriteria = uvCodes
                    .Select(static x => new RuleCriterion
                    {
                        Code = x.Code,
                        Label = x.Label,
                        CategoryCode = RuleCriterionCategoryConstants.UVCode
                    })
                    .ToList();
                break;
            case BatchNameEnum.DistributorBatch:
                csvReader.Context.RegisterClassMap<DistributorMap>();
                var distributors = csvReader.GetRecords<Distributor>().ToArray();
                ruleCriteria = distributors
                    .Select(static x => new RuleCriterion
                    {
                        Code = x.DistributorCode,
                        Label = x.DistributorName,
                        CategoryCode = RuleCriterionCategoryConstants.IntermediaryName
                    })
                    .ToList();
                break;
            default:
                break;
        }

        var numberOfRecords = ruleCriteria?.Count() ?? 0;
        _logger.LogInformation("Csv file has been read. {numberOfRecords} records found.", numberOfRecords);

        return ruleCriteria;
    }
}
