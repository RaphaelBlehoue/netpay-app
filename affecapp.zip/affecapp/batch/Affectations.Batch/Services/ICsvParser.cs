using Affectations.Batch.Domain.Models;
using Affectations.Batch.Enums;

namespace Affectations.Batch.Services;

public interface ICsvParser
{
    IEnumerable<RuleCriterion>? ParseFromFile(BatchNameEnum batchName);
}
