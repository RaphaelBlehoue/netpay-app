using Affectations.Batch.Enums;

namespace Affectations.Batch.Services;

public interface IBatchService
{
    Task ExecuteBatchAsync(BatchNameEnum batchName, CancellationToken cancellationToken);
}
