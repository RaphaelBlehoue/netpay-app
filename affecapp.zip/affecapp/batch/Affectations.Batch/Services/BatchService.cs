using Affectations.Batch.Domain.Models;
using Affectations.Batch.Domain.Repositories;
using Affectations.Batch.Enums;
using Microsoft.Extensions.Logging;

namespace Affectations.Batch.Services;

public class BatchService : IBatchService
{
    private readonly ICsvParser _csvParser;
    private readonly ILogger<BatchService> _logger;
    private readonly IRuleCriterionRepository _ruleCriteriaRepository;

    public BatchService(
        ICsvParser csvParser,
        ILogger<BatchService> logger,
        IRuleCriterionRepository ruleCriteriaRepository
    )
    {
        _csvParser = csvParser;
        _logger = logger;
        _ruleCriteriaRepository = ruleCriteriaRepository;
    }

    public async Task ExecuteBatchAsync(BatchNameEnum batchName, CancellationToken cancellationToken)
    {
        var ruleCriteria = _csvParser.ParseFromFile(batchName);
        await ImportRuleCriteriaAsync(ruleCriteria, cancellationToken);
    }

    private async Task ImportRuleCriteriaAsync(
        IEnumerable<RuleCriterion>? ruleCriteria,
        CancellationToken cancellationToken
    )
    {
        _logger.LogInformation("Begin Import.");
        if (ruleCriteria != null && ruleCriteria.Any())
        {
            await _ruleCriteriaRepository.InsertManyRuleCriteriaAsync(ruleCriteria, cancellationToken);
        }
        else
        {
            _logger.LogInformation("No record found to import!");
        }
        _logger.LogInformation("End Import.");
    }
}
