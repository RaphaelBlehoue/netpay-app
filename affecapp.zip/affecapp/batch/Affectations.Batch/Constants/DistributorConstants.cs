namespace Affectations.Batch.Constants;

public static class DistributorConstants
{
    public static readonly string DefaultDistributorCodeColumnName = "distributorCode";
    public static readonly string DefaultDepartmentColumnName = "department";
    public static readonly string DefaultDistributorScoreColumnName = "distributorScore";
    public static readonly string DefaultDistributorNameColumnName = "distributorName";
    public static readonly string DefaultDistributorNetworkColumnName = "distributorNetwork";
    public static readonly string DefaultDistributorClassificationColumnName = "distributorClassification";
    public static readonly string DefaultContractCountColumnName = "contractCount";
    public static readonly string DefaultPotentialContributionHTColumnName = "potentialContributionHT";
    public static readonly string DefaultRegionIdColumnName = "regionId";
}
