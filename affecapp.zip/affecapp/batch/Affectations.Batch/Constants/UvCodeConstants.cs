namespace Affectations.Batch.Constants;

public static class UvCodeConstants
{
    public static readonly string DefaultUvCodeColumnName = "codeuv";
    public static readonly string DefaultLabelColumnName = "libelle";
    public static readonly string DefaultPerimeterColumnName = "perimetre";
    public static readonly string DefaultLifePerimeterCode = "V";
}
