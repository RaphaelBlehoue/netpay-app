using Affectations.Batch.Services;
using Microsoft.Extensions.DependencyInjection;

namespace Affectations.Batch;

public static class BatchServiceCollection
{
    public static void ConfigureBatchServices(this IServiceCollection services)
    {
        services.AddTransient<ICsvParser, CsvParser>();
        services.AddTransient<IBatchService, BatchService>();
    }
}
