using Affectations.Batch.Enums;
using Affectations.Batch.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace Affectations.Batch;

public class Worker : IHostedService
{
    private readonly IBatchService _batchService;
    private readonly ILogger<Worker> _logger;
    private readonly BatchNameEnum _batchName;

    public Worker(IBatchService batchService, ILogger<Worker> logger, BatchNameEnum batchName)
    {
        _batchService = batchService;
        _logger = logger;
        _batchName = batchName;
    }

    public async Task StartAsync(CancellationToken cancellationToken)
    {
        try
        {
            _logger.LogInformation("Affectations {_batchName} Hosted Service is starting.", _batchName);

            await _batchService.ExecuteBatchAsync(_batchName, cancellationToken);

            _logger.LogInformation("Affectations {_batchName} Hosted Service has completed.", _batchName);
        }
        catch (OperationCanceledException)
        {
            _logger.LogWarning("The operation was cancelled!");
        }
        catch (DbUpdateException e)
        {
            _logger.LogError("An error has occurred {e.Message}", e.Message);
            throw;
        }
    }

    public Task StopAsync(CancellationToken cancellationToken)
    {
        _logger.LogInformation("Worker Hosted Service is stopping...");
        return Task.CompletedTask;
    }
}
