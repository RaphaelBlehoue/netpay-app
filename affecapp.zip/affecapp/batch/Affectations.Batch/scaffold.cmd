@echo off&setlocal

set "originalLocation=%~dp0"

for %%I in ("%~dp0.") do for %%J in ("%%~dpI.") do set "parentFolder=%%~dpnxJ"

echo [INFO] Your current location is '%originalLocation%'.
echo [INFO] Base dir set to '%parentFolder%'.

echo [RM] Cleaning target folder...
del "%parentFolder%\Affectations.Batch.Infrastructure\Data\Models\*.cs"

if %ERRORLEVEL% NEQ 0 (
    echo [RM] Error detected, exiting ^(code: %ERRORLEVEL%^) 1>&2
    exit /b 1
)
echo [RM] Done

echo [SF] Scaffolding using EF Core...
dotnet ef dbcontext scaffold "Name=ConnectionStrings:affectationsdb" Microsoft.EntityFrameworkCore.SqlServer -p "%originalLocation%\Affectations.Batch.csproj" -o "%parentFolder%\Affectations.Batch.Infrastructure\Data\Models"  --namespace "Affectations.Batch.Infrastructure.Data.Models" --no-onconfiguring --no-build --schema "sch_affr" -c AffectationsContext -- --environment Development

if %ERRORLEVEL% NEQ 0 (
	echo [SF] Error detected, exiting ^(code: %ERRORLEVEL%^) 1>&2
	pause
    exit /b 3
)
echo [SF] Done

echo [RN] Renaming output files...
ren "%parentFolder%\Affectations.Batch.Infrastructure\Data\Models\*.cs" "*.g.cs"
if %ERRORLEVEL% NEQ 0 (
    echo [RN] Error detected, exiting ^(code: %ERRORLEVEL%^) 1>&2
    exit /b 5
)
echo [RN] Done

echo [INFO] All done
exit /b 0