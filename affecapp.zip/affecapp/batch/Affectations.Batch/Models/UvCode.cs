namespace Affectations.Batch.Models;

public class UvCode
{
    public required string Code { get; set; }
    public string? Label { get; set; }
    public string? Perimeter { get; set; }
}
