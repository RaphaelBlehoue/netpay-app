using Affectations.Batch.Constants;
using CsvHelper.Configuration;

namespace Affectations.Batch.Models;

public class DistributorMap : ClassMap<Distributor>
{
    public DistributorMap()
    {
        Map(m => m.DistributorCode).Name(DistributorConstants.DefaultDistributorCodeColumnName);
        Map(m => m.Department).Name(DistributorConstants.DefaultDepartmentColumnName);
        Map(m => m.DistributorScore).Name(DistributorConstants.DefaultDistributorScoreColumnName);
        Map(m => m.DistributorName).Name(DistributorConstants.DefaultDistributorNameColumnName);
        Map(m => m.DistributorNetwork).Name(DistributorConstants.DefaultDistributorNetworkColumnName);
        Map(m => m.DistributorClassification).Name(DistributorConstants.DefaultDistributorClassificationColumnName);
        Map(m => m.ContractCount).Name(DistributorConstants.DefaultContractCountColumnName);
        Map(m => m.PotentialContributionHT).Name(DistributorConstants.DefaultPotentialContributionHTColumnName);
        Map(m => m.RegionId).Name(DistributorConstants.DefaultRegionIdColumnName);
    }
}
