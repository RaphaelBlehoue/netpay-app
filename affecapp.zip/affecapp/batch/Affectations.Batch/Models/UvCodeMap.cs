using Affectations.Batch.Constants;
using CsvHelper.Configuration;

namespace Affectations.Batch.Models;

public class UvCodeMap : ClassMap<UvCode>
{
    public UvCodeMap()
    {
        Map(m => m.Code).Name(UvCodeConstants.DefaultUvCodeColumnName);
        Map(m => m.Label).Name(UvCodeConstants.DefaultLabelColumnName);
        Map(m => m.Perimeter).Name(UvCodeConstants.DefaultPerimeterColumnName);
    }
}
