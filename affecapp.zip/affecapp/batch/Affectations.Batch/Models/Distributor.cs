namespace Affectations.Batch.Models;

public class Distributor
{
    public required string DistributorCode { get; set; }
    public string? Department { get; set; }
    public string? DistributorScore { get; set; }
    public string? DistributorName { get; set; }
    public string? DistributorNetwork { get; set; }
    public string? DistributorClassification { get; set; }
    public string? ContractCount { get; set; }
    public string? PotentialContributionHT { get; set; }
    public string? RegionId { get; set; }
}
