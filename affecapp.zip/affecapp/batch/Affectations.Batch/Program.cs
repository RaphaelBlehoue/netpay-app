﻿using Affectations.Batch;
using Affectations.Batch.Domain.Repositories;
using Affectations.Batch.Enums;
using Affectations.Batch.Infrastructure;
using Affectations.Batch.Infrastructure.Configuration;
using Affectations.Batch.Services;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

var hostBuilder = Host.CreateDefaultBuilder(args)
    .ConfigureServices(
        (hostContext, services) =>
        {
            services.Configure<BlobStorageOptions>(
                hostContext.Configuration.GetSection(BlobStorageOptions.ConfigurationKey)
            );
            services.ConfigureBatchServices();
            services.ConfigureInfrastructureServices(hostContext.Configuration);
            services.AddSingleton<IHostedService>(provider =>
            {
                var batchService = provider.GetRequiredService<IBatchService>();
                var logger = provider.GetRequiredService<ILogger<Worker>>();
                return new Worker(batchService, logger, BatchNameEnum.UvcodeBatch);
            });
            services.AddSingleton<IHostedService>(provider =>
            {
                var batchService = provider.GetRequiredService<IBatchService>();
                var logger = provider.GetRequiredService<ILogger<Worker>>();
                var ruleCriterionRepository = provider.GetRequiredService<IRuleCriterionRepository>();
                return new Worker(batchService, logger, BatchNameEnum.DistributorBatch);
            });
        }
    );

await hostBuilder.Build().RunAsync();
