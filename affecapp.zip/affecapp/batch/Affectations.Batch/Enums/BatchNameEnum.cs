namespace Affectations.Batch.Enums;

public enum BatchNameEnum
{
    UvcodeBatch,
    DistributorBatch
}
